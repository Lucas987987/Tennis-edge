# Tennis Edge — Recovery overlay (29 Sep 2026)

Built from the saved 27 Sep snapshot plus the current 29 Sep snapshot.

## Safe-to-restore root files
The append-only/history files in this overlay were restored only where comparison showed the current file was an exact subset of the 27 Sep file, or were merged by exact-line deduplication.

- clv_history.jsonl: 2919 records (current had 1728, all included in old)
- odds_alerts_log.jsonl: 2506 (current 1727, all included in old)
- canal_public_log.jsonl: 351 (current 199, all included in old)
- kalshi_lead_obs.jsonl: 8231 (current 1084, all included in old)
- h13_signal_log.jsonl: 132 (current 14, all included in old)
- resultats_oddspapi.json: 2841 keys (current 1655, all included in old)
- paper_trades_canal.jsonl: union old+current
- paper_trades_match.jsonl: union old+current
- paper_trades_set1.jsonl: union old+current
- canal_clv_detail.csv: union old+current exact rows
- odds_logged_state.json: union of dictionary keys, current values win on collisions

Missing H15/H16/H17/zone signal logs, states and analysis scripts from the 27 Sep snapshot are included.

## Reference only
`recovery_reference/` contains the exact 27 Sep analytical inputs for H16/H16-B/H17/H18. Do not overwrite the current `moves_detail_hist.csv` automatically because its schema changed.

## Not included
Large historical raw partitions (`parts/hist_*`, `parts/live_*`, `parts/pm_ticks_*`, `parts/kx_ticks_*`) are intentionally not included in this small overlay. They remain available in the full 27 Sep snapshot.

H16b/H18 dedicated live signal log/state files are not present in either the 27 Sep snapshot or the current 29 Sep snapshot. The H16-B/H18 analytical population itself is recoverable from the 27 Sep `moves_detail_hist.csv` and the saved recap document.
