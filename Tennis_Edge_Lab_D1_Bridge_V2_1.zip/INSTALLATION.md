# Tennis Edge Lab 2.1 — Audit D1 ↔ GitHub

## Installation sur Codespaces (sur une branche dédiée)

Décompressez ce paquet à la racine de `Tennis-edge`, APRÈS vérification qu'aucun de ces fichiers n'a été modifié localement. Trois fichiers existants sont remplacés :

- `.github/workflows/pages.yml` (déploiement Pages existant conservé, avec capture Worker additionnelle)
- `Tennis_Edge_Lab/app.js` (nouvelle page d'audit)
- `Tennis_Edge_Lab/index.html` (nouvelle entrée de menu)

Un nouveau fichier est créé : `Tennis_Edge_Lab/fetch_worker_snapshot.py`.

La capture se fait pendant GitHub Actions, pas dans le navigateur ; aucune modification ni jeton côté Worker, aucune requête CORS supplémentaire. Si l'API publique ne répond pas, Pages continue et indique « indisponible », sans présenter de vieux chiffres comme à jour.

## Test dans Codespaces

```
python3 Tennis_Edge_Lab/fetch_worker_snapshot.py Tennis_Edge_Lab/worker_hypotheses.json
python3 -m json.tool Tennis_Edge_Lab/worker_hypotheses.json >/dev/null
node --check Tennis_Edge_Lab/app.js
```

Le fichier `worker_hypotheses.json` est temporaire et NE DOIT PAS être commité. Vérifier `git status --short`, utiliser `git add .github/workflows/pages.yml Tennis_Edge_Lab/app.js Tennis_Edge_Lab/index.html Tennis_Edge_Lab/fetch_worker_snapshot.py` (pas `git add -A`). Préparer une PR ; ne pas fusionner sans vérification. Le site principal doit continuer à publier ses anciens fichiers.

## Définitions

Worker D1 : `out_of_sample.n`, `.roi`, `.clv_moyen` depuis `/api/hypotheses`.
Historique GitHub : mouvements `moves_detail_hist.csv` réglés, filtrés selon les critères et la date gelés dans `scripts/validation_report.py` au 12/10/2026.
Telegram : journaux `h*_signal_log.jsonl`, envoyés distincts des déclenchements.

Les différences de n ne prouvent pas une anomalie tant que les définitions, les dates et les versions des fichiers ne coïncident pas. Les règles historiques codées dans l'interface sont datées ; les actualiser si `validation_report.py` change.
