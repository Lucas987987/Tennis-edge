# TENNIS EDGE LAB — V1.0

**Application Web d’analyse tennis, autonome, adaptée aux mobiles.**

## Démarrer immédiatement

- Le fichier **`Tennis_Edge_Lab.html`** fourni séparément est une version autonome : téléchargez-le puis ouvrez-le dans Chrome, Firefox ou un navigateur prenant en charge JavaScript, sur PC ou téléphone. Il inclut les données et n'exige aucun compte ni installation. Sur Android, si un visualiseur de fichiers affiche le code HTML au lieu de l'application, utilisez « Ouvrir avec » puis un navigateur, ou privilégiez l'hébergement GitHub Pages.
- Le dossier **`Tennis_Edge_Lab_V1`** de l’archive ZIP est la version modulaire prévue pour GitHub Pages. Publiez les fichiers `index.html`, `style.css`, `app.js`, `data.js` dans le **même répertoire**.
- L'application fonctionne en consultation **hors ligne** à partir de l'instantané de l'archive du **12 octobre 2026**. Elle n’appelle aucune API externe.

## Ce qui fonctionne dans la V1

1. Explorateur de données : filtres combinables par source, circuit, bookmaker, statut, cote, amplitude, délai avant match, dates et recherche textuelle.
2. Calculs immédiats : ROI à mises unitaires, nombre de paris réglés/non réglés, profit en unités, CLV moyen, proportion de CLV positifs et approximation de l'IC95.
3. Comparaison H13/H15/H16/H16-B/H17/H18 et matrice des intersections par `uid` des signaux envoyés.
4. Analyse CLV × ROI par tranches, évolution hebdomadaire, segmentation circuit et bookmakers.
5. Fiches matchs : détail des observations liées par UID et historique de cotes de Pinnacle si la paire/date correspond.
6. Export des observations filtrées en CSV, vues sauvegardées localement dans le navigateur, thème clair/sombre.
7. Audit de couverture et provenance des données.

**Populations distinctes** : mouvements historiques (1 905), mouvements live (58), canal public simulé (277), paris match simulés (199), signaux H13 (185), H15 (35), H16 (92), H16-B (78), H17 (30), H18 (11), journal CLV (490). **3 360 lignes** affichables, **1 911 courbes** de clôture importées. Certains matchs existent dans plusieurs populations : les additionner est incorrect.

## Actualiser l'application depuis la base Tennis Edge

L'archive initiale n'est PAS nécessaire au fonctionnement de l'application, car les données utiles sont déjà incluses.

Pour réimporter un nouveau ZIP (sur un ordinateur, Python 3.10+) :

```sh
python build_data.py "/chemin/vers/Tennis-edge-main.zip"
```

Cela réécrit `data.js` depuis le ZIP. Les journaux lourds de ticks Polymarket et Kalshi ne sont pas inclus dans cette V1 : le générateur en extrait les sources explicites documentées dans `build_data.py`. Pour générer les données depuis le dépôt cloné sur ordinateur ou dans GitHub Actions :

```sh
python Tennis_Edge_Lab/build_from_repo.py .
```

## Intégrer à GitHub Pages **sans toucher au site actuel**

Le ZIP fournit une version modifiée du workflow existant dans `github-integration/pages.yml` (à **relire avant de remplacer** le fichier `.github/workflows/pages.yml` de votre dépôt). Elle :

- conserve les pages et données du site actuel dans `_site/` ;
- ajoute `Tennis_Edge_Lab/` à la publication ;
- reconstruit `Tennis_Edge_Lab/data.js` à partir des sources présentes dans le dépôt ;
- réutilise le calendrier de publication déjà présent dans votre workflow ;
- ne modifie aucun journal de source ni aucune stratégie.

Sur GitHub depuis un téléphone :

1. Ajoutez dans la branche `main` le **dossier `Tennis_Edge_Lab`** avec `index.html`, `style.css`, `app.js`, `data.js`, `build_data.py` et `build_from_repo.py`. Le dossier doit porter exactement ce nom.
2. Remplacez `.github/workflows/pages.yml` par le contenu **du fichier `github-integration/pages.yml`** inclus dans l’archive (ou fusionnez les ajouts si le workflow actuel a changé depuis le 12 octobre).
3. Dans **Actions**, lancez **Deploy Pages** via `Run workflow` ou déclenchez-le par un commit ; vérifiez le succès du job.
4. Ouvrez l’adresse de votre site GitHub Pages suivie de `/Tennis_Edge_Lab/`.

Si le dépôt Git actuel a évolué, vérifiez les noms de fichiers présents dans le workflow avant de le remplacer. Le déploiement est **fourni mais n'a pas été exécuté sur votre compte**.

## Limites, qualité et règles statistiques

- Le ROI est calculé uniquement sur les tickets dont le règlement existe et sur une mise constante d'une unité ; non réglé n'est **jamais** égal à perdant.
- Certains résultats des hypothèses viennent d'un appariement par identifiant fixture, d'autres d'un rapprochement non ambigu selon noms/date/tournoi. Ils restent **provisoires** et ne prouvent pas une performance réalisée. Sélectionnez « Appariements directs seulement » pour un sous-ensemble plus strict.
- L'IC95 est une approximation normale du profit moyen et **ne corrige pas les dépendances** entre matchs, plusieurs paris sur une rencontre ou les multiples tests.
- Le CLV des sources n'est pas uniformisé avec une méthode de dévigage identique. Le journal CLV seul ne doit pas être interprété comme une source de ROI.
- Pour les hypothèses, l'amplitude est en **points de probabilité** ; pour les mouvements, elle est en **pourcentage de cote**. Ces unités ne doivent pas être agrégées.
- Les variables `*_POSTHOC` n'ont volontairement pas été intégrées comme filtres, pour réduire le risque d'utiliser des informations futures dans une décision passée.
- H16-B recoupe H16 et H18 recoupe H16/H17 ; le chevauchement est affiché.
- V1 est une analyse de **snapshot** : pas de flux temps réel, pas de moteur automatique de recherche de milliers de combinaisons, pas de stockage serveur, pas de compte utilisateur, pas de stratégie envoyée aux bookmakers.
- Pour la prochaine version, ajouter un service de requêtes des courbes intégrales et ticks multi-books sur des partitions Parquet/DuckDB externes ; ne pas charger le dépôt 4,91 Go sur GitHub Pages ou dans la mémoire du téléphone.

## Origine des données de la V1

Le fichier `build_data.py` lit `moves_detail_hist.csv`, `moves_detail.csv`, `paper_trades_canal.jsonl`, `paper_trades_match.jsonl`, `canal_clv_detail.csv`, `h13_signal_log.jsonl`, `h15_signal_log.jsonl`, `h16_signal_log.jsonl`, `h16b_signal_log.jsonl`, `h17_signal_log.jsonl`, `h18_signal_log.jsonl`, `closing_lines.json`, `resultats_oddspapi.json`, `resultats_derived.json`, `pipeline_status.json`, `book_index.json` et `paper_canal_report.json`.

Cette application est un outil de recherche et ne garantit aucun profit financier.
