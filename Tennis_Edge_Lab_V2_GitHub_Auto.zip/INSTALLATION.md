# Tennis Edge Lab V2 — Synchronisation GitHub Pages

## Fonctionnement

Le site principal Tennis Edge reste inchangé. Le workflow `.github/workflows/pages.yml` reconstruit à chaque publication un jeu de données à partir des 17 fichiers sources de la branche `main`. Il publie :

- `/Tennis_Edge_Lab/index.html` : application responsive
- `/Tennis_Edge_Lab/live/data.json` : données normalisées
- `/Tennis_Edge_Lab/live/manifest.json` : date, effectifs, empreinte SHA-256

L'application vérifie automatiquement ce manifeste au chargement, toutes les 5 minutes tant que l'onglet est visible, et sur retour dans l'onglet. Un bouton ↻ permet la vérification manuelle. Les données sont *reconstruites au plus* toutes les 30 minutes via la planification GitHub Actions (horaire non garanti par GitHub), et lors des publications déclenchées par push sur les chemins configurés ou lancement manuel. Les changements des données sources seules n'engendrent **pas** de publication immédiate par push ; ils seront pris en compte au prochain schedule / workflow_dispatch.

Ce système est **une synchronisation de snapshots**, pas un streaming des ticks en temps réel, et n'utilise pas de Worker privé. Pour actualiser depuis Cloudflare R2 en direct, ajouter plus tard un adaptateur API approprié et les contrôles d'accès, sans exposer de secret côté client.

## Installation sur le dépôt existant depuis un smartphone

1. Ouvrir le dépôt GitHub `Lucas987987/Tennis-edge` dans le navigateur ou dans l'application GitHub.
2. Sur une nouvelle branche, ajouter **tout le dossier `Tennis_Edge_Lab`**, avec ses sept fichiers : `index.html`, `style.css`, `app.js`, `data.js`, `data.json`, `manifest.json`, `build_data.py`, `build_from_repo.py`. (Huit fichiers.) Les deux JSON/JS initiaux servent aussi de base de secours ; ils sont régénérés automatiquement en CI.
3. Remplacer `.github/workflows/pages.yml` par le fichier fourni **après relecture** : celui-ci conserve les fichiers publiés par l'ancien site, mais ajoute les sources requises et la publication du Lab.
4. Ouvrir **Actions → Deploy Pages → Run workflow** sur `main` une fois le changement fusionné. Vérifier le journal `Jeu vérifié` et le déploiement réussi.
5. Ouvrir https://lucas987987.github.io/Tennis-edge/Tennis_Edge_Lab/ et contrôler la pastille `● DONNÉES AUTO`, la date et le nombre d'observations.

**Alternative sans modifier main immédiatement :** créer une branche et une pull request, vérifier ses changements puis fusionner après validation. Ne pas installer un second workflow de déploiement : remplacer/adapter l'existant.

## Contrôles

- Dossier de sources : 17 fichiers dans la racine du dépôt ; le script n'essaie pas de télécharger l'archive ZIP, R2 ou des endpoints externes.
- Refuse une base avec moins de 200 observations, moins de 100 mouvements historiques ou moins de 100 courbes.
- Refuse une chute de plus de 40 % du nombre d'observations par rapport au snapshot fourni lorsque `LAB_CHECK_PREVIOUS=1`.
- Le manifeste contient nombre de lignes, nombre de courbes, sources, date de génération et SHA-256 du JSON ; le navigateur vérifie l'empreinte du JSON avant de charger.
- Si la synchronisation échoue, il conserve les dernières données chargées en mémoire ; au premier chargement sans accès réseau, il utilise l'instantané de secours de l'archive du 12 octobre 2026. Une pastille `MODE LOCAL` ne doit jamais être confondue avec des données à jour.

## Limitations

Le fichier `data.js` reste inclus comme secours (~2,8 Mo). La version dynamique transfère aussi ~2,8 Mo de JSON lors des mises à jour, pas 490 Mo. Le site lit les exports Git publiés, et **pas** les partitions géantes de tick. Les données sont donc aussi fraîches que les fichiers présents dans le dépôt et leur publication.

Pour exécuter localement le générateur : `python Tennis_Edge_Lab/build_from_repo.py .`

Cette version ne déploie rien toute seule dans GitHub ; elle fournit des fichiers et un workflow prêts à être vérifiés puis installés. Ne pas publier de données privées, d'identifiants ou de tokens dans le répertoire public.
