# Tennis Edge Lab V2.0

Application Web d'analyse tennis responsive, avec données rafraîchies depuis les exports publiés automatiquement par GitHub Pages.

- Explorateur, filtres combinables, statistiques ROI/CLV, hypothèses, bookmakers, fiches matchs, contrôle qualité et export CSV.
- Source : 17 fichiers courants du dépôt, normalisés à chaque déploiement Pages.
- Synchronisation : manifeste horodaté + contrôle SHA-256 ; rafraîchissement lorsque le site est visible environ toutes les 5 minutes ; workflow Pages planifié toutes les 30 minutes (GitHub Actions peut décaler certains runs).
- Secours : jeux statiques intégrés à la version V2, issus de l'archive du 12 octobre 2026.
- Aucune clé API dans le navigateur ; aucune mise réalisée auprès des bookmakers.

Voir **INSTALLATION.md** pour la procédure détaillée Android/GitHub et les limites.

La synchronisation ne signifie pas que les données sont collectées en temps réel : elle diffuse les dernières sources disponibles sur GitHub. Les analyses continuent à utiliser les mêmes définitions méthodologiques que dans V1.
