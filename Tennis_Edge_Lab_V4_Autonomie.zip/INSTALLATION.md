# Tennis Edge Lab V4 — Installation sûre depuis Codespaces

**Version cumulative** : contient toutes les modifications de l’extension V2.1, V3 et V3.1 non encore installées et la V4. **Dépend de la V2 existante**, déjà présente dans le dépôt. Ne remplace pas Tennis Edge principal, ni ses données brutes, ni ses Workers, ni Telegram.

## Fonctionnement

- **GitHub Pages ~30 min** : continue à publier le site principal, les analyses existantes et le nouveau rapport de validation prospective `live/prospective.json` en lecture seule.
- **GitHub Actions chaque nuit** (planning à 04 h 20 UTC) : répertorie les fichiers de données du dépôt, indexe par flux les partitions bookmaker historiques, Polymarket et Kalshi, construit les agrégats *connus avant le signal*, et indexe l'archive historique de matchs par année.
- **Recherche** : interroge maintenant jusqu'à 1 038 règles pré-définies sur l'archive du 12 octobre (1, 2 ou 3 dimensions), incluant circuit, prix, amplitude causale, délai, bookmaker, ouverture Pinnacle, et quelques indicateurs PM/Kalshi et bookmaker lorsqu'ils sont disponibles avant l'heure de prise. Le total évolue avec les adaptations du catalogue.
- **Gel automatique** : jusqu'à trois nouvelles pistes par tranche de sept jours, seulement lorsqu'elles satisfont les garde-fous historiques, sans les déclarer gagnantes. Chaque gel est stocké dans `Tennis_Edge_Lab/registry/candidates.jsonl` (écrit en ajout seul, chaîné SHA-256 et versionné dans Git). La règle, le scénario et le hash de la source au gel sont conservés.
- **Suivi prospectif** : **le premier jour admissible est le lendemain du gel**, indépendamment de la date de publication du résultat. ROI et IC95 sur nouveaux matchs seulement ; le statut ne devient un « signal prospectif » que si n≥60, 12 jours distincts, IC bootstrap >0 et test nominal corrigé par Holm <0,05. Aucun pari n'est envoyé automatiquement.

### Couverture réelle et limites

**Exploités** : mouvements réglés de `moves_detail_hist.csv`, journaux d'alertes en statistiques descriptives, résultats consolidés/OddsPapi, `closing_lines`, fichiers archives historiques 2010–2026 (résultats et prix de référence), hypothèses gelées et bilan D1. Les partitions de bookmaker, PM et Kalshi seront **indexées lors du premier workflow nocturne**, mais leurs facteurs ne seront admissibles à une découverte que si l'UID, l'orientation et un horodatage antérieur au signal sont disponibles. Toutes les autres sources sont inventoriées sans prétendre qu'elles sont prédictives : certaines ne fournissent pas de lien fiable vers un prix jouable. Le navigateur ne charge jamais les centaines de Mo de ticks.

**Registre :** append-only et détectable en cas de modification d'une ligne, mais **pas absolument immuable** si un administrateur peut réécrire l'intégralité de l'historique Git et recalculer les hashes. Protéger `main` contre les *force-push*, et sauvegarder régulièrement le registre hors du dépôt, ou ajouter ultérieurement un magasin WORM pour une immutabilité forte.

**Risque statistique** : la sélection est rétrospective et ne devient pas un pari rentable prouvé. Les résultats appariés provisoirement ne servent pas à promouvoir les candidats ; seule la comptabilité des mouvements réglés est utilisée pour les tests prospectifs dans cette version. Des colonnes ne sont jamais utilisées pour sélectionner un candidat si elles sont postérieures au moment de pari.

## Installation pas à pas

1. Rouvrir Codespaces et vérifier les modifications non enregistrées, puis partir du dernier `main` :

```bash
git status --short
git switch main
git pull --ff-only origin main
git switch -c feature/tennis-edge-lab-v4
```

2. Télécharger `Tennis_Edge_Lab_V4_Autonomie.zip` sur le téléphone et le téléverser **à la racine du dépôt** dans l'Explorateur VS Code. Extraire uniquement les fichiers du Lab et les deux workflows :

```bash
unzip -o Tennis_Edge_Lab_V4_Autonomie.zip 'Tennis_Edge_Lab/*' '.github/workflows/pages.yml' '.github/workflows/lab_autonomous.yml'
```

3. Tests sans écriture sur le site :

```bash
python3 -m unittest discover -s Tennis_Edge_Lab/tests -v
python3 -m py_compile Tennis_Edge_Lab/*.py
node --check Tennis_Edge_Lab/research.js
node --check Tennis_Edge_Lab/v4.js
python3 Tennis_Edge_Lab/build_from_repo.py .
python3 Tennis_Edge_Lab/autoresearch.py .
python3 Tennis_Edge_Lab/candidate_registry.py verify --root .
python3 Tennis_Edge_Lab/candidate_registry.py evaluate --root .
python3 -m http.server 8765 --directory Tennis_Edge_Lab
```

Ouvrir le port 8765 et la page `research.html`, vérifier les rubriques **Découvertes**, **Pistes gelées automatiquement**, **Sources & archive**, et le site V2 à `index.html`. L'archive longue ne sera disponible qu'après le premier workflow nocturne ; l'absence avant ce run est normale. **Ne pas lancer `candidate_registry.py freeze` à la main dans Codespaces** : le workflow planifié le fera à date réelle, après installation.

4. Dans un second terminal, contrôler et versionner seulement les fichiers ciblés :

```bash
git status --short
git diff --stat
# NE PAS ajouter les ZIP, les gros fichiers bruts ou la sortie temporaire live/.
git add .github/workflows/pages.yml .github/workflows/lab_autonomous.yml \
  Tennis_Edge_Lab/app.js Tennis_Edge_Lab/autoresearch.py \
  Tennis_Edge_Lab/candidate_registry.py Tennis_Edge_Lab/fetch_worker_snapshot.py \
  Tennis_Edge_Lab/historical_archive.py Tennis_Edge_Lab/index.html \
  Tennis_Edge_Lab/research.css Tennis_Edge_Lab/research.html \
  Tennis_Edge_Lab/research.js Tennis_Edge_Lab/source_catalog.py \
  Tennis_Edge_Lab/source_features.py Tennis_Edge_Lab/tests/test_v4.py \
  Tennis_Edge_Lab/v4.js
git diff --cached --check
git diff --cached --stat
git commit -m "Tennis Edge Lab V4: index sources et gels prospectifs"
git push -u origin feature/tennis-edge-lab-v4
```

**Ne pas faire `git add -A`.** Créer la Pull Request sur GitHub vers `main`. Vérifier que seules `.github/workflows/pages.yml`, `.github/workflows/lab_autonomous.yml` et `Tennis_Edge_Lab/` figurent dans les changements ; fusionner après contrôle.

5. Sur GitHub Actions, choisir **Tennis Edge Lab - découverte et gels automatiques** puis **Run workflow** une fois pour lancer l'indexation initiale (risque de consommation de minutes Actions avec les archives volumineuses). Contrôler le statut `success` et les données publiées dans `Tennis_Edge_Lab/cache/*` et le registre. Puis vérifier **Deploy Pages** et `https://lucas987987.github.io/Tennis-edge/Tennis_Edge_Lab/research.html`.

## Sécurité du processus

- Le nouveau workflow n'écrit que `Tennis_Edge_Lab/cache/*` et `Tennis_Edge_Lab/registry/candidates.jsonl`, jamais les fichiers de données historiques, les Workers ou les alertes.
- Chaque fichier source reçoit une empreinte Git indexée pour réduire les relectures futures; une nouvelle partition est automatiquement repérée. Les horodatages futures sont exclus des prédicteurs.
- En cas de conflit Git lors de la publication, le workflow échoue sans écraser le registre, plutôt que de choisir silencieusement une version.
- Les gros fichiers restent sur GitHub; seules les données agrégées et archives par année sont publiées dans Pages.
- La première nuit peut être lourde : le dépôt contient plus de 450 Mo de partitions compressées dans l'archive initiale; le démarrage peut prendre plusieurs minutes.

## Vérifications faites lors du développement

- Test sur données issues de l'archive du 12 octobre : 1 905 mouvements, 1 452 réglés, 1 038 règles examinées, 91 croisements hypothèses × circuits.
- Résultats d'archive indexés sur 17 années (60 817 clés dédupliquées).
- Test limité de 3 partitions (bookmaker, Polymarket, Kalshi) pour l'indexateur. Les autres partitions seront analysées lors du premier run complet : leur bon traitement réel reste à confirmer.
- Registre : idempotence, détection de falsification, absence de look-ahead, tests unitaires Python.
- Test de navigation de la nouvelle interface avec un écran mobile de 390 px.

**Remarque :** ce ZIP n'a PAS encore été installé sur ton GitHub. Ton site et les Workers actuels restent inchangés jusqu'à la fusion explicite de la nouvelle Pull Request.
