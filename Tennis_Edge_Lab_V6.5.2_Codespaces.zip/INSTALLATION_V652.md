# V6.5.2 — diagnostic de compatibilité des alertes
Installation dans une branche dédiée Codespaces. Ajouter seulement les trois fichiers sous `.github/workflows/` et `Tennis_Edge_Lab/`. Fusionner la PR après tests, puis lancer `Tennis Edge Lab V6.5.2 - Compatibility preview` sur main.

**Limite volontaire :** les alertes `odds_alerts_log.jsonl` n'indiquent pas le bookmaker, le marché, la sélection et l'horizon au moment du signal. Les noms de dimensions historiques ne peuvent pas être automatiquement assimilés aux champs d'alertes. Par conséquent cette version ne fabrique **aucun** signal et marque les hypothèses bloquées. L'artifact fournit les dimensions à raccorder pour l'étape suivante.

Le ZIP ne touche ni aux collecteurs, ni aux snapshots V6.4, ni aux registres V6.3. Aucune écriture dans Git pendant le workflow.
