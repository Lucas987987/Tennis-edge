# V6.5.4 — Moteur de correspondance, aperçu sécurisé

Installer depuis Codespaces dans une branche `lab-v654-rule-matcher` puis ouvrir une PR.

**Attention :** aucune donnée réelle de bookmaker n’est automatiquement ingérée dans cette version. Le fichier `observations_v654.jsonl` est vide intentionnellement. Les tests utilisent des observations synthétiques. Le run vert confirme les gardes du moteur, pas un suivi prospectif fonctionnel.

Le moteur exige des preuves explicites (source, bookmaker, marché, sélection, horizon, métriques et dates de mesure antérieures au signal). Il ne certifie aucun pari. Les valeurs `horizon_verified`, `selection_verified`, `market_verified`, `verified_source` ne doivent être émises que par un adaptateur audité, jamais déduites de l'alerte.

La prochaine étape doit connecter un vrai collecteur de snapshots de cotes, avec schéma et preuves vérifiables, puis créer un journal durable et immuable.
