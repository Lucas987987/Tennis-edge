# V6.5.5 — lecture automatisée des sources (mode observation)

Cette version lance un scan toutes les 6 heures et sur demande. Elle ne contacte **aucune API bookmaker**. Elle lit les fichiers présents dans le checkout GitHub et ne fabrique jamais les champs absents. Le workflow ne conserve pas encore les événements entre exécutions : seuls les artifacts (90 jours) sont produits. Les observations éligibles sont transmises au moteur V6.5.4, qui applique ses vérifications supplémentaires. Le statut `verified_source` est une assertion de l'émetteur, pas une vérification cryptographique. Les sources actuelles peuvent produire **0** observation exploitable : c'est normal.

L'API/collecteur d'origine devra ensuite produire un fichier `Tennis_Edge_Lab/v65/bookmaker_snapshots.jsonl` horodaté avec toutes les preuves, ou un flux équivalent. Il ne faut pas mettre de données sensibles ni d'identifiants API dans le dépôt.

## Installation
Créer une branche `lab-v655-ingestion` depuis `main`, extraire le ZIP à la racine, lancer les tests `test_v655.py`, puis ajouter uniquement les trois fichiers `.github/workflows/lab_v655_ingestion.yml`, `Tennis_Edge_Lab/v65/ingest_v655.py`, `Tennis_Edge_Lab/tests/test_v655.py`. PR vers main, vérifier et fusionner. Lancer `Tennis Edge Lab V6.5.5 - Collector ingestion preview` sur `main` et transmettre l'artifact.
