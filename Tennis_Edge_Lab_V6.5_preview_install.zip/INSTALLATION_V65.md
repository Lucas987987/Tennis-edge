# Tennis Edge Lab V6.5 — Observation preview

## Installation mobile
1. GitHub > Tennis-edge > branche `main` > créer une branche `lab-v65-prospective-observation`.
2. Décompresser le ZIP **à la racine de cette branche** en conservant les chemins.
3. Vérifier les quatre fichiers sous `Tennis_Edge_Lab/v65/`, le test et le workflow.
4. Créer une PR vers `main`, attendre les contrôles puis fusionner manuellement.
5. GitHub Actions > `Tennis Edge Lab V6.5 - Observation preview` > Run workflow > branche `main`.
6. Télécharger l'artifact JSON et vérifier les résultats.

## Limite importante
C'est une **première brique sûre** : lecture d'événements *préqualifiés*, calcul de ROI/CLV et rapports en artifact.
Elle ne collecte pas encore automatiquement les signaux ni ne persiste un historique entre runs.
Le fichier `events.jsonl` est volontairement vide : le premier run vert donne donc zéro observation.
Aucun pari ne doit être déduit de cette sortie.

## Format d'une ligne JSONL
{"event_id":"unique-001","hypothesis_id":"<id exact du snapshot>","fixture_id":"match-123","signal_at_utc":"2026-10-16T10:00:00Z","book":"unibet","market":"match","odds_at_signal":2.2,"rules_verified_at_signal":true}

Champs facultatifs après clôture: `closing_odds`, `result` (`win`, `loss`, `void`),
`settled_at_utc` (obligatoire si closing_odds/result présents).

La validation des critères (circuit, horizon, sélection, amplitude, etc.) doit être réalisée
en amont, **avec les données connues au moment du signal**. Ne pas renseigner
`rules_verified_at_signal=true` sans vérification. Le moteur refuse les événements non vérifiés.

CLV = 100 × (cote signal / cote clôture − 1), sans dévig.
ROI = 100 × somme(profits unitaires) / nombre de paris gagnés ou perdus.
`void` n'entre pas dans le dénominateur. Pas d'IC statistique dans cette première brique.

## Suite V6.5
Brancher un adaptateur aux données horodatées de l'existant, vérifier les règles exactes,
archiver les signaux de façon immuable et persistante, puis ajouter le dashboard J+30/60/90.
Ne pas confondre le succès du workflow avec la mise en place complète de ce suivi.
