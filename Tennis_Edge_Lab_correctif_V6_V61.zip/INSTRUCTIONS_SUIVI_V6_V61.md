# Correctif Tennis Edge Lab — suivi V6 et V6.1

## Pourquoi ?
Le code V6/V6.1 conserve la date de génération précédente si les statistiques n'ont pas changé. Lorsque V6 compte **zéro hypothèse gelée**, la date reste ancienne, même si le calcul s'exécute. Le workflow nocturne calcule aussi `candidate_watch_v61_prospective.json`, mais **ne l'ajoute pas à la liste des fichiers publiés**.

Ce correctif :
1. date chaque exécution réelle des calculs V6 et V6.1, sans inventer de paris ;
2. publie le rapport V6.1 déjà calculé par le workflow nocturne ;
3. ne touche pas aux registres, à la sélection V6.4 ni aux statistiques historiques ;
4. ne publie pas l'archive V6.1 exhaustive sur Pages (volumineuse, conservée en artifact).

## Installation depuis Codespaces, à la racine du dépôt
Télécharger `Tennis_Edge_Lab_correctif_V6_V61.zip`, le glisser dans l'explorateur Codespaces à la racine `Tennis-edge`, puis exécuter :

```bash
unzip -o Tennis_Edge_Lab_correctif_V6_V61.zip
python3 install_suivi_v6_v61.py
python3 -m py_compile Tennis_Edge_Lab/candidate_registry_v6.py Tennis_Edge_Lab/candidate_watch_v61.py
git diff --check
git diff --stat
```

## Publier

```bash
git switch -c fix-publication-v6-v61
git add Tennis_Edge_Lab/candidate_registry_v6.py Tennis_Edge_Lab/candidate_watch_v61.py .github/workflows/lab_autonomous_auto_v63.yml
git commit -m "Lab: actualiser les dates de calcul et publier le suivi V6.1"
git push -u origin fix-publication-v6-v61
```

Ouvrir : https://github.com/Lucas987987/Tennis-edge/compare/main...fix-publication-v6-v61?expand=1
Créer puis fusionner la Pull Request.

## Vérification

1. Ouvrir https://github.com/Lucas987987/Tennis-edge/actions/workflows/lab_autonomous_auto_v63.yml
2. Cliquer `Run workflow` sur `main`. Pour déclencher la publication des rapports, l'entrée `publish_v63` doit être `true`, **mais cette option autorise aussi une publication des gels V6.3** : ne pas l'utiliser uniquement pour actualiser les rapports. **Préférer attendre l'exécution planifiée nocturne**, qui publie les rapports sans modifier les gels.
3. Après la prochaine exécution nocturne réussie, ouvrir `Deploy Pages`, puis `research.html` et le tableau « Fraîcheur des analyses ».
4. Vérifier que `bookmakers_sets_prospective.json` et `candidate_watch_v61_prospective.json` ont une nouvelle date de génération. Un rapport vide peut être à jour : il signifie **zéro gel** et non une rentabilité positive.

**Important** : le workflow Pages ne recalcule pas ces rapports ; il publie les sorties du workflow autonome. La correction n'ajoute aucune observation nouvelle et ne garantit pas que des gels V6 apparaîtront.
