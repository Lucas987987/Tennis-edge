#!/usr/bin/env python3
"""Correctif minimal et idempotent de publication V6/V6.1."""
from pathlib import Path
import ast, subprocess
root=Path(__file__).resolve().parent
lab=root/'Tennis_Edge_Lab'
workflow=root/'.github/workflows/lab_autonomous_auto_v63.yml'
files=[lab/'candidate_registry_v6.py',lab/'candidate_watch_v61.py',workflow]
for p in files:
    if not p.is_file(): raise SystemExit(f'Fichier requis absent: {p}')
changes={}
for p in files[:2]:
    s=p.read_text(encoding='utf-8')
    if p.name=='candidate_registry_v6.py':
        old='''    if path.is_file():
        previous = json.loads(path.read_text(encoding="utf-8"))
        if {k: v for k, v in previous.items() if k != "generated_at"} == {
            k: v for k, v in report.items() if k != "generated_at"
        }:
            report["generated_at"] = previous.get("generated_at", report["generated_at"])
'''
        new='''    # Date du dernier calcul, même si aucun gel ou résultat n'a changé.
    # Le nombre de gels et les statistiques restent inchangés.
'''
    else:
        old='''    if path.is_file():
        existing = json.loads(path.read_text(encoding="utf-8"))
        old_without_time = {key: value for key, value in existing.items() if key != "generated_at"}
        new_without_time = {key: value for key, value in report.items() if key != "generated_at"}
        if old_without_time == new_without_time:
            report["generated_at"] = existing.get("generated_at", report["generated_at"])
'''
        new='''    # Date du dernier calcul, même si les observations sont inchangées.
'''
    if old in s: s=s.replace(old,new,1)
    elif new not in s: raise SystemExit(f'Code inattendu, aucun changement : {p}')
    ast.parse(s,filename=str(p));changes[p]=s
s=workflow.read_text(encoding='utf-8')
old='''            Tennis_Edge_Lab/live/bookmakers_sets_prospective.json \\
            Tennis_Edge_Lab/live/bookmakers_sets_audit.json \\
'''
new='''            Tennis_Edge_Lab/live/bookmakers_sets_prospective.json \\
            Tennis_Edge_Lab/live/candidate_watch_v61_prospective.json \\
            Tennis_Edge_Lab/live/bookmakers_sets_audit.json \\
'''
if old in s:s=s.replace(old,new,1)
elif new not in s:raise SystemExit('Section publication nocturne introuvable; aucun changement')
changes[workflow]=s
for p,s in changes.items():p.write_text(s,encoding='utf-8');print('OK:',p.relative_to(root))
print('Contrôle syntaxe Python OK. Aucun registre gelé modifié.')
