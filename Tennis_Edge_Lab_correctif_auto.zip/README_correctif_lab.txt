TENNIS EDGE LAB - CORRECTIF DE PUBLICATION AUTOMATIQUE V6.3

Fichier à remplacer : .github/workflows/lab_autonomous.yml

Apport :
- conserve les 60 hypothèses déjà gelées et leurs empreintes ;
- publie seulement le rapport prospectif V6.3, les rapports légers V6,
  le résumé d'audit V6.1 et les catalogues source/archive ;
- fonctionne sur le déclenchement nocturne ou publish_v63=true ;
- contrôle les registres et bloque en présence de nouveaux gels non autorisés ;
- déclenche automatiquement un nouveau déploiement Pages par le push Git.

Limites volontaires :
- Ne publie pas le rapport exhaustif V6.1 ni l'archive complète (plusieurs centaines de Mo).
  Ceux-ci restent accessibles en tant qu'artifact du workflow Lab (90 jours).
- Les rapports sans nouvelles données sources peuvent rester signalés anciens ;
  ce message est honnête et ne doit pas être masqué artificiellement.

État du dépôt : la connexion GitHub de ChatGPT a refusé la création d'une
branche (403, Resource not accessible by integration). Le fichier a été
préparé localement, mais aucune modification n'a été poussée sur main.

Installation :
1. Dans GitHub/Codespaces, remplacer .github/workflows/lab_autonomous.yml
   par ce fichier et committer.
2. Déclencher le workflow V6.3 avec publish_v63=true (autres options false).
3. Vérifier le run vert, le nouveau commit bot et le déploiement Pages.
