# check_joins redirigé vers la vraie source (30/08/2026)

    unzip audit_qa_join.zip
    cp audit_qa_join/scripts/*.py scripts/

    bash audit_qa_join/verifier.sh
    # doit afficher "TOUT EST EN PLACE (2 contrôles passés + test de non-régression)"
    # le test critique tourne sur tes VRAIES données, pas un exemple synthétique

    python tests/test_pure_functions.py      # doit afficher 13/13

    rm -rf audit_qa_join audit_qa_join.zip
    git add -A
    git commit -m "audit_qa.py check_joins : redirigé vers resultats_derived.json via ResultIndex -- resultats.json est en mode repli permanent (Sackmann injoignable) avec un format d'id structurellement incompatible depuis le 27/08"
    git pull --no-rebase --no-edit && git push

---

## Ce que le 98/98 signalait vraiment

Pas un bug de jointure au sens classique -- une comparaison entre deux
formats d'identifiant devenus incompatibles. `resultats.json` a un mode de
repli, documenté depuis le 27/08/2026 (audit §1.3) : Sackmann (sa source
primaire) est injoignable depuis ce runner (egress bloqué), et le fichier
tourne depuis en mode repli PERMANENT sur `resultats_derived.json`, avec un
format d'id `date_gagnant_repli` -- UN SEUL joueur, jamais deux. Le
`check_joins` d'`audit_qa.py` comparait toujours les uid à deux joueurs du
backtest contre ce format à un seul joueur : 100% d'échec garanti, à
chaque run, depuis 3 jours -- pas une vraie anomalie, le bruit d'une
comparaison entre deux conventions qui ne se recoupent plus.

## Le correctif

`check_joins` compare maintenant directement contre `resultats_derived.json`
(la source RÉELLE derrière le repli, format nativement compatible à deux
joueurs), via `results_join.ResultIndex` -- le même outil, déjà testé
aujourd'hui à 90/99 sur les trades canal, pas réimplémenté depuis zéro. La
restriction de plage de dates (ne juger que sur la période couverte) est
reprise, adaptée à la vraie source.

**Résultat mesuré, sur les vraies données** : 163/305 (53%), contre le
98/98 (100%) structurel d'avant. Ce nouveau chiffre porte sur les 305
lignes du backtest tombant dans les 10 premiers jours de couverture de
`resultats_derived.json` (11-21 juin) -- une fenêtre étroite, tout au
début de la collecte. **Ce reste (53%) est un vrai signal, pas résolu ici**
-- possiblement une collecte moins complète en tout début de période,
distinct du bug structurel maintenant corrigé. À creuser séparément si tu
veux aller plus loin.

## Tests : 13/13 (inchangé)
