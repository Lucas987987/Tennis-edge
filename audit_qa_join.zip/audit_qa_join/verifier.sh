#!/usr/bin/env bash
# verifier.sh — check_joins comparait contre une source structurellement
# incompatible (30/08/2026, signalé par Lucas : 98/98 = 100% d'échec).
#
# Usage : bash verifier.sh   (à la racine du dépôt, APRÈS le cp)

set -uo pipefail
ECHECS=0

verif() {
    local fichier="$1" motif="$2" description="$3"
    if [ ! -f "$fichier" ]; then
        echo "❌ $fichier : FICHIER ABSENT"
        ECHECS=$((ECHECS+1))
        return
    fi
    if grep -q "$motif" "$fichier"; then
        echo "✅ $fichier : $description"
    else
        echo "❌ $fichier : $description -- MOTIF ABSENT ($motif)"
        ECHECS=$((ECHECS+1))
    fi
}

echo "=== Vérification -- check_joins redirigé vers la vraie source (30/08/2026) ==="
echo

verif scripts/audit_qa.py "from results_join import ResultIndex, FENETRE_J" "utilise ResultIndex (déjà testé, éprouvé)"
verif scripts/audit_qa.py "resultats_derived.json" "compare contre la source compatible"

echo
echo "=== Test critique : sur les vraies données, si présentes ici ==="
if [ -f backtest_tennis.csv ] && [ -f resultats_derived.json ]; then
    python3 -c "
import sys; sys.path.insert(0,'scripts')
import audit_qa
problems = []
audit_qa.check_joins(problems)
for niveau, msg in problems:
    print(f'{niveau}: {msg}')
if not problems:
    print('(aucun problème -- sous le seuil)')
# le point clé : ça ne doit PLUS jamais afficher un ratio proche de 100%
# (le symptôme du bug -- comparaison contre un format structurellement
# incompatible), qu'il y ait ou non un problème de fond à signaler.
for niveau, msg in problems:
    import re
    m = re.search(r'(\d+)/(\d+) matchs', msg)
    if m:
        miss, total = int(m.group(1)), int(m.group(2))
        assert miss < total, 'ratio 100%, le symptôme du bug est de retour'
print('✅ pas de ratio proche de 100% -- le bug structurel est résolu')
"
else
    echo "⏭️  backtest_tennis.csv / resultats_derived.json absents ici -- test sauté"
fi

echo
if [ "$ECHECS" -eq 0 ]; then
    echo "✅✅✅ TOUT EST EN PLACE (2 contrôles passés + test de non-régression). Sûr de committer."
    exit 0
else
    echo "❌❌❌ $ECHECS CONTRÔLE(S) EN ÉCHEC. NE PAS COMMITTER avant d'avoir compris pourquoi."
    exit 1
fi
