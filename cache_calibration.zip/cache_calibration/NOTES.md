# Cache de calibration — cadence 10 min → 5 min (03/09/2026)

    unzip cache_calibration.zip
    cp cache_calibration/scripts/*.py scripts/
    cat cache_calibration/ajout_gitignore.txt >> .gitignore

    bash cache_calibration/verifier.sh
    # doit afficher "TOUT EST EN PLACE (6 contrôles + 2 tests critiques)"

    python tests/test_pure_functions.py      # doit afficher 13/13

    rm -rf cache_calibration cache_calibration.zip
    git add -A
    git commit -m "Cache de calibration : l'historique (43 s) n'est plus rechargé 6x par cycle -- run de 5,1 à 3,1 min, la cadence peut enfin tenir 5 min"
    git pull --no-rebase --no-edit && git push

---

## La cause, mesurée pas à pas

Le worker déclenche bien toutes les 5 min (confirmé par tes journaux
Cloudflare). Le blocage était côté GitHub : chaque run DÉPASSAIT sa fenêtre
de 5 min, et `concurrency: capture-closing` (`cancel-in-progress: false`)
mettait le dispatch suivant en file -- un run sur deux, donc 10 min.

Chronométrage réel de l'étape la plus lourde (149 s au total) :

    rebuild des fichiers plats ............  1,6 s   (pas le problème)
    steam_alert.py (1 marché) ............. 51,8 s
    paper_journal.py (1 marché) ........... 49,8 s

Et à l'intérieur :

    load_curves(live) ......................  0,4 s
    load_curves(TRACK = historique) ....... 43,1 s   <-- la cause

Cet historique (12 partitions, 1882 matchs) était rechargé **6 fois par
cycle** -- 3 marchés x 2 scripts -- alors qu'il ne sert QU'À calculer la
calibration (vérifié : `past` n'a aucun autre usage dans les deux scripts).

## Le correctif

`sa.stats_avec_cache()` : la calibration est persistée dans
`calib_cache.json` (TTL 60 min, configurable par `CALIB_TTL_MIN`) et
partagée par les 6 exécutions du cycle. L'historique n'est rechargé que
lorsque le cache expire. Le chargement est PARESSEUX : il n'a lieu que si
le cache est absent ou périmé.

Second gisement traité dans `paper_journal.py` : `track` (le repli pour
régler les trades dont le match est sorti de `data`) était chargé d'office.
Il est maintenant chargé paresseusement, au premier trade qui en a
réellement besoin.

**Mesuré sur tes vraies données :**

    steam_alert   : 52,7 s -> 0,6 s (cache chaud)
    paper_journal : 89,2 s -> 43,9 s
    cycle complet : 306 s (5,1 min) -> 185 s (3,1 min), soit -39 %

Le run repasse sous la fenêtre de 5 min : la file d'attente ne se déclenche
plus, la cadence peut tenir.

## Vérifié avant livraison

**Les seuils sont identiques.** Comparaison cache vs calcul direct sur les
20 books : **0 divergence**. Le cache ne change aucune décision d'alerte.

**Le cache expire vraiment.** Testé avec une entrée vieille de 2 h : elle
est bien rechargée. Un cache qui n'expirerait jamais figerait les seuils --
c'est le risque principal de ce genre d'optimisation, il est couvert par un
test qui échoue si on le casse (vérifié par sabotage).

**Le journal reste intact** : `diff` avant/après identique.

**`calib_cache.json` est dans `.gitignore`** -- le committer à chaque cycle
gonflerait l'historique git pour une donnée dérivée, exactement ce que la
sentinelle de taille surveille. Vérifié sur un dépôt git jetable.

## Ce que je n'ai pas fait, volontairement

`paper_journal` reste à 44 s parce que 6 trades anciens en
`CLOSED_NO_RESULT` forcent le chargement du repli `track`. Les optimiser
demanderait de toucher à la logique de règlement corrigée hier -- le gain
(44 s -> ~5 s) ne justifie pas ce risque dans la même session. Ces 6 trades
basculeront en `ABANDONNED` d'eux-mêmes après 7 jours, et le coût
disparaîtra avec eux.

## Tests : 13/13 (inchangé)
