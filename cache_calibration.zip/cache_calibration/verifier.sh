#!/usr/bin/env bash
# verifier.sh — cache de calibration (03/09/2026).
# Corrige la cause mesurée de la cadence à 10 min : l'historique complet
# (43 s) était rechargé 6x par cycle, faisant déborder chaque run de sa
# fenêtre de 5 min et mettant le dispatch suivant en file d'attente.
#
# Usage : bash verifier.sh   (à la racine du dépôt, APRÈS les cp)

set -uo pipefail
ECHECS=0

verif() {
    local fichier="$1" motif="$2" description="$3"
    if [ ! -f "$fichier" ]; then
        echo "❌ $fichier : FICHIER ABSENT"; ECHECS=$((ECHECS+1)); return
    fi
    if grep -q "$motif" "$fichier"; then
        echo "✅ $fichier : $description"
    else
        echo "❌ $fichier : $description -- MOTIF ABSENT ($motif)"; ECHECS=$((ECHECS+1))
    fi
}

echo "=== Vérification -- cache de calibration (03/09/2026) ==="
echo

verif scripts/steam_alert.py "def stats_avec_cache" "fonction de cache créée"
verif scripts/steam_alert.py "CALIB_TTL_MIN" "TTL configurable"
verif scripts/steam_alert.py "stats, softbooks = stats_avec_cache" "steam_alert branché"
verif scripts/paper_journal.py "sa.stats_avec_cache" "paper_journal branché"
verif scripts/paper_journal.py "def _track()" "chargement paresseux du repli track"
verif .gitignore "^calib_cache.json$" "cache exclu de git"

echo
echo "=== Test critique 1 : le cache donne-t-il EXACTEMENT les mêmes seuils ? ==="
if [ -f book_curves_live.jsonl ] || [ -d parts ]; then
  rm -f calib_cache.json
  python3 -c "
import sys, os, json; sys.path.insert(0,'scripts')
os.environ.update({'CURVES':'book_curves_live.jsonl','TRACK_CURVES':'book_curves.jsonl','MARKET':'match'})
import steam_alert as sa

data = sa.load_curves(); now = sa._now()
track = sa.load_curves(sa.TRACK_CURVES)
win = now - sa.WINDOW_DAYS*86400
past = {u: bk for u, bk in track.items() if bk.get('_commence') and win <= bk['_commence'] < now}
softbooks = sorted({b for m in list(past.values()) + list(data.values())
                    for b in m if not b.startswith('_') and b != sa.SHARP})
if sa.SOFT_PREF:
    keep = set(s.strip() for s in sa.SOFT_PREF.split(','))
    softbooks = [b for b in softbooks if b in keep]

direct = sa.compute_stats(past, softbooks)
thr_direct = {sb: sa.best_threshold(direct, sb) for sb in softbooks}

# via le cache (1er appel remplit, 2e relit)
sa.stats_avec_cache('match', lambda: (past, softbooks))
stats_c, sb_c = sa.stats_avec_cache('match', lambda: (_ for _ in ()).throw(AssertionError('ne doit PAS recharger')))
thr_cache = {sb: sa.best_threshold(stats_c, sb) for sb in sb_c}

diff = [sb for sb in softbooks if thr_cache.get(sb) != thr_direct[sb]]
assert not diff, f'SEUILS DIVERGENTS : {diff}'
print(f'✅ {len(softbooks)} books, seuils identiques entre cache et calcul direct')
" 2>&1 | grep -v "commence_time croisé\|load_curves(" || ECHECS=$((ECHECS+1))
  rm -f calib_cache.json
else
  echo "⏭️  données absentes ici -- test sauté (normal hors du dépôt réel)"
fi

echo
echo "=== Test critique 2 : le cache expire-t-il bien ? ==="
python3 -c "
import sys, os, json, datetime; sys.path.insert(0,'scripts')
os.environ['CALIB_TTL_MIN'] = '60'
import steam_alert as sa
sa.CALIB_CACHE = '/tmp/_v_calib.json'
sa.CALIB_TTL_MIN = 60

# cache périmé (2h) -> doit recharger
vieux = (datetime.datetime.utcnow() - datetime.timedelta(hours=2)).isoformat()
json.dump({'match': {'t': vieux, 'stats': {'0.05': {}}, 'softbooks': ['x']}},
          open('/tmp/_v_calib.json','w'))
recharge = []
sa.stats_avec_cache('match', lambda: (recharge.append(1) or ({}, ['y'])))
assert recharge, 'cache PÉRIMÉ non rechargé -- des seuils obsolètes seraient utilisés'
print('✅ un cache de plus de 60 min est bien rechargé')
os.remove('/tmp/_v_calib.json')
" || ECHECS=$((ECHECS+1))

echo
if [ "$ECHECS" -eq 0 ]; then
    echo "✅✅✅ TOUT EST EN PLACE (6 contrôles + 2 tests critiques). Sûr de committer."
    exit 0
else
    echo "❌❌❌ $ECHECS CONTRÔLE(S) EN ÉCHEC. NE PAS COMMITTER."
    exit 1
fi
