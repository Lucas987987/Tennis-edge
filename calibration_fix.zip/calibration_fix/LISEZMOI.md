# calibration_books.py — réécriture du 25/08/2026

Le fichier d'origine (étude du 24/08) est arrivé corrompu dès son premier
commit (12 542 octets nuls, aucune version saine dans l'historique).
Réécrit à partir du rapport publié calibration_books.md.

Validation sur les données du 25/08 : 1025 matchs dénoués (1004 dans l'étude
d'origine, +1 jour de données), tranche 30-45 % observée à 41,7 % / +3,8 pts
(original : 41,8 % / +3,8 pts), 45-55 % pile à 50,0 %. Même signature
favori-outsider aux extrêmes. Méthode : closing STRICTEMENT pré-match
(coupure à commence_time — le dernier point de courbe est souvent in-play,
le prendre fabrique une fausse calibration par look-ahead), dévig de Shin,
Brier sur échantillon commun (matchs cotés par TOUS les opérateurs retenus,
seuil de couverture MIN_COUVERTURE, défaut 0,5).

Application, à la racine du dépôt :
    cp calibration_fix/scripts/calibration_books.py scripts/
    cp calibration_fix/.github/workflows/book_index.yml .github/workflows/
    python scripts/calibration_books.py     # régénère calibration_books.md
    git add scripts/calibration_books.py .github/workflows/book_index.yml calibration_books.md
    git commit -m "Réécriture calibration_books + régénération hebdo"
    git push

Le workflow book_index (hebdomadaire) régénère désormais le rapport chaque
semaine, en non-bloquant mais avec échec visible dans les logs.
