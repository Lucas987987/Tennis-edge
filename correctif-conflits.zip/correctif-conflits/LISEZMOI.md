# Trois problèmes, un seul enchaînement

    cd /tmp && unzip -o correctif-conflits.zip
    cd /workspaces/Tennis-edge
    bash /tmp/correctif-conflits/appliquer.sh
    bash /tmp/correctif-conflits/appliquer.sh POSER

Le script travaille **depuis /tmp** : rien ne traîne dans le dépôt.

## 1. Ma régression du 3 octobre

En renforçant le retry sur 25 workflows, j'ai remplacé la boucle entière —
**y compris l'appel à `merge_json_state.py`** qu'elle contenait.

Ce script résout les conflits de contenu sur `closing_lines.json`, qui est
un **accumulateur** : prendre une version au hasard effacerait les matchs
ajoutés par l'autre exécution.

Sans lui, `fetch_clv` échouait depuis deux jours :

    CONFLICT (content): Merge conflict in closing_lines.json
    ⚠️ merge en conflit · tentative 6/6
    ❌ PUSH ÉCHOUÉ après 6 tentatives

Six tentatives ne servent à rien face à un conflit de contenu : il se
reproduit à l'identique à chaque essai.

Cette fois je ne remplace que l'en-tête de boucle et les `sleep`. Vérifié
fichier par fichier : **les 20 workflows qui appelaient `merge_json_state`
l'appellent toujours**, et les 5 autres l'ont désormais.

## 2. Les 25 000 requêtes en 10 jours

La cause est dans votre code, et c'est une **récidive du défaut du 29/08** :

```python
if dernier_extended is None:
    return True   # état absent : forcer
```

Si `extended_state.json` n'est pas relu — fichier absent, JSON corrompu,
ou **push perdu au run précédent** — cette branche renvoie `True` à chaque
cycle. Avec 480 cycles/jour, c'est 480 passes étendues au lieu de 12.

Et vos pushs échouaient depuis deux jours, pour la raison ci-dessus. Les
deux problèmes se nourrissaient l'un l'autre.

**Le correctif** : un repli sur l'horloge quand l'état manque, borné à une
fenêtre de 3 minutes toutes les 2 heures.

| | passes/jour | requêtes/jour |
|---|---|---|
| sans garde-fou | 480 | 3 360 |
| avec repli | **12** | **1 020** |

Sur 30 jours : **30 600 requêtes** sur un quota de 50 000.

La fenêtre est à 3 minutes et pas 10 : à 480 cycles/jour il en passe un
toutes les 3 minutes, donc 10 minutes en attraperaient quatre.

## 3. La permission de relance

`capture_closing` reçoit `actions: write`, qui lui manquait pour relancer
les collecteurs via `watchdog_collecteurs.py`.

## Après la pose

Lancez `fetch_clv` à la main. Le log doit afficher :

    ⚠️ conflit — tentative de fusion JSON (essai 1)
    ✅ PUSH OK

puis surveillez RapidAPI demain : la pente doit passer d'environ 2 500
à 1 000 requêtes par jour.

## Ce que ça dit

Le défaut du 29/08 avait été corrigé en déplaçant l'état dans un fichier
dédié. Mais la correction gardait un point de rupture : **elle dépendait
d'un fichier commité**. Dès que les pushs ont cassé, le défaut est revenu
à l'identique.

Un garde-fou qui dépend de l'état qu'il protège n'en est pas un.
