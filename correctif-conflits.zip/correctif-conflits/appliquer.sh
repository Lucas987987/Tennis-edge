#!/usr/bin/env bash
# appliquer.sh — 25 workflows + capture_closing.py.
# A lancer DEPUIS /tmp, pas depuis le depot : rien ne traine a la racine.
#
#     cd /tmp && unzip -o ~/correctif.zip && cd /workspaces/Tennis-edge
#     bash /tmp/correctif-conflits/appliquer.sh
#     bash /tmp/correctif-conflits/appliquer.sh POSER
set -euo pipefail
MODE="${1:-}"
SRC="$(cd "$(dirname "$0")" && pwd)"
[ -d .git ] || { echo "❌ Lancez ce script a la racine du depot."; exit 1; }

echo "=== A POSER ==="
n=0
for s in "$SRC"/corrige/*.yml; do
  d=".github/workflows/$(basename "$s")"
  [ -f "$d" ] || continue
  cmp -s "$s" "$d" && continue
  echo "  $(basename "$s")"; n=$((n+1))
done
echo "  scripts/capture_closing.py"; n=$((n+1))
echo "  -> $n fichier(s)"

if [ "$MODE" != "POSER" ]; then
  echo; echo "🛑 SIMULATION. Pour appliquer : bash $0 POSER"; exit 0
fi

echo; echo "=== POSE ==="
for s in "$SRC"/corrige/*.yml; do
  d=".github/workflows/$(basename "$s")"
  [ -f "$d" ] || continue
  cp "$s" "$d"
done
cp "$SRC"/scripts/capture_closing.py scripts/
echo "  ✅ 25 workflows + capture_closing.py"

python3 - <<'PY'
import yaml, glob, sys, ast
for p in sorted(glob.glob('.github/workflows/*.yml')):
    try: yaml.safe_load(open(p, encoding='utf-8'))
    except Exception as e: print(f'  ❌ {p} : {str(e)[:70]}'); sys.exit(1)
ast.parse(open('scripts/capture_closing.py', encoding='utf-8').read())
print('  ✅ YAML et Python valides')
PY

git add -A
git commit -m "Resolution des conflits JSON retablie + passe etendue bornee"
git pull --rebase origin main
git push origin main
echo "✅ POUSSE."
