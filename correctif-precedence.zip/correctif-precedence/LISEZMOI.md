# Mon erreur de précédence shell — 3 workflows

    cd /tmp && unzip -o correctif-precedence.zip
    cd /workspaces/Tennis-edge
    bash /tmp/correctif-precedence/appliquer.sh POSER

## Ce que j'ai cassé

Hier, en ajoutant la fusion JSON à `health_check`, `pistes_weekly` et
`polymarket_studies`, j'ai écrit une version compacte :

```bash
git merge origin/main --no-edit || python scripts/merge_json_state.py \
  && git commit --no-edit || { ...; continue; }
```

En shell, `A || B && C || D` s'évalue **`((A || B) && C) || D`**.

Donc **quand le merge RÉUSSIT**, le `git commit` s'exécute quand même,
échoue avec « nothing to commit », et la branche d'échec déclenche un
`continue` — **sans jamais pousser**.

Le log de `health_check` le montre exactement :

    [main 4f5661e] Sentinelle taille du dépôt (2026-10-07)
    Already up to date.
    nothing to commit, working tree clean
    -> 3 tentatives, exit 1, commit perdu

Le cas nominal — pas de conflit — était devenu un échec systématique.

## Le correctif

Structure explicite, sans enchaînement d'opérateurs :

```bash
if ! git merge origin/main --no-edit; then
  if python scripts/merge_json_state.py; then
    git commit --no-edit || true
  else
    git merge --abort 2>/dev/null || true
    [ "$essai" -lt 6 ] && { sleep "$attente"; attente=$((attente*2)); }
    continue
  fi
fi
```

Testé sur les deux cas : merge réussi → push atteint ; merge échoué →
fusion puis retry.

## Ce qui n'est PAS de mon fait

**`kalshi_collector` et `polymarket_collector`** — « après 3 tentatives ».
Ils ne faisaient pas partie des 25 fichiers corrigés : ils ont leur propre
boucle, inchangée depuis toujours. C'est de la contention réelle.

Si vous voulez, je peux leur appliquer le même traitement — mais c'est un
choix séparé, pas une réparation.

**`courbes_alertes`** a échoué sur :

    ! [remote rejected] main -> main (Internal Server Error)

après mes 6 tentatives. C'est une panne GitHub, pas un conflit. Aucune
boucle de retry ne peut rien contre un 500.

**Les runs en attente depuis 44 minutes** sont de la contention de runners
chez GitHub, comme les erreurs « job was not acquired » du 5 octobre.

## Ce que ça dit

Trois fois cette semaine, j'ai cassé quelque chose en le corrigeant : la
fusion JSON supprimée, puis cette précédence. À chaque fois parce que j'ai
écrit une forme condensée au lieu d'une structure explicite.

Les trois fichiers sont désormais en `if/then/else`, plus verbeux et sans
ambiguïté d'évaluation.
