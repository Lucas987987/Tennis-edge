#!/usr/bin/env bash
# Correctif de precedence shell — 3 workflows.
# A lancer DEPUIS /tmp :
#   cd /tmp && unzip -o <zip> && cd /workspaces/Tennis-edge
#   bash /tmp/correctif-precedence/appliquer.sh POSER
set -euo pipefail
MODE="${1:-}"
SRC="$(cd "$(dirname "$0")" && pwd)"
[ -d .git ] || { echo "❌ Lancez ce script a la racine du depot."; exit 1; }

echo "=== A POSER ==="
for s in "$SRC"/corrige/*.yml; do
  d=".github/workflows/$(basename "$s")"
  [ -f "$d" ] || continue
  cmp -s "$s" "$d" && echo "  $(basename "$s") : deja a jour" || echo "  $(basename "$s")"
done

if [ "$MODE" != "POSER" ]; then
  echo; echo "🛑 SIMULATION. Pour appliquer : bash $0 POSER"; exit 0
fi

for s in "$SRC"/corrige/*.yml; do
  d=".github/workflows/$(basename "$s")"
  [ -f "$d" ] && cp "$s" "$d"
done
python3 - <<'PY'
import yaml, glob, sys
for p in sorted(glob.glob('.github/workflows/*.yml')):
    try: yaml.safe_load(open(p, encoding='utf-8'))
    except Exception as e: print(f'  ❌ {p} : {str(e)[:70]}'); sys.exit(1)
print('  ✅ YAML valides')
PY
git add -A
git commit -m "Corriger la precedence shell dans la boucle de push (3 workflows)"
git pull --rebase origin main
git push origin main
echo "✅ POUSSE."
