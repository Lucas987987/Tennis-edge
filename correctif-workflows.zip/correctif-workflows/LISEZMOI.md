# Correctif — 7 workflows lisaient un historique tronqué

    bash appliquer.sh          # simulation
    bash appliquer.sh POSER    # écrit, commit et pousse

À lancer à la racine du dépôt, dans un Codespace.

## Le défaut

Depuis que `archive_curves` sort les partitions de plus de 28 jours vers
les releases, **sept workflows lisent `hist_*` sans les restaurer**. Ils
travaillent sur un historique tronqué, et aucune erreur n'est levée.

Constaté aujourd'hui sur `book_index` :

| | 07/09 | aujourd'hui |
|---|---|---|
| matchs | 1 863 | **1 251** |
| mouvements | 650 | **351** |
| réactivité | positive sur 8 books | **négative partout** |

Les chiffres ont changé sans que rien ne le signale. C'est le même défaut
que `steam_pipeline` avant-hier, qui faisait tomber
`moves_detail_hist.csv` de 1 748 à 302 lignes.

## Les sept workflows

| | script qui lit l'historique |
|---|---|
| `book_index.yml` | `calibration_books` |
| `courbes_alertes.yml` | `steam_alert` |
| `drift_outcome.yml` | `drift_outcome` |
| `fetch_book_curves.yml` | `book_reliability`, `compress_hist_partitions` |
| `kalshi_collector.yml` | `compress_hist_partitions` |
| `polymarket_collector.yml` | `compress_hist_partitions` |
| `soft_open_detector.yml` | `soft_open_detector` |

`courbes_alertes` est le plus important : `steam_alert` y calcule les
seuils par book, qui alimentent vos sept signaux.

## Ce qui a été vérifié

**Placement.** Dans chacun, l'étape de restauration précède l'usage des
partitions — vérifié en relisant le YAML chargé, pas le texte brut :

    book_index.yml        restore étape 3/5 · usage étape 4
    courbes_alertes.yml   restore étape 3/7 · usage étape 5
    polymarket_collector  restore étape 4/9 · usage étape 5

**YAML.** Les sept se chargent sans erreur. Le script revérifie l'ensemble
du dossier **avant** de commiter : un fichier cassé bloquerait tous les
workflows.

**Idempotence.** Un workflow contenant déjà `restore_curves` est ignoré.
Relancer le script est sans effet.

## Le reste du dépôt

Contrôlé au passage, et sain :

- 52 workflows, **tous les YAML valides**
- aucun script appelé mais absent
- 19 hypothèses chargées, constantes présentes
- les cinq scripts de signaux importent bien leurs bornes depuis
  `validation_report`
- un seul import externe non standard : `websocket` dans
  `polymarket_collector_scripts.py` — normal, c'est une dépendance
  installée par le workflow

## Ce que ça ne corrige pas

**`set_results.json` est à 3 012 matchs** contre 3 493 avant la purge. Le
rattrapage progresse (2 880 → 2 997 → 3 012) mais reste lent :
`RESULTS_MAX_PER_RUN` est à 80. Relancez `Steam Pipeline` à la main
quelques fois pour accélérer.

**`book_index` ne sera fiable qu'ensuite.** Relancez-le une fois les
partitions restaurées ET les résultats rattrapés, puis comparez avec les
chiffres du 7 septembre. Si les marges restent plus hautes et la
réactivité négative, ce sera un vrai changement de marché — et un résultat
intéressant. Publier avant serait diffuser des chiffres indéfendables.
