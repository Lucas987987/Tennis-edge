#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
move_audit.py — Détail de TOUS les moves pré-match + agrégats, pour répondre à
"les gros moves cachent-ils un edge ?" en analysant courbes + résultats.

Pour CHAQUE match capturé, on mesure (PRÉ-MATCH UNIQUEMENT, aucun look-ahead) :
  - le move Pinnacle : côté raccourci, ampleur (% cote + points de proba),
  - le timing : minutes avant le coup d'envoi à la détection,
  - le prix mou DISPONIBLE sur le côté steamé au moment de la détection (le lag),
  - le CLV qu'on aurait pris (entrée mou vs clôture de ce book, et vs clôture Pinnacle),
  - le résultat (le côté steamé a-t-il gagné),
  - le P&L à mise plate si on avait suivi.

Sorties :
  - moves_detail.csv : une ligne par move (toutes les colonnes ci-dessus),
  - tableau agrégé par tranche d'ampleur (n, CLV médian, %battent la clôture,
    %côté steamé gagne, ROI),
  - les plus gros moves affichés.

Env : CURVES (def book_curves_live.jsonl ; sinon book_curves.jsonl),
  SET_RESULTS (set_results.json), RESULTS_CSV (backtest_tennis.csv, fallback),
  SHARP (pinnacle), SOFTS (unibet,bwin,betsson), THR (0.02 = seuil de détection,
  en points de proba), MIN_LEAD (5 min), MIN_PTS (2), OUT (moves_detail.csv).
"""
import os, sys, json, csv, datetime, unicodedata, re, statistics as st
from collections import defaultdict
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import oddspapi_v5 as ov
import match_key as mk
import curves_common as cc

CURVES      = os.environ.get('CURVES', 'book_curves_live.jsonl')
SET_RESULTS = os.environ.get('SET_RESULTS', 'set_results.json')
RESULTS_CSV = os.environ.get('RESULTS_CSV', 'backtest_tennis.csv')
SHARP       = os.environ.get('SHARP', 'pinnacle')
# BOOKS D'ENTRÉE : importés de validation_report, source unique.
# L'ancien défaut 'unibet,bwin,betsson' n'avait jamais été revu depuis la
# création du script, alors que les courbes contiennent 18 books — le
# détecteur ne pouvait choisir son prix d'entrée que parmi trois.
# Passer par une variable d'environnement laisserait h13_signal.py (autre
# workflow) et ce script diverger sans qu'aucune erreur ne se déclenche.
# SOFTS reste surchargeable pour les ÉTUDES (comparaison de configurations),
# jamais en production.
try:
    import validation_report as _vr
    _DEF_SOFTS = ','.join(_vr.H14_SOFTS)
except Exception:                      # import circulaire ou module absent
    _DEF_SOFTS = 'unibet,bwin,betsson,bet365,888sport,betway,leovegas'
SOFTS       = [b.strip() for b in os.environ.get('SOFTS', _DEF_SOFTS).split(',') if b.strip()]
THR         = float(os.environ.get('THR', '0.02'))      # détection : décalage de proba mini
MIN_LEAD    = float(os.environ.get('MIN_LEAD', '5'))    # minutes avant départ mini
MIN_PTS     = int(os.environ.get('MIN_PTS', '2'))
OUT         = os.environ.get('OUT', 'moves_detail.csv')


def _dt(s):
    try: return datetime.datetime.fromisoformat(str(s).replace('Z', '').replace('+00:00', ''))
    except Exception: return None
def _norm(s):
    s = unicodedata.normalize('NFD', str(s).lower().strip())
    s = ''.join(c for c in s if not unicodedata.combining(c))
    return re.sub(r'[^a-z0-9 ]+', ' ', s).strip()
def _ln(s):
    t = [x for x in _norm(s).split() if x not in ('jr','sr','ii','iii','iv')]
    return t[-1] if t else ''
def _pair(a, b): return frozenset({_ln(a), _ln(b)})
def _at(series, t):
    v = None
    for tt, o in series:
        if tt <= t: v = o
        else: break
    return v
def prob_home(oh, oa):
    if not oh or not oa or oh <= 1 or oa <= 1: return None
    ih, ia = 1/oh, 1/oa
    return ih/(ih+ia)


def load_results():
    """uid -> 'home'/'away' (vainqueur match) + index par paire de joueurs (fallback)."""
    by_uid, by_pair = {}, {}
    if os.path.exists(SET_RESULTS):
        try:
            for uid, v in json.load(open(SET_RESULTS, encoding='utf-8')).items():
                m = (v or {}).get('match')
                if m in ('home', 'away'): by_uid[uid] = m
        except Exception: pass
    # fallback CSV : winner par paire
    if os.path.exists(RESULTS_CSV):
        try:
            for r in csv.DictReader(open(RESULTS_CSV, encoding='utf-8'), delimiter=';'):
                res = (r.get('resultat') or '').strip()
                ja, jb = r.get('joueurA'), r.get('joueurB')
                if res in ('0', '1') and ja and jb:
                    by_pair[_pair(ja, jb)] = _ln(ja) if res == '1' else _ln(jb)
        except Exception: pass
    return by_uid, by_pair


def load_curves():
    games = {}
    _records = []
    # open_curves() : résout legacy monolithique -> partitions hist, et plat
    # live absent -> rebuild depuis parts/ (cf. oddspapi_v5.open_curves).
    try:
        lines = ov.open_curves(CURVES)
    except FileNotFoundError as e:
        print(f"❌ {e}"); return games, mk.build_index([])
    # AJOUTÉ LE 28/08/2026 (audit v4 §U), CORRIGÉ LE 28/08/2026 (audit v5
    # §AA -- voir curves_common.cherche_avec_tolerance()) : pont commun
    # avec steam_alert/paper_journal/canal_clv, une seule copie. Ce fichier
    # alimente moves_detail_hist.csv -> p0_temoin -- l'étalon de TOUTES
    # les hypothèses gelées, le fichier où ce pont compte le plus.
    _closing_lines, _cl_idx = cc.build_closing_index()
    _croises_resolus, _croises_tentes = 0, 0
    for line in lines:
        line = line.strip()
        if not line: continue
        r = json.loads(line)
        ct = _dt(r.get('commence_time'))
        if ct is None: continue
        _croises_tentes += 1
        _nat_r = mk.natural_key(r.get('home', ''), r.get('away', ''),
                                r.get('commence_time'))
        _cl_uid = cc.cherche_avec_tolerance(_cl_idx, _nat_r)
        ct_croise = _dt((_closing_lines.get(_cl_uid) or {}).get('commence_time')) \
            if _cl_uid else None
        if ct_croise:
            _croises_resolus += 1
            if ct_croise < ct:
                ct = ct_croise
        # CORRIGÉ LE 30/08/2026 : `_records.append(r)` gardait l'ENREGISTREMENT
        # COMPLET en mémoire -- courbes de prix incluses, l'essentiel du volume --
        # alors que mk.build_index() n'utilise que 5 champs légers (uid,
        # home/home_team, away/away_team, commence_time, fixture_id ; voir sa
        # docstring). Sur les 12 partitions actuelles, l'accumulation faisait
        # tuer le script par l'OOM killer du noyau (« Killed », pas une
        # exception Python -- donc rien à intercepter, et le `|| true` du
        # workflow rendait l'échec totalement silencieux : moves_detail_hist.csv
        # figé à 32h, détecté par l'observateur externe le 30/08).
        _records.append({'uid': r.get('uid'),
                         'home_team': r.get('home_team'), 'home': r.get('home'),
                         'away_team': r.get('away_team'), 'away': r.get('away'),
                         'commence_time': r.get('commence_time'),
                         'fixture_id': r.get('fixture_id'),
                         'tournament': r.get('tournament')})
        def pre(seq):
            pts = [(_dt(p[0]), p[1]) for p in (seq or []) if _dt(p[0]) and p[1]]
            return sorted((t, o) for t, o in pts if t < ct)   # PRÉ-MATCH
        h = pre(r.get('home_curve')); a = pre(r.get('away_curve'))
        if len(h) < MIN_PTS or len(a) < MIN_PTS: continue
        uid = r['uid']
        g = games.setdefault(uid, {'_ct': ct,
                                   '_home': r.get('home_team') or r.get('home') or '',
                                   '_away': r.get('away_team') or r.get('away') or '',
                                   '_tour': r.get('tournament') or ''})
        g[r['book']] = {'h': h, 'a': a}
    if _croises_tentes >= 10:
        taux = 100 * _croises_resolus / _croises_tentes
        niveau = "⚠️ " if taux < 30 else ""
        print(f"{niveau}move_audit.load_curves() : commence_time croisé via "
              f"closing_lines sur {_croises_resolus}/{_croises_tentes} "
              f"lignes ({taux:.0f}%).")
    return games, mk.build_index(_records)


def analyse():
    by_uid, by_pair = load_results()
    games, _idx = load_curves()
    rows = []
    # DÉDUPLICATION CANONIQUE (16/08/2026) — deux conventions d'uid ont coexisté du
    # 11/06 au 09/08/2026 (par tournoi, puis par date) et l'horaire annoncé d'un
    # match bouge d'une source à l'autre : 208 uid désignaient un match DÉJÀ compté.
    # mk.build_index() les regroupe (fixture_id, puis joueurs+tournoi+proximité 36h,
    # jamais entre tournois différents). Sans ça, les n sont surévalués d'environ
    # 10 % sur juin-août et les intervalles de confiance trop étroits.
    _vus = set()
    for uid, g in games.items():
        _k = _idx.key_of(uid)
        if _k in _vus:
            continue                      # même match sous un 2e uid
        _vus.add(_k)
        pin = g.get(SHARP)
        if not pin: continue
        ct = g['_ct']; home, away = g['_home'], g['_away']
        # proba Pinnacle home à l'ouverture et à la clôture (pré-match)
        topen = pin['h'][0][0]; tclose = pin['h'][-1][0]
        p_open = prob_home(_at(pin['h'], topen), _at(pin['a'], topen))
        p_close = prob_home(_at(pin['h'], tclose), _at(pin['a'], tclose))
        if p_open is None or p_close is None: continue

        # ══ CORRIGÉ LE 06/09/2026 — BIAIS DE LOOK-AHEAD SUR LE CÔTÉ JOUÉ ══
        #
        # La version précédente déterminait le côté parié AVEC LA CLÔTURE :
        #     shift = p_close - p_open
        #     steam = 'h' if shift > 0 else 'a'
        # puis remontait au premier instant où la proba avait bougé de THR
        # DANS CE SENS-LÀ. Elle regardait donc où la cote avait FINI par
        # aller avant de décider quoi parier — information qui n'existe pas
        # à l'instant du pari.
        #
        # Effet : un mouvement qui part dans un sens puis se retourne ne
        # produit JAMAIS de pari perdant, il est reclassé du côté final. Le
        # biais gonfle mécaniquement le ROI, et il est présent de façon
        # identique sur toute période — d'où le fait qu'un découpage
        # temporel (ROI +13,8 % puis +13,1 % sur deux moitiés, écart de
        # 0,7 point) ne pouvait PAS le détecter. Une réplication stable
        # confirme la stabilité d'un artefact aussi bien que celle d'un
        # signal.
        #
        # Le reste de la chaîne était pourtant propre : _at() est
        # strictement causal (tt <= t, sans interpolation), le prix
        # d'entrée est bien le meilleur prix MOU disponible à t_det, et
        # t_det est bien un premier franchissement. Seul le choix du côté
        # trichait — mais c'est lui qui décide du résultat.
        #
        # Version causale : on balaie les instants dans l'ordre et on
        # s'arrête au PREMIER franchissement de THR, quel que soit son
        # sens. Le côté est celui du mouvement OBSERVÉ À CET INSTANT.
        # C'est exactement ce qu'un détecteur temps réel peut savoir.
        t_det, steam = None, None
        for t, _ in pin['h']:
            ph = prob_home(_at(pin['h'], t), _at(pin['a'], t))
            if ph is None:
                continue
            delta = ph - p_open
            if abs(delta) >= THR:
                t_det = t
                steam = 'h' if delta > 0 else 'a'
                break
        if t_det is None:
            continue
        lead = (ct - t_det).total_seconds() / 60.0
        if lead < MIN_LEAD: continue

        steam_name = home if steam == 'h' else away
        opp_name = away if steam == 'h' else home
        o_open = _at(pin['h'] if steam == 'h' else pin['a'], topen)
        o_close = _at(pin['h'] if steam == 'h' else pin['a'], tclose)
        # AMPLEUR EN % DE COTE — DEUX MESURES, NE JAMAIS LES CONFONDRE
        # (corrigé le 12/09/2026).
        #
        # `mag_odds` est calculée sur o_close : elle contient la CLÔTURE
        # Pinnacle, information qui n'existe pas à l'instant du pari. Elle
        # était pourtant exportée sous le nom neutre `mag_cote_pct` et servait
        # de critère d'entrée dans H14 (validation_report.py) et dans les
        # pistes (pistes_common.py) -- exactement le look-ahead que le
        # suffixe _POSTHOC de `mag_proba_pts_POSTHOC` était censé rendre
        # impossible, mais par une colonne qui, elle, n'avait pas de suffixe.
        # Mesuré sur l'historique : corr(ampleur détection, ampleur finale)
        # = 0,21. Ce ne sont pas deux mesures de la même grandeur.
        #
        # `mag_odds_det` est la MÊME grandeur mesurée à t_det : le
        # raccourcissement déjà réalisé au moment où un détecteur temps réel
        # peut le voir. C'est elle qui sort désormais sous le nom
        # `mag_cote_pct` ; la rétrospective prend le suffixe criard.
        o_det = _at(pin['h'] if steam == 'h' else pin['a'], t_det)
        mag_odds = (o_open - o_close) / o_open if o_open else 0.0   # POSTHOC
        mag_odds_det = ((o_open - o_det) / o_open
                        if (o_open and o_det) else 0.0)             # causale
        # AMPLEUR À LA DÉTECTION, plus |p_close - p_open| : cette colonne
        # sert de critère dans les études (« ampleur < 5 pts »...). La
        # renseigner avec l'amplitude finale y réintroduirait le même
        # look-ahead par la porte de derrière.
        p_det = prob_home(_at(pin['h'], t_det), _at(pin['a'], t_det))
        mag_prob = abs(p_det - p_open) * 100 if p_det is not None else 0.0
        # Conservée pour l'analyse rétrospective, JAMAIS comme critère
        # d'entrée : elle contient la clôture.
        mag_prob_final = abs(p_close - p_open) * 100

        # meilleur prix MOU dispo sur le côté steamé à la détection (le lag)
        entry, entry_book = None, None
        for b in SOFTS:
            s = g.get(b)
            if not s: continue
            pr = _at(s['h'] if steam == 'h' else s['a'], t_det)
            if pr and (entry is None or pr > entry):
                entry, entry_book = pr, b
        if entry is None: continue
        # clôtures côté steamé
        soft_close = _at(g[entry_book]['h'] if steam == 'h' else g[entry_book]['a'], tclose)
        pin_close = o_close
        clv_book = (entry / soft_close - 1) * 100 if soft_close else None     # lag capté sur ce book
        clv_pin = (entry / pin_close - 1) * 100 if pin_close else None        # vs clôture sharp

        # résultat : le côté steamé a-t-il gagné ?
        won = None
        if uid in by_uid:
            won = (by_uid[uid] == ('home' if steam == 'h' else 'away'))
        else:
            w = by_pair.get(_pair(home, away))
            if w: won = (_ln(steam_name) == w)
        pnl = ((entry - 1) if won else -1) if won is not None else None

        rows.append(dict(
            uid=uid, tour=g['_tour'], date=ct.date().isoformat(),
            steame=steam_name, opp=opp_name,
            mag_cote_pct=round(mag_odds_det * 100, 1),
            mag_cote_pct_POSTHOC=round(mag_odds * 100, 1),
            mag_proba_pts=round(mag_prob, 1),
            # Suffixe _POSTHOC volontairement criard : cette colonne contient
            # la clôture Pinnacle et ne peut PAS servir de critère d'entrée.
            # Un `mag_proba_finale` anodin finirait un jour dans un filtre.
            mag_proba_pts_POSTHOC=round(mag_prob_final, 1),
            pin_open=round(o_open, 2), pin_close=round(pin_close, 2),
            lead_min=round(lead, 0), entry_book=entry_book, entry=round(entry, 2),
            soft_close=round(soft_close, 2) if soft_close else None,
            clv_book_pct=round(clv_book, 1) if clv_book is not None else None,
            clv_vs_pin_pct=round(clv_pin, 1) if clv_pin is not None else None,
            steame_gagne=('' if won is None else ('oui' if won else 'non')),
            pnl=round(pnl, 2) if pnl is not None else ''))
    return rows


def report(rows):
    rows.sort(key=lambda r: -r['mag_cote_pct'])
    # CSV détail
    # `mag_cote_pct`       = ampleur en % de cote À LA DÉTECTION (causale)
    # `mag_cote_pct_POSTHOC` = ampleur finale en % de cote, contient la
    #                        clôture Pinnacle, JAMAIS en critère d'entrée
    # `mag_proba_pts`      = ampleur À LA DÉTECTION, utilisable comme critère
    # `mag_proba_pts_POSTHOC` = ampleur finale, rétrospective, JAMAIS en critère
    # `clv_vs_pin_pct`     = utilise pin_close -> rétrospective elle aussi
    #
    # La présence de `mag_cote_pct_POSTHOC` dans l'en-tête est le MARQUEUR de
    # version du CSV : les lecteurs (pistes_common.charge_moves,
    # validation_report.roi_ampli_watch) refusent de tourner sans elle plutôt
    # que de relire un ancien fichier où `mag_cote_pct` valait la valeur
    # rétrospective. Un fallback silencieux redonnerait les chiffres gonflés.
    cols = ['date','tour','steame','opp','mag_cote_pct','mag_cote_pct_POSTHOC',
            'mag_proba_pts',
            'mag_proba_pts_POSTHOC','pin_open','pin_close',
            'lead_min','entry_book','entry','soft_close','clv_book_pct','clv_vs_pin_pct',
            'steame_gagne','pnl','uid']
    with open(OUT, 'w', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=cols); w.writeheader()
        for r in rows: w.writerow({k: r.get(k, '') for k in cols})

    print(f"\n=== {len(rows)} moves analysés (pré-match, {CURVES}) -> {OUT} ===")
    # BINS D'AFFICHAGE SEULEMENT — aucune hypothèse n'est définie ici.
    # Redécoupés le 12/09/2026 : ils portaient sur l'ampleur rétrospective
    # (0-10/10-20/.../50%+) ; l'ampleur à la détection vit dans une plage
    # bien plus resserrée, où l'ancien découpage mettait tout dans la
    # première tranche. Ce tableau est descriptif, il ne sert de critère
    # nulle part.
    bins = [(0,.03,'0-3%'),(.03,.06,'3-6%'),(.06,.10,'6-10%'),
            (.10,.20,'10-20%'),(.20,9,'20%+')]
    print("\nTranche move | n | CLV mou médian | %battent clôture | %côté steamé gagne | ROI suivi")
    for lo, hi, lab in bins:
        grp = [r for r in rows if lo <= r['mag_cote_pct']/100 < hi]
        if not grp: print(f"  {lab:7} | 0"); continue
        clv = [r['clv_book_pct'] for r in grp if r['clv_book_pct'] is not None]
        beat = (100*sum(1 for x in clv if x > 0)/len(clv)) if clv else 0
        wr = [r for r in grp if r['steame_gagne'] in ('oui','non')]
        winp = (100*sum(1 for r in wr if r['steame_gagne']=='oui')/len(wr)) if wr else None
        pnls = [r['pnl'] for r in grp if isinstance(r['pnl'], (int,float))]
        roi = (100*sum(pnls)/len(pnls)) if pnls else None
        cm = f"{st.median(clv):+.1f}%" if clv else "—"
        print(f"  {lab:7} | {len(grp):3} | {cm:>7} | {beat:3.0f}% | "
              f"{('%.0f%%'%winp) if winp is not None else '  —':>5} (n={len(wr)}) | "
              f"{('%+.1f%%'%roi) if roi is not None else '  —'}")

    print("\n--- Top 15 plus gros moves ---")
    print("date       | steamé→ | ampleur | lead | entrée(mou) | clôt | CLV | gagné")
    for r in rows[:15]:
        print(f"  {r['date']} | {r['steame'][:18]:18} | {r['mag_cote_pct']:4.0f}% | "
              f"{r['lead_min']:4.0f}m | {r['entry_book'] or '-':7} {str(r['entry']):>5} | "
              f"{str(r['pin_close']):>4} | {str(r['clv_book_pct'])+'%':>6} | {r['steame_gagne']}")


if __name__ == '__main__':
    report(analyse())
