from pathlib import Path
import ast
root=Path(__file__).resolve().parent
lab=root/'Tennis_Edge_Lab'
guard=lab/'publish_guard.py'
pros=lab/'prospective_v64.py'
js=lab/'freshness.js'
for p in (guard,pros,js):
    if not p.is_file(): raise SystemExit(f'Fichier manquant : {p}')

def patch(path, old, new, marker):
    s=path.read_text(encoding='utf-8')
    if marker in s:
        print('Déjà corrigé :',path)
        return
    if s.count(old)!=1: raise SystemExit(f'Insertion introuvable ou ambiguë dans {path}; aucune écriture dans ce fichier')
    updated=s.replace(old,new,1)
    if path.suffix=='.py': ast.parse(updated,filename=str(path))
    path.write_text(updated,encoding='utf-8')
    print('Corrigé :',path)

patch(guard,'    "economic_v64.json":', '    "prospective_v64.json": ("Tennis_Edge_Lab/live/prospective_v64.json", False, 24, {"status": "not_published", "hypotheses": {}}, "Suivi prospectif V6.4"),\n    "economic_v64.json":', '    "prospective_v64.json":')
patch(pros,"return {'schema_version':1,'selection_id':selection['selection_id'],'hypotheses':stats}","return {'schema_version':1,'selection_id':selection['selection_id'],'generated_at':dt.datetime.now(dt.timezone.utc).isoformat(),'hypotheses':stats}","'generated_at':dt.datetime.now(dt.timezone.utc).isoformat()")
patch(js,"  const GOOD = new Set(['ok', 'ok_sans_date']);", "  const GOOD = new Set(['ok', 'ok_sans_date']);\n  const HISTORICAL = new Set(['economic_v64.json', 'archive/bookmakers_sets_v61/current']);", "  const HISTORICAL = new Set(")
patch(js,"    const bad = rows.filter(entry => !GOOD.has(entry.live));", "    const bad = rows.filter(entry => !GOOD.has(entry.live) && !HISTORICAL.has(entry.file));", "!HISTORICAL.has(entry.file)")
patch(js,"GOOD.has(entry.live) ? '' : 'stale'", "GOOD.has(entry.live) || HISTORICAL.has(entry.file) ? '' : 'stale'", "GOOD.has(entry.live) || HISTORICAL.has(entry.file)")
print('Terminé : vérifie git diff puis crée une branche et une Pull Request.')
