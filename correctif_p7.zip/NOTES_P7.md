# Correctif P7 — segmentation par circuit (12/09/2026)

## Diagnostic

`segment_circuit()` reconnaît `Challenger`, `WTA`, `ATP` et verse tout le
reste dans `autre`. Les Grands Chelems ne portent aucun de ces préfixes dans
les libellés du fournisseur, et tombaient donc intégralement dans le
fourre-tout.

Sur `moves_detail_hist.csv` (n=1296), les seuls libellés non classés :

| libellé | n |
|---|---|
| US Open Men Singles | 112 |
| US Open Women Singles | 101 |
| Wimbledon Men Singles | 55 |
| Berlin | 28 |
| French Open Men Singles | 1 |

Ce n'est **pas une régression** : le trou existe depuis l'origine. Il est
devenu visible quand l'US Open a dominé la population — après le 26/08,
167 moves sur 180 tombaient dans `autre`, rendant la piste illisible.

## Correctif

- Nouveau segment **`Grand Chelem`** (US Open, Wimbledon, French Open,
  Australian Open), testé APRÈS `Challenger` pour qu'un éventuel
  « ATP Challenger … Open » ne soit jamais reclassé.
- Les Grands Chelems ne sont PAS versés dans ATP/WTA : un Grand Chelem
  diffère structurellement d'un ATP 250 (profondeur de marché, format), et
  les mélanger recréerait l'hétérogénéité silencieuse que la piste cherche à
  mesurer. Hommes et femmes regroupés pour tenir n>=30 ; séparables plus tard.
- `libelles_non_classes()` + affichage dans `segments_study.py` : `autre`
  n'est plus muet. Le prochain libellé inconnu se verra au premier rapport
  hebdo, pas trois semaines après.
- `Berlin` (28 moves) reste dans `autre` : son circuit n'est pas déductible
  du libellé, et deviner serait pire que de l'afficher.

## Le protocole gelé n'est pas touché

Le gel du 25/08 porte sur « Challengers moins efficients -> CLV supérieur au
témoin GLOBAL ». La règle `Challenger` est inchangée, le témoin global porte
sur tous les moves. Le test gelé se joue exactement comme avant — seule la
ventilation descriptive gagne un segment. **Aucun nouveau gel nécessaire**
(un test du verifier le contrôle explicitement).

## Résultat immédiat

    témoin global   67.1% (n=1296)
    ATP             n= 399 | 70% (65-74) | méd +4.7%
    WTA             n= 401 | 65% (61-70) | méd +4.2%
    Challenger      n= 199 | 60% (53-66) | méd +2.7%
    Grand Chelem    n= 269 | 71% (65-76) | méd +4.7%
    autre           n=  28 | 71% (53-85) | méd +4.8%  [Berlin]

**Le Challenger sort à 60% [53 ; 66] contre un témoin à 67,1%, à n=199.**
Le témoin est hors de l'intervalle. L'hypothèse pré-spécifiée disait
l'inverse : elle est contredite dans sa DIRECTION, pas seulement non
confirmée. À acter dans `frozen_pistes.json`.

## Application

    unzip -o correctif_p7.zip -d /tmp/p7
    cp /tmp/p7/scripts/. scripts/ -r
    cp /tmp/p7/tests/. tests/ -r
    cp /tmp/p7/verifier_p7.sh . && chmod +x verifier_p7.sh
    bash verifier_p7.sh          # attendu : A ✅  B ✅
    rm -rf /tmp/p7
    git add -A && git commit -m "Correctif P7 : segment Grand Chelem + bucket autre visible"
    git pull --no-rebase --no-edit && git push
