from pathlib import Path
r=Path(__file__).resolve().parent
w=r/'.github/workflows/pages.yml'
s=w.read_text(encoding='utf-8')
if 'scripts/restore_curves.py' not in s:
    s=s.replace('            scripts/oddspapi_v5.py', '            scripts/oddspapi_v5.py\n            scripts/restore_curves.py\n            parts/ARCHIVE_INDEX.json')
if 'Suivi V6.4 sur la base existante' not in s:
    raise SystemExit('ERREUR : étape de suivi V6.4 absente ; vérifier la branche avant de modifier.')
start=s.index('      - name: Suivi V6.4 sur la base existante')
end=s.index('      - name: Construire _site',start)
s=s[:start]+'''      - name: Suivi V6.4 sur la base existante
        env:
          GH_TOKEN: ${{ secrets.GITHUB_TOKEN }}
        run: |
          set -e
          test -s Tennis_Edge_Lab/live/economic_v64.json || { echo "::error::Sélection V6.4 gelée introuvable"; exit 1; }
          python3 - <<'PYCODE'
          import json
          p='Tennis_Edge_Lab/live/economic_v64.json'
          x=json.load(open(p))
          assert x['selected_count']==1627 and len(x['candidates'])==1627
          assert x['policy_version']=='tennis-edge-economic-v64-1'
          print('Sélection gelée V6.4 validée:',x['selection_id'])
          PYCODE
          python3 scripts/restore_curves.py
          python3 - <<'PYCODE'
          from pathlib import Path
          p=Path('parts')
          for prefix in ('hist_book_','hist_set1_','hist_set2_'):
            count=sum(1 for f in p.glob(prefix+'*') if f.suffix in ('.gz','.jsonl'))
            if count==0: raise SystemExit('::error::Partitions '+prefix+' absentes après restauration')
            print(prefix,count,'partitions')
          PYCODE
          python3 Tennis_Edge_Lab/prospective_v64.py
          test -s Tennis_Edge_Lab/live/prospective_v64.json

'''+s[end:]
# Ensure selection file copied even if publish guard didn't restore it
w.write_text(s,encoding='utf-8')
print('Correctif Pages installé. Sélection gelée conservée. Sources restaurées depuis les releases existantes.')
