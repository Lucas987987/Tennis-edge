# Correctifs du 25/08/2026 — suite à l'audit du dépôt

Application : dézipper à la racine du dépôt, puis `bash correctifs_25-08/apply.sh`
(ou copier les fichiers à la main — l'arborescence du zip suit celle du dépôt).

## Fiabilité de la donnée
- **scripts/oddspapi_v5.py** — retry 2/4/8 s dans `api_get`. Rejoue : exceptions
  curl, timeouts, 5xx, réponses non-JSON. Ne rejoue jamais : 429/403-quota
  (QUOTA_HIT protège le budget de 938 req/jour) ni les autres 4xx.
  C'est la protection directe de `closing_reliable`. Env : `ODDS_RETRIES`.
- **scripts/merge_json_state.py** — plus aucune perte silencieuse : les listes
  sans clé (points de trajectoire) fusionnent par empreinte JSON au lieu de
  renvoyer None (qui gardait « nous » et jetait les points de l'autre run).
  Tri chronologique doux quand tous les éléments portent un `ts`.

## Volumétrie (96 % du dépôt était de la donnée sans rétention)
- **scripts/archive_ticks.py + .github/workflows/archive_ticks.yml** — chaque
  jour, les `pm_ticks/kx_ticks *.jsonl.gz` de plus de 7 jours partent dans une
  Release mensuelle `ticks-YYYY-MM`, puis SEULEMENT sont retirés du dépôt.
  Échec d'upload = fichier conservé + run rouge. Récupération :
  `gh release download ticks-2026-08 -p 'pm_ticks_2026-08-20*'`.
  NB : l'historique git ne maigrit pas rétroactivement (ça, c'est
  `git filter-repo`, opération manuelle à froid) — le gain est sur chaque
  checkout et sur la croissance future (~115 Mo/jour mesurés le 25/08).
- **.github/workflows/capture_closing.yml** — le seul workflow qui merge dans
  une boucle de reprise tournait sur un clone superficiel : `fetch-depth: 0` +
  `blob:none` (nécessaire au merge), + sparse-checkout excluant
  pm_ticks/kx_ticks/hist_ (~400 Mo non matérialisés × 150 runs/jour).
  Rollback : supprimer les 3 lignes `sparse-*`.

## Monitoring honnête
- **scripts/pipeline_status.py** — `resultats_derived.json` marqué « externe »
  (produit par capture_closing, plus de fausse alerte ❌ permanente),
  `paper_trades_set2` marqué « optionnel », les `.gz` comptés dans le total
  des partitions, et un mode `--strict` (exit 1 si un livrable critique est
  ABSENT/VIDE).
- **.github/workflows/steam_pipeline.yml** — verrou `--strict` en dernière
  étape, APRÈS le commit/push : le job ne peut plus être vert avec un livrable
  critique manquant, et les données sont persistées avant qu'il rougisse.

## Rigueur statistique
- **scripts/validation_report.py** — bilan tests multiples en fin de rapport :
  les 11 hypothèses gelées listées avec leur date de gel, P(≥1 faux positif)
  ~43 % à alpha=0,05, et la traduction du 1er palier de Holm en « refermés »
  (n=30 → ≥23/30, n=50 → ≥35/50, n=100 → ≥64/100, n=150 → ≥92/150).
  Le test CLV alerté vs témoin reste le critère primaire, jugé seul à 0,05.

## Dette
- **requirements.txt** — épinglé (pandas 3.0.2, openpyxl 3.1.5,
  requests 2.33.1, websocket-client 1.8.0, pytest 8.3.4).
- **tests/test_pure_functions.py + .github/workflows/tests.yml** — 8 tests sur
  les fonctions pures critiques (Wilson, dévig Shin, trim_history,
  norm_nom/paire, natural_key, formule CLV avec invariant anti-inversion de
  côté, fusion JSON). CI sans aucun `|| true`. 8/8 passent sur le dépôt actuel.
- **apply.sh** supprime `probe_markets.yml` (script cible inexistant) et le
  `list_fields.py` de la racine (version cassée ; la corrigée est dans
  scripts/), et tente de restaurer `calibration_books.py` depuis l'historique.

## Volontairement PAS traité (et pourquoi)
- Les 25 `git add -A` restants : le scénario de conflit de l'audit était
  surestimé (un fichier non modifié localement ne se stage pas) ; la vraie
  cause historique — les .pyc — est déjà corrigée. Churn > bénéfice.
- Les 166 `|| true` étape par étape : le verrou `--strict` en sortie couvre le
  mode de panne réel (livrable manquant) sans fragiliser chaque étape.
- 61 `utcnow()` dépréciés, 9 `except:` nus : sans risque en 3.11 épinglé ;
  à traiter le jour d'une migration Python, pas à l'aveugle sur 112 scripts.
