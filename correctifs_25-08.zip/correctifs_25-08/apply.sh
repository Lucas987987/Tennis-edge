#!/bin/bash
# Applique les correctifs du 25/08/2026 — à lancer À LA RACINE du dépôt.
#   bash apply.sh
set -e
[ -d .github/workflows ] || { echo "❌ À lancer à la racine du dépôt Tennis-edge."; exit 1; }
ICI="$(cd "$(dirname "$0")" && pwd)"

echo "— Copie des fichiers corrigés"
mkdir -p tests
cp -v "$ICI"/scripts/oddspapi_v5.py        scripts/
cp -v "$ICI"/scripts/merge_json_state.py   scripts/
cp -v "$ICI"/scripts/pipeline_status.py    scripts/
cp -v "$ICI"/scripts/validation_report.py  scripts/
cp -v "$ICI"/scripts/archive_ticks.py      scripts/
cp -v "$ICI"/.github/workflows/capture_closing.yml .github/workflows/
cp -v "$ICI"/.github/workflows/steam_pipeline.yml  .github/workflows/
cp -v "$ICI"/.github/workflows/archive_ticks.yml   .github/workflows/
cp -v "$ICI"/.github/workflows/tests.yml           .github/workflows/
cp -v "$ICI"/tests/test_pure_functions.py  tests/
cp -v "$ICI"/requirements.txt              .

echo "— Suppressions (audit points 2 et 8)"
git rm -f .github/workflows/probe_markets.yml 2>/dev/null || rm -fv .github/workflows/probe_markets.yml
git rm -f list_fields.py 2>/dev/null || rm -fv list_fields.py   # la version corrigée reste dans scripts/

echo "— Restauration de calibration_books.py depuis l'historique (12 542 octets nuls)"
SHA=$(git log --all --format=%H -- scripts/calibration_books.py 2>/dev/null | while read s; do
        if git show "$s:scripts/calibration_books.py" 2>/dev/null | head -c 64 | grep -q '[^\x00]'; then echo "$s"; break; fi
      done)
if [ -n "$SHA" ]; then
  git show "$SHA:scripts/calibration_books.py" > scripts/calibration_books.py
  python3 -m py_compile scripts/calibration_books.py && echo "  ✅ restauré depuis $SHA (compile)"
else
  echo "  ⚠️ aucun commit sain trouvé dans l'historique local — voir sur GitHub :"
  echo "     https://github.com/Lucas987987/Tennis-edge/commits/main/scripts/calibration_books.py"
fi

echo "— Vérifications"
python3 -m py_compile scripts/oddspapi_v5.py scripts/merge_json_state.py \
  scripts/pipeline_status.py scripts/validation_report.py scripts/archive_ticks.py
python3 tests/test_pure_functions.py

echo
echo "✅ Correctifs appliqués. Revue avec : git status && git diff"
echo "   Puis : git add -A && git commit -m 'Correctifs audit 25/08' && git push"
