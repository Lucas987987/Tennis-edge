# Correctifs audit du 27/08/2026 — application (codespace, racine)

⚠️ Le retrofill (étape 4) ne se relance qu'UNE fois — il modifie
paper_trades_match.jsonl/set1.jsonl en place. Si tu le relances par erreur
sur des fichiers déjà corrigés, c'est sans risque (idempotent : les trades
qui ont déjà 'pnl' sont sautés), mais pas la peine de le refaire.

    unzip correctifs_audit_27-08.zip
    cp correctifs_audit_27-08/scripts/*.py scripts/
    cp correctifs_audit_27-08/tests/test_pure_functions.py tests/
    cp correctifs_audit_27-08/.github/workflows/*.yml .github/workflows/
    rm -f scripts/inspect_curves.py.orig  # rien à faire, juste au cas où
    rm -f note_fiabilite.zip pistes_v1.zip inspect_curves.py 2>/dev/null

    # 1. tests d'abord — doit afficher 12/12
    python tests/test_pure_functions.py

    # 2. rétro-remplissage des 53 paris (UNE FOIS)
    python scripts/retrofill_paper_trades.py            # lecture seule, à lire d'abord
    python scripts/retrofill_paper_trades.py --write     # applique

    # 3. fusion des partitions scindées (UNE FOIS)
    python scripts/merge_split_partitions.py             # lecture seule
    python scripts/merge_split_partitions.py --write      # applique

    rm -rf correctifs_audit_27-08 correctifs_audit_27-08.zip
    git add -A
    git commit -m "Correctifs audit 27/08 : SETTLED sans résultat, journal canal, partitions scindées, stats (Holm/p0/IC), match_key, resultats.json vide"
    git pull --no-rebase --no-edit && git push

---

## Ce qui change, par priorité (ordre de l'audit)

**1. Le bug central (§1.1).** `settle_trade()` ne pose plus `SETTLED` que si
un `pnl` a été calculé — nouvel état `CLOSED_NO_RESULT` sinon, retraité à
chaque cycle (avant : sortait de `OPEN` sans jamais être revisité). L'id des
trades utilise désormais la clé canonique (`match_key`), corrigeant aussi la
dédup inter-cycles (§4.4). Le rétro-remplissage a réparé 45/53 paris
existants : **le vrai ROI forward est négatif** (match −21,2 % IC
[−80,4,+37,9], set1 −11,8 % IC [−73,4,+49,8]) — non confirmé, mais ce n'est
plus zéro données réelles.

**2. Le journal canal (§1.2).** Nouveau lecteur dédié `report_canal()`,
joint au CLV via `canal_clv_detail.csv`. ROI réel : +20,6 % mais IC95
[−20,7 %, +62,0 %] — large, non confirmé. (Un bug d'unités trouvé et
corrigé EN ÉCRIVANT cette fonction : IC95 [+20,2,+21,0] au premier essai
était invraisemblable — `sd` en unités de mise brutes mélangé avec `roi` en
pourcentage.)

**3. Partitions scindées (§2.1).** Cause racine : mon propre patch d'hier
(`PM_GLOB`/`KX_GLOB` en `*.jsonl*`, qui avale aussi les `.gz`). Motif
corrigé, `load_partitions()` ne tranche plus jamais en silence (comparaison
de taille, avertissement + lecture des deux si suspect), `open_any()`
corrigé pour ne plus lire un `.gz` comme texte brut. `merge_split_partitions.py`
récupère 303 167 lignes actuellement invisibles (pm_ticks + kx_ticks du
26/08).

**4. Volumétrie (§2.2/§2.3).** `capture_closing.yml` : `git add -A` remplacé
par une exclusion par pathspec des partitions des collecteurs
(`:!parts/pm_ticks_*' ':!parts/kx_ticks_*'`), garde-fou 95 Mo ajouté (même
principe que kalshi/polymarket). Le watchdog d'hier soir est intact — vérifié
explicitement (j'ai failli l'écraser une seconde fois en travaillant sur une
copie locale périmée, repéré avant application).

**5. La branche Polymarket orpheline (§4.1).** Nouveau workflow quotidien
`polymarket_studies.yml` qui appelle les 5 scripts jamais exécutés
(`polymarket_flow`, `polymarket_leadlag`, `polymarket_studies`,
`pm_calibration_track`, `pm_observations`). Testés sans crash immédiat sur
les vraies données (lents sur le volume réel, timeout 600s prévu). La
sentinelle (`repo_sentinel.py`) est re-câblée dans `pistes_weekly.yml` —
j'avais moi-même écrasé mon ajout d'hier avec un patch suivant construit sur
une copie locale périmée.

**6. Le pont CLV→PnL, enfin mesuré (§3.5).** Nouveau script
`pnl_vs_clv_study.py`. Résultat honnête : **aucune tranche de cote n'a un IC
excluant zéro** — le pont central du dispositif n'est pas démontré à ce n,
malgré la doctrine. Réserve non résolue : `entry_odds` = max de ~20 books,
biais mécanique possible (documenté dans le script, pas corrigé).

**7. Statistique (§3.1-3.4, 3.6, 3.7).**
- Critère primaire requalifié EXPLORATOIRE (gel rétroactif ≠ pré-enregistrement).
- Test à DEUX échantillons (`_p_deux_proportions`) au lieu d'un test contre
  p0 traité comme constante connue — propage l'incertitude de p0 (réserve
  assumée et documentée : la référence inclut encore le sous-groupe testé,
  l'exclusion complète reste à faire).
- **Verdict gelé à la première lecture qualifiante** (`verdicts_geles.json`) :
  une hypothèse n'est plus jamais retestée une fois n≥30 atteint — règle le
  FWER gonflé par les runs quotidiens. Résultat sur les données actuelles :
  5 verdicts gelés, 1 rejet (« ouverture précoce », 90 % vs 72,6 %, p=0,0007).
- IC du P&L : bootstrap percentile (graine fixe, reproductible) + `stdev`
  au lieu de `pstdev`. `n_needed()` explicitement recadré en ordre de
  grandeur, jamais un objectif.
- ROI par book supprimé sous n=30 (affichait des « ROI +137,5 % » sur n=2).
- Réfutation `value_clv_report.json` remontée explicitement dans le rapport.

**8. `match_key.py` (§4.3).** Docstring d'en-tête corrigé (heure → journée).
Seuil des tokens abaissé à 2 lettres (Wu/Li/Xu/An ne s'effondrent plus en
ensemble vide), avec filet si même ça échoue. Fusion par inclusion d'ensemble
pour les prénoms abrégés (« T. Griekspoor » ↔ « Tallon Griekspoor ») —
**bug trouvé et corrigé en écrivant ce correctif** : ma première version
comparait les paires de joueurs comme un bloc plat, qui échouait
systématiquement y compris sur le cas qu'elle devait couvrir ; corrigé avec
un appariement bipartite joueur par joueur. 4 tests dédiés, dont un cas de
garde (un seul joueur partagé ne doit jamais fusionner).

**9. `resultats.json` / `resultats_fast.json` vides (§1.3).** Repli honnête
sur `resultats_derived.json` (1400+ résultats à jour) quand la source
primaire (Sackmann injoignable / api_fast vide) ne produit rien. Le champ
`source` dit désormais la vérité sur l'origine des données. index.html
n'est PAS touché (1 Mo, 120 fonctions, risque disproportionné pour ce soir).

## Décisions volontairement PAS prises ce soir

- **CAPTURE_BOOKS sans williamhill** : williamhill apparaît dans les
  journaux mais est absent de la liste (racine ET override workflow), sans
  commentaire expliquant pourquoi. Pas rajouté à l'aveugle — à trancher
  avec le contexte que je n'ai pas.
- **`elo_ratings.json`** : écrit par `elo_model.py`, lu nulle part (ni
  scripts ni index.html). Pas supprimé — je ne connais pas le rôle exact
  d'`elo_model.py`. À toi de voir si le script sert encore à autre chose.
- **`index.html`** : appelle `api.the-odds-api.com`, mais c'est un widget
  autonome (clé perso de visiteur, quota séparé), pas une source
  concurrente à OddsPapi. Vérifié, non modifié.
- **§3.2, réserve assumée** : le test à deux échantillons ne retire pas
  encore le sous-groupe testé de l'estimation de p0 (auto-référencement
  partiel). Demanderait de retracer, pour chaque hypothèse, quelles lignes
  de moves_detail_hist.csv la composent — pas toutes n'en viennent. Documenté
  dans le code, pas résolu.
