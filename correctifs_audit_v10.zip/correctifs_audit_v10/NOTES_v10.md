# Correctifs audit v10 (29/08/2026) — URGENT, opérationnel

⚠️⚠️ La validation est à l'arrêt depuis ~18h selon l'audit. Ce paquet corrige
la cause probable ET ajoute un observateur qui n'aurait plus jamais pu manquer
cet incident. `verifier.sh` reste obligatoire, et il te rappelle une étape que
je ne peux pas faire moi-même.

    unzip correctifs_audit_v10.zip
    cp correctifs_audit_v10/.github/workflows/*.yml .github/workflows/

    # ── ÉTAPE OBLIGATOIRE ──
    bash correctifs_audit_v10/verifier.sh
    # doit afficher "TOUT EST EN PLACE (5 contrôles passés)"

    rm -rf correctifs_audit_v10 correctifs_audit_v10.zip
    git add -A
    git commit -m "Audit v10 URGENT : division par zéro dans Q3 corrigée (§AV), bloc Q3 rendu incapable de tuer le job, observateur externe créé (fraîcheur des livrables, indépendant de steam_pipeline)"
    git pull --no-rebase --no-edit && git push

---

## ⚠️ Étape que je ne peux pas faire à ta place

Sur GitHub : **onglet Actions → workflow "Steam Pipeline" → dernier run du
29/08 à 00h15 UTC**. Regarde où il s'est arrêté :
- **le run n'apparaît pas du tout** → le cron ne s'est pas déclenché, cause
  différente de celle traitée ce soir, à creuser autrement ;
- **rouge sur une étape avant "Commit résultats"** → c'est le scénario
  ci-dessous, le correctif de ce soir empêche la récidive ;
- **rouge sur le push lui-même** → le message "❌ PUSH ÉCHOUÉ" du bloc de
  commit dit quoi faire, le commit local est récupérable au run suivant.

Vérifie aussi **`polymarket_studies.yml`** de la même façon —
`polymarket_studies_status.json` n'existe toujours pas non plus.

## Ce qui s'est probablement passé

`capture_quality.py` imprime `n=0 (pas de recouvrement)` quand une
comparaison n'a aucun chevauchement. Le bloc Q3 capture ce `0` littéral
dans `n_total`, et `${n_total:-1}` (la protection existante) ne couvre que
la chaîne VIDE, pas le littéral `"0"`. Reproduit exactement :

    n_ecarts=0 n_total=0 -> ZeroDivisionError -> bash -e (le défaut GitHub
    Actions) tue l'étape -> le job s'arrête AVANT l'étape de commit ->
    tout le travail des étapes précédentes (résultats, journaux,
    moves_detail_hist.csv) n'est jamais committé, sans aucun message
    d'erreur visible ailleurs que dans le log de ce run précis.

Deux corrections complémentaires, testées :

1. **La cause précise** : `[ "$n_total" -gt 0 ] || n_total=1` avant la
   division -- ferme le trou exact.
2. **La protection générale** : `set +e` en tête de tout le bloc Q3. Testé
   avec une erreur PIRE que l'originale (une valeur non numérique
   provoquant un `NameError` Python) -- le bloc continue et se termine en
   code 0 malgré l'erreur. N'importe quelle ligne future de ce bloc qui
   viendrait à échouer ne pourra plus, à elle seule, faire perdre une
   journée de résultats.

Petit bonus trouvé en repassant sur ce bloc : le message d'alerte
référençait `$n` et `$seuil`, deux variables qui n'existent nulle part
dans ce contexte (le message sortait vide). Corrigé en `$n_ecarts`,
`$pct_ecarts`, `$seuil_pct` -- les bons noms.

## L'observateur externe

`.github/workflows/observateur_externe.yml` (nouveau, isolé, ne touche à
rien d'existant). Tourne à 09h30 UTC -- après les deux workflows qu'il
surveille, à une heure différente d'eux pour ne pas partager une éventuelle
panne d'infrastructure commune. Vérifie l'âge du dernier COMMIT (via
`git log`, pas la date de checkout) de quatre fichiers témoins
(`pipeline_status.md`, `moves_detail_hist.csv`, `set_results.json`,
`polymarket_studies_report.md`) contre un seuil de 36h. Un run rouge ICI
est l'alerte elle-même -- ce workflow ne répare rien, il constate ce que
`steam_pipeline` ne peut structurellement pas constater sur lui-même
(un moniteur qui meurt avant d'écrire son propre constat).

Testé sur un vrai dépôt git avec trois cas (fichier frais, fichier vieux de
89h avec un commit backdaté, fichier absent) -- les trois correctement
détectés.

## Ce qui n'a pas été fait ce soir, volontairement

- **Le gros réaménagement structurel** (commit AVANT les étapes de
  diagnostic, pas seulement après) -- l'audit le présente comme "et
  surtout", plus important que les correctifs immédiats. Vrai, mais c'est
  une réorganisation profonde d'un fichier de 270+ lignes que je ne peux
  pas tester de bout en bout sans faire réellement tourner le workflow --
  trop risqué à faire sous pression ce soir avec les outils dont je
  dispose. Les deux correctifs livrés (division par zéro + `set +e`)
  traitent la cause précise ET la classe de risque plus large sans
  toucher à la structure du fichier.
- **`pipeline_status.md` ajouté aux livrables internes surveillés** --
  l'audit note lui-même que ce contrôle spécifique n'aurait pas détecté CET
  incident (le job meurt avant d'atteindre ce point). L'observateur externe
  couvre exactement ce trou, indépendamment. Ajout marginal pour d'autres
  modes de panne, pas fait ce soir.
- **`repo_sentinel.py`** (remarque secondaire de l'audit, pas une action
  numérotée) -- orphelin dans ma copie locale, mais je l'avais câblé il y
  a deux jours et je ne peux pas confirmer si c'est ma copie qui a divergé
  ou si la production a vraiment régressé. Pas touché pour ne pas risquer
  une correction basée sur une fausse prémisse.

## Tests : 13/13 (inchangé -- ce paquet ne touche que des workflows)
