#!/usr/bin/env bash
# verifier.sh (v10) — contrôle automatique post-application (29/08/2026).
#
# Usage : bash verifier.sh   (à la racine du dépôt, APRÈS les cp)

set -uo pipefail
ECHECS=0

verif() {
    local fichier="$1" motif="$2" description="$3"
    if [ ! -f "$fichier" ]; then
        echo "❌ $fichier : FICHIER ABSENT"
        ECHECS=$((ECHECS+1))
        return
    fi
    if grep -q "$motif" "$fichier"; then
        echo "✅ $fichier : $description"
    else
        echo "❌ $fichier : $description -- MOTIF ABSENT ($motif)"
        ECHECS=$((ECHECS+1))
    fi
}

echo "=== Vérification des correctifs audit v10 (29/08/2026) ==="
echo

verif .github/workflows/steam_pipeline.yml '\[ "\$n_total" -gt 0 \]' "§AV : protection contre le littéral 0 (division par zéro)"
verif .github/workflows/steam_pipeline.yml "set +e" "§AV : le bloc Q3 ne peut plus tuer le job"
verif .github/workflows/steam_pipeline.yml '\$n_ecarts écarts' "§AV : message d'alerte avec les bonnes variables"
verif .github/workflows/observateur_externe.yml "SEUIL_H=36" "observateur externe créé"
verif .github/workflows/observateur_externe.yml "git log -1 --format=%ct" "observateur : fraîcheur par commit, pas par mtime"

echo
if [ "$ECHECS" -eq 0 ]; then
    echo "✅✅✅ TOUT EST EN PLACE (5 contrôles passés). Sûr de committer."
    echo
    echo "⚠️  RAPPEL IMPORTANT (non automatisable) : va voir l'onglet Actions"
    echo "   de GitHub -> workflow 'Steam Pipeline' -> dernier run du 29/08"
    echo "   00h15 -> identifie où il s'est arrêté. Le correctif de ce soir"
    echo "   empêche la récidive, mais ne répare pas le run déjà manqué."
    exit 0
else
    echo "❌❌❌ $ECHECS CONTRÔLE(S) EN ÉCHEC. NE PAS COMMITTER avant d'avoir compris pourquoi."
    exit 1
fi
