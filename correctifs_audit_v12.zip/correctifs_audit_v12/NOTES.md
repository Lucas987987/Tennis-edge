# Correctif URGENT — audit v12 (29/08/2026)

⚠️⚠️ Régression de ma propre session précédente : le budget API a doublé au
lieu de baisser. `verifier.sh` reste obligatoire, et cette fois son propre
contenu a été retesté dans les deux sens (propre → vert, bug réintroduit →
rouge) avant livraison, après avoir trouvé un premier contrôle cassé.

    unzip correctifs_audit_v12.zip
    cp correctifs_audit_v12/scripts/*.py scripts/
    cp correctifs_audit_v12/.github/workflows/*.yml .github/workflows/

    # ── ÉTAPE OBLIGATOIRE ──
    bash correctifs_audit_v12/verifier.sh
    # doit afficher "TOUT EST EN PLACE (6 contrôles passés)"

    python tests/test_pure_functions.py      # doit afficher 13/13

    rm -rf correctifs_audit_v12 correctifs_audit_v12.zip
    git add -A
    git commit -m "URGENT : NameError extended/dernier_extended entre fetch_odds et main corrigé (§BC, budget API 696->314 req/jour), filtre matchs commencés (§BD.1, ->197/jour), budget mesuré (§BE), verdicts_geles.json 5e témoin"
    git pull --no-rebase --no-edit && git push

---

## Ce qui s'est passé

Hier soir, `_is_extended_pass()` a été corrigée pour se baser sur l'état
persisté plutôt que l'horloge -- la logique elle-même était juste, testée,
et l'est toujours. Le défaut : `extended` et `dernier_extended` étaient
calculés dans `fetch_odds()` mais l'écriture qui en dépendait vivait dans
`main()`, une fonction différente. `NameError` à l'exécution, avalé par un
`except Exception` générique qui ne loggait qu'un message anodin.

Conséquence en cascade : `capture_state.json` plus jamais réécrit ->
`last_extended_at` jamais posé -> chaque run repart de zéro -> chaque passe
redevient "étendue" (le comportement voulu au tout premier run, devenu
permanent) -- **139 runs/jour en passe étendue au lieu de 12, +38% du
budget au lieu de -9% visé.**

## Le correctif (§BC)

Plutôt que de faire remonter `extended`/`dernier_extended` à travers les 5
`return` de `fetch_odds()` (risque d'en oublier un -- le bug même de cette
passe), tout le mécanisme reste maintenant À L'INTÉRIEUR de `fetch_odds()`,
dans son propre fichier (`extended_state.json`), découplé de
`capture_state.json` qui redevient un heartbeat pur. Testé de bout en bout
sans faire de vrais appels API : premier appel force la passe étendue et
l'écrit, un deuxième appel 5 minutes plus tard ne redéclenche plus.

## §BD.1 -- le plus gros gain restant

La passe standard batchait TOUS les matchs du jour, y compris ceux
commencés depuis des heures -- la passe étendue filtrait déjà sur
l'horizon futur, la passe standard ne filtrait rien. Filtre ajouté (marge
de 2h, même convention que le filtre équivalent de `write_matches_json`).
Testé sur 4 cas : à venir, dans la marge, à 3h (hors marge), à 6h (bien
hors marge) -- tous corrects.

## §BE -- le budget mesuré, pas estimé

`nreq` était déjà calculé et déjà imprimé dans le log ("3 req...") --
extrait par expression régulière plutôt que de changer la signature de
`fetch_odds()`. `requetes_ce_run` et `requetes_cumul_jour` (remis à zéro
chaque nouveau jour UTC) ajoutés à `capture_state.json`. Testé sur les 4
formats réels de `remaining` et sur les 2 cas de cumul (même jour, jour
différent).

`verdicts_geles.json` ajouté comme 5e témoin à `observateur_externe.yml`
-- mais avec un contrôle d'EXISTENCE séparé, pas le seuil de fraîcheur des
4 autres (ce fichier ne se met à jour que quand une hypothèse franchit
N_CIBLE, cadence légitimement irrégulière -- le même seuil aurait produit
des fausses alertes en continu).

## Le bug trouvé dans mon propre `verifier.sh`, avant livraison

Le premier contrôle censé vérifier l'absence du bug d'origine utilisait un
motif multi-lignes (`grep` avec des `\n` littéraux) -- **il ne détectait
jamais rien**, testé en réinjectant le vrai code bugué d'hier et en
constatant que le contrôle restait vert. Remplacé par un test scopé à la
fonction `fetch_odds()` via `awk`, puis retesté dans les deux sens (propre
→ vert, bug réintroduit → rouge) avant d'empaqueter. La leçon du jour,
appliquée à mon propre outil de vérification plutôt qu'au code du dépôt.

## Budget attendu après ces deux correctifs

    696 req/jour (bug actif) -> 314 (§BC seul) -> ~197 (§BC + §BD.1)

Soit environ -61% par rapport à avant les changements d'hier matin, sans
rien perdre en couverture.

## Tests : 13/13 (inchangé)
