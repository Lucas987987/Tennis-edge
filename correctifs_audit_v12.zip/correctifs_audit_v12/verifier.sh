#!/usr/bin/env bash
# verifier.sh — contrôle automatique post-application (29/08/2026).
# URGENT : répare une régression qui doublait le budget d'appels API.
#
# Usage : bash verifier.sh   (à la racine du dépôt, APRÈS les cp)

set -uo pipefail
ECHECS=0

verif() {
    local fichier="$1" motif="$2" description="$3"
    if [ ! -f "$fichier" ]; then
        echo "❌ $fichier : FICHIER ABSENT"
        ECHECS=$((ECHECS+1))
        return
    fi
    if grep -q "$motif" "$fichier"; then
        echo "✅ $fichier : $description"
    else
        echo "❌ $fichier : $description -- MOTIF ABSENT ($motif)"
        ECHECS=$((ECHECS+1))
    fi
}

verif_absent() {
    local fichier="$1" motif="$2" description="$3"
    if [ ! -f "$fichier" ]; then
        echo "❌ $fichier : FICHIER ABSENT"
        ECHECS=$((ECHECS+1))
        return
    fi
    if grep -q "$motif" "$fichier"; then
        echo "❌ $fichier : $description -- MOTIF ENCORE PRÉSENT (doit être absent)"
        ECHECS=$((ECHECS+1))
    else
        echo "✅ $fichier : $description"
    fi
}

echo "=== Vérification -- correctif URGENT budget API (29/08/2026) ==="
echo

verif scripts/capture_closing.py "EXTENDED_STATE_FILE" "§BC : extended_state.json, fichier dédié"
echo "=== Test scopé (le motif multi-lignes naïf ne fonctionne pas avec grep) ==="
if [ -f scripts/capture_closing.py ]; then
    n_dans_fetch_odds=$(awk '/^def fetch_odds/{p=1} /^def main/{p=0} p' scripts/capture_closing.py \
        | grep -v "^\s*#" | grep -c "capture_state.json" || true)
    if [ "$n_dans_fetch_odds" -eq 0 ]; then
        echo "✅ scripts/capture_closing.py : §BC : fetch_odds() ne touche plus capture_state.json (hors commentaires)"
    else
        echo "❌ scripts/capture_closing.py : §BC : fetch_odds() référence encore capture_state.json en code réel -- MOTIF ENCORE PRÉSENT"
        ECHECS=$((ECHECS+1))
    fi
else
    echo "❌ scripts/capture_closing.py : FICHIER ABSENT"
    ECHECS=$((ECHECS+1))
fi
verif scripts/capture_closing.py "cutoff_standard" "§BD.1 : filtre des matchs déjà commencés"
verif scripts/capture_closing.py "requetes_cumul_jour" "§BE : budget mesuré, pas estimé"
verif scripts/capture_closing.py "import json, datetime, os, re, sys" "import re ajouté"
verif .github/workflows/observateur_externe.yml "verifier_existence" "§BE : verdicts_geles.json en 5e témoin (existence seule)"

echo
echo "=== Test critique : le NameError d'origine ne peut plus se reproduire ==="
python3 -c "
import re
for s in ['5 req (OddsPapi v5)', '2 req (aucun match)', '0 (aucun tournoi)', '?']:
    m = re.match(r'^(\d+)', s)
    assert (int(m.group(1)) if m else 0) >= 0
print('✅ parsing de nreq robuste sur les 4 formats réels de remaining')
"

echo
if [ "$ECHECS" -eq 0 ]; then
    echo "✅✅✅ TOUT EST EN PLACE (6 contrôles passés). Sûr de committer."
    echo
    echo "Rappel : au prochain run réel, vérifier capture_state.json --"
    echo "il doit contenir requetes_ce_run et requetes_cumul_jour, et la"
    echo "sortie du run doit alterner entre PASSE ÉTENDUE et passe standard,"
    echo "pas afficher PASSE ÉTENDUE à chaque fois."
    exit 0
else
    echo "❌❌❌ $ECHECS CONTRÔLE(S) EN ÉCHEC. NE PAS COMMITTER avant d'avoir compris pourquoi."
    exit 1
fi
