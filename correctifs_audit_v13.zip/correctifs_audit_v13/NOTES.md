# Correctifs audit v13 (29/08/2026) — application (codespace, racine)

⚠️ `verifier.sh` reste obligatoire. Cette fois chacun de ses 13 contrôles a
été testé dans les deux sens (application propre → vert, bug réintroduit →
rouge) avant livraison -- la leçon d'hier soir sur mon propre outil de
vérification, appliquée dès le départ plutôt qu'après coup.

    unzip correctifs_audit_v13.zip
    cp correctifs_audit_v13/scripts/*.py scripts/
    cp correctifs_audit_v13/.github/workflows/*.yml .github/workflows/

    # ── ÉTAPE OBLIGATOIRE ──
    bash correctifs_audit_v13/verifier.sh
    # doit afficher "TOUT EST EN PLACE (13 contrôles passés)"

    python tests/test_pure_functions.py      # doit afficher 13/13

    rm -rf correctifs_audit_v13 correctifs_audit_v13.zip
    git add -A
    git commit -m "§BF : écriture atomique (capture_state, closing_lines, extended_state, active_tournaments, early_open_state) -- §BG : compteur nreq juste sur fixtures/today -- §BH : observateur externe (seuil 30h, blob:none, timeout 10min)"
    git pull --no-rebase --no-edit && git push

---

## §BF — le fichier vide était pire que ce que je pensais

`open(chemin, 'w')` tronque AVANT la première écriture. Le NameError d'hier
soir a explosé APRÈS la troncature de `capture_state.json` -- le fichier
n'était pas "plus réécrit", il a été VIDÉ, committé à 0 octet.

`ov.ecriture_atomique()` (nouveau, dans `oddspapi_v5.py` -- déjà importé
comme `ov` dans 48 scripts, aucun nouvel import nécessaire ailleurs plus
tard) : écrit dans un `.tmp`, puis `os.replace()` -- atomique au niveau du
système de fichiers. Testé en reproduisant EXACTEMENT le scénario de panne
(une exception au milieu de la sérialisation JSON) : le fichier original
reste bit pour bit identique, jamais tronqué.

**Bug trouvé en testant mon propre correctif** : la première version
laissait le fichier `.tmp` sur disque en cas d'échec -- un résidu qui
aurait pu lui-même se faire embarquer par un `git add -A` non filtré,
exactement le même risque que celui corrigé. Ajouté un nettoyage (`finally`
implicite via `except` + `os.remove`), retesté : plus aucun résidu, dans
aucun des deux cas.

Appliqué ce soir aux 5 fichiers nommés par l'audit : `capture_state.json`,
`closing_lines.json` (1255+ matchs, l'accumulateur central -- la cible la
plus précieuse), `extended_state.json`, `active_tournaments.json`,
`early_open_state.json`. **~35 autres scripts du dépôt utilisent encore le
motif non atomique** -- non convertis ce soir (risque de réécriture à
grande échelle sous pression), mais l'utilitaire est prêt pour eux dès
qu'une prochaine passe s'y attaque.

## §BG — le compteur qui masquait son propre gain

`nreq = 1` était posé avant même de savoir si `fixtures_today_cached()`
ferait un vrai appel réseau ou servirait depuis le cache -- le compteur
ajouté hier pour MESURER le gain de la piste A absorbait silencieusement
79 requêtes/jour de ce même gain. `fixtures_today_cached()` renvoie
maintenant `(fixtures, appel_reel)` ; l'appelant n'incrémente `nreq` que si
`appel_reel` est vrai. Testé sur les deux cas (cache frais, cache périmé) :
le drapeau est correct dans les deux.

## §BH — les deux lignes reportées de la passe 11

`SEUIL_H` 36 → 30 (un run quotidien manqué laisse un écart de ~33h, sous
l'ancien seuil -- il fallait DEUX runs manqués pour que l'alerte se
déclenche). `filter: blob:none` + `timeout-minutes: 10` sur le checkout de
l'observateur, cohérent avec les dix autres workflows qui l'ont déjà.
Vérifié : le nouveau seuil détecte bien 1 run manqué (33,2h > 30h) sans
créer de fausse alerte sur le cas sain (~9h15 d'écart normal).

## §BI — rien à corriger

L'audit confirme lui-même que `verifier_existence()` fait exactement son
travail : `verdicts_geles.json` a disparu une troisième fois, et l'audit
suggère de vérifier demain matin s'il est revenu après le run de
`steam_pipeline` de cette nuit. Pas une action de code, un point de suivi.

## §BJ — informationnel, aucune action

L'audit qualifie lui-même les deux observations (extended_state.json posé
avant confirmation du résultat ; risque de doublon sur des runs
concurrents) de « négligeable » et « pas grave » -- des choix assumés, pas
des oublis. Rien codé, comme suggéré.

## Tests : 13/13 (inchangé)
