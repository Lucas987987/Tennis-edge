#!/usr/bin/env python3
"""
Capture les closing lines Pinnacle pour les matchs qui commencent bientôt.

Déclenché par le worker Cloudflare (repository_dispatch) au bon moment :
- snapshot T-25 (marge de sécurité contre le délai GitHub)
- snapshot T-10 (vrai dernier instant)
Le cron horaire (minute 7) sert seulement à découvrir les matchs du jour.

Le closing de référence pour le CLV = le snapshot le PLUS TARDIF disponible,
à condition qu'il soit dans la fenêtre fiable (<= CLOSING_MAX_MINS avant le match).
Sinon le match est marqué closing_reliable=False et doit être EXCLU du CLV.
"""
import json, datetime, os, re, sys
import oddspapi_v5 as ov  # client commun OddsPapi v5 (RapidAPI, appels curl)

# ─────────────────────────────────────────────────────────────────────────
# Source de cotes : OddsPapi v5 via RapidAPI (module oddspapi_v5).
# - auth headers RapidAPI (secret RAPIDAPI_KEY), appels curl
# - tennis = sportId 12 ; marché vainqueur = marketId 121 (géré par le client)
# - cotes BATCHÉES par fixtureIds : tous les matchs imminents en 1 requête
# ─────────────────────────────────────────────────────────────────────────
TENNIS_SPORT_ID = ov.TENNIS_SPORT_ID   # 12

# Books capturés (Pinnacle = cœur ; les autres pour matches_oddspapi.json / analyses).
CAPTURE_BOOKS = os.environ.get('CAPTURE_BOOKS', 'pinnacle,unibet,bwin,betsson')

# Filtre circuit principal : on suit les tournois dont le categorySlug ∈ cette liste
# ET dont le nom contient "singles" (exclut doubles / challenger / itf / utr / wta-125k).
# Élargissable via env (ex "atp,wta,wta-125k,challenger") pour gonfler le volume CLV.
# CATÉGORIES SUIVIES — liste BLANCHE, jamais une liste noire.
# Le catalogue OddsPapi contient 9 670 tournois répartis en 25 categorySlug,
# dont « simulated-reality », « virtual-tennis » et « electronic-leagues » :
# des matchs SIMULÉS, plus de 340 tournois. Une liste noire finirait par en
# laisser passer un au premier slug ajouté côté fournisseur.
#
# Élargi à « challenger » le 21/08/2026. Mesuré ce jour-là sur les fixtures
# réelles (203 fixtures, 4 SRL écartées) :
#     itf-men   49 · utr-men 46 · challenger 34 · itf-women 32
#     utr-women 28 · atp       6 · wta         4   <- seuls suivis
# Soit 10 matchs suivis sur 199. Tout élargir multiplierait le volume par 20.
# « challenger » seul fait passer à 44 matchs/jour, facteur 4,4 :
#   • Kalshi les cote (KXATPCHALLENGERMATCH, KXWTACHALLENGERMATCH) ;
#   • les books mous y sont bien plus lents qu'en ATP — là où le canal a le
#     plus de valeur ;
#   • les joueurs restent classés, donc présents dans les Elo Tennis Abstract.
# ÉCARTÉS volontairement : l'ITF (81 matchs/jour, marchés minces des deux
# côtés, joueurs souvent absents des classements) et UTR (74 matchs/jour,
# circuit privé qu'aucun de nos books de référence ne cote sérieusement).
TRACK_CATEGORY_SLUGS = set(
    s.strip().lower() for s in os.environ.get('TRACK_CATEGORY_SLUGS', 'atp,wta,challenger').split(',') if s.strip()
)
# Catégories INTERDITES quoi qu'il arrive : matchs simulés ou virtuels. Elles
# ne doivent jamais entrer, même si quelqu'un les ajoute par erreur à la
# variable d'environnement.
SLUGS_INTERDITS = {'simulated-reality', 'simulated-reality-women',
                   'virtual-tennis', 'virtual-tennis-in-play',
                   'electronic-leagues'}
# Garde-fou de volume : au-delà, on ALERTE sans bloquer. Découvrir une
# surcharge après coup (requêtes API, closing_lines.json, courbes) coûte cher ;
# la voir dans le log au moment où elle arrive coûte une ligne.
MAX_TOURNOIS_ATTENDUS = int(os.environ.get('MAX_TOURNOIS_ATTENDUS', '25'))
REQUIRE_SINGLES = os.environ.get('REQUIRE_SINGLES', '1') not in ('0', 'false', 'False')

# Nb max de fixtureIds par requête odds/main (batch). Marge large sous la limite d'URL.
FIDS_PER_REQUEST = int(os.environ.get('FIDS_PER_REQUEST', '40'))

# Fichier listant les tournois actifs découverts (mis à jour ~1×/jour).
# Format : { "2775": {"name":"ATP Stuttgart","cat":"ATP"}, ... }
ACTIVE_TOURNAMENTS_FILE = 'active_tournaments.json'

# (plus de table joueurs locale : les noms viennent directement de l'API v5)
PLAYERS_FILE = 'players_oddspapi.json'

CLOSING_FILE = 'closing_lines.json'

# Stockage des points d'historique (trajectoire). Plus le seuil de mouvement est bas,
# plus on garde de points fins pour voir l'évolution des cotes en direct. On stocke un
# point si la cote a bougé de > STORE_MOVE_PCT, OU si > STORE_MAX_GAP_MIN depuis le dernier.
STORE_MOVE_PCT    = float(os.environ.get('STORE_MOVE_PCT', '0.004'))   # 0,4 % (était 1 %)
STORE_MAX_GAP_MIN = float(os.environ.get('STORE_MAX_GAP_MIN', '30'))   # plancher temporel
HISTORY_CAP       = int(os.environ.get('HISTORY_CAP', '400'))          # points max/match (élagage intelligent, voir trim_history)

# Hygiène du fichier closing_lines.json (qui grossit avec la capture dense) :
# - un match TERMINÉ n'a plus besoin de sa trajectoire dense (son CLV est figé dans
#   clv_history.jsonl) → on compresse son historique à FINISHED_HISTORY_CAP points
#   (ouverture + closing + milieu échantillonné conservés).
# - les entrées de plus de PURGE_DAYS jours sont retirées (CLV déjà permanent ailleurs).
FINISHED_HISTORY_CAP = int(os.environ.get('FINISHED_HISTORY_CAP', '30'))
PURGE_DAYS           = int(os.environ.get('PURGE_DAYS', '60'))

# Fenêtres de capture (minutes avant le match). Resserrées car le timing est
# maintenant garanti par le worker Cloudflare (plus de boucle aveugle */10).
CAPTURE_WINDOWS = [
    (20, 32, 't25'),   # cible T-25 : marge de sécurité, absorbe le délai GitHub
    (12, 20, 't15'),   # cible T-15
    (5, 12, 't7'),     # cible T-7
    (0, 5, 't3'),      # cible T-3 : tout dernier instant
]
# Au-delà de ce délai, un snapshot n'est PAS considéré comme un closing fiable.
CLOSING_MAX_MINS = 35

# ── Passe ÉTENDUE : suivi des matchs FUTURS (J+1..J+FUTURE_DAYS) ───────────
# Toutes les EXTENDED_EVERY_H heures (1re capture de l'heure), la capture balaie
# les tournois suivis via /fixtures/odds/main?tournamentId, qui renvoie TOUTES
# les fixtures à venir avec cotes — un match entre donc en suivi dès que
# Pinnacle ouvre sa ligne (vraie cote d'ouverture, courbes J-3 complètes) et
# l'outil HTML reste peuplé plusieurs jours en avance.
# Coût : n_tournois requêtes par passe étendue (~+25-50 req/jour), points de
# courbe toutes les ~2h pour les matchs lointains (suffisant si loin du match).
# Forçable à la main : python capture_closing.py --extended
EXTENDED_EVERY_H = int(os.environ.get('EXTENDED_EVERY_H', '2'))
FUTURE_DAYS      = int(os.environ.get('FUTURE_DAYS', '4'))


def _is_extended_pass(now, dernier_extended=None):
    """Vraie tous les EXTENDED_EVERY_H heures ÉCOULÉES depuis la dernière passe
    étendue effective (état persisté), ou si --extended est passe en argument
    (ou lors d'une decouverte --discover).

    CORRIGÉ LE 29/08/2026 (piste B, optimisation des requêtes) : la version
    précédente se basait sur l'horloge (heure paire, minute<12) -- les
    dispatch T-25/T-10 arrivent à des minutes arbitraires, ~10% d'entre eux
    tombaient dans cette fenêtre et déclenchaient une passe étendue NON
    voulue (7 requêtes au lieu de 3, ~10/jour, -9% du budget). Défaut
    symétrique plus grave : si le cron d'une heure paire glissait après la
    minute 12, la passe étendue de ce créneau était perdue, SANS rattrapage.
    Basé sur `dernier_extended` (capture_state.json['last_extended_at']) :
    exactement EXTENDED_EVERY_H heures entre deux passes, quel que soit le
    calendrier réel des déclenchements, avec rattrapage automatique."""
    if '--extended' in sys.argv or '--discover' in sys.argv:
        return True
    if dernier_extended is None:
        return True   # jamais vu de passe étendue -- état absent/1er run : forcer
    return (now - dernier_extended) >= datetime.timedelta(hours=EXTENDED_EVERY_H)

# (l'ancien _api_get v4 est remplacé par oddspapi_v5.api_get — appels RapidAPI/curl)


def load_players():
    """Charge la table locale id->nom (format OddsPapi 'Nom, Prénom')."""
    if os.path.exists(PLAYERS_FILE):
        try:
            with open(PLAYERS_FILE, encoding='utf-8') as f:
                return json.load(f)
        except Exception:
            return {}
    return {}


def refresh_players(players):
    """Obsolète en v5 : les noms des joueurs viennent directement des fixtures
    (participant1Name / participant2Name). Conservé en no-op par compatibilité."""
    return players, False


def normalize_name(oddspapi_name):
    """'Djokovic, Novak' -> 'Novak Djokovic'. Si pas de virgule, renvoie tel quel."""
    if not oddspapi_name:
        return ''
    if ',' in oddspapi_name:
        parts = [p.strip() for p in oddspapi_name.split(',', 1)]
        return f"{parts[1]} {parts[0]}".strip()
    return oddspapi_name.strip()


def load_active_tournaments():
    """Charge la liste des tournois actifs découverts (fichier local)."""
    if os.path.exists(ACTIVE_TOURNAMENTS_FILE):
        try:
            with open(ACTIVE_TOURNAMENTS_FILE, encoding='utf-8') as f:
                return json.load(f)
        except Exception:
            return {}
    return {}


def _tournaments_stale(active, max_age_h=18):
    """Vrai si la liste est absente, sans horodatage, ou plus vieille que max_age_h."""
    if not active:
        return True
    ts = active.get('_discovered_at')
    if not ts:
        return True
    try:
        disc = datetime.datetime.fromisoformat(ts)
    except Exception:
        return True
    return (datetime.datetime.utcnow() - disc).total_seconds() > max_age_h * 3600


# AJOUTÉ LE 29/08/2026 (optimisation, piste A) : fixtures_today() était
# appelée sans cache à CHAQUE passe standard (~99 requêtes/jour) pour une
# liste qui ne change qu'aux ajouts de programme -- quelques fois par jour.
# Même motif que _tournaments_stale ci-dessus (horodatage + seuil), mais
# vit délibérément dans /tmp (voir capture_closing.yml, actions/cache) :
# committer ce fichier ajouterait une écriture au git add de CHAQUE run
# (120/jour) pour un cache qui n'a de sens que dans le runner, jamais dans
# l'historique.
FIXTURES_TODAY_CACHE = os.environ.get('FIXTURES_TODAY_CACHE', '/tmp/fixtures_today_cache.json')
FIXTURES_TODAY_TTL_MIN = int(os.environ.get('FIXTURES_TODAY_TTL_MIN', '30'))


def fixtures_today_cached(sport_id, now=None):
    """fixtures_today() avec cache fichier -- 30 min par défaut, plus court
    que la fenêtre T-25→T-10 (un match ajouté au programme est vu au plus
    tard une demi-heure après, largement avant sa capture de clôture).

    CORRIGÉ LE 29/08/2026 (audit v13 §BG) : renvoie désormais (fixtures,
    appel_reel) -- avant, l'appelant comptait 1 requête à chaque passage,
    cache HIT ou pas, ce qui masquait EXACTEMENT le gain que ce cache est
    censé produire (~79 requêtes/jour sur 235, mesuré). Un compteur qui ne
    compte pas ce qu'il annonce mesurer est pire qu'utile : il aurait fait
    conclure à tort que le cache ne sert à rien."""
    now = now or datetime.datetime.utcnow()
    try:
        c = json.load(open(FIXTURES_TODAY_CACHE, encoding='utf-8'))
        t = datetime.datetime.fromisoformat(c['t'])
        if (now - t).total_seconds() < FIXTURES_TODAY_TTL_MIN * 60:
            return c['fixtures'], False   # cache HIT -- pas d'appel réseau
    except (OSError, ValueError, KeyError, TypeError):
        pass   # absent, corrompu, ou périmé -> on retombe sur un appel réel
    fixtures = ov.fixtures_today(sport_id)
    try:
        # CORRIGÉ LE 29/08/2026 (audit v13 §BF) : écriture atomique.
        ov.ecriture_atomique(FIXTURES_TODAY_CACHE, {'t': now.isoformat(), 'fixtures': fixtures})
    except OSError as e:
        print(f"  ℹ️ cache fixtures/today non écrit: {e}")
    return fixtures, True   # appel réseau réel


def discover_active_tournaments():
    """DÉCOUVERTE (~1×/jour) : croise le catalogue /tournaments (catSlug + nom)
    avec les fixtures du jour pour lister les tournois du circuit principal
    (catSlug ∈ TRACK_CATEGORY_SLUGS + "singles") ayant des matchs aujourd'hui.
    Écrit active_tournaments.json. Coûte 2 requêtes. Retourne {tid: {name, cat}}."""
    now = datetime.datetime.utcnow()
    catalog = ov.get_tournaments(TENNIS_SPORT_ID)
    if not catalog:
        print("  ⚠️ découverte: /tournaments a échoué, on garde la liste existante")
        return load_active_tournaments()

    # Tournois "suivis" (circuit principal, singles) présents dans le catalogue.
    tracked = {}
    for t in catalog:
        cs = str(t.get('categorySlug') or '').lower()
        name = str(t.get('tournamentName') or '')
        nlow = name.lower()
        if cs in SLUGS_INTERDITS:
            continue                     # matchs simulés : jamais, sous aucun prétexte
        if cs not in TRACK_CATEGORY_SLUGS:
            continue
        if REQUIRE_SINGLES and 'singles' not in nlow:
            continue
        if 'doubles' in nlow:
            continue
        short = name.split(',')[0].strip()   # "ATP Stuttgart" depuis "ATP Stuttgart, Germany Men Singles"
        tracked[str(t.get('tournamentId'))] = {
            'name': short, 'cat': (t.get('categoryName') or cs.upper())}

    # Croiser avec les fixtures du jour (hors SRL) -> seulement les ACTIFS.
    today = set()
    for f in ov.fixtures_today(TENNIS_SPORT_ID):
        if ov.is_srl(f):
            continue
        tid = (f.get('tournament') or {}).get('tournamentId')
        if tid is not None:
            today.add(str(tid))

    active = {tid: info for tid, info in tracked.items() if tid in today}
    active['_discovered_at'] = now.isoformat()
    # CORRIGÉ LE 29/08/2026 (audit v13 §BF) : écriture atomique.
    try:
        ov.ecriture_atomique(ACTIVE_TOURNAMENTS_FILE, active, ensure_ascii=False, indent=2)
    except Exception as e:
        print(f"  ⚠️ écriture {ACTIVE_TOURNAMENTS_FILE}: {e}")
    real = {k: v for k, v in active.items() if not k.startswith('_')}
    print(f"  🔭 Découverte: {len(real)} tournois {sorted(TRACK_CATEGORY_SLUGS)} actifs (singles={REQUIRE_SINGLES})")
    # Ventilation par catégorie : sans elle, on ne voit pas d'où vient une
    # éventuelle explosion du nombre de tournois.
    par_cat = {}
    for info in real.values():
        par_cat[info['cat']] = par_cat.get(info['cat'], 0) + 1
    if par_cat:
        print(f"      par catégorie : {dict(sorted(par_cat.items(), key=lambda x: -x[1]))}")
    if len(real) > MAX_TOURNOIS_ATTENDUS:
        print(f"  ⚠️ {len(real)} tournois actifs — au-dessus du seuil "
              f"{MAX_TOURNOIS_ATTENDUS}. Vérifier TRACK_CATEGORY_SLUGS : chaque "
              f"tournoi en plus alourdit les requêtes API, closing_lines.json "
              f"et les courbes historiques.")
    for tid, info in real.items():
        print(f"      {tid} | {info['name']} [{info['cat']}]")
    return active


def deduce_niveau(sport_key, title):
    """Déduit le niveau du tournoi à partir du sport_key et du titre.
    The Odds API couvre : Grands Chelems, ATP/WTA 1000 et 500.
    Retourne : 'grand_chelem' | '1000' | '500' | 'autre'.
    Le sport_key brut est toujours conservé à part, donc une mauvaise
    déduction reste corrigeable a posteriori sans perte d'info."""
    s = (sport_key or '').lower() + ' ' + (title or '').lower()
    grands_chelems = ['french_open', 'french open', 'wimbledon',
                      'us_open', 'us open', 'australian_open', 'australian open',
                      'roland', 'roland_garros']
    if any(g in s for g in grands_chelems):
        return 'grand_chelem'
    if '1000' in s or 'masters' in s or 'master' in s:
        return '1000'
    if '500' in s:
        return '500'
    return 'autre'


def get_pinnacle_h2h(fixture):
    """(home, away) Pinnacle du marché vainqueur — délégué au client v5."""
    return ov.get_pinnacle_h2h(fixture)


def all_bookmakers_h2h(fixture):
    """[{key, home, away}] pour tous les books d'une fixture — délégué au client v5."""
    return ov.all_books_h2h(fixture)


def fetch_odds(now=None):
    """v5 : récupère les cotes (Pinnacle + books mous) des matchs des tournois
    suivis. Passe STANDARD : matchs du jour (fixtures/today + batch fixtureIds,
    2 req). Passe ÉTENDUE (~1x/2h) : balayage par tournoi = TOUTES les fixtures
    à venir (J+FUTURE_DAYS) avec cotes. Produit 'matches' — l'aval est inchangé."""
    now = now or datetime.datetime.utcnow()
    if not ov.KEY:
        print("❌ RAPIDAPI_KEY absente")
        return [], '?'

    # Tournois actifs (re-découverte si vide ou périmé > 18h).
    active = load_active_tournaments()
    if _tournaments_stale(active):
        active = discover_active_tournaments()
    tids = set(k for k in active.keys() if not k.startswith('_'))
    if not tids:
        print("  Aucun tournoi actif à suivre")
        return [], '0 (aucun tournoi)'

    # CORRIGÉ LE 29/08/2026 (audit v12 §BC, URGENT) : `extended` et
    # `dernier_extended` étaient calculés ICI puis utilisés dans main()
    # (l'écriture de capture_state.json) -- deux PORTÉES DIFFÉRENTES.
    # fetch_odds() renvoie (matches, remaining), jamais ce couple. Résultat
    # réel : NameError avalé par le `except Exception` de main(), qui ne
    # loggait qu'un message anodin ("capture_state non écrit: ..."). Effet
    # de bord grave : capture_state.json n'était plus jamais réécrit, donc
    # last_extended_at jamais posé, donc dernier_extended toujours None au
    # run suivant, donc _is_extended_pass() renvoie TOUJOURS True -- 139
    # runs/jour en passe étendue au lieu de 12, +38% du budget API au lieu
    # de -9% visé. Corrigé en gardant tout le mécanisme DANS cette
    # fonction, un fichier dédié plutôt que de coupler fetch_odds() et
    # main() via des variables partagées -- aucun `return` à modifier,
    # aucun risque d'en oublier un parmi les 5 sorties de cette fonction.
    EXTENDED_STATE_FILE = 'extended_state.json'
    dernier_extended = None
    try:
        _etat_prec = json.load(open(EXTENDED_STATE_FILE, encoding='utf-8'))
        _le = _etat_prec.get('last_extended_at')
        if _le:
            dernier_extended = datetime.datetime.fromisoformat(_le)
    except (OSError, ValueError, TypeError):
        pass   # 1er run, fichier absent, ou format inattendu -> dernier_extended reste None
    extended = _is_extended_pass(now, dernier_extended)
    if extended:
        # CORRIGÉ LE 29/08/2026 (audit v13 §BF) : écriture atomique, même
        # raisonnement que capture_state.json ci-dessous.
        try:
            ov.ecriture_atomique(EXTENDED_STATE_FILE, {'last_extended_at': now.isoformat()})
        except OSError as e:
            print(f"  ℹ️ extended_state non écrit: {e}")
    horizon = now + datetime.timedelta(days=FUTURE_DAYS)

    if extended:
        # PASSE ÉTENDUE : 1 requête par tournoi → toutes les fixtures à venir
        # (aujourd'hui inclus) AVEC cotes. Pas besoin de fixtures/today.
        nreq = 0
        keep, by_id = [], {}
        for tid in sorted(tids):
            for fo in ov.odds_main(tid, CAPTURE_BOOKS):
                if ov.is_srl(fo):
                    continue
                st = (ov.fixture_meta(fo) or {}).get('startTime_iso', '')
                try:
                    stdt = datetime.datetime.fromisoformat(st.replace('Z', '+00:00')).replace(tzinfo=None)
                except Exception:
                    continue
                if stdt > horizon:
                    continue   # au-delà de l'horizon de suivi
                fid = fo.get('fixtureId')
                if fid:
                    keep.append(fo)
                    by_id[fid] = fo
            nreq += 1
        n_future = sum(1 for f in keep
                       if (ov.fixture_meta(f) or {}).get('startTime_iso', '')[:10] > now.strftime('%Y-%m-%d'))
        print(f"  🔭 PASSE ÉTENDUE: {len(keep)} matchs ≤J+{FUTURE_DAYS} dont {n_future} futurs "
              f"({len(tids)} tournois, {nreq} requête(s) v5)")
        if not keep:
            return [], f'{nreq} req (aucun match)'
    else:
        # PASSE STANDARD : fixtures du jour (hors SRL) + cotes batchées.
        # CORRIGÉ LE 29/08/2026 (audit v13 §BG) : nreq=1 était posé ici
        # AVANT l'appel à fixtures_today_cached() -- comptait la requête
        # même sur un cache HIT, masquant ~79 requêtes/jour du gain que
        # la piste A est censée produire. nreq part maintenant de 0, et
        # +1 seulement si l'appel était réellement réseau.
        nreq = 0
        keep = []
        # AJOUTÉ LE 29/08/2026 (audit v12 §BD.1) : fixtures_today() renvoie
        # TOUS les matchs du jour, y compris ceux commencés il y a des
        # heures -- la passe étendue filtre déjà sur l'horizon futur (plus
        # bas), la passe standard ne filtrait RIEN. Mesuré : ~33% des
        # fixtures du jour déjà commencées à une heure prise au hasard,
        # ~19 fixtures inutiles batchées sur ~58 -> 1,45 lot en moyenne au
        # lieu de 0,98. Même marge de 2h que le filtre équivalent de
        # write_matches_json (ligne ~519) : un commence_time approximatif
        # peut être en avance, et c'est justement la fenêtre où la clôture
        # se capture -- mieux vaut une marge large qu'un match manqué.
        cutoff_standard = now - datetime.timedelta(hours=2)
        _fixtures, _appel_reel = fixtures_today_cached(TENNIS_SPORT_ID, now)
        if _appel_reel:
            nreq += 1
        for f in _fixtures:
            if ov.is_srl(f):
                continue
            tid = str((f.get('tournament') or {}).get('tournamentId'))
            if tid not in tids:
                continue
            _st_iso = ov.fixture_meta(f).get('startTime_iso') or ''
            try:
                _st = datetime.datetime.fromisoformat(_st_iso.replace('Z', '+00:00')).replace(tzinfo=None)
            except (ValueError, TypeError):
                _st = None   # heure inconnue -> on garde par prudence, jamais on n'écarte sur un doute
            if _st is not None and _st < cutoff_standard:
                continue
            keep.append(f)
        if not keep:
            print("  Aucun match aujourd'hui pour les tournois suivis")
            return [], f'{nreq} req (aucun match)'

        # Cotes BATCHÉES par fixtureIds (lots de FIDS_PER_REQUEST → ~1 requête).
        fids = [f.get('fixtureId') for f in keep if f.get('fixtureId')]
        by_id = {}
        for i in range(0, len(fids), FIDS_PER_REQUEST):
            lot = fids[i:i + FIDS_PER_REQUEST]
            for fo in ov.odds_main_by_fixtures(lot, CAPTURE_BOOKS):
                if fo.get('fixtureId'):
                    by_id[fo['fixtureId']] = fo
            nreq += 1
        print(f"  {len(keep)} matchs ({len(tids)} tournois, {nreq} requête(s) v5)")

    matches = []
    for f in keep:
        fid = f.get('fixtureId')
        fo = by_id.get(fid, f)              # fixture enrichie de ses cotes (sinon meta seule)
        meta = ov.fixture_meta(fo)
        name1 = normalize_name(meta['p1name'])
        name2 = normalize_name(meta['p2name'])
        if not name1 or not name2:
            continue
        tid = str(meta['tournamentId'])
        info = active.get(tid, {})
        tour_name = info.get('name') or meta['tournamentName'] or f"tournoi_{tid}"
        psH, psA = get_pinnacle_h2h(fo)
        s1H, s1A = ov.get_pinnacle_set1(fo)   # marché set 1 (123) — même payload, 0 requête
        books = all_bookmakers_h2h(fo)
        books_s1 = ov.all_books_market(fo, ov.SET1_MARKET, ov.SET1_HOME, ov.SET1_AWAY)  # set1 par book
        books_s2 = ov.all_books_market(fo, ov.SET2_MARKET, ov.SET2_HOME, ov.SET2_AWAY)  # set2 par book
        matches.append({
            'id': fid,
            'home_team': name1,
            'away_team': name2,
            'commence_time': meta['startTime_iso'],
            '_sport': tour_name,
            '_sport_key': f"oddspapi_{tid}",
            '_ps_home': psH,
            '_ps_away': psA,
            '_s1_home': s1H,
            '_s1_away': s1A,
            '_bookmakers': books,
            '_bk_set1': books_s1,
            '_bk_set2': books_s2,
        })
    return matches, f'{nreq} req (OddsPapi v5)'


def get_pinnacle(match):
    """Lit les cotes Pinnacle déjà extraites par fetch_odds (champs _ps_home/_ps_away)."""
    return match.get('_ps_home'), match.get('_ps_away')


MATCHES_FILE = 'matches_oddspapi.json'

def write_matches_for_tool(matches):
    """Génère matches_oddspapi.json au FORMAT The Odds API pour l'outil HTML.

    IMPORTANT : on FUSIONNE avec l'existant au lieu d'écraser. Avec la capture toutes
    les 10 min, un passage qui ne ramène aucun match (matchs du jour finis, ceux de
    demain pas encore publiés par le flux) effaçait sinon tout l'outil. Ici, un passage
    « vide » ne supprime jamais les matchs à venir déjà connus ; on rafraîchit ceux
    présents et on ne purge que les matchs déjà commencés (avec 2h de marge)."""
    def build(m):
        home, away = m['home_team'], m['away_team']
        bookmakers = []
        for b in m.get('_bookmakers', []):
            bookmakers.append({
                'key': b['key'],
                'markets': [{
                    'key': 'h2h',
                    'outcomes': [
                        {'name': home, 'price': b['home']},
                        {'name': away, 'price': b['away']},
                    ],
                }],
            })
        return {
            'id': m.get('id', ''),
            'sport_title': m.get('_sport', ''),
            'sport_key': m.get('_sport_key', ''),
            'commence_time': m.get('commence_time', ''),
            'home_team': home,
            'away_team': away,
            'bookmakers': bookmakers,
        }

    # Entrées du passage courant (cotes fraîches)
    fresh = {}
    for m in matches:
        e = build(m)
        if e['id']:
            fresh[e['id']] = e

    # Charger l'existant et fusionner (le passage courant a la priorité)
    merged = {}
    if os.path.exists(MATCHES_FILE):
        try:
            with open(MATCHES_FILE, encoding='utf-8') as f:
                for e in json.load(f):
                    if e.get('id'):
                        merged[e['id']] = e
        except Exception:
            merged = {}
    merged.update(fresh)

    # Purger les matchs déjà commencés (gardé 2h de marge), garder les à venir
    def _ct(s):
        try:
            return datetime.datetime.fromisoformat((s or '').replace('Z', '+00:00')).replace(tzinfo=None)
        except Exception:
            return None
    cutoff = datetime.datetime.utcnow() - datetime.timedelta(hours=2)
    out = [e for e in merged.values() if (_ct(e.get('commence_time', '')) or cutoff) >= cutoff]
    out.sort(key=lambda e: e.get('commence_time', ''))

    try:
        with open(MATCHES_FILE, 'w', encoding='utf-8') as f:
            json.dump(out, f, ensure_ascii=False)
        print(f"  📝 {MATCHES_FILE}: {len(out)} matchs à venir ({len(fresh)} rafraîchis ce passage)")
    except Exception as e:
        print(f"  ⚠️ Écriture {MATCHES_FILE}: {e}")
        return

    # Sidecar avec timestamp EMBARQUÉ DANS LE CONTENU (pas le mtime fichier) :
    # dans un checkout GitHub Actions frais, le mtime reflète l'heure du clone,
    # pas la dernière vraie écriture -- inutilisable pour un audit de fraîcheur.
    # matches_oddspapi.json lui-même doit rester un tableau brut au format The
    # Odds API (index.html le lit tel quel) : impossible d'y ajouter un champ
    # sans casser la page. D'où ce petit fichier séparé, lu par audit_qa.py.
    try:
        with open('matches_oddspapi_meta.json', 'w', encoding='utf-8') as f:
            json.dump({'last_write': datetime.datetime.utcnow().isoformat(),
                      'n_matches': len(out), 'n_refreshed_this_pass': len(fresh)}, f)
    except Exception as e:
        print(f"  ⚠️ Écriture matches_oddspapi_meta.json: {e}")


LIVE_ODDS_FILE = 'live_odds.json'

def write_live_odds(matches):
    """Snapshot live MULTI-BOOKS match + set1 + set2 pour build_live_curves.

    Fichier distinct de matches_oddspapi.json (qui reste dédié à l'outil HTML).
    Même logique de fusion : on rafraîchit les matchs du passage, on ne purge que
    les matchs déjà commencés (2h de marge). Zéro requête (cotes déjà en main)."""
    def by_key(books):
        return {b['key']: {'home': b['home'], 'away': b['away']}
                for b in (books or []) if b.get('home') and b.get('away')}
    fresh = {}
    for m in matches:
        mid = m.get('id')
        if not mid:
            continue
        fresh[mid] = {
            'id': mid, 'commence_time': m.get('commence_time', ''),
            'home_team': m.get('home_team'), 'away_team': m.get('away_team'),
            'sport_title': m.get('_sport', ''),
            'books_match': by_key(m.get('_bookmakers')),
            'books_set1': by_key(m.get('_bk_set1')),
            'books_set2': by_key(m.get('_bk_set2')),
        }
    merged = {}
    if os.path.exists(LIVE_ODDS_FILE):
        try:
            with open(LIVE_ODDS_FILE, encoding='utf-8') as f:
                for e in json.load(f):
                    if e.get('id'):
                        merged[e['id']] = e
        except Exception:
            merged = {}
    merged.update(fresh)

    def _ct(s):
        try:
            return datetime.datetime.fromisoformat((s or '').replace('Z', '+00:00')).replace(tzinfo=None)
        except Exception:
            return None
    cutoff = datetime.datetime.utcnow() - datetime.timedelta(hours=2)
    out = [e for e in merged.values() if (_ct(e.get('commence_time', '')) or cutoff) >= cutoff]
    out.sort(key=lambda e: e.get('commence_time', ''))
    try:
        with open(LIVE_ODDS_FILE, 'w', encoding='utf-8') as f:
            json.dump(out, f, ensure_ascii=False)
        n_s1 = sum(1 for e in out if e.get('books_set1'))
        print(f"  📝 {LIVE_ODDS_FILE}: {len(out)} matchs (set1 chez {n_s1})")
    except Exception as e:
        print(f"  ⚠️ Écriture {LIVE_ODDS_FILE}: {e}")


def trim_history(hist, cap):
    """Borne l'historique à `cap` points SANS perdre l'info utile :
    - garde toujours le 1er point (la cote d'OUVERTURE, précieuse pour le CLV open→close) ;
    - garde DENSES les points les plus récents (la moitié du budget) = le build-up qui compte ;
    - sous-échantillonne uniformément le milieu/ancien pour tenir dans le reste du budget.
    La trajectoire couvre ainsi toute la durée de vie du match (2-3 j inclus) à coût borné."""
    if len(hist) <= cap:
        return hist
    recent_keep = max(1, cap // 2)
    recent = hist[-recent_keep:]
    older = hist[:-recent_keep]
    budget_old = cap - len(recent)
    if budget_old <= 1 or len(older) <= budget_old:
        sampled = older if len(older) <= budget_old else [older[0]]
    else:
        step = len(older) / budget_old
        idxs = sorted(set([0] + [int(i * step) for i in range(budget_old)]))
        idxs = [i for i in idxs if i < len(older)]
        sampled = [older[i] for i in idxs]
    return sampled + recent

def main():
    import sys
    now = datetime.datetime.utcnow()
    if not ov.KEY:
        print("❌ RAPIDAPI_KEY absente (secret GitHub manquant)")
        return

    # Mode découverte (lancé 1×/jour par un workflow dédié) : rafraîchit la liste
    # des tournois ATP/WTA actifs, puis continue normalement avec le suivi.
    if '--discover' in sys.argv:
        print("Mode DÉCOUVERTE des tournois actifs")
        discover_active_tournaments()

    print(f"Capture closing lines (OddsPapi) @ {now.isoformat()} UTC")

    # Charger les closing lines existantes
    closing = {}
    if os.path.exists(CLOSING_FILE):
        with open(CLOSING_FILE, encoding='utf-8') as f:
            closing = json.load(f)

    matches, remaining = fetch_odds(now)
    print(f"  {len(matches)} matchs exploitables · quota {remaining}")

    # AJOUTÉ LE 29/08/2026 (audit v12 §BE) : "une optimisation qui vise à
    # diviser un compteur par deux devrait commencer par afficher ce
    # compteur." nreq est déjà calculé par fetch_odds() et déjà imprimé
    # dans `remaining` (ex. "3 req (OddsPapi v5)") -- il manquait juste de
    # le PERSISTER. Extrait par regex plutôt que de changer la signature
    # de fetch_odds() (5 `return` différents, risque d'en oublier un -- le
    # bug même de cette passe, cf. §BC). Lu AVANT l'écrasement de
    # capture_state.json plus bas, pour cumuler sur la même journée UTC.
    _m_nreq = re.match(r'^(\d+)', remaining)
    nreq_ce_run = int(_m_nreq.group(1)) if _m_nreq else 0
    requetes_cumul_jour = nreq_ce_run
    try:
        _prec = json.load(open('capture_state.json', encoding='utf-8'))
        _prec_ts = datetime.datetime.fromisoformat(_prec.get('last_capture_at', ''))
        if _prec_ts.date() == now.date():
            requetes_cumul_jour += _prec.get('requetes_cumul_jour', 0)
    except (OSError, ValueError, KeyError, TypeError):
        pass   # 1er run du jour, fichier absent, ou format inattendu -> repart de nreq_ce_run seul

    # Générer le fichier pour l'outil HTML (tous les bookmakers, format Odds API)
    write_matches_for_tool(matches)
    # Snapshot live multi-books match+set pour build_live_curves (courbes live forward)
    write_live_odds(matches)

    captured = 0
    seen_now = set()   # uid des matchs présents dans cette réponse API
    for m in matches:
        ct = m.get('commence_time','')
        if not ct: continue
        try:
            start = datetime.datetime.fromisoformat(ct.replace('Z','+00:00')).replace(tzinfo=None)
        except:
            continue

        mins_until = (start - now).total_seconds() / 60

        # On capture les matchs à venir (jusqu'à 240h = 10j, pour suivre dès leur
        # apparition dans l'API et capter la vraie cote d'ouverture) ET ceux dont
        # l'heure annoncée est dépassée mais qui sont TOUJOURS présents dans l'API
        # (1er tour décalé, demi-finale mal datée). Tolérance 6h de dépassement.
        if mins_until > 240*60 or mins_until < -360:
            continue

        home = m.get('home_team','')
        away = m.get('away_team','')
        # uid STABLE : indépendant de la date ET de l'ordre des joueurs.
        # IMPORTANT : on utilise '_sport' (titre lisible, ex "ATP French Open")
        # pour être IDENTIQUE à makeMatchId() de l'outil HTML qui utilise sport_title.
        # Sinon l'outil et la capture génèrent des uid différents et ne se
        # synchronisent pas (le CLV ne se rattache pas au bon match).
        _tour = (m.get('_sport','') or m.get('_sport_key','')).replace(' ','_').lower()
        _joueurs = sorted([home.replace(' ','_').lower(), away.replace(' ','_').lower()])
        uid = f"{_tour}_{_joueurs[0]}_vs_{_joueurs[1]}"
        psH, psA = get_pinnacle(m)
        if not (psH and psA):
            continue
        seen_now.add(uid)

        # Initialiser l'entrée si nouvelle
        if uid not in closing:
            closing[uid] = {
                'date': ct[:10],
                'home': home, 'away': away,
                'tournament': m.get('_sport',''),
                'sport_key': m.get('_sport_key',''),
                'niveau': deduce_niveau(m.get('_sport_key',''), m.get('_sport','')),
                'commence_time': ct,
                'fixture_id': m.get('id',''),   # nécessaire pour fetch_clv (historique gratuit)
                'history': [],
            }
        else:
            # Compléter les entrées existantes qui n'auraient pas encore ces champs
            if not closing[uid].get('sport_key'):
                closing[uid]['sport_key'] = m.get('_sport_key','')
            if not closing[uid].get('niveau'):
                closing[uid]['niveau'] = deduce_niveau(m.get('_sport_key',''), m.get('_sport',''))
            if not closing[uid].get('fixture_id'):
                closing[uid]['fixture_id'] = m.get('id','')
            # Rafraîchir commence_time si l'API a corrigé l'heure ou la date.
            # Avec un uid stable (sans date), on suit toujours la valeur fraîche
            # de l'API, qu'il s'agisse d'un changement d'heure ou de jour
            # (report, match décalé). On recalcule alors les mins_before.
            old_ct = closing[uid].get('commence_time','')
            if ct and ct != old_ct:
                closing[uid]['schedule_changes'] = closing[uid].get('schedule_changes', 0) + 1
                print(f"  🕐 Horaire mis à jour: {home} vs {away} | {old_ct} -> {ct}")
                closing[uid]['commence_time'] = ct
                closing[uid]['date'] = ct[:10]
                for p in closing[uid].get('history', []):
                    pt = p.get('t')
                    if pt:
                        try:
                            tp = datetime.datetime.fromisoformat(pt.replace('Z','+00:00')).replace(tzinfo=None)
                            p['mins_before'] = round((start - tp).total_seconds() / 60)
                        except Exception:
                            pass
                # Le closing reconstruit devient caduc : on le laissera se recréer
                closing[uid].pop('closing', None)
        # S'assurer que history existe (compat anciennes entrées)
        if 'history' not in closing[uid]:
            closing[uid]['history'] = []
        # Match présent dans l'API : remettre le compteur d'absence à zéro
        closing[uid]['absent_count'] = 0

        # Dédoublonnage : ne stocker que si la cote a bougé de façon significative
        # (> STORE_MOVE_PCT) OU si > STORE_MAX_GAP_MIN depuis le dernier point.
        # Seuils abaissés pour capturer finement l'évolution des cotes.
        hist = closing[uid]['history']
        last = hist[-1] if hist else None
        store = True
        if last:
            try:
                dh = abs(psH - last['home']) / last['home']
                da = abs(psA - last['away']) / last['away']
                # Temps écoulé depuis le dernier point
                t_last = datetime.datetime.fromisoformat(last['t'])
                mins_since = (now - t_last).total_seconds() / 60
                # Stocker si variation significative OU plancher temporel dépassé
                store = (dh > STORE_MOVE_PCT or da > STORE_MOVE_PCT or mins_since > STORE_MAX_GAP_MIN)
            except:
                store = True
        if store and mins_until >= -2:
            # mins_until >= -2 : on ne stocke JAMAIS de point une fois le match
            # lancé (Pinnacle cote le LIVE sur OddsPapi v5 → sans ce garde-fou,
            # l'history se pollue de cotes in-play qui faussent les alertes de
            # mouvement et toute analyse pré-match). Tolérance -2 min d'horloge.
            pt = {
                't': now.isoformat(),
                'mins_before': round(mins_until),
                'home': psH, 'away': psA,
            }
            s1H, s1A = m.get('_s1_home'), m.get('_s1_away')
            if s1H and s1A:
                pt['s1h'], pt['s1a'] = s1H, s1A   # cotes Pinnacle du marché set 1
            hist.append(pt)
            captured += 1
        # Borner l'historique en gardant ouverture + récents denses + milieu échantillonné
        if len(hist) > HISTORY_CAP:
            closing[uid]['history'] = trim_history(hist, HISTORY_CAP)

        # Snapshots de référence T-25 et T-10
        for win_min, win_max, label in CAPTURE_WINDOWS:
            if win_min <= mins_until <= win_max:
                snap = {
                    'home': psH, 'away': psA,
                    'mins_before': round(mins_until),
                    'captured_at': now.isoformat(),
                }
                _s1H, _s1A = m.get('_s1_home'), m.get('_s1_away')
                if _s1H and _s1A:
                    snap['s1_home'], snap['s1_away'] = _s1H, _s1A
                closing[uid][f'pinnacle_{label}'] = snap
                print(f"  ✅ [{label}] {home} vs {away}: {psH}/{psA} (T-{round(mins_until)})")

        # Déterminer le closing de référence = snapshot le PLUS TARDIF disponible.
        # Marqué fiable seulement s'il a été capturé <= CLOSING_MAX_MINS avant le match.
        snaps = []
        for label in ('t25', 't15', 't7', 't3'):
            s = closing[uid].get(f'pinnacle_{label}')
            if s and 'mins_before' in s:
                snaps.append(s)
        if snaps:
            best = min(snaps, key=lambda s: s['mins_before'])  # le plus proche du match
            closing[uid]['closing'] = {
                'home': best['home'], 'away': best['away'],
                'mins_before': best['mins_before'],
                'captured_at': best['captured_at'],
                'closing_method': 'snapshot',
                'reliable': best['mins_before'] <= CLOSING_MAX_MINS,
            }

    # ===== Détection du closing par DISPARITION =====
    # Un match qui était présent puis disparaît de l'API pendant ABSENT_THRESHOLD
    # passages consécutifs est considéré comme COMMENCÉ. Son dernier point d'historique
    # est alors le vrai closing — indépendamment de l'heure annoncée (qui peut être
    # fausse pour les 1ers tours décalés ou les demi-finales mal datées).
    ABSENT_THRESHOLD = 3   # ~15 min (3 passages de 5 min) avant de figer
    for uid, m in closing.items():
        if uid in seen_now:
            continue  # présent, déjà remis à 0
        # Absent : incrémenter le compteur
        m['absent_count'] = m.get('absent_count', 0) + 1

        # Déjà figé par disparition ? ne pas refaire
        if m.get('closing', {}).get('closing_method') == 'disappearance':
            continue

        # PRIORITE AU SNAPSHOT (OddsPapi v5) : si on a deja un closing snapshot
        # FIABLE et FRAIS (capture en fenetre fine <= CLOSING_MAX_MINS), il est
        # bien meilleur que le dernier point avant disparition. On ne l'ecrase
        # pas. La disparition ne sert plus que de filet pour les matchs jamais
        # vus en fenetre fine (snapshot absent ou trop ancien).
        cl_existing = m.get('closing') or {}
        if (cl_existing.get('closing_method') == 'snapshot'
                and cl_existing.get('reliable')):
            continue

        if m['absent_count'] < ABSENT_THRESHOLD:
            continue

        hist = m.get('history', [])
        if not hist:
            continue
        last = hist[-1]

        # Garde-fou "heure plausible" : un match ne commence quasi jamais bien AVANT
        # son heure annoncée. Si le dernier point a été capturé largement avant l'heure
        # annoncée, la disparition est probablement un raté d'API, pas un vrai départ.
        ct = m.get('commence_time', '')
        plausible = True
        try:
            start = datetime.datetime.fromisoformat(ct.replace('Z','+00:00')).replace(tzinfo=None)
            t_last = datetime.datetime.fromisoformat(last['t'])
            # mins entre le dernier point et l'heure annoncée (positif = avant l'heure)
            before_announced = (start - t_last).total_seconds() / 60
            # Si le dernier point est > 60 min AVANT l'heure annoncée, suspect
            if before_announced > 60:
                plausible = False
        except Exception:
            pass

        if not plausible:
            # On n'a pas confiance : on garde le match "en attente" sans figer,
            # et on remet le compteur à 0 pour laisser une chance au retour de l'API.
            m['absent_count'] = 0
            continue

        # Figer le closing sur le dernier point observé avant disparition
        m['closing'] = {
            'home': last['home'], 'away': last['away'],
            'captured_at': last['t'],
            'closing_method': 'disappearance',
            'reliable': True,   # dernier point réel avant le départ = vrai closing
        }
        print(f"  🏁 Closing par disparition: {m.get('home','?')} vs {m.get('away','?')} "
              f"(dernier point {last['t'][:16]})")


    # Compresser l'historique des matchs TERMINÉS : leur CLV est figé dans
    # clv_history.jsonl, ils n'ont plus besoin d'une trajectoire dense. On garde
    # l'entrée et tous ses champs + une trajectoire échantillonnée (ouverture/closing
    # préservés). C'est ce qui empêche closing_lines.json de gonfler indéfiniment.
    finished_cutoff = now - datetime.timedelta(hours=24)
    for uid, m in closing.items():
        h = m.get('history') or []
        if len(h) <= FINISHED_HISTORY_CAP:
            continue
        finished = bool(m.get('clv_hist_done'))
        if not finished:
            try:
                st = datetime.datetime.fromisoformat(
                    m.get('commence_time', '').replace('Z', '+00:00')).replace(tzinfo=None)
                finished = st < finished_cutoff
            except Exception:
                finished = False
        if finished:
            m['history'] = trim_history(h, FINISHED_HISTORY_CAP)

    # Nettoyer les vieilles entrées (> PURGE_DAYS jours) — leur CLV est déjà figé de
    # façon permanente dans clv_history.jsonl, donc rien d'utile n'est perdu.
    cutoff = (now - datetime.timedelta(days=PURGE_DAYS)).strftime('%Y-%m-%d')
    closing = {k: v for k, v in closing.items() if v.get('date', '') >= cutoff}

    # CORRIGÉ LE 29/08/2026 (audit v13 §BF) : écriture atomique -- l'audit
    # nomme explicitement ce fichier comme la cible la plus coûteuse d'un
    # écrasement accidentel (1255+ matchs, l'accumulateur central de tout
    # le dispositif). Une exception au milieu de l'écriture non-atomique
    # aurait le MÊME effet que capture_state.json le 28/08, avec des
    # conséquences bien plus lourdes qu'un heartbeat perdu.
    ov.ecriture_atomique(CLOSING_FILE, closing, ensure_ascii=False, indent=2)

    n_s1 = sum(1 for m in matches if m.get('_s1_home') and m.get('_s1_away'))
    print(f"\n✅ {captured} captures · {len(closing)} matchs dans closing_lines.json"
          f" · cotes set1 dispo: {n_s1}/{len(matches)}")

    # Marqueur de heartbeat pour le worker Cloudflare : instant du dernier run de
    # capture, INDÉPENDANT du fait qu'un point d'historique ait été stocké (l'history
    # a sa propre dé-dup >1%/>30min). Le worker s'en sert pour piloter sa cadence.
    # CORRIGÉ LE 29/08/2026 (audit v13 §BF) : open(...,'w') tronque le
    # fichier AVANT la première écriture -- exactement ce qui a laissé
    # capture_state.json à 0 octet la nuit dernière (le NameError du §BC
    # a explosé APRÈS la troncature, le fichier vide a été committé tel
    # quel). ov.ecriture_atomique() écrit dans un .tmp puis os.replace()
    # -- soit l'ancien fichier complet reste, soit le nouveau complet le
    # remplace, jamais un état intermédiaire.
    try:
        ov.ecriture_atomique('capture_state.json', {
            'last_capture_at': now.isoformat(),
            'captured': captured,
            'matches': len(closing),
            'requetes_ce_run': nreq_ce_run,
            'requetes_cumul_jour': requetes_cumul_jour,
        }, ensure_ascii=False, indent=2)
    except Exception as e:
        print(f"  ℹ️ capture_state non écrit: {e}")

    # Détecteur de mouvement de cote (alerte Telegram défensive).
    # Importé ici pour ne pas casser la capture si le module/secrets manquent.
    try:
        from odds_movement import run_movement_detector
        run_movement_detector()
    except Exception as e:
        print(f"  ℹ️ Détecteur mouvement non exécuté: {e}")

    # NB : la collecte des marchés "jeux" (games_markets) était spécifique à The Odds
    # API. Elle est désactivée tant qu'elle n'a pas été portée sur OddsPapi (marchés
    # totals/spreads = autres IDs, ex. 12271). À réactiver plus tard si besoin.

if __name__ == '__main__':
    main()
