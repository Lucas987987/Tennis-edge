#!/usr/bin/env bash
# verifier.sh — contrôle automatique post-application (29/08/2026).
#
# Usage : bash verifier.sh   (à la racine du dépôt, APRÈS les cp)

set -uo pipefail
ECHECS=0

verif() {
    local fichier="$1" motif="$2" description="$3"
    if [ ! -f "$fichier" ]; then
        echo "❌ $fichier : FICHIER ABSENT"
        ECHECS=$((ECHECS+1))
        return
    fi
    if grep -q "$motif" "$fichier"; then
        echo "✅ $fichier : $description"
    else
        echo "❌ $fichier : $description -- MOTIF ABSENT ($motif)"
        ECHECS=$((ECHECS+1))
    fi
}

verif_absent() {
    local fichier="$1" motif="$2" description="$3"
    if [ ! -f "$fichier" ]; then
        echo "❌ $fichier : FICHIER ABSENT"
        ECHECS=$((ECHECS+1))
        return
    fi
    if grep -q "$motif" "$fichier"; then
        echo "❌ $fichier : $description -- MOTIF ENCORE PRÉSENT (doit être absent)"
        ECHECS=$((ECHECS+1))
    else
        echo "✅ $fichier : $description"
    fi
}

echo "=== Vérification -- audit v13 (29/08/2026) ==="
echo

verif scripts/oddspapi_v5.py "def ecriture_atomique" "§BF : utilitaire d'écriture atomique créé"
verif scripts/oddspapi_v5.py "os.remove(chemin_tmp)" "§BF : nettoyage du .tmp en cas d'échec"
verif scripts/capture_closing.py "ov.ecriture_atomique('capture_state.json'" "§BF : capture_state.json atomique"
verif scripts/capture_closing.py "ov.ecriture_atomique(CLOSING_FILE" "§BF : closing_lines.json atomique (1255+ matchs)"
verif scripts/capture_closing.py "ov.ecriture_atomique(EXTENDED_STATE_FILE" "§BF : extended_state.json atomique"
verif scripts/capture_closing.py "ov.ecriture_atomique(ACTIVE_TOURNAMENTS_FILE" "§BF : active_tournaments.json atomique"
verif scripts/early_open_signal.py "ov.ecriture_atomique(STATE_FILE" "§BF : early_open_state.json atomique"
verif scripts/capture_closing.py "return c\['fixtures'\], False" "§BG : cache HIT renvoie appel_reel=False"
verif scripts/capture_closing.py "return fixtures, True" "§BG : appel réel renvoie appel_reel=True"
verif_absent scripts/capture_closing.py "nreq = 1$" "§BG : nreq ne part plus de 1 inconditionnellement"
verif .github/workflows/observateur_externe.yml "SEUIL_H=30" "§BH : seuil abaissé (détecte 1 run manqué)"
verif .github/workflows/observateur_externe.yml "filter: blob:none" "§BH : checkout allégé"
verif .github/workflows/observateur_externe.yml "timeout-minutes: 10" "§BH : marge de temps"

echo
echo "=== Test critique : le scénario exact du bug d'hier (exception en écriture) ==="
python3 -c "
import sys; sys.path.insert(0,'scripts')
import oddspapi_v5 as ov
import json, os
chemin = '/tmp/verif_atomique_final.json'
json.dump({'avant': True}, open(chemin,'w'))
avant = open(chemin).read()
class Boom:
    def __repr__(self): raise NameError('boom')
try:
    ov.ecriture_atomique(chemin, {'casse': Boom()}, default=lambda o: o.x())
except Exception:
    pass
apres = open(chemin).read()
assert apres == avant, 'RÉGRESSION'
assert not os.path.exists(chemin + '.tmp'), 'RÉSIDU .tmp'
print('✅ fichier intact + aucun résidu .tmp après une exception en cours d\'écriture')
"

echo
if [ "$ECHECS" -eq 0 ]; then
    echo "✅✅✅ TOUT EST EN PLACE (13 contrôles passés). Sûr de committer."
    exit 0
else
    echo "❌❌❌ $ECHECS CONTRÔLE(S) EN ÉCHEC. NE PAS COMMITTER avant d'avoir compris pourquoi."
    exit 1
fi
