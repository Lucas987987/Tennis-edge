# Correctifs audit v2 (27/08/2026) — application (codespace, racine)

⚠️ Cette fois, `verifier.sh` est une étape OBLIGATOIRE avant tout commit —
c'est le garde-fou contre le bug qui m'a fait perdre du temps trois fois
aujourd'hui (un correctif testé qui n'atterrit pas dans le fichier livré).
S'il affiche un ❌, NE PAS committer : dis-le moi, je regarde.

    unzip correctifs_audit_v2.zip
    cp correctifs_audit_v2/scripts/*.py scripts/
    cp correctifs_audit_v2/tests/test_pure_functions.py tests/
    cp correctifs_audit_v2/.github/workflows/*.yml .github/workflows/

    # ── ÉTAPE OBLIGATOIRE ──
    bash correctifs_audit_v2/verifier.sh
    # doit afficher "TOUT EST EN PLACE (18 contrôles passés)" avant de continuer

    python tests/test_pure_functions.py      # doit afficher 12/12
    rm -f verdicts_geles.json                # purge l'entrée périmée (gel à n=34)

    rm -rf correctifs_audit_v2 correctifs_audit_v2.zip
    git add -A
    git commit -m "Audit v2 : SETTLED+clôture fiable (§A/§L), commence_time croisé (§M), N_CIBLE (§C), reinforce_watch (§D), match_key sans risque (§G), Q3+pont CLV branchés (§I/§L)"
    git pull --no-rebase --no-edit && git push

---

## Le plus important de cette session

**§A n'avait jamais été livré ce matin.** J'avais corrigé `settle_trade()`
dans un répertoire de travail, testé la logique là-bas, mais jamais recopié
vers le fichier réellement empaqueté — le paquet livré ce matin contenait
la version bugguée malgré mes tests. Repéré par l'audit v2, pas par moi.
Cette fois le correctif est écrit et vérifié directement dans le fichier
final, sans aucun aller-retour entre répertoires, et `verifier.sh` grep
chaque marqueur attendu avant que quoi que ce soit ne soit livré.

## §L (le plus important sur le fond) — deux clôtures coexistaient

`closing_lines.json` (daté, `reliable` flag, 1079/1193 matchs fiables)
n'était lu par AUCUN script qui calcule un CLV — toute la chaîne de
validation utilisait le dernier point de courbe, sans garde-fou. Écart
mesuré par l'audit : >3% sur 7,9% des matchs, >10% sur 1,3%.

Nouvelle fonction `cloture_fiable()` dans `paper_journal.py` : préfère
`closing_lines[uid]['closing']` quand `reliable=True`, replie sur le
dernier point de courbe sinon. Testé sur les vraies données (le prix
attendu correspond exactement). `close_source` tracé sur chaque trade pour
audit futur.

## §M — commence_time croisé entre les deux sources

Divergence jusqu'à 24h40 sur 6,9% des matchs, laissant parfois passer du
in-play dans la zone dite pré-match. `steam_alert.load_curves()` prend
désormais le MIN entre le commence_time de sa propre source et celui de
`closing_lines.json`. Testé sur 1722 matchs réels, aucune erreur.

## §C — le gel à n=34 se contredisait dans son propre rapport

`ouverture précoce` était gelée le jour même à n=34 (97,1%) pendant que la
mesure du jour affichait 88,0% (n=75) dans la MÊME exécution. Gel désormais
à `N_CIBLE=100` (nombre rond, pré-enregistré, identique pour toutes les
hypothèses). L'entrée périmée est purgée (`rm verdicts_geles.json`).
Nouveau verdict testé : "en accumulation (cible n>=100, 30 restants)" —
plus de contradiction possible dans le même rapport.

## §G — la fusion par inclusion RETIRÉE, pas rapiécée

L'audit a montré un vrai risque (Alexander et Mischa Zverev fusionnés à
tort, même tournoi même jour) pour un gain mesuré NUL sur les données
réelles. Plutôt que de corriger une troisième fois sous pression, l'étape a
été retirée entièrement.

**Découverte en écrivant le test de non-régression** : le risque ne venait
pas QUE de l'étape retirée — `_toks()` supprimait les initiales isolées
("A." de "A. Zverev"), donc deux joueurs de même nom de famille réduisaient
à un ensemble IDENTIQUE dès l'égalité de base, avant même une quelconque
étape de proximité. Corrigé : `_toks()` ne supprime plus aucun jeton, même
à 1 lettre — garder l'initiale ne peut qu'ajouter de la précision, jamais
en retirer. 12/12 tests passent, dont le nouveau cas Zverev.

## §E — le résultat qui va à l'encontre de l'hypothèse de l'audit

`clv_pin` (contre le juste-prix Pinnacle) est maintenant affiché à côté de
`clv_book`. Sur les 30 paris rétro-remplis : **clv_pin à 100% positif
(IC95 89-100%)**, PLUS net que clv_book (80%). Ça va dans le sens INVERSE
de l'hypothèse "sélection mécanique qui gonfle clv_book" — mesuré, pas
supposé. Ne tranche pas la question (n=30), mais c'est la bonne direction
d'enquête pour la suite : biais de sélection écarté par cette mesure,
restent "n trop petit" et "CLV réel mais mangé en aval" (marge/gubbing).

## Reste, volontairement pas fait ce soir

- **La décision Polymarket/Kalshi elle-même** (§H) : `polymarket_flow` et
  `polymarket_leadlag` sont structurellement incapables de répondre à leur
  question (aucun montant échangé enregistré ; résolution Pinnacle 5-10 min
  indiscernable d'un lead-lag proche de zéro). Le budget temps est corrigé,
  mais la vraie décision — densifier l'échantillonnage Pinnacle, faire
  enregistrer les volumes au collecteur, ou couper la collecte — est à toi.
- **§E, la version complète** : republier le CLV contre la référence
  closing_lines EXPLICITEMENT en 3e colonne (aujourd'hui, clv_book en
  bénéficie déjà implicitement via cloture_fiable(), mais ce n'est pas
  isolé comme métrique séparée).

## Tests : 12/12 (le test de match_key remplacé, voir §G)
