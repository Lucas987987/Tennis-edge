#!/usr/bin/env bash
# verifier.sh — contrôle automatique post-application (créé le 27/08/2026).
#
# POURQUOI CE SCRIPT EXISTE. Trois fois dans la même journée, un correctif
# testé et validé dans un répertoire de travail n'a pas atterri dans le
# fichier réellement empaqueté ou livré -- détecté une fois par un audit
# externe (paper_journal.py, plusieurs heures de bug non corrigé malgré des
# tests qui passaient), deux fois par moi-même en cours de correction. Ce
# script grep chaque marqueur attendu dans chaque fichier CIBLE (celui du
# dépôt, après application) et échoue bruyamment si un seul manque -- il ne
# fait confiance à aucune affirmation, y compris les miennes.
#
# Usage : bash verifier.sh   (à lancer à la racine du dépôt, APRÈS les cp)

set -uo pipefail
ECHECS=0

verif() {
    local fichier="$1" motif="$2" description="$3"
    if [ ! -f "$fichier" ]; then
        echo "❌ $fichier : FICHIER ABSENT"
        ECHECS=$((ECHECS+1))
        return
    fi
    if grep -q "$motif" "$fichier"; then
        echo "✅ $fichier : $description"
    else
        echo "❌ $fichier : $description -- MOTIF ABSENT ($motif)"
        ECHECS=$((ECHECS+1))
    fi
}

echo "=== Vérification des correctifs audit v2 (27/08/2026) ==="
echo

verif scripts/paper_journal.py "CLOSED_NO_RESULT" "§A : statut conditionnel au pnl"
verif scripts/paper_journal.py "cloture_fiable" "§L : clôture fiable (closing_lines.json en priorité)"
verif scripts/steam_alert.py "ct_croise" "§M : commence_time croisé"
verif scripts/validation_report.py "N_CIBLE" "§C : gel à n pré-enregistré"
verif scripts/validation_report.py "return n_reinf, len(rows), 0.5" "§D : reinforce_watch renvoie un tuple"
verif scripts/validation_report.py "mean_ci(pnl)" "§F : report_canal utilise le bootstrap"
verif scripts/validation_report.py "clv_pin" "§E : CLV contre juste-prix Pinnacle affiché"
verif scripts/match_key.py "len(t) >= 1" "§G (découverte) : initiales conservées dans _toks"
verif scripts/match_key.py "RETIRÉE LE 27/08/2026" "§G : étape 4 (fusion par inclusion) retirée"
verif scripts/fetch_results.py "SEUIL_QUALITE" "§J : seuil de qualité sur le repli"
verif scripts/fetch_results_fast.py "SEUIL_QUALITE" "§J : seuil de qualité (fast)"
verif .github/workflows/steam_pipeline.yml "verdicts_geles.json" "§B : verdicts_geles.json committé"
verif .github/workflows/steam_pipeline.yml "pnl_vs_clv_study.py" "§I : pont CLV->P&L branché"
verif .github/workflows/steam_pipeline.yml "capture_quality.py" "§L : Q3 triangulation branchée"
verif .github/workflows/capture_closing.yml "git diff --cached --name-only" "§K : parsing awk corrigé"
verif .github/workflows/capture_closing.yml "Watchdog collecteurs" "watchdog du 26/08 toujours présent"
verif .github/workflows/polymarket_studies.yml "sparse-checkout" "§H : sparse-checkout ajouté"
verif .github/workflows/polymarket_studies.yml "timeout-minutes: 60" "§H : budget temps corrigé"

echo
if [ "$ECHECS" -eq 0 ]; then
    echo "✅✅✅ TOUT EST EN PLACE ($((18)) contrôles passés). Sûr de committer."
    exit 0
else
    echo "❌❌❌ $ECHECS CONTRÔLE(S) EN ÉCHEC. NE PAS COMMITTER avant d'avoir compris pourquoi."
    exit 1
fi
