# Correctifs audit v3 (27/08/2026) — application (codespace, racine)

⚠️ `verifier.sh` reste obligatoire. C'est cette étape qui a raté le tour
précédent (le zip a été committé sans être décompressé) — ne pas la sauter.

    unzip correctifs_audit_v3.zip
    cp correctifs_audit_v3/scripts/*.py scripts/
    cp correctifs_audit_v3/retrofill_paper_trades.py .
    cp correctifs_audit_v3/.github/workflows/*.yml .github/workflows/

    # ── ÉTAPE OBLIGATOIRE ──
    bash correctifs_audit_v3/verifier.sh
    # doit afficher "TOUT EST EN PLACE (16 contrôles passés)"

    python tests/test_pure_functions.py      # doit afficher 12/12
    rm -f verdicts_geles.json                # les n ont changé (§R), reglèle proprement

    rm -rf correctifs_audit_v3 correctifs_audit_v3.zip
    git add -A
    git commit -m "Audit v3 : pont match_key réel pour closing_lines (§P), clv_vs_median (§Q), n reproductible (§R), Q3 committé (§S)"
    git pull --no-rebase --no-edit && git push

---

## Ce qui s'est passé

Les deux correctifs les plus importants du tour précédent (§L : bascule sur
`closing_lines.json`, §M : `commence_time` croisé) étaient du **code mort**.
`closing_lines.json` utilise la convention `circuit_tournoi_joueurs`, le
reste du dépôt utilise `date_joueurs` -- intersection directe mesurée à
**0/25**. Mes `.get(uid)` ne se déclenchaient jamais. Compilait, tests
passaient, tout avait l'air de fonctionner : mes tests utilisaient un uid
pris DANS `closing_lines.json` lui-même, auto-cohérents par construction,
donc incapables de révéler le problème.

## §P — le pont réel, avec compteur

Les deux fonctions utilisent maintenant `match_key.natural_key()` (déjà
importé dans les deux fichiers, déjà utilisé pour la dédup) pour construire
un index par clé naturelle -- agnostique au format d'uid. Testé sur un vrai
trade de production (`Luciano Darderi vs Gabriel Diallo`) : trouve bien son
entrée `closing_lines` (`atp_montreal_gabriel_diallo_vs_luciano_darderi`).
**35/36** résolutions côté `paper_journal`, **85-88%** côté `steam_alert`
sur les vraies partitions.

Découverte en cours de correction : `closing_lines[uid]['closing']` est un
prix **Pinnacle**, pas celui du book. L'utiliser directement aurait
redéfini `clv_book` en silence -- un deuxième biais caché derrière le
premier. Corrigé : on n'emprunte que le TIMESTAMP fiable, utilisé pour
trancher la courbe du BOOK lui-même. Fraîcheur et référence de prix restent
deux axes séparés.

**Garde-fou permanent ajouté** : si le taux de résolution tombe sous 30%,
`steam_alert` affiche un avertissement. Un correctif qui échoue à 100% en
silence ne pourra plus le refaire sans que ça se voie.

## §Q — clv_pin relabellisé, vrai test ajouté

`clv_pin` utilisait la même formule à l'entrée (filtre `EV_MIN_NOW`) et à
la clôture -- corrélation quasi mécanique, 100% de positifs mesurés par
l'audit. Relabellisé honnêtement dans le rapport ("EV au filtre d'entrée,
PAS un CLV"). `clv_vs_median` ajouté : compare l'entrée au book MÉDIAN
plutôt qu'au max choisi par `pick_signal()` -- le vrai test du biais de
sélection posé par l'audit précédent.

**Limite assumée** : `retrofill_paper_trades.py` ne recalcule pas
`clv_vs_median` sur l'historique déjà réglé (il ne charge pas les courbes
multi-books). Documenté dans son propre docstring plutôt que bricolé.

## §R — le gel dépendait de l'heure du run

`book_curves_live.jsonl` (éphémère, gitignore, purgé à 5 jours) faisait
partie des sources comptées pour les verdicts gelés à `N_CIBLE`. Retiré :
`_hist_sources()` ne renvoie plus que les partitions versionnées. Les `n`
sont maintenant reproductibles -- vérifié : "round" 85→23, "marge" 23→17,
les vrais chiffres déterministes.

## §S — les trois points mineurs

- Q3 écrit dans `q3_status.json` (committé), lu par `pipeline_status.py`.
  Bug trouvé en testant : `true`/`false` bash injectés tels quels dans du
  JSON Python (`NameError`) -- corrigé en `True`/`False`.
- `n_settled` ne compte plus les `CLOSED_NO_RESULT`.
- `ARCHIVE_INDEX.json` : avertissement informatif dans `load_partitions()`
  si des dates archivées manquent du disque. **Non testé sur le vrai
  fichier** (absent de mon snapshot local) -- logique défensive
  (try/except large), mais à surveiller au premier vrai run.

## Tests : 12/12 (inchangés depuis le v2 -- aucune régression)
