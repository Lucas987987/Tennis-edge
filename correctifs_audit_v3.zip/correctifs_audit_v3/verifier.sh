#!/usr/bin/env bash
# verifier.sh (v3) — contrôle automatique post-application (27/08/2026).
#
# Même principe que le v2 : grep chaque marqueur attendu dans les fichiers
# RÉELLEMENT présents après application, échoue bruyamment si un seul
# manque. Cette version couvre les correctifs de l'audit v3, qui a trouvé
# que les deux correctifs prioritaires du v2 (§L, §M) étaient du CODE MORT
# -- conflit de format d'uid entre closing_lines.json et le reste du dépôt,
# jamais détecté par des tests auto-cohérents.
#
# Usage : bash verifier.sh   (à la racine du dépôt, APRÈS les cp)

set -uo pipefail
ECHECS=0

verif() {
    local fichier="$1" motif="$2" description="$3"
    if [ ! -f "$fichier" ]; then
        echo "❌ $fichier : FICHIER ABSENT"
        ECHECS=$((ECHECS+1))
        return
    fi
    if grep -q "$motif" "$fichier"; then
        echo "✅ $fichier : $description"
    else
        echo "❌ $fichier : $description -- MOTIF ABSENT ($motif)"
        ECHECS=$((ECHECS+1))
    fi
}

echo "=== Vérification des correctifs audit v3 (27/08/2026) ==="
echo

verif scripts/paper_journal.py "_cache\['idx'\]" "§P : pont match_key réel (pas de .get(uid) direct)"
verif scripts/paper_journal.py "book_a_snapshot_fiable" "§P : clôture BOOK à l'instant daté (pas le prix Pinnacle)"
verif scripts/paper_journal.py "cloture_fiable_stats" "§P : compteur de résolutions exposé"
verif scripts/paper_journal.py "clv_vs_median" "§Q : vrai test du biais de sélection ajouté"
verif scripts/paper_journal.py "n_reste_a_regler" "§S : n_settled ne compte plus les non-dénoués"
verif scripts/steam_alert.py "import match_key as mk" "§P : match_key importé dans steam_alert"
verif scripts/steam_alert.py "_cl_idx" "§P : index par clé naturelle (pas .get(r\['uid'\]) direct)"
verif scripts/steam_alert.py "commence_time croisé via" "§P : compteur de résolutions affiché"
verif scripts/validation_report.py "clv_vs_median" "§Q : clv_vs_median affiché dans le rapport"
verif scripts/validation_report.py "PAS un CLV" "§Q : clv_pin relabellisé honnêtement"
verif scripts/validation_report.py "return ov.hist_partitions" "§R : book_curves_live.jsonl retiré de _hist_sources"
verif scripts/pipeline_status.py "q3_status.json" "§S : Q3 lu par pipeline_status.py"
verif scripts/oddspapi_v5.py "ARCHIVE_INDEX.json" "§S : trou d'archive distingué d'un vrai trou"
verif .github/workflows/steam_pipeline.yml "q3_status.json" "§S : Q3 écrit dans un fichier committé"
verif .github/workflows/steam_pipeline.yml "echo True" "§S : bug booléen bash->Python corrigé"
verif retrofill_paper_trades.py "LIMITE ASSUMÉE" "§Q : limite sur clv_vs_median documentée"

echo
if [ "$ECHECS" -eq 0 ]; then
    echo "✅✅✅ TOUT EST EN PLACE (16 contrôles passés). Sûr de committer."
    exit 0
else
    echo "❌❌❌ $ECHECS CONTRÔLE(S) EN ÉCHEC. NE PAS COMMITTER avant d'avoir compris pourquoi."
    exit 1
fi
