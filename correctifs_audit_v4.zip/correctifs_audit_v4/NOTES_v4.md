# Correctifs audit v4 (28/08/2026) — application (codespace, racine)

⚠️ `verifier.sh` reste obligatoire.

    unzip correctifs_audit_v4.zip
    cp correctifs_audit_v4/scripts/*.py scripts/
    cp correctifs_audit_v4/.github/workflows/*.yml .github/workflows/

    # ── ÉTAPE OBLIGATOIRE ──
    bash correctifs_audit_v4/verifier.sh
    # doit afficher "TOUT EST EN PLACE (8 contrôles passés)"

    # ── nettoyage §X (fichiers égarés, apparus hors de mon suivi) ──
    rm -f scripts/retrofill_paper_trades.py scripts/steam_pipeline.yml

    python tests/test_pure_functions.py      # doit afficher 12/12
    rm -f verdicts_geles.json                # les n ont pu changer

    rm -rf correctifs_audit_v4 correctifs_audit_v4.zip
    git add -A
    git commit -m "Audit v4 : pont anti-in-play étendu à p0_temoin (§U), index avec date (§W), bug True/true (§V), clv_vs_median hors ligne (§Y), ABANDONNED après 7j (§Z)"
    git pull --no-rebase --no-edit && git push

---

## Le fait marquant de cette session : un correctif vérifié inutile

L'audit a mesuré, sur les vraies partitions, que le pont vers `closing_lines.json`
(§L/§P) fonctionne parfaitement (97,4-100% de résolution) mais produit
**zéro différence** avec l'ancien comportement -- 1364/1364 prix strictement
identiques. Raison mécanique : `steam_alert._pre()` tronque déjà la courbe
à `commence_time` avant que la fonction intervienne, donc il n'y a jamais
rien après le dernier point pour que le pont puisse trouver.

**Vérifié de mon côté** : mon premier test (sur courbes brutes, non
tronquées) donnait 154 différences sur 184 -- j'ai refait le test en
passant par le vrai pipeline (`steam_alert.load_curves()`, qui applique
`_pre()`) et j'obtiens bien 0 différence, confirmant l'audit.

**Ce que ça signifie** : le biais que l'addendum avait mesuré (écart >3%
sur 7,9% des matchs) opposait deux sources **Pinnacle** entre elles, pas la
courbe du book à quoi que ce soit -- extrapolé au mauvais objet. Le
correctif n'a rien cassé et rien inventé : il a transformé une hypothèse en
invariant mesuré. La docstring de `cloture_fiable()` le dit maintenant
explicitement (§T), pour que le prochain lecteur ne croie pas qu'un biais a
été corrigé alors qu'il a été réfuté.

## §U — le vrai enjeu de cette passe

Le garde-fou anti-in-play (croiser `commence_time` avec `closing_lines.json`)
n'existait que dans `steam_alert.py` (54 paris protégés). Absent de :
- `move_audit.py` → alimente `moves_detail_hist.csv` (891 moves) →
  **`p0_temoin` (0,725)** → l'étalon de TOUTES les hypothèses gelées
- `canal_clv.py` → alimente `canal_clv_detail.csv`, le CLV publié aux abonnés

Même pont posé dans les deux fichiers (ils importaient déjà `match_key`).
Testé : **91% de résolution** sur `move_audit.py` (6680/7305 lignes) --
c'est le fichier qui compte le plus, et il est maintenant protégé.

`canal_clv.py` n'a pas pu être testé de bout en bout dans ce codespace
(tué pour dépassement mémoire) -- diagnostiqué : la cause est une ligne
PRÉEXISTANTE (`records.append(r)`, accumule les courbes complètes de tout
l'historique), pas mon correctif (vérifié isolément : léger, 0,06s). Le
runner GitHub Actions a plus de mémoire que ce codespace ; à surveiller au
premier vrai run.

## §Y — répond au §E aujourd'hui, pas dans un mois

`scripts/clv_vs_median_offline.py` (nouveau) calcule `clv_vs_median` sur
les 891 moves historiques au lieu d'attendre n≥30 nouveaux paris. Résultat
mesuré : **44/891 appariés** (contrainte de correspondance de côté stricte),
écart médian clv_book vs clv_median = **+0,48 pts** -- bien sous le seuil
de 3 pts. Pas de signature nette de biais de sélection sur cet échantillon.
Suggestif, pas définitif (échantillon limité à 44) -- mais c'est une vraie
réponse, aujourd'hui.

## §V, §W, §Z — les trois corrections rapides

- **§V** : `"true"` (minuscule) ne matchait jamais `"True"` (le littéral
  Python nécessaire pour le JSON) -- l'alerte du log ne s'affichait jamais,
  ironie du jour puisque ce bloc avait été écrit CE MATIN pour corriger
  exactement ce problème (un echo qui n'alerte personne).
- **§W** : les deux index utilisaient `nat[0]` (sans la date), écrasant les
  homonymes à dates différentes -- **13 collisions mesurées et résolues**
  en gardant `nat` complet (le tuple avec la date, comme `natural_key()`
  le prévoit dans sa propre docstring).
- **§Z** : les paris `CLOSED_NO_RESULT` sans résultat après 7 jours
  basculent en `ABANDONNED`, sortent de la boucle de relecture. Les 6 déjà
  bloqués recevront leur date de départ au prochain cycle (pas immédiat --
  ils n'existaient pas quand `closed_no_result_depuis` a été ajouté).

## §X — fichiers égarés, pas dans mon suivi

`retrofill_paper_trades.py` et `steam_pipeline.yml` sont apparus dans
`scripts/` (probablement lors d'un des terminaux embrouillés de tout à
l'heure). Absents de ma copie locale, donc rien à corriger côté code --
juste à supprimer, commande incluse ci-dessus.

## Tests : 12/12 (inchangés)
