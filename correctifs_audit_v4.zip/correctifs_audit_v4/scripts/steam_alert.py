#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
steam_alert.py — Alerte Telegram "MISER ICI" (steam-following), seuils par book.

COMPLEMENTAIRE de l'alerte d'evolution (odds_movement.py). A chaque cycle :
  1. Lit la derniere capture (book_curves.jsonl).
  2. Track record sur FENETRE GLISSANTE (WINDOW_DAYS) : par book et par palier,
     % qui battent la cloture + CLV median. Auto-actualise chaque run.
  3. SEUIL PROPRE A CHAQUE BOOK : pour chaque book on choisit le palier qui
     maximise la reussite (parmi ceux ayant >= MIN_N cas). Repli sur DEFAULT_THR
     si donnees insuffisantes (signale comme indicatif).
  4. Matchs a venir : detection forward-only ; un book "s'active" si le drift
     atteint SON seuil et qu'il offre encore de la value. Alerte le meilleur.
  5. Dedup via state ; re-alerte si un palier superieur est franchi.

Env : TELEGRAM_TOKEN, TELEGRAM_CHAT_ID (sinon DRY_RUN auto), CURVES, STATE,
  GRID (def 0.02,0.03,0.05,0.08), WINDOW_DAYS (def 90 ; 0 = tout l'historique),
  MIN_N (def 30), DEFAULT_THR (def 0.05), MIN_LEAD (def 15), EV_MIN_NOW (def 0.0),
  SOFT_BOOKS (restreindre), NOW_OVERRIDE (tests), DRY_RUN.
"""
import json, os, urllib.request, urllib.parse, statistics as st, re, unicodedata
import oddspapi_v5 as ov
import match_key as mk
from datetime import datetime, timezone

MARKET = os.environ.get('MARKET', 'match').lower()
_DEF_CURVES = {'match': 'book_curves.jsonl', 'set1': 'set1_curves.jsonl', 'set2': 'set2_curves.jsonl'}
_MKT_LABEL = {'match': '', 'set1': ' (SET 1)', 'set2': ' (SET 2)'}
_MKT_VERB = {'match': 'gagne le match', 'set1': 'gagne le set 1', 'set2': 'gagne le set 2'}
CURVES = os.environ.get('CURVES', _DEF_CURVES.get(MARKET, 'book_curves.jsonl'))
STATE = os.environ.get('STATE', f'steam_alert_state_{MARKET}.json')
SHARP = os.environ.get('SHARP_BOOK', 'pinnacle')
GRID = sorted(float(x) for x in os.environ.get('GRID', '0.02,0.03,0.05,0.08').split(','))
WINDOW_DAYS = float(os.environ.get('WINDOW_DAYS', '90'))
# Fichier de TRACK RECORD (historique riche) pour calibrer les seuils par book.
# Si vide, on utilise les matchs passes du fichier live (cold-start = "indicatif").
TRACK_CURVES = os.environ.get('TRACK_CURVES', '')
MIN_N = int(os.environ.get('MIN_N', '30'))
DEFAULT_THR = float(os.environ.get('DEFAULT_THR', '0.05'))
MIN_LEAD = float(os.environ.get('MIN_LEAD', '15'))
# ── Coussin d'EV vs fair (LE critere qui paie) ─────────────────────────────
# Battre la cloture d'un book MOU ne suffit pas : sa cloture contient sa marge
# (~5%). Empiriquement (zones CLV) : CLV +4,5% vs cloture molle -> ROI -2% ;
# seul l'ecart au FAIR dévigué (Shin, Pinnacle) se convertit en ROI.
# On n'alerte donc que si : cote_mou x proba_fair_shin - 1 >= EV_MIN_NOW.
# 0.05 = defaut raisonnable ; 0.10 = regle stricte type "chasing steamers"
# (coussin contre l'overshoot post-move). Reglable par env sans redeployer.
EV_MIN_NOW = float(os.environ.get('EV_MIN_NOW', '0.05'))
CAP_JUMP = float(os.environ.get('CAP_FAIR_JUMP', '0.4'))
TOKEN = os.environ.get('TELEGRAM_TOKEN', '')
CHAT = os.environ.get('TELEGRAM_CHAT_ID', '')
DRY_RUN = os.environ.get('DRY_RUN', '1' if not (TOKEN and CHAT) else '0') == '1'
SOFT_PREF = os.environ.get('SOFT_BOOKS', '')

def _load_json(path, default):
    if os.path.exists(path):
        try:
            with open(path, encoding='utf-8') as f:
                return json.load(f)
        except Exception:
            return default
    return default


def _dt(s):
    try: return datetime.fromisoformat(str(s).replace('Z','+00:00')).timestamp()
    except Exception: return None
def _now():
    o = os.environ.get('NOW_OVERRIDE')
    return _dt(o) if o else datetime.now(timezone.utc).timestamp()


# ── Garde horaires : les commence_time accumules dans les courbes peuvent etre
# PERIMES (reports, horaires "not before" du tennis). Un match deja commence
# apparait alors "a venir" et ses cotes IN-PLAY passent pour du pre-match ->
# alerte sur un match en cours. matches_oddspapi.json (matchs A VENIR, reecrit
# a chaque cycle) est la source de verite. Fail-open si absent.
UPCOMING_FILE = os.environ.get('UPCOMING', 'matches_oddspapi.json')

def _norm_up(x):
    x = unicodedata.normalize('NFD', str(x).lower().strip())
    x = ''.join(c for c in x if not unicodedata.combining(c))
    return re.sub(r'[^a-z0-9]+', '_', x).strip('_')

def load_upcoming():
    if not os.path.exists(UPCOMING_FILE):
        return None
    try:
        d = json.load(open(UPCOMING_FILE, encoding='utf-8'))
    except Exception:
        return None
    items = d if isinstance(d, list) else list(d.values())
    out = {}
    for m in items:
        if not isinstance(m, dict): continue
        h, a, ct = m.get('home_team'), m.get('away_team'), m.get('commence_time')
        if not (h and a and ct): continue
        t = _dt(ct)
        if not t: continue
        k = f"{_norm_up(h)}_{_norm_up(a)}"
        if k not in out or t < out[k]: out[k] = t
    return out

def load_curves(path=None):
    data = {}
    src = path or CURVES
    # RÉGRESSION CORRIGÉE (15/08/2026) : book_curves.jsonl/set1_curves.jsonl/
    # set2_curves.jsonl n'existent plus depuis la migration en partitions du
    # 14/08 (140,73 Mo -> limite dure GitHub). TRACK_CURVES continue de passer
    # ces noms legacy (workflow inchangé) -- sans ce correctif, load_curves()
    # trouvait le fichier absent et retournait un dict vide en silence, d'où
    # "aucun book n'a encore de track record" affiché sur TOUS les books
    # depuis la migration, alors que l'historique réel existe bel et bien
    # (juste réparti dans parts/hist_<market>_*.jsonl).
    LEGACY_MARKET = {'book_curves.jsonl': 'book', 'set1_curves.jsonl': 'set1', 'set2_curves.jsonl': 'set2'}
    if src in LEGACY_MARKET:
        lines_iter = ov.iter_hist_lines(LEGACY_MARKET[src])
    elif os.path.exists(src):
        lines_iter = open(src, encoding='utf-8')
    else:
        # GARDE-FOU (25/08/2026) : un historique demandé explicitement qui
        # revient vide n'est JAMAIS normal. Ce mode de panne (lecture vide
        # silencieuse) a déjà frappé deux fois : le 15/08 (migration en
        # partitions) et le 25/08 au matin (sparse-checkout qui excluait
        # parts/hist_*). Une ligne de log coûte rien ; trois semaines de
        # seuils dégradés ont un prix.
        print(f"⚠️ load_curves('{src}') : fichier absent et pas de "
              f"correspondance legacy -> track record VIDE. Vérifier le "
              f"checkout (sparse ?) ou le chemin.")
        return data
    # AJOUTÉ LE 27/08/2026 (audit v2 §M), CORRIGÉ LE 27/08/2026 (audit v3
    # §P) : `_closing_lines.get(r['uid'])` ne s'est JAMAIS déclenché --
    # closing_lines.json utilise la convention circuit_tournoi_joueurs,
    # book_curves utilise date_joueurs, intersection directe mesurée à
    # 0/40. Même correctif que paper_journal.cloture_fiable() : un index
    # par CLÉ NATURELLE (match_key.natural_key, agnostique au format
    # d'uid), construit UNE FOIS avant la boucle (pas à chaque ligne).
    try:
        _closing_lines = json.load(open('closing_lines.json', encoding='utf-8'))
    except (OSError, ValueError):
        _closing_lines = {}
    _cl_idx = {}
    for _k, _v in _closing_lines.items():
        _nat = mk.natural_key(_v.get('home', ''), _v.get('away', ''),
                              _v.get('commence_time'))
        # CORRIGÉ LE 28/08/2026 (audit v4 §W) : _nat[0] seul jetait la date
        # -- même correctif que paper_journal.cloture_fiable(), voir son
        # commentaire. `_nat` complet au lieu de `_nat[0]`.
        if _nat[0]:
            _cl_idx[_nat] = _k
    _croises_resolus = 0
    _croises_tentes = 0
    for line in lines_iter:
        line = line.strip()
        if not line: continue
        r = json.loads(line)
        ct = _dt(r.get('commence_time'))
        # CORRIGÉ (audit v3 §P) : lookup par clé naturelle, pas par uid brut.
        _croises_tentes += 1
        _nat_r = mk.natural_key(r.get('home', ''), r.get('away', ''),
                                r.get('commence_time'))
        _cl_uid = _cl_idx.get(_nat_r) if _nat_r[0] else None
        ct_croise = _dt((_closing_lines.get(_cl_uid) or {}).get('commence_time')) \
            if _cl_uid else None
        if ct_croise:
            _croises_resolus += 1
            if ct is None or ct_croise < ct:
                ct = ct_croise
        # PRÉ-MATCH UNIQUEMENT. book_curves.jsonl contient ~90% de points IN-PLAY
        # (après le coup d'envoi). Les garder fausse la calibration : le "close"
        # (ser[-1]) devient un prix in-play qui encode le résultat -> look-ahead.
        # On coupe au départ. (Sans effet sur les courbes LIVE : départ dans le futur.)
        def _pre(seq):
            pts = [(_dt(p[0]), p[1]) for p in seq if _dt(p[0]) and p[1]]
            return [(t, o) for t, o in pts if ct is None or t < ct]
        h = _pre(r.get('home_curve', []))
        a = _pre(r.get('away_curve', []))
        if len(h) < 2 or len(a) < 2: continue
        d = data.setdefault(r['uid'], {})
        d[r['book']] = {'h': sorted(h), 'a': sorted(a)}
        d['_commence'] = ct
        d['_uid'] = r['uid']
        d['_home'] = r.get('home_team') or r.get('home') or r['uid']
        d['_away'] = r.get('away_team') or r.get('away') or ''
        d['_tour'] = r.get('tournament') or ''
    # AJOUTÉ LE 27/08/2026 (audit v3 "un correctif qui échoue en silence
    # est pire que pas de correctif") : le pont vers closing_lines.json
    # n'affiche RIEN s'il ne se déclenche jamais -- exactement le mode de
    # panne qui a rendu le §M inerte toute la journée sans que rien ne le
    # signale. Seuil bas (10 lignes) pour ne pas polluer les tout petits
    # chargements (courbes live avec 1-2 matchs).
    if _croises_tentes >= 10:
        taux = 100 * _croises_resolus / _croises_tentes
        niveau = "⚠️ " if taux < 30 else ""
        print(f"{niveau}load_curves('{src}') : commence_time croisé via "
              f"closing_lines sur {_croises_resolus}/{_croises_tentes} "
              f"lignes ({taux:.0f}%).")
    # Le recalage sur le planning "à venir" (load_upcoming) corrige les
    # commence_time PÉRIMÉS -- utile UNIQUEMENT pour les courbes LIVE
    # (path=None, donc src=CURVES). Appliqué aussi au chargement de
    # l'historique (TRACK_CURVES, path explicite), il supprimait
    # purement et simplement tout le track record : un match d'il y a
    # des semaines n'est plus jamais "à venir" aujourd'hui, donc TOUJOURS
    # absent de load_upcoming() -- d'où "aucun book n'a encore de track
    # record" quasi permanent, constaté ce jour (1 match chargé sur des
    # milliers). Bug pré-existant, indépendant de la migration en
    # partitions du 14/08 -- celle-ci n'a fait que le rendre visible en
    # forçant à ré-examiner ce chemin de code.
    if path is None:
        up = load_upcoming()
        if up is not None:
            for uid in list(data.keys()):
                key = uid.split('_', 1)[1] if '_' in uid else uid
                official = up.get(key)
                if official is None:
                    del data[uid]                 # plus a venir => commence/termine
                else:
                    data[uid]['_commence'] = official
    if not data and src in LEGACY_MARKET:
        # GARDE-FOU SUR LA BRANCHE EFFECTIVE (audit du 25/08 après-midi : le
        # précédent était dans la branche morte — le chemin legacy passe par
        # iter_hist_lines et ne l'atteignait jamais). Un historique legacy
        # demandé qui produit ZÉRO courbe = partitions absentes ou illisibles.
        print(f"⚠️ load_curves('{src}') : 0 courbe chargée depuis "
              f"parts/hist_{LEGACY_MARKET[src]}_* — track record VIDE. "
              f"Checkout sparse incomplet ?")
    return data
def _at(s, t):
    v = None
    for tt, o in s:
        if tt <= t: v = o
        else: break
    return v

import math
DEVIG = os.environ.get('DEVIG', 'shin').lower()

def _shin_home(oh, oa):
    """Proba fair de 'home' (methode de Shin) : corrige le biais favori-outsider
    que le devig proportionnel ignore. Resout z dans [0,1) tel que p_h+p_a=1.
    Repli proportionnel si la cote est incoherente."""
    try:
        rh, ra = 1.0 / oh, 1.0 / oa
        B = rh + ra
        if B <= 1.0:
            return rh / B
        def p(ri, z):
            return (math.sqrt(z * z + 4 * (1 - z) * ri * ri / B) - z) / (2 * (1 - z))
        lo, hi = 0.0, 0.999
        for _ in range(60):                  # bisection : f(z)=p_h+p_a-1 decroissante
            z = (lo + hi) / 2
            if p(rh, z) + p(ra, z) > 1: lo = z
            else: hi = z
        z = (lo + hi) / 2
        return min(max(p(rh, z), 1e-6), 1 - 1e-6)
    except Exception:
        ih, ia = 1 / oh, 1 / oa
        return ih / (ih + ia)

def _devig_home(oh, oa):
    if DEVIG == 'proportional':
        ih, ia = 1 / oh, 1 / oa
        return ih / (ih + ia)
    return _shin_home(oh, oa)

def _fair(bk, t):
    oh, oa = _at(bk['h'], t), _at(bk['a'], t)
    if oh and oa and oh > 1.01 and oa > 1.01:
        return _devig_home(oh, oa)
    return None

def detect(pin, thr):
    """Forward-only : 1er instant ou |drift| >= thr. (t_entry, side) ou None."""
    times = sorted(set(t for t, _ in pin['h']))
    if len(times) < 2: return None
    f0 = _fair(pin, times[0])
    if f0 is None: return None
    for t in times[1:]:
        f = _fair(pin, t)
        if f is None or abs(f - f0) > CAP_JUMP: continue
        if abs(f - f0) >= thr:
            return (t, 'home' if f > f0 else 'away')
    return None

def compute_stats(past, softbooks):
    """{thr: {book: {'med','pct','n'} | None}} sur la fenetre."""
    stats = {mv: {sb: None for sb in softbooks} for mv in GRID}
    bucket = {mv: {sb: [] for sb in softbooks} for mv in GRID}
    for uid, bk in past.items():
        if SHARP not in bk: continue
        commence = bk.get('_commence')
        for mv in GRID:
            d = detect(bk[SHARP], mv)
            if not d: continue
            t_e, side = d
            if commence is not None and (commence - t_e)/60.0 < MIN_LEAD:
                continue   # meme filtre d'avance que le backtest valide
            for sb in softbooks:
                if sb not in bk: continue
                ser = bk[sb]['h'] if side == 'home' else bk[sb]['a']
                entry = _at(ser, t_e)
                if not entry or entry <= 1 or not ser: continue
                close = ser[-1][1]
                if close and close > 1:
                    bucket[mv][sb].append((entry/close - 1) * 100)
    for mv in GRID:
        for sb in softbooks:
            lst = bucket[mv][sb]
            if lst:
                stats[mv][sb] = {'med': round(st.median(lst), 1),
                                 'pct': round(100*sum(1 for x in lst if x > 0)/len(lst)),
                                 'n': len(lst)}
    return stats

def best_threshold(stats, sb):
    """Palier maximisant la reussite (pct) avec n>=MIN_N. Repli DEFAULT_THR (indicatif)."""
    cands = [(mv, stats[mv][sb]) for mv in GRID
             if stats[mv][sb] and stats[mv][sb]['n'] >= MIN_N]
    if cands:
        mv, sdat = max(cands, key=lambda c: (c[1]['pct'], c[1]['med']))
        return mv, sdat, True
    # repli : seuil par defaut, on rattache la stat dispo (faible n) si elle existe
    sdat = stats.get(DEFAULT_THR, {}).get(sb) if DEFAULT_THR in stats else None
    return DEFAULT_THR, sdat, False

def fmt_lead(sec):
    m = int(sec // 60)
    return f"{m}min" if m < 60 else f"{m//60}h{m%60:02d}"

def x_search_url(home, away):
    """Lien de recherche X pre-rempli sur les deux joueurs, tri 'Recent'.
    Gratuit, zero API, ne peut pas casser (contrairement a un scraper) -- un
    tap ouvre directement les posts en cours sur ce match."""
    def last(name):
        parts = [p for p in (name or '').split() if p]
        return parts[-1] if parts else (name or '')
    q = f'"{last(home)}" OR "{last(away)}"'
    return "https://x.com/search?q=" + urllib.parse.quote(q) + "&f=live"


def send(text):
    if DRY_RUN:
        print("---- (DRY_RUN) message Telegram ----\n" + text + "\n"); return True
    url = f"https://api.telegram.org/bot{TOKEN}/sendMessage"
    data = urllib.parse.urlencode({'chat_id': CHAT, 'text': text}).encode()
    req = urllib.request.Request(url, data=data, headers={'User-Agent': 'tennis-edge-steam/1.0'})
    try:
        with urllib.request.urlopen(req, timeout=15) as r: return r.status == 200
    except Exception as e:
        print("Telegram KO:", e); return False

def main():
    data = load_curves(); now = _now()
    # track record : fichier historique dedie si fourni, sinon les passes du live
    track = load_curves(TRACK_CURVES) if TRACK_CURVES else data
    win_start = now - WINDOW_DAYS*86400 if WINDOW_DAYS > 0 else 0
    past = {u: bk for u, bk in track.items()
            if bk.get('_commence') and win_start <= bk['_commence'] < now}
    upcoming = {u: bk for u, bk in data.items()
            if bk.get('_commence') and bk['_commence'] >= now}
    # books mous : union (track passe + a venir), hors sharp
    softbooks = sorted({b for m in list(past.values()) + list(upcoming.values())
                        for b in m if not b.startswith('_') and b != SHARP})
    if SOFT_PREF:
        keep = set(s.strip() for s in SOFT_PREF.split(','))
        softbooks = [b for b in softbooks if b in keep]
    fen = f"{WINDOW_DAYS:.0f}j glissants" if WINDOW_DAYS > 0 else "tout l'historique"
    src = f" | track<-{TRACK_CURVES}" if TRACK_CURVES else ""
    print(f"{CURVES}: {len(data)} matchs | track record {len(past)}{src} ({fen}) | a venir {len(upcoming)} | books {softbooks}")
    if not softbooks:
        print("Aucun book mou — rien a faire."); return
    stats = compute_stats(past, softbooks)

    # seuil optimal par book
    thr_by_book = {sb: best_threshold(stats, sb) for sb in softbooks}
    # LISIBILITÉ : lister les 18 books même quand TOUS sont "n/a" (pas encore de
    # track record) noie le message dans du bruit répétitif -- et double l'info
    # déjà donnée juste au-dessus pour le book qui a déclenché l'alerte. On ne
    # détaille que les books avec un vrai historique (confirmé ou indicatif à
    # faible n) ; les "n/a" sont juste comptés, pas listés un par un.
    confirmed, indicative, unknown = [], [], []
    for sb, (mv, sd, conf) in thr_by_book.items():
        if sd and conf:
            confirmed.append(f"{sb}≥{int(mv*100)}pt({sd['pct']}%)")
        elif sd:
            indicative.append(f"{sb}≥{int(mv*100)}pt({sd['pct']}%?)")
        else:
            unknown.append(sb)
    parts = confirmed + indicative
    if parts:
        seuils_line = " · ".join(parts)
        if unknown:
            seuils_line += f" · +{len(unknown)} book(s) sans historique"
    else:
        seuils_line = f"aucun book n'a encore de track record ({len(unknown)} suivis, système en calibration)"
    print("Seuils adaptes par book :", seuils_line)

    try: state = json.load(open(STATE))
    except Exception: state = {}

    n_sent = 0
    for uid, bk in upcoming.items():
        if SHARP not in bk: continue
        lead = bk['_commence'] - now
        if lead < MIN_LEAD*60: continue
        fnow = _fair(bk[SHARP], sorted(set(t for t,_ in bk[SHARP]['h']))[-1])
        # candidats : chaque book actif (drift >= SON seuil) qui offre de la value
        cands = []
        for sb in softbooks:
            if sb not in bk: continue
            mv, sdat, conf = thr_by_book[sb]
            d = detect(bk[SHARP], mv)
            if not d: continue
            _, side = d
            pfair_side = (fnow if side == 'home' else 1-fnow) if fnow else None
            ser = bk[sb]['h'] if side == 'home' else bk[sb]['a']
            cur = ser[-1][1] if ser else None
            if not cur or cur <= 1: continue
            # EV vs fair Shin = le critere qui paie. Fair non calculable -> pas d'alerte
            # (on n'alerte plus "a l'aveugle" sur le seul franchissement de palier).
            if not pfair_side: continue
            ev = cur * pfair_side - 1
            if ev < EV_MIN_NOW: continue
            pct = sdat['pct'] if sdat else 0
            cands.append({'sb': sb, 'thr': mv, 'side': side, 'odds': cur,
                          'stat': sdat, 'conf': conf, 'pct': pct,
                          'ev': ev, 'fair': 1.0/pfair_side})
        if not cands: continue
        # meilleur : EV d'abord (c'est elle qui paie), reussite historique ensuite
        best = max(cands, key=lambda c: (c['ev'], c['pct']))
        if state.get(uid, 0) >= best['thr']: continue   # deja alerte a ce niveau+
        side = best['side']
        pser = bk[SHARP]['h'] if side == 'home' else bk[SHARP]['a']
        o_open, o_now = pser[0][1], pser[-1][1]
        who = bk['_home'] if side == 'home' else bk['_away']
        sd = best['stat']
        verb = _MKT_VERB.get(MARKET, 'gagne le match')
        # Evolution de la MARGE de l'operateur signale (overround = 1/cote_h + 1/cote_a).
        # Piste en cours de validation (voir margin_watch dans validation_report) :
        # une marge qui S'ELARGIT semble accompagner la correction de l'ecart
        # (le book rabaisse le cote sur lequel il est expose). Affiche pour
        # observation — ne conditionne aucune decision tant que n < 30.
        marge_line = ""
        try:
            sbk = bk.get(best['sb']) or {}
            sh, sa = sbk.get('h') or [], sbk.get('a') or []
            if len(sh) >= 2 and len(sa) >= 2:
                def _ov(i_h, i_a):
                    oh, oa = sh[i_h][1], sa[i_a][1]
                    return (1/oh + 1/oa) if (oh > 1 and oa > 1) else None
                m0, m1 = _ov(0, 0), _ov(-1, -1)
                if m0 and m1:
                    d = (m1 - m0) * 100
                    tend = "élargie" if d > 0.5 else ("resserrée" if d < -0.5 else "stable")
                    marge_line = (f"📐 Marge {best['sb']} : {100*(m0-1):.1f}% → {100*(m1-1):.1f}% "
                                  f"({d:+.1f}pt, {tend})\n")
        except Exception:
            pass
        rec = (f"Reussite {int(best['thr']*100)}pt sur {best['sb']} : {sd['pct']}% battent la cloture "
               f"(CLV med {sd['med']:+.0f}%, n={sd['n']})" + ("" if best['conf'] else " ⚠ indicatif, n faible")
               ) if sd else f"Seuil {int(best['thr']*100)}pt (pas encore de track record — indicatif)"
        # Fiabilité du book signalé (voir book_reliability.py) : sa "paresse"
        # historique est PERSISTANTE (rho lag_t/lag_t+1 = 0,5 à 0,9 mesuré sur
        # 1046 matchs) -- purement informatif, ne filtre rien.
        reliab_line = ""
        try:
            bs = _load_json('book_scores.json', {}).get('scores', {}).get(best['sb'])
            if bs:
                twins = bs.get('twins') or []
                twin_txt = f" · jumeau de {twins[0][0]} (rho {twins[0][1]:.2f})" if twins else ""
                reliab_line = (f"📊 Fiabilité {best['sb']} : retard moyen {bs['reliability_score']:.1f}pt "
                               f"sur {bs['n']} matchs{twin_txt}\n")
        except Exception:
            pass
        msg = (f"🎯 MISER{_MKT_LABEL.get(MARKET, '')} · {bk['_home']} vs {bk['_away']}"
               + (f" ({bk['_tour']})" if bk['_tour'] else "") + "\n"
               f"→ {who} {verb} @ {best['odds']:.2f} ({best['sb']})\n"
               f"💰 EV {best['ev']*100:+.1f}% vs fair {best['fair']:.2f} (Shin Pinnacle, seuil {EV_MIN_NOW*100:.0f}%)\n"
               f"Palier {int(best['thr']*100)}pt · Pinnacle {o_open:.2f}→{o_now:.2f} · depart dans {fmt_lead(lead)}\n"
               + marge_line + reliab_line +
               f"{rec}\n"
               f"Seuils/book : {seuils_line}\n"
               f"🔎 Posts X sur ce match : {x_search_url(bk['_home'], bk['_away'])}")
        if send(msg):
            state[uid] = best['thr']; n_sent += 1
    if not DRY_RUN:
        json.dump(state, open(STATE, 'w'))
    print(f"\nsignaux envoyes : {n_sent}")

if __name__ == '__main__':
    main()
