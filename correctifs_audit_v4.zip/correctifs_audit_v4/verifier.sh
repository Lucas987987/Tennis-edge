#!/usr/bin/env bash
# verifier.sh (v4) — contrôle automatique post-application (28/08/2026).
#
# Usage : bash verifier.sh   (à la racine du dépôt, APRÈS les cp)
# ⚠️ Ce script vérifie les fichiers dans scripts/ et .github/workflows/ --
# lance TOUS les `cp` d'abord, sinon il verra les anciens fichiers.

set -uo pipefail
ECHECS=0

verif() {
    local fichier="$1" motif="$2" description="$3"
    if [ ! -f "$fichier" ]; then
        echo "❌ $fichier : FICHIER ABSENT"
        ECHECS=$((ECHECS+1))
        return
    fi
    if grep -q "$motif" "$fichier"; then
        echo "✅ $fichier : $description"
    else
        echo "❌ $fichier : $description -- MOTIF ABSENT ($motif)"
        ECHECS=$((ECHECS+1))
    fi
}

echo "=== Vérification des correctifs audit v4 (28/08/2026) ==="
echo

verif scripts/paper_journal.py "VÉRIFIÉ LE 28/08/2026" "§T : docstring honnête (vérifié inutile, pas un biais corrigé)"
verif scripts/paper_journal.py "_cache\['idx'\]\[nat\]" "§W : index par clé naturelle COMPLÈTE (avec date)"
verif scripts/paper_journal.py "closed_no_result_depuis" "§Z : trades bloqués -> ABANDONNED après 7j"
verif scripts/steam_alert.py "_cl_idx\[_nat\]" "§W : index complet côté steam_alert aussi"
verif scripts/move_audit.py "commence_time croisé via" "§U : pont anti-in-play dans move_audit.py"
verif scripts/canal_clv.py "commence_time croisé via" "§U : pont anti-in-play dans canal_clv.py"
verif scripts/clv_vs_median_offline.py "moves_detail_hist" "§Y : clv_vs_median calculé hors ligne sur 891 moves"
verif .github/workflows/steam_pipeline.yml 'alerte" = "True"' "§V : bug booléen True/true réellement corrigé"

echo
if [ "$ECHECS" -eq 0 ]; then
    echo "✅✅✅ TOUT EST EN PLACE (8 contrôles passés). Sûr de committer."
    echo
    echo "Rappel manuel (audit v4 §X, pas de fichier à copier -- juste nettoyer) :"
    echo "  rm -f scripts/retrofill_paper_trades.py scripts/steam_pipeline.yml"
    exit 0
else
    echo "❌❌❌ $ECHECS CONTRÔLE(S) EN ÉCHEC. NE PAS COMMITTER avant d'avoir compris pourquoi."
    exit 1
fi
