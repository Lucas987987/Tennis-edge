# Correctifs audit v5 (28/08/2026) — application (codespace, racine)

⚠️ `verifier.sh` reste obligatoire, avant tout commit.

    unzip correctifs_audit_v5.zip
    cp correctifs_audit_v5/scripts/*.py scripts/
    cp correctifs_audit_v5/tests/test_pure_functions.py tests/
    cp correctifs_audit_v5/.github/workflows/*.yml .github/workflows/

    # ── ÉTAPE OBLIGATOIRE ──
    bash correctifs_audit_v5/verifier.sh
    # doit afficher "TOUT EST EN PLACE (11 contrôles passés)"

    python tests/test_pure_functions.py      # doit afficher 13/13
    rm -f verdicts_geles.json

    rm -rf correctifs_audit_v5 correctifs_audit_v5.zip
    git add -A
    git commit -m "Audit v5 : curves_common.py partagé (§AA, tolérance ±1j), clv_vs_median_offline réécrit (§AB, côté par les noms + troncature homogène), branché en quotidien (§AC)"
    git pull --no-rebase --no-edit && git push

---

## Le motif de cette passe : deux correctifs justes qui s'annulent

Le §W (hier, clé complète avec date) et le §M (avant-hier, commence_time
croisé parce que la date diverge parfois) sont individuellement corrects.
Mais le §W suppose la date fiable ; le §M existe parce qu'elle ne l'est
pas. Sur les matchs de fin de soirée à cheval sur minuit, le §W refusait
exactement les cas que le §M corrige. **4 matchs perdus sur 160** dans la
mesure de l'audit.

Aucun test unitaire ne pouvait l'attraper : la contradiction n'était pas
dans une fonction, mais entre deux fonctions qui ne se parlaient pas.

## §AA — la vraie réponse : une fonction partagée, pas une 5e copie

Le bloc de pont vers `closing_lines.json` avait été copié dans quatre
fichiers en une journée (`paper_journal`, `steam_alert`, `move_audit`,
`canal_clv`). Plutôt que de patcher les quatre séparément une nouvelle
fois -- exactement le mode de panne qui a produit cette contradiction --
`scripts/curves_common.py` centralise :
- `build_closing_index()` : charge et indexe `closing_lines.json`
- `cherche_avec_tolerance()` : ±1 jour, n'accepte que si un seul candidat
  distinct existe (jamais de fusion à l'aveugle)
- `tronque_prematch()` : troncature pré-match partagée (utilisée aussi
  par le §AB)

Testé unitairement (3 cas : minuit, 4 jours d'écart exact, cas ambigu) et
sur les vraies partitions : **move_audit passe de 91% à 97% de
résolution** (l'effet direct de la tolérance), sans aucune régression sur
`steam_alert` (84%, identique). `canal_clv` reste non testable de bout en
bout dans ce codespace (limite mémoire préexistante, sans rapport).

## §AB — le script neuf avait réintroduit les deux défauts déjà corrigés ailleurs

`clv_vs_median_offline.py` (hier) devinait le côté (home/away) par un test
numérique corrélé au phénomène étudié -- ne gardait un move QUE si le
marché n'avait pas bougé après le coup d'envoi. Résultat : 44/923 (4,8%),
un échantillon biaisé, pas un échantillon petit.

**Réécrit entièrement** :
- Côté identifié par les noms (`mk._toks`), comme partout ailleurs
- Troncature pré-match sur TOUTES les courbes (via `curves_common`), pas
  seulement celle du book d'entrée
- Plus d'affirmation catégorique ("pas de signature nette") -- IC95
  bootstrap rapporté tel quel, sans conclure à sa place

**Résultat mesuré, nouveau** : 603/891 appariés (68%, contre 4,8% avant --
14x plus de données). IC95 de l'écart clv_book−clv_median : [−0,28, −0,01]
pts -- exclut zéro, mais l'effet est minuscule (quelques centièmes de
point), et dans le sens INVERSE de l'hypothèse du biais de sélection. La
bimodalité n_books (3 vs 8+ uniquement, rien entre) a disparu -- confirmé
que c'était un artefact du biais d'échantillonnage, pas une vraie
propriété du marché.

## §AC — branché, mais en quotidien

Charge 10 partitions de courbes complètes (~2-3 min) -- trop lourd pour
tourner à chaque cycle de 5 minutes. Même motif que le baromètre hebdo/
mensuel déjà dans `steam_pipeline.yml` (`date -u +%u`/`+%d`) : tourne une
fois par jour (`date -u +%H = 05`).

## Tests : 13/13 (le nouveau test de tolérance de date ajouté)
