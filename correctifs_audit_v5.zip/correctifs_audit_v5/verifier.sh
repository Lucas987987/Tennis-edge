#!/usr/bin/env bash
# verifier.sh (v5) — contrôle automatique post-application (28/08/2026).
#
# Usage : bash verifier.sh   (à la racine du dépôt, APRÈS les cp)

set -uo pipefail
ECHECS=0

verif() {
    local fichier="$1" motif="$2" description="$3"
    if [ ! -f "$fichier" ]; then
        echo "❌ $fichier : FICHIER ABSENT"
        ECHECS=$((ECHECS+1))
        return
    fi
    if grep -q "$motif" "$fichier"; then
        echo "✅ $fichier : $description"
    else
        echo "❌ $fichier : $description -- MOTIF ABSENT ($motif)"
        ECHECS=$((ECHECS+1))
    fi
}

echo "=== Vérification des correctifs audit v5 (28/08/2026) ==="
echo

verif scripts/curves_common.py "cherche_avec_tolerance" "§AA : module partagé créé, tolérance ±1 jour"
verif scripts/curves_common.py "tronque_prematch" "§AA/§AB : troncature pré-match partagée"
verif scripts/paper_journal.py "import curves_common as cc" "§AA : paper_journal branché sur le module partagé"
verif scripts/steam_alert.py "import curves_common as cc" "§AA : steam_alert branché sur le module partagé"
verif scripts/move_audit.py "import curves_common as cc" "§AA : move_audit branché sur le module partagé"
verif scripts/canal_clv.py "import curves_common as cc" "§AA : canal_clv branché sur le module partagé"
verif scripts/clv_vs_median_offline.py "_cote_par_noms" "§AB.1 : côté identifié par les noms, pas deviné"
verif scripts/clv_vs_median_offline.py "cc.tronque_prematch" "§AB.2 : troncature pré-match sur toutes les courbes"
verif scripts/clv_vs_median_offline.py "IC95 traverse 0" "§AB.4 : plus d'affirmation catégorique non soutenue"
verif tests/test_pure_functions.py "test_curves_common_tolerance_date" "§AA : test unitaire minuit/4-jours ajouté"
verif .github/workflows/steam_pipeline.yml "clv_vs_median_offline.py" "§AC : script branché dans le pipeline"

echo
if [ "$ECHECS" -eq 0 ]; then
    echo "✅✅✅ TOUT EST EN PLACE (11 contrôles passés). Sûr de committer."
    exit 0
else
    echo "❌❌❌ $ECHECS CONTRÔLE(S) EN ÉCHEC. NE PAS COMMITTER avant d'avoir compris pourquoi."
    exit 1
fi
