# Correctifs audit v6 (28/08/2026) — application (codespace, racine)

⚠️ `verifier.sh` reste obligatoire.

    unzip correctifs_audit_v6.zip
    cp correctifs_audit_v6/scripts/*.py scripts/
    cp correctifs_audit_v6/.github/workflows/*.yml .github/workflows/

    # ── ÉTAPE OBLIGATOIRE ──
    bash correctifs_audit_v6/verifier.sh
    # doit afficher "TOUT EST EN PLACE (7 contrôles passés)"

    python tests/test_pure_functions.py      # doit encore afficher 13/13
    rm -f verdicts_geles.json clv_vs_median_report.json

    rm -rf correctifs_audit_v6 correctifs_audit_v6.zip
    git add -A
    git commit -m "Audit v6 : garde-fou d'heure mort retiré (§AE), rapport committé, décomposition prime/dérive répond au §E (§AF/§AG), seuil de pertinence pratique, ambiguïté de côté refusée (§AH), seuil Q3 relatif (§AI)"
    git pull --no-rebase --no-edit && git push

---

## §E est enfin tranché

Après six versions, la question posée hier soir a une réponse nette,
reproduite indépendamment sur les vraies données (script réécrit, sans
regarder le chiffre de l'audit avant de calculer) :

    PRIME DE SÉLECTION (choix du meilleur book)  : +1,28 % [IC95 1,10, 1,44]
    DÉRIVE DU MARCHÉ    (mouvement réel après)   : +3,60 % [IC95 3,19, 4,00]
    part de la prime dans le total               : ~26 %

**Environ un quart du CLV vient du choix du meilleur book ; trois quarts
d'un mouvement réel du marché.** Chiffres très proches de ceux de l'audit
(26 % vs leur 26 %, 1,28 vs 1,35, 3,60 vs 3,51 -- écarts mineurs dus à
l'évolution des données entre les deux mesures).

Ce que ça ne dit pas : le journal forward affiche toujours ROI -21,2 % sur
31 paris pendant que ce calcul dit CLV net de sélection +3,60 %. Soit
n=31 ne dit rien (IC très large, l'explication la plus probable), soit la
dérive ne se convertit pas en profit (marge, limites, gubbing). C'est la
seule vraie question qui reste ouverte -- et elle se répond par
l'accumulation de données, pas par une nouvelle correction de code.

## §AE — le motif le plus têtu de la journée, cinquième occurrence

`if [ "$(date -u +%H)" = "05" ]` ne pouvait jamais se déclencher :
`steam_pipeline.yml` n'a qu'un seul cron, à 00h15 UTC. Le script réécrit
n'aurait donc jamais tourné. Vérifié : le workflow n'a QUE
`workflow_dispatch` et ce cron unique (pas de repository_dispatch) --
retirer la garde est donc sûr, le script tournera une fois par jour comme
prévu, sans condition impossible.

Deuxième moitié du même défaut : la sortie partait en `stdout`, jamais
committée -- la situation exacte de Q3 avant son propre correctif, resté
non lu deux mois et demi. `clv_vs_median_report.json` est maintenant écrit,
ajouté aux deux listes de commit, et lu par `pipeline_status.py` (même
motif que Q3).

## §AF/§AG — la vraie décomposition, pas un mélange de deux effets

Le script d'hier comparait `clv_book` (entrée vs clôture du book choisi,
le max) à `clv_median` (entrée vs clôture médiane) -- deux quantités qui ne
mesurent pas la même chose : l'entrée est déjà un maximum, la médiane à la
clôture est donc mécaniquement plus basse, indépendamment de tout
mouvement de marché. Réécrit pour comparer prime et dérive **au même
instant chacune** :
- prime = entry / médiane À L'ENTRÉE (isole le choix du book)
- dérive = médiane à l'entrée / médiane à la clôture (isole le mouvement)

L'instant d'entrée est reconstruit via `commence_time - lead_min`.

**§AF.2, corrigé aussi** : un IC qui exclut zéro ne suffit plus à lui seul
-- il faut EN PLUS que l'écart dépasse un seuil de pertinence pratique
(1 point). Sans ça, n'importe quel écart infime devient « significatif »
sur un échantillon de plusieurs centaines de lignes.

## §AH — la même ambiguïté que match_key.py, réintroduite localement

`_cote_par_noms` renvoyait `'h'` dès que le côté home matchait, SANS
vérifier que away ne matchait pas aussi -- exactement le risque qui avait
fait retirer l'étape 4 de `match_key.py` en passe 3 (Zverev/Zverev,
Wu/Wu). Corrigé : teste les deux côtés, ne renvoie que si un seul
correspond. Sur les données actuelles, 1 cas ambigu détecté et écarté
proprement (confirmé en test).

## §AI — seuil Q3 relatif

200 écarts absolus, choisi quand le compte était à 150, aurait été franchi
en quelques semaines par simple croissance de la population comparée.
Remplacé par un seuil sur la PROPORTION (écarts / n total comparé). Le
premier seuil essayé (15 %) se serait déclenché dès le déploiement --
l'état réel actuel est à 16,6 %. Relevé à 30 %, qui laisse une marge
confortable sur l'état actuel tout en restant protecteur.

## Tests : 13/13 (inchangé)
