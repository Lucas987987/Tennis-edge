#!/usr/bin/env bash
# verifier.sh (v6) — contrôle automatique post-application (28/08/2026).
#
# Usage : bash verifier.sh   (à la racine du dépôt, APRÈS les cp)

set -uo pipefail
ECHECS=0

verif() {
    local fichier="$1" motif="$2" description="$3"
    if [ ! -f "$fichier" ]; then
        echo "❌ $fichier : FICHIER ABSENT"
        ECHECS=$((ECHECS+1))
        return
    fi
    if grep -q "$motif" "$fichier"; then
        echo "✅ $fichier : $description"
    else
        echo "❌ $fichier : $description -- MOTIF ABSENT ($motif)"
        ECHECS=$((ECHECS+1))
    fi
}

verif_absent() {
    local fichier="$1" motif="$2" description="$3"
    if [ ! -f "$fichier" ]; then
        echo "❌ $fichier : FICHIER ABSENT"
        ECHECS=$((ECHECS+1))
        return
    fi
    if grep -q "$motif" "$fichier"; then
        echo "❌ $fichier : $description -- MOTIF ENCORE PRÉSENT ($motif, doit être absent)"
        ECHECS=$((ECHECS+1))
    else
        echo "✅ $fichier : $description"
    fi
}

echo "=== Vérification des correctifs audit v6 (28/08/2026) ==="
echo

verif_absent .github/workflows/steam_pipeline.yml 'date -u +%H' "§AE : garde-fou d'heure inatteignable retiré"
verif .github/workflows/steam_pipeline.yml "clv_vs_median_report.json" "§AE : rapport écrit dans un fichier committé"
verif .github/workflows/steam_pipeline.yml "seuil_pct=30" "§AI : seuil Q3 relatif (pas absolu)"
verif scripts/pipeline_status.py "clv_vs_median_report.json" "§AE : pipeline_status.py lit le nouveau rapport"
verif scripts/clv_vs_median_offline.py "PRIME DE SELECTION" "§AF/§AG : décomposition prime/dérive"
verif scripts/clv_vs_median_offline.py "SEUIL_PERTINENCE_PTS" "§AF.2 : seuil de pertinence pratique, pas seulement l'IC"
verif scripts/clv_vs_median_offline.py "ih and not ia" "§AH : ambiguïté de côté refusée, pas devinée"

echo
if [ "$ECHECS" -eq 0 ]; then
    echo "✅✅✅ TOUT EST EN PLACE (7 contrôles passés). Sûr de committer."
    exit 0
else
    echo "❌❌❌ $ECHECS CONTRÔLE(S) EN ÉCHEC. NE PAS COMMITTER avant d'avoir compris pourquoi."
    exit 1
fi
