# Correctifs audit v7 (28/08/2026) — application (codespace, racine)

⚠️ `verifier.sh` reste obligatoire.

    unzip correctifs_audit_v7.zip
    cp correctifs_audit_v7/scripts/*.py scripts/
    cp correctifs_audit_v7/.github/workflows/*.yml .github/workflows/

    # ── ÉTAPE OBLIGATOIRE ──
    bash correctifs_audit_v7/verifier.sh
    # doit afficher "TOUT EST EN PLACE (8 contrôles passés)"

    python tests/test_pure_functions.py      # doit encore afficher 13/13
    rm -f verdicts_geles.json clv_vs_median_report.json

    rm -rf correctifs_audit_v7 correctifs_audit_v7.zip
    git add -A
    git commit -m "Audit v7 : sparse-checkout Polymarket réparé (§AJ), garde-fou sur le rapport, TOTAL corrigé (§AK.1-3), ventilation par délai (§AL), uniformisation clôture (§AM)"
    git pull --no-rebase --no-edit && git push

---

## Le plus important : l'audit a cassé sa propre recommandation, et l'a réparé lui-même

Le sparse-checkout de `polymarket_studies.yml` (proposé en passe 2 pour tenir
le budget de 30 min) excluait `parts/hist_book_*` -- les 5 études en ont
pourtant absolument besoin, c'est tout leur objet (croiser les ticks
Polymarket/Kalshi avec les courbes Pinnacle). Résultat : les 5 études ont
tourné, chargé 2,3 millions de ticks, et échoué avec `0 match commun`. Une
ligne ajoutée au sparse-checkout (`/parts/hist_book_*`, ~300 Mo, large marge
sous les 60 minutes).

Deuxième moitié du problème, plus insidieuse : `test -s` (fichier non vide)
laissait passer un rapport contenant 5 `❌` sans rien signaler -- le commit
partait normalement. Corrigé avec le même motif que Q3 et le rapport CLV :
compte des `❌`, écrit dans `polymarket_studies_status.json`, lu par
`pipeline_status.py`.

Le problème de fond reste entier et n'est pas du ressort d'un correctif :
le collecteur Polymarket n'enregistre toujours pas les volumes échangés
(`0 échange(s) horodaté(s)` sur 2,3M de ticks) -- `polymarket_flow` ne
pourra rien produire même une fois les courbes disponibles. Décision à
prendre : soit le collecteur enregistre les montants, soit ce volet
disparaît. Pas tranché ce soir.

## §AK — le TOTAL affiché hier était faux de 0,35 à 0,56 point

Trois défauts distincts dans la même ligne de sortie :

1. **Composition de médianes ≠ médiane des compositions.** `(1+méd_prime)×
   (1+méd_dérive)−1` n'est pas la médiane du produit ligne par ligne.
   Corrigé : chaque move a maintenant son propre `total` (entry/médiane
   clôture), et le rapport prend la médiane de CES valeurs. Résultat
   mesuré : +5,26% (contre +4,93% avec l'ancien calcul).

2. **L'étiquette désignait la mauvaise quantité.** Le total de la
   décomposition EST `clv_vs_median` (entry vs book médian), pas
   `clv_book` (entry vs book D'ENTRÉE). Les deux sont maintenant affichés
   côte à côte, avec l'écart (−0,26 pt mesuré) explicitement interprété :
   ce que coûte de rester au book d'entrée plutôt que d'être au médian
   jusqu'à la clôture.

3. **`part_prime` divisée par un nombre qui n'existe nulle part ailleurs**
   (`mp+md`, ni le total d'hier ni celui d'aujourd'hui). Corrigé :
   `part_prime = mp / total_réel`.

## §AL — la ventilation par délai, et une hypothèse de l'audit réfutée par la mesure

L'audit avait supposé que les 363 moves exclus (faute de 3 books à
l'entrée) auraient une prime plus forte -- **mesuré, c'est faux** : la
prime reste stable (±0,2 pt) sur toutes les tranches de délai, y compris
en élargissant le seuil à 2 books. Le +1,28% est donc robuste.

En revanche la **dérive** varie d'un facteur 3 selon le délai détection→
départ (confirmé sur les données actuelles : +1,17% avant 6h contre +3,75
à +4,64% au-delà). Ventilation ajoutée au script (4 tranches, coût : une
douzaine de lignes) -- actionnable sur `MIN_LEAD` (actuellement 15 min),
qui laisse passer des signaux qui n'apportent quasiment que la prime de
sélection, pas de vrai mouvement de marché.

## §AM — deux points mineurs, l'un corrigé, l'autre documenté

- Clôture uniformisée sur `_point_a_ou_avant` (scan, ne suppose pas l'ordre)
  au lieu de `pts[-1][1]` (suppose trié) -- même fonction que pour l'entrée.
  Aucun effet mesuré aujourd'hui (0 courbe désordonnée sur 8474), mais une
  seule convention au lieu de deux.
- Le join `moves ↔ courbes` reste volontairement SANS tolérance de date
  (le seul du dépôt) -- documenté pourquoi (même source pour les deux
  dates), pour qu'on ne le "corrige" pas à tort plus tard.

## Tests : 13/13 (inchangé)
