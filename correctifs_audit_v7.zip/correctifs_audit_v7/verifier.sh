#!/usr/bin/env bash
# verifier.sh (v7) — contrôle automatique post-application (28/08/2026).
#
# Usage : bash verifier.sh   (à la racine du dépôt, APRÈS les cp)

set -uo pipefail
ECHECS=0

verif() {
    local fichier="$1" motif="$2" description="$3"
    if [ ! -f "$fichier" ]; then
        echo "❌ $fichier : FICHIER ABSENT"
        ECHECS=$((ECHECS+1))
        return
    fi
    if grep -q "$motif" "$fichier"; then
        echo "✅ $fichier : $description"
    else
        echo "❌ $fichier : $description -- MOTIF ABSENT ($motif)"
        ECHECS=$((ECHECS+1))
    fi
}

echo "=== Vérification des correctifs audit v7 (28/08/2026) ==="
echo

verif .github/workflows/polymarket_studies.yml "/parts/hist_book_\*" "§AJ : hist_book ajouté au sparse-checkout"
verif .github/workflows/polymarket_studies.yml "polymarket_studies_status.json" "§AJ : comptage des échecs écrit"
verif scripts/pipeline_status.py "polymarket_studies_status.json" "§AJ : pipeline_status.py lit le statut Polymarket"
verif scripts/clv_vs_median_offline.py "médiane des totaux PAR MOVE" "§AK.1 : total = médiane des totaux, pas composition"
verif scripts/clv_vs_median_offline.py "clv_book_pct_median" "§AK.2 : comparaison clv_book vs clv_vs_median ajoutée"
verif scripts/clv_vs_median_offline.py "100 \* mp / mt" "§AK.3 : part_prime avec le bon dénominateur"
verif scripts/clv_vs_median_offline.py "Ventilation par délai" "§AL : ventilation prime/dérive par tranche de lead"
verif scripts/clv_vs_median_offline.py "_point_a_ou_avant(pts, ct)" "§AM.1 : clôture uniformisée sur _point_a_ou_avant"

echo
if [ "$ECHECS" -eq 0 ]; then
    echo "✅✅✅ TOUT EST EN PLACE (8 contrôles passés). Sûr de committer."
    exit 0
else
    echo "❌❌❌ $ECHECS CONTRÔLE(S) EN ÉCHEC. NE PAS COMMITTER avant d'avoir compris pourquoi."
    exit 1
fi
