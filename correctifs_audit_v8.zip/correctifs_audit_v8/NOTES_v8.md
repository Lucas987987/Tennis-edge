# Correctifs audit v8 (28/08/2026) — application (codespace, racine)

⚠️ `verifier.sh` reste obligatoire.

    unzip correctifs_audit_v8.zip
    cp correctifs_audit_v8/scripts/*.py scripts/
    cp correctifs_audit_v8/.github/workflows/*.yml .github/workflows/

    # ── ÉTAPE OBLIGATOIRE ──
    bash correctifs_audit_v8/verifier.sh
    # doit afficher "TOUT EST EN PLACE (9 contrôles passés)"

    python tests/test_pure_functions.py      # doit encore afficher 13/13
    rm -f verdicts_geles.json clv_vs_median_report.json pipeline_status.json pipeline_status.md

    rm -rf correctifs_audit_v8 correctifs_audit_v8.zip
    git add -A
    git commit -m "Audit v8 : les 3 blocs d'alerte enfin rendus dans pipeline_status.md (§AP), alerte branchée sur --strict, écart apparié par pari (§AN), comptage Polymarket corrigé + horodaté (§AO)"
    git pull --no-rebase --no-edit && git push

---

## §AP — le correctif au meilleur rapport effort/valeur des huit passes

Quatre correctifs différents (§S, §AE, §AJ) avaient fait remonter une alerte
depuis un log de run jusqu'à un fichier JSON committé. **Aucun n'avait fait
le dernier pas** : `pipeline_status.py` chargeait bien `q3`, `clv_median` et
`pm_studies` dans le payload JSON, mais ne les ajoutait JAMAIS au rendu
Markdown -- le seul fichier que tu regardes réellement sur GitHub. Vérifié :
`grep -ci "q3|clv_vs_median|polymarket|alerte" pipeline_status.md` renvoyait
0. Le champ `alerte`, écrit trois fois, n'était lu par aucun script.

Corrigé : les trois blocs apparaissent maintenant dans `pipeline_status.md`
(testé sur les trois cas -- Q3 seul, CLV seul, Polymarket avec alerte --
tous confirmés présents dans le fichier réel). Et `alerte` (Q3 et
Polymarket) est branché sur le mode `--strict`, le seul mécanisme du dépôt
qui rend un run rouge -- testé, `exit 1` confirmé sur une vraie alerte.

## §AN — j'ai répété l'erreur trois lignes après l'avoir corrigée

`ecart_book_median = med_clv_book - mt` : différence de deux médianes
agrégées séparément, EXACTEMENT l'erreur du §AK.1 corrigée juste au-dessus
dans le même fichier. La question posée ("que coûte de rester au book
d'entrée ?") est une quantité PAR PARI -- il fallait `médiane(a-b)`, pas
`médiane(a)-médiane(b)`.

Corrigé avec une différence appariée, passée par `_ic_bootstrap()` et
`_verdict()` comme le reste du script. Résultat mesuré sur les données
actuelles : **-0,04 pt** [IC95 -0,28, -0,00] -- classé automatiquement
« pas actionnable » par `_verdict()`, cohérent avec la lecture de l'audit
(le book d'entrée revient au niveau du pack à la clôture, la prime
s'encaisse à l'entrée, pas conservée jusqu'au bout).

## §AO — le comptage Polymarket, corrigé et horodaté

`grep -c "❌"` ne comptait que 3 échecs sur 5 réels -- 2 des 5 études
émettent `⚠️` plutôt que `❌`. Remplacé par `grep -cE "❌|⚠️"` (testé sur le
vrai rapport de l'audit : 5/5 cette fois). Reste fragile par nature (un
grep sur des émojis en texte libre) -- documenté comme tel, pas prétendu
résolu.

`genere_le` ajouté : ce statut est écrit par un workflow SÉPARÉ
(`polymarket_studies.yml`, 04h20 UTC), lu par un autre
(`steam_pipeline.yml`, 00h15 UTC). Sans date, un statut vieux de plusieurs
semaines s'afficherait indéfiniment comme frais si le producteur
s'arrêtait. `pipeline_status.py` vérifie maintenant l'âge (seuil 36h) et
affiche `⏳ statut périmé` plutôt qu'un faux vert -- testé sur les trois
cas (frais/OK, frais/alerte, périmé à 48h), y compris que `--strict`
échoue bien sur un statut périmé.

## Tests : 13/13 (inchangé)
