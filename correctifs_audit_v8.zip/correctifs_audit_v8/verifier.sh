#!/usr/bin/env bash
# verifier.sh (v8) — contrôle automatique post-application (28/08/2026).
#
# Usage : bash verifier.sh   (à la racine du dépôt, APRÈS les cp)

set -uo pipefail
ECHECS=0

verif() {
    local fichier="$1" motif="$2" description="$3"
    if [ ! -f "$fichier" ]; then
        echo "❌ $fichier : FICHIER ABSENT"
        ECHECS=$((ECHECS+1))
        return
    fi
    if grep -q "$motif" "$fichier"; then
        echo "✅ $fichier : $description"
    else
        echo "❌ $fichier : $description -- MOTIF ABSENT ($motif)"
        ECHECS=$((ECHECS+1))
    fi
}

echo "=== Vérification des correctifs audit v8 (28/08/2026) ==="
echo

verif scripts/pipeline_status.py "Qualité de clôture (Q3)" "§AP : bloc Q3 rendu dans le Markdown"
verif scripts/pipeline_status.py "CLV décomposé" "§AP : bloc CLV rendu dans le Markdown"
verif scripts/pipeline_status.py "Études Polymarket" "§AP : bloc Polymarket rendu dans le Markdown"
verif scripts/pipeline_status.py "alertes_contenu" "§AP : alerte branchée sur --strict"
verif scripts/pipeline_status.py "fraicheur_inconnue_ou_perimee" "§AO : vérification de fraîcheur du statut Polymarket"
verif scripts/clv_vs_median_offline.py "ecarts_pairs = \[cb - x\['total'\]" "§AN : écart apparié par pari, pas différence de médianes"
verif scripts/clv_vs_median_offline.py "_verdict('écart clv_book" "§AN : écart passé par _verdict() comme le reste"
verif .github/workflows/polymarket_studies.yml 'grep -cE "❌|⚠️"' "§AO : comptage des 2 symboles (pas seulement ❌)"
verif .github/workflows/polymarket_studies.yml "genere_le=" "§AO : horodatage ajouté au statut Polymarket"

echo
if [ "$ECHECS" -eq 0 ]; then
    echo "✅✅✅ TOUT EST EN PLACE (9 contrôles passés). Sûr de committer."
    exit 0
else
    echo "❌❌❌ $ECHECS CONTRÔLE(S) EN ÉCHEC. NE PAS COMMITTER avant d'avoir compris pourquoi."
    exit 1
fi
