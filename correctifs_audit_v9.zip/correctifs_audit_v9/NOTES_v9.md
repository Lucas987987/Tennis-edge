# Correctifs audit v9 (28/08/2026) — URGENT, avant le run de 04h20 UTC

⚠️⚠️⚠️ Ce paquet est plus urgent que les précédents. Sans lui, `steam_pipeline`
sera rouge à CHAQUE exécution à partir de demain matin (le run Polymarket de
04h20 UTC écrit un statut, `steam_pipeline` le relit à 00h15 UTC le lendemain
-- la première exécution rouge arrivera donc au plus tard après-demain, mais
le disjoncteur est déjà armé dès que `polymarket_studies_status.json` sera
régénéré avec le code d'hier soir).

`verifier.sh` reste obligatoire, et cette version SIMULE explicitement le cas
nominal (rapport sain, 0 échec, avertissements normaux) -- c'est précisément
le geste qui a manqué hier soir.

    unzip correctifs_audit_v9.zip
    cp correctifs_audit_v9/scripts/*.py scripts/
    cp correctifs_audit_v9/.github/workflows/*.yml .github/workflows/

    # ── ÉTAPE OBLIGATOIRE ──
    bash correctifs_audit_v9/verifier.sh
    # doit afficher "TOUT EST EN PLACE (6 contrôles passés, dont la simulation)"
    # ET "le cas nominal reste vert" -- si ce n'est pas le cas, NE PAS committer

    python tests/test_pure_functions.py      # doit encore afficher 13/13
    rm -f verdicts_geles.json clv_vs_median_report.json pipeline_status.json pipeline_status.md

    rm -rf correctifs_audit_v9 correctifs_audit_v9.zip
    git add -A
    git commit -m "Audit v9 URGENT : découple echecs/avertissements Polymarket avant que --strict ne bloque en permanence (§AR), auto-vérif pipeline_status (§AS)"
    git pull --no-rebase --no-edit && git push

---

## Ce qui s'est passé

Deux correctifs d'hier soir, chacun individuellement défendable, se
combinaient en un blocage permanent :
- §AO (compter les deux symboles ❌ et ⚠️ pour ne plus sous-compter)
- §AP (brancher `alerte` sur `--strict`, le seul verrou du dépôt)

Le problème : `⚠️ historique tronqué` n'est PAS un marqueur d'échec dans
ces scripts -- c'est l'annonce, en fonctionnement NORMAL, que le mécanisme
d'archivage (ajouté en passe 4) fonctionne. Il s'affiche dès que
`parts/ARCHIVE_INDEX.json` contient au moins une entrée -- **6 désormais**,
donc affiché à chaque run, pour toujours.

Simulé sur un rapport où les 5 études réussissent intégralement :
`n_echecs` comptait quand même **7** (les avertissements normaux), donc
`alerte=True`, donc `--strict` échouait -- **même quand tout va bien**.

## Le correctif

Deux compteurs séparés, écrits dans `polymarket_studies_status.json` :
- `n_echecs` : uniquement `❌` (les vraies pannes -- aucune série, aucun
  match commun, fichier absent). C'est LUI qui alimente `alerte` et donc
  `--strict`.
- `n_avertissements` : `⚠️` en plus, affiché dans `pipeline_status.md`
  (« 0 échec(s) · 6 avertissement(s) (info) »), jamais transmis à `alerte`.

Simulé avant livraison, cette fois : rapport avec 6 avertissements normaux
+ 0 vrai échec → `n_echecs=0`, `alerte=False` → `--strict` reste vert.
Rapport avec les mêmes 6 avertissements + 1 vrai échec ajouté →
`n_echecs=1`, `alerte=True` → `--strict` détecte toujours correctement le
vrai problème.

## Ce qui reste non fait, volontairement

Le `STATUS: ok|degraded|failed` par script (la solution « durable »
suggérée deux fois par l'audit) n'a pas été fait ce soir -- ça touche 5
fichiers que je n'ai pas ouverts aujourd'hui, sous la pression du délai de
04h20. Le découplage échecs/avertissements est la version « immédiate,
une ligne » que l'audit propose en alternative, explicitement validée par
simulation avant livraison. À faire dans une prochaine passe, sans la même
urgence.

Le §AS (auto-surveillance de `pipeline_status.json`/`.md`) est traité de
façon minimale (vérification que ce run a bien écrit un fichier non vide) --
la disparition d'hier soir était très probablement due à des commandes de
nettoyage locales, pas à un bug du pipeline ; les deux fichiers sont déjà
dans la liste `git add`.

## Tests : 13/13 (inchangé)
