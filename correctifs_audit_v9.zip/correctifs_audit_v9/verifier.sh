#!/usr/bin/env bash
# verifier.sh (v9) — contrôle automatique post-application (28/08/2026).
#
# Cette version simule EXPLICITEMENT le cas nominal (rapport sain, 0 échec
# réel, avertissements normaux) -- c'est précisément le geste qui a manqué
# hier soir et qui aurait évité le disjoncteur permanent du §AR.
#
# Usage : bash verifier.sh   (à la racine du dépôt, APRÈS les cp)

set -uo pipefail
ECHECS=0

verif() {
    local fichier="$1" motif="$2" description="$3"
    if [ ! -f "$fichier" ]; then
        echo "❌ $fichier : FICHIER ABSENT"
        ECHECS=$((ECHECS+1))
        return
    fi
    if grep -q "$motif" "$fichier"; then
        echo "✅ $fichier : $description"
    else
        echo "❌ $fichier : $description -- MOTIF ABSENT ($motif)"
        ECHECS=$((ECHECS+1))
    fi
}

verif_absent() {
    local fichier="$1" motif="$2" description="$3"
    if [ ! -f "$fichier" ]; then
        echo "❌ $fichier : FICHIER ABSENT"
        ECHECS=$((ECHECS+1))
        return
    fi
    if grep -q "$motif" "$fichier"; then
        echo "❌ $fichier : $description -- MOTIF ENCORE PRÉSENT ($motif, doit être absent)"
        ECHECS=$((ECHECS+1))
    else
        echo "✅ $fichier : $description"
    fi
}

echo "=== Vérification des correctifs audit v9 (28/08/2026) ==="
echo

verif_absent .github/workflows/polymarket_studies.yml 'grep -cE "❌|⚠️"' "§AR : ne compte plus les 2 symboles ensemble comme échecs"
verif .github/workflows/polymarket_studies.yml 'n_echecs=\$(grep -c "❌"' "§AR : n_echecs = ❌ seul (bloquant)"
verif .github/workflows/polymarket_studies.yml "n_avertissements=" "§AR : n_avertissements séparé (affiché, non bloquant)"
verif scripts/pipeline_status.py "n_avertissements" "§AR : pipeline_status.py affiche n_avertissements à part"
verif scripts/pipeline_status.py "écriture de ce run absente ou vide" "§AS : auto-vérification après écriture"

echo
echo "=== SIMULATION DU CAS NOMINAL (le geste qui a manqué hier soir) ==="
cat > /tmp/rapport_nominal_verif.md <<'EOF'
--- polymarket_flow ---
⚠️ historique tronqué : 6 partition(s) archivée(s) hors git (voir parts/ARCHIVE_INDEX.json)
--- polymarket_leadlag ---
⚠️ historique tronqué : 6 partition(s) archivée(s) hors git (voir parts/ARCHIVE_INDEX.json)
⚠️ |décalage| <= 5 min = pas de la grille
--- polymarket_studies ---
⚠️ ceci suppose que le milieu de fourchette est non biaisé.
--- pm_calibration_track ---
⚠️ historique tronqué : 6 partition(s) archivée(s) hors git (voir parts/ARCHIVE_INDEX.json)
--- pm_observations ---
⚠️ historique tronqué : 6 partition(s) archivée(s) hors git (voir parts/ARCHIVE_INDEX.json)
EOF
n_echecs=$(grep -c "❌" /tmp/rapport_nominal_verif.md || true)
alerte=$(python3 -c "print($n_echecs > 0)" 2>/dev/null || echo "?")
echo "0 échec réel, 6 avertissements normaux -> n_echecs=$n_echecs, alerte=$alerte"
if [ "$n_echecs" = "0" ]; then
    echo "✅ le cas nominal reste vert -- le disjoncteur ne se déclenche plus à tort"
else
    echo "❌❌❌ ALERTE : le cas nominal déclenche encore une alerte -- NE PAS COMMITTER"
    ECHECS=$((ECHECS+1))
fi

echo
if [ "$ECHECS" -eq 0 ]; then
    echo "✅✅✅ TOUT EST EN PLACE (6 contrôles passés, dont la simulation). Sûr de committer."
    exit 0
else
    echo "❌❌❌ $ECHECS CONTRÔLE(S) EN ÉCHEC. NE PAS COMMITTER avant d'avoir compris pourquoi."
    exit 1
fi
