# Correctifs v3 — 25/08/2026 après-midi (régression sparse + durcissements)

## 🔴 La régression (audit confirmé, panne active de 09:01 au déploiement de ce patch)
Le sparse-checkout de capture_closing excluait parts/hist_*, lu via
l'indirection steam_alert.load_curves() -> ov.iter_hist_lines(). Prouvé dans
le log de production de 09:01 : « track record 0 … aucun book n'a encore de
track record ». Conséquences pendant la fenêtre : alertes sur seuils
DEFAULT_THR, journal forward sous seuils dégradés, resultats_derived figé.

- capture_closing.yml : /parts/hist_* réintégré au sparse. pm_ticks/kx_ticks
  restent exclus (revérifiés EN SUIVANT LES INDIRECTIONS : lus par aucun
  script de ce workflow). Économie conservée : ~240 Mo/run.
- steam_alert.py + oddspapi_v5.py : deux garde-fous « lecture vide » — un
  historique demandé qui revient vide imprime un ⚠️ explicite. C'est le
  garde-fou qui aurait rendu la panne visible en 1 run au lieu de 2 h 30.
- Validé : 0 courbe + ⚠️ en environnement sparse fautif ; 1682 courbes sur le
  dépôt complet.

⚠️ À noter pour l'honnêteté du forward : les entrées du journal du 25/08
entre 09:01 UTC et le déploiement de ce patch ont été produites sous seuils
par défaut. Elles sont horodatées — à annoter ou exclure du bilan.

## 🟠 Le piège du verdict « externe » (pipeline_status.py)
Le mtime d'un fichier checkouté = l'heure du checkout : le test d'âge était
toujours vrai, une panne du producteur restait ✅ pour toujours. La fraîcheur
est maintenant lue DANS le fichier (generated_at/updated). Sans champ
lisible : « ⏳ FIGÉ (fraîcheur inconnue) », jamais un faux ✅.
Validé : ✅ avec le generated_at réel (08:43 ce matin), ⏳ FIGÉ avec un
generated_at vieilli artificiellement de 3 jours.

## 🟠 Deadline globale de retry (oddspapi_v5.py)
Budget partagé ODDS_DEADLINE_S (300 s défaut) : une fois épuisé, chaque appel
garde SA tentative unique mais plus aucun ne rejoue. Une API morte coûte des
points, plus jamais le run entier. Validé avec un faux curl.

## 🟠 Troncature d'archivage rendue visible
archive_ticks.py écrit parts/ARCHIVE_INDEX.json (fichier, date, release,
octets). polymarket_common.charger_pm(), pm_observations et
pm_calibration_track impriment « historique tronqué : … » dès qu'il existe.

## 🟢 Divers
- steam_pipeline.yml : le verrou --strict écrit dans /tmp (ne réécrit plus
  les pipeline_status.* commités après le push).
- elo_mov.yml : pip install -r requirements.txt (dernier install nu).
- pandas 3.0.2 : existe (installé par le runner ce matin) ET
  merge_backtest.py validé dessus — run complet, 252 résultats protégés.

## Points de l'audit NON retenus, avec raison
- « calibration_books.py appelé par aucun workflow » : faux depuis ce matin,
  book_index.yml l'appelle (ligne 64) et committe calibration_books.md.
- 15 scripts orphelins : réel, reporté — un tri à froid, pas un correctif.

## Application (codespace, à la racine)
    unzip correctifs_v3.zip
    cp -r correctifs_v3/scripts/. scripts/
    cp -r correctifs_v3/.github/workflows/. .github/workflows/
    python tests/test_pure_functions.py
    rm -rf correctifs_v3 correctifs_v3.zip
    git add -A -- scripts .github/workflows
    git commit -m "Fix régression sparse (hist_*) + garde-fous lecture vide + deadline retry"
    git pull --no-rebase --no-edit && git push
