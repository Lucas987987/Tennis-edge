# Correctifs v4 — 25/08/2026 soir (verrou externe + couverture troncature + Holm)

## 🔴 Le verrou --strict verrouille enfin l'externe
La ligne de partage est désormais interne vs externe : interne+FIGÉ = normal ;
externe+FIGÉ (y compris « fraîcheur inconnue ») = producteur mort = ROUGE.
`externe` est propagé dans le dict de chaque livrable. Testé : vert avec le
generated_at réel de ce matin, exit 1 avec un generated_at vieilli de 3 jours.

## 🟠 Troncature : les 2 lecteurs restants couverts
polymarket_leadlag et polymarket_flow impriment l'avis « historique tronqué »
(ARCHIVE_INDEX couvre déjà pm_ticks ET kx_ticks). NB : pm_observations et
pm_calibration_track l'avaient DÉJÀ depuis la v3 (commit 39bd42d) — le point
de l'audit était faux pour ces deux-là.

## 🟠 Garde-fou steam_alert déplacé sur la branche effective
L'ancien restait (chemin arbitraire absent) ; le nouveau se déclenche quand un
historique legacy produit 0 courbe. Testé : double ⚠️ en environnement sparse
fautif, silence + 1682 courbes sur le dépôt complet.

## 🟡 polymarket_collector.yml épinglé (pip -r requirements.txt)

## 📐 Méthodologie
- holm(pvals, alpha) : fonction PURE dans validation_report, step-down
  documenté, 2 tests unitaires (10 tests au total, 10/10).
- Chaque suivi imprime son rang : « ─── hypothèse 7/11 : … (gel …) ─── ».
- Doctrine écrite dans le bilan : gelé-avant-données = CONFIRMATOIRE
  (alpha plein puis holm sur la famille) ; exploré in-sample = EXPLORATOIRE
  (peut motiver un gel, jamais une décision).
- Reste à câbler : une p-value PAR watcher pour passer le verdict final dans
  holm() automatiquement — chaque watcher imprime aujourd'hui ses stats sans
  la retourner. C'est le prochain chantier méthodo, pas un correctif.

## Application (codespace, racine)
    unzip correctifs_v4.zip
    cp -r correctifs_v4/scripts/. scripts/
    cp correctifs_v4/tests/test_pure_functions.py tests/
    cp -r correctifs_v4/.github/workflows/. .github/workflows/
    python tests/test_pure_functions.py
    rm -rf correctifs_v4 correctifs_v4.zip
    git add -A -- scripts tests .github/workflows
    git commit -m "Verrou externe + troncature leadlag/flow + holm() + compteurs"
    git pull --no-rebase --no-edit && git push
