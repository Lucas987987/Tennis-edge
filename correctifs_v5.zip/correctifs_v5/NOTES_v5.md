# Correctifs v5 — 25/08/2026 soir : le chaînon manquant est câblé

## Ce qui change
1. **holm() est opérationnel, plus documentaire.** Les 11 watchers renvoient
   désormais leur comptage out-of-sample (k, n, p0) au lieu de seulement
   l'imprimer ; bilan_tests_multiples() calcule les p-values binomiales
   exactes, passe la famille dans holm(), et imprime UN VERDICT PAR LIGNE.
2. **p0 généralisé.** Calibration et heure ne se testent pas contre 50 % :
   leur hypothèse nulle est le taux attendu par Shin. Le binomial exact
   accepte p0 quelconque, en log-espace (OverflowError constaté à n=1287).
3. **Source de vérité unique.** (nom, gel, fonction) voyagent ensemble dans
   UNE liste — plus de zip de listes parallèles, plus d'assert de longueur :
   un réordonnancement ne peut plus publier un verdict sous le nom du voisin.
4. **FREEZE_DATE_PRIMAIRE = '2026-08-25 (consigné rétroactivement)'.** Le
   critère primaire (CLV alerté vs témoin, hors famille) a maintenant une
   date de gel falsifiable, marquée honnêtement comme rétroactive.
5. **La règle maison prime.** Un rejet Holm avec n<30 s'affiche « passe Holm
   MAIS n<30 : sous le seuil maison, à confirmer ⏳ » — la significativité ne
   court-circuite pas ton refus de conclure sous 30.

## Premier verdict réel (données du 25/08)
6 hypothèses testables sur 11, 3 rejets au risque global 5 % :
- **seuil adaptatif : 1231/2042 refermés (60,3 %), p≈0 — REJETTE, n solide.**
- variation de marge : 13/13, p=0,0001 — passe Holm mais n<30, à confirmer.
- round : 22/23, p≈0 — passe Holm mais n<30, à confirmer.
- calibration 2,20-3,50 : 87/240 vs attendu Shin 36 % — résidu retombé,
  ne rejette pas (l'été à surprises, probablement).
- heure, renforcement outsider : ne rejettent pas.
- 5 suivis pas encore testables (n insuffisant) — dit explicitement.

## Tests : 11/11 (nouveau : test_binomial_p0_generalise)

## Application (codespace, racine)
    unzip correctifs_v5.zip
    cp correctifs_v5/scripts/validation_report.py scripts/
    cp correctifs_v5/tests/test_pure_functions.py tests/
    python tests/test_pure_functions.py
    rm -rf correctifs_v5 correctifs_v5.zip
    git add scripts/validation_report.py tests/test_pure_functions.py
    git commit -m "holm() opérationnel : 11 watchers -> p-values -> verdicts"
    git pull --no-rebase --no-edit && git push
