# Correctifs v6 — 25/08/2026 : le témoin devient l'étalon

## 🔴 p0 témoin (le point qui change les verdicts)
Tester « CLV>0 » contre 0,5 était faux : la dérive asymétrique des outsiders
déplace le point d'équilibre, et le dispositif possède son étalon — la
population des moves détectés. p0_temoin() mesure le taux de base réel de
CLV>0 sur moves_detail_hist.csv : **72,2 % (593/821)**. Les 8 hypothèses CLV
sont désormais testées contre CE taux ; calibration et heure gardent leur
attendu Shin. La valeur et son n sont imprimés dans l'en-tête du bilan.
Réserve documentée : les sous-groupes issus d'autres détecteurs (ouverture
précoce, seuils par book) sont comparés au même étalon sous l'hypothèse
« tout ceci est du steam-following ».

## reinforce_watch sort de la famille binomiale
Son comptage mesure la dérive outsider (un phénomène de marché), pas un CLV —
le tester contre 0,5 ou contre le témoin n'a pas de sens. Hors famille avec
message explicite, jusqu'à définition d'un test de gradient dédié.

## 🟠 HYPOTHESES : une seule source de vérité, au niveau module
HYPOTHESES_GELEES (la liste parallèle ressuscitée pour l'en-tête) est
supprimée. HYPOTHESES = [(nom, gel, fonction)] vit au niveau module, lue par
l'en-tête ET par la boucle. Ajouter une 12e hypothèse = un seul endroit.

## 🟡 Plancher n>=30 EN AMONT de Holm
La règle maison est pré-enregistrée et indépendante du résultat : l'exclure
avant la famille est légitime. Une hypothèse à n=13 n'occupe plus un créneau
qui durcissait le seuil des autres. Affichage dédié : « n<30 : suivi, HORS
famille ».

## Le verdict corrigé (données du 25/08) — à lire en face
**Famille : 3 testables sur 11, 0 rejet au risque global 5 %.**
- seuil adaptatif : 1231/2042 = 60,3 % vs témoin 72,2 % — SOUS le taux de
  base ⚠️. À investiguer avant toute conclusion : les CLV du suivi adaptatif
  viennent du détecteur par book, la comparabilité des populations est une
  hypothèse. Mais le signal mérite l'enquête : les seuils gelés
  sélectionnent-ils des moves qui referment MOINS que le move moyen ?
- calibration : 87/240 pile sur l'attendu Shin — résidu mort, confirmé.
- heure : 112/207, p=0,11 — rien.
- marge 13/13 et round 22/23 : prometteurs, hors famille jusqu'à n>=30.
L'ancien « 3 rejets » de la v5 était un artefact du p0=0,5. Le dispositif
dit maintenant la vérité : rien n'est confirmé à ce stade, et c'est une
information de grande valeur — elle protège le forward public.

## Tests : 11/11

## Application (codespace, racine)
    unzip correctifs_v6.zip
    cp correctifs_v6/scripts/validation_report.py scripts/
    python tests/test_pure_functions.py
    rm -rf correctifs_v6 correctifs_v6.zip
    git add scripts/validation_report.py
    git commit -m "p0 témoin (72,2%) + source unique + plancher n>=30 avant Holm"
    git pull --no-rebase --no-edit && git push
