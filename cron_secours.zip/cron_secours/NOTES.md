# Cron de secours pour capture_closing (29/08/2026)

    unzip cron_secours.zip
    cp cron_secours/scripts/*.py scripts/
    cp cron_secours/.github/workflows/*.yml .github/workflows/

    bash cron_secours/verifier.sh
    # doit afficher "TOUT EST EN PLACE (5 contrôles passés)"

    python tests/test_pure_functions.py      # doit afficher 13/13

    rm -rf cron_secours cron_secours.zip
    git add -A
    git commit -m "Cron de secours capture_closing : resserré à 15 min, court-circuit de fraîcheur (0 requête consommée si le worker est déjà actif)"
    git pull --no-rebase --no-edit && git push

---

## Ce qui change

`capture_closing.yml` avait déjà un cron de secours horaire (`'7 * * * *'`)
en plus du déclenchement principal par le worker Cloudflare -- jusqu'à 60
minutes de trou possible si le worker tombe. Resserré à 15 minutes.

**Sans garde-fou, ça aurait fait passer le coût de ce cron de 24
passages/jour (déjà compté dans le budget de 235 req/jour d'aujourd'hui) à
~96, en grande partie redondants avec un worker en bonne santé.** Ajouté :
`main()` vérifie, UNIQUEMENT quand il est déclenché par le cron (jamais par
le worker ni un lancement manuel), si une capture a réussi il y a moins de
15 minutes -- si oui, il s'arrête immédiatement sans consommer une seule
requête API. Il ne fait un vrai passage que si le worker semble
réellement silencieux.

Seuil à 15 min, pas 20 (la demande d'origine) : le cron GitHub est du
best-effort et peut démarrer en retard sous charge -- 15 min de seuil
garde une marge sous le plafond de 20 min même si ce run-là part avec
quelques minutes de délai.

## Testé sur 5 cas

- cron, capture récente (5 min) → s'arrête, 0 requête
- cron, capture ancienne (20 min) → passage réel
- worker (repository_dispatch), même à 20 min → TOUJOURS un passage réel,
  jamais court-circuité
- manuel (workflow_dispatch), même à 60 min → TOUJOURS un passage réel
- cron, exactement 15 min (la limite) → passage réel (mieux vaut capturer
  à la frontière que rater un trou)
- bonus : `capture_state.json` absent ou illisible → passage réel par
  défaut, jamais un saut silencieux sur une erreur de lecture

## Tests : 13/13 (inchangé)
