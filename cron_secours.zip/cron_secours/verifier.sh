#!/usr/bin/env bash
# verifier.sh — cron de secours pour capture_closing (29/08/2026).
#
# Usage : bash verifier.sh   (à la racine du dépôt, APRÈS les cp)

set -uo pipefail
ECHECS=0

verif() {
    local fichier="$1" motif="$2" description="$3"
    if [ ! -f "$fichier" ]; then
        echo "❌ $fichier : FICHIER ABSENT"
        ECHECS=$((ECHECS+1))
        return
    fi
    if grep -q "$motif" "$fichier"; then
        echo "✅ $fichier : $description"
    else
        echo "❌ $fichier : $description -- MOTIF ABSENT ($motif)"
        ECHECS=$((ECHECS+1))
    fi
}

echo "=== Vérification -- cron de secours (29/08/2026) ==="
echo

verif .github/workflows/capture_closing.yml "cron: '\*/15 \* \* \* \*'" "cron resserré à 15 minutes"
verif .github/workflows/capture_closing.yml "GITHUB_EVENT_NAME: \${{ github.event_name }}" "nom de l'événement transmis au script"
verif scripts/capture_closing.py "SEUIL_CRON_SECOURS_MIN = 15" "seuil de fraîcheur défini"
verif scripts/capture_closing.py "os.environ.get('GITHUB_EVENT_NAME') == 'schedule'" "court-circuit réservé au cron"

echo
echo "=== Test critique : les 5 cas (schedule frais/périmé, worker, manuel, limite) ==="
python3 -c "
import os, json, datetime

def simulate(event_name, minutes_ago, seuil=15):
    now = datetime.datetime(2026,8,29,15,0)
    derniere = now - datetime.timedelta(minutes=minutes_ago)
    court_circuit = False
    if event_name == 'schedule':
        d = derniere
        age_min = (now - d).total_seconds() / 60
        if age_min < seuil:
            court_circuit = True
    return court_circuit

cas = [
    ('schedule', 5, True), ('schedule', 20, False),
    ('repository_dispatch', 20, False), ('workflow_dispatch', 60, False),
    ('schedule', 15, False),
]
ok = True
for event, mins, attendu in cas:
    r = simulate(event, mins)
    if r != attendu:
        ok = False
        print(f'❌ {event} @ {mins}min -> {r}, attendu {attendu}')
if ok:
    print('✅ les 5 cas se comportent comme attendu')
else:
    exit(1)
" || ECHECS=$((ECHECS+1))

echo
if [ "$ECHECS" -eq 0 ]; then
    echo "✅✅✅ TOUT EST EN PLACE (5 contrôles passés). Sûr de committer."
    exit 0
else
    echo "❌❌❌ $ECHECS CONTRÔLE(S) EN ÉCHEC. NE PAS COMMITTER avant d'avoir compris pourquoi."
    exit 1
fi
