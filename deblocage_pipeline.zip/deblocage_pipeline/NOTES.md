# steam_pipeline débloqué (03/09/2026)

    cp deblocage_pipeline/.github/workflows/*.yml .github/workflows/
    git add -A
    git commit -m "polymarket_flow retiré de la boucle : timeout systématique (code 124) sur un script structurellement incapable de produire, il faisait échouer tout steam_pipeline"
    git pull --no-rebase --no-edit && git push

---

## Pourquoi steam_pipeline échouait

Le run analysé montre 9 livrables sur 10 en `✅ OK`. Le pipeline fait
parfaitement son travail. Il échoue sur une seule ligne :

    🔒 STRICT : 0 livrable(s) critique(s) en défaut, 1 alerte(s) de contenu -> exit 1
       ⚠️ Polymarket : 1 échec(s)

Cet échec, c'est `polymarket_flow.py` — **code 124, un timeout**, tous les
jours, à 300 s.

## C'est une chaîne de mes propres correctifs

1. Le rapport consolidé (point 2) signalait que les timeouts étaient notés
   `⚠️` au lieu de `❌`, donc comptés comme de simples avertissements.
2. J'ai corrigé ça — un timeout EST un échec, la correction était juste.
3. Mais `alerte` était aussi branché sur `--strict` (correctif antérieur).
4. Résultat : un problème préexistant, jusque-là invisible, fait maintenant
   échouer un pipeline entier qui fonctionne.

Le problème n'est pas nouveau. Il est devenu visible — et bloquant.

## Pourquoi retirer plutôt que rallonger le timeout

`polymarket_flow.py` mesure le flux d'ARGENT (`trade_notional`,
`trade_size`) avant un mouvement Pinnacle. Or le collecteur n'enregistre
**aucun volume** : 0 échange horodaté sur 2,4 millions de ticks (mesuré lors
d'audits précédents). Le script ne peut rien produire, quelle que soit la
durée qu'on lui accorde.

Lui donner 600 s au lieu de 300 ne ferait que doubler le temps perdu avant
le même échec. Il est donc sorti de la boucle, avec dans le code la
condition exacte de son retour : le jour où le collecteur enregistrera les
volumes.

Simulé : sans lui, `n_echecs=0`, `alerte=False` — steam_pipeline redevient
vert.

## Sur la cadence de capture_closing — information au passage

`steam_pipeline` dure **15,7 min** (dont 340 s pour le tableau de validation
et 284 s pour les résultats API). Mais c'est un workflow SÉPARÉ, avec son
propre groupe de concurrence : il n'a aucun effet sur la cadence de
`capture_closing`. Cette piste-là est écartée.

## Tests : 13/13 (inchangé)
