# Gestion des données v8 — application (codespace, racine)
    unzip donnees_v8.zip
    cp donnees_v8/scripts/*.py scripts/
    cp donnees_v8/.github/workflows/pistes_weekly.yml .github/workflows/
    cp donnees_v8/RUNBOOK_FILTER_REPO.md .
    python -c "import sys; sys.path.insert(0,'scripts'); import gz_append; print('gz_append OK')"
    rm -rf donnees_v8 donnees_v8.zip
    git add scripts .github/workflows/pistes_weekly.yml RUNBOOK_FILTER_REPO.md
    git commit -m "Ticks en gzip-append à la source + sentinelle taille + runbook filter-repo"
    git pull --no-rebase --no-edit && git push
Effets : dès le prochain cycle, les collecteurs écrivent pm/kx_ticks_*.jsonl.gz
(historique ~divisé par 7) ; la sentinelle tourne chaque dimanche dans le
rapport de pistes ; le filter-repo se planifie avec le runbook, dimanche matin.
NB : les partitions .jsonl du jour déjà entamées restent lisibles telles
quelles (tous les lecteurs acceptent les deux formats) et seront compressées
par le cycle nocturne habituel, puis archivées comme les autres.
