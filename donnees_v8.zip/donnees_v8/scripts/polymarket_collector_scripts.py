#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
polymarket_collector.py

Etape 2 — Collecteur Polymarket temps réel pour Tennis Edge.

Architecture :
  1) Gamma API : découvre les événements/marchés tennis actifs.
  2) Match local : fait le mapping avec matches_oddspapi.json quand disponible.
  3) CLOB WebSocket : reçoit en temps réel book / price_change / last_trade_price
     / best_bid_ask.
  4) Ecrit un historique append-only dans polymarket_ticks.jsonl.

Aucune clé API n'est nécessaire : les endpoints de lecture Gamma/CLOB sont publics.

Fichiers par défaut :
  matches_oddspapi.json
  polymarket_markets.json       mapping des marchés suivis
  parts/pm_ticks_<date>.jsonl   historique temps réel (1 partition/jour)
  polymarket_collector_state.json

Dépendances : requests, websocket-client

Usage :
  python polymarket_collector.py
  python polymarket_collector.py --once
  python polymarket_collector.py --refresh-seconds 180
  python polymarket_collector.py --duration-seconds 240 --refresh-seconds 180
  python polymarket_collector.py --no-match-filter

Variables d'environnement :
  PM_GAMMA_URL             https://gamma-api.polymarket.com
  PM_CLOB_WS_URL           wss://ws-subscriptions-clob.polymarket.com/ws/market
  PM_MATCHES_FILE          matches_oddspapi.json
  PM_MARKETS_FILE          polymarket_markets.json
  PM_TICKS_DIR             parts  (PM_TICKS_FILE force un fichier unique)
  PM_STATE_FILE            polymarket_collector_state.json
  PM_REFRESH_SECONDS       180
  PM_HTTP_TIMEOUT          20
  PM_MAX_EVENTS_PER_TAG    100
  PM_MATCH_LOOKAHEAD_HOURS 72
  PM_MATCH_WINDOW_HOURS    36   (écart max entre horaire Polymarket et local)
  PM_MATCH_MIN_SCORE       0.62
  PM_MARKET_TYPES          match,set1,set2  (handicap/total/score exclus)
  PM_NO_MATCH_FILTER       0/1
  PM_DIAG                  0/1 (écrit polymarket_diag.json : motifs de rejet + échantillon brut)

Important : le collecteur ne produit PAS d'alerte de pari. Il collecte uniquement
les données pour permettre ensuite l'analyse lead/lag Polymarket -> Pinnacle -> softs.
"""

from __future__ import annotations

import argparse
import ast
import difflib
import json
import gz_append
import os
import re
import signal
import threading
import time
import unicodedata
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

import requests
import websocket


GAMMA_URL = os.environ.get("PM_GAMMA_URL", "https://gamma-api.polymarket.com").rstrip("/")
CLOB_WS_URL = os.environ.get(
    "PM_CLOB_WS_URL", "wss://ws-subscriptions-clob.polymarket.com/ws/market"
)

MATCHES_FILE = Path(os.environ.get("PM_MATCHES_FILE", "matches_oddspapi.json"))
MARKETS_FILE = Path(os.environ.get("PM_MARKETS_FILE", "polymarket_markets.json"))
# PARTITIONNEMENT DES TICKS — indispensable, pas cosmétique.
# Un fichier de ticks append-only commité toutes les quelques minutes est
# exactement ce qui a porté ce dépôt à 637 Mo et bloqué tous les push pendant
# 5 jours en août (mur GitHub : 100 Mo par fichier). Les ticks partent donc dans
# parts/pm_ticks_<YYYY-MM-DD>.jsonl, une partition par jour, que
# compress_hist_partitions.py pourra gzipper une fois close (~85 % de gain).
# PM_TICKS_FILE reste accepté pour forcer un fichier unique (tests locaux).
# LIMITATION DE DÉBIT — sans elle, le collecteur est ingérable.
# Mesuré le 19/08/2026 sur un run de 15 min en soirée (matchs en cours) :
# 312 683 lignes, soit 101 Mo. À ce rythme : 404 Mo/heure, 9,7 Go/jour, et le
# mur GitHub de 100 Mo PAR FICHIER atteint en 15 MINUTES de collecte.
# Cause : chaque delta du carnet d'ordres produit une ligne. Sur un carnet
# actif c'est plusieurs écritures par seconde et par jeton -- alors que
# l'analyse travaille sur une grille de 5 MINUTES. Sur-échantillonnage d'un
# facteur mille, sans le moindre gain d'information.
#
# Règle : au plus une écriture par jeton et par type d'événement toutes les
# PM_MIN_INTERVAL_S secondes, SAUF si le prix a bougé d'au moins PM_MIN_DELTA
# -- un vrai mouvement passe donc toujours, immédiatement, sans latence.
# Les échanges (last_trade_price) ne sont JAMAIS filtrés : ils sont rares et
# portent les mises, c'est-à-dire ce que l'étude de flux exploite.
# 10 s laissait passer ~410 000 lignes par jour (210 Mo). La grille d'analyse
# étant de 5 minutes, 30 s donne encore 10 points par intervalle : largement
# assez, pour trois fois moins de volume. Un vrai mouvement (PM_MIN_DELTA)
# passe toujours immédiatement, quelle que soit cette valeur.
MIN_INTERVAL_S = float(os.environ.get("PM_MIN_INTERVAL_S", "30"))
MIN_DELTA = float(os.environ.get("PM_MIN_DELTA", "0.002"))

TICKS_DIR = Path(os.environ.get("PM_TICKS_DIR", "parts"))
TICKS_FILE_OVERRIDE = os.environ.get("PM_TICKS_FILE", "").strip()
STATE_FILE = Path(os.environ.get("PM_STATE_FILE", "polymarket_collector_state.json"))

REFRESH_SECONDS = int(os.environ.get("PM_REFRESH_SECONDS", "180"))
HTTP_TIMEOUT = float(os.environ.get("PM_HTTP_TIMEOUT", "20"))
MAX_EVENTS_PER_TAG = int(os.environ.get("PM_MAX_EVENTS_PER_TAG", "100"))
LOOKAHEAD_HOURS = float(os.environ.get("PM_MATCH_LOOKAHEAD_HOURS", "72"))
NO_MATCH_FILTER = os.environ.get("PM_NO_MATCH_FILTER", "0") == "1"
# Score minimum exigé de CHAQUE joueur (pas de la moyenne des deux).
MATCH_MIN_SCORE = float(os.environ.get("PM_MATCH_MIN_SCORE", "0.62"))
# Fenêtre horaire entre l'horaire Polymarket et l'horaire local. 8 h était trop
# serré : Polymarket affiche parfois un horaire approximatif ou l'ouverture de
# session, et un décalage de plus de 8 h suffisait à écarter un match dont les
# DEUX noms correspondaient parfaitement. À 36 h le risque de confusion reste
# nul : deux mêmes joueurs ne se rencontrent pas deux fois dans cet intervalle,
# et à score égal on départage désormais par le plus petit écart de temps.
MATCH_WINDOW_H = float(os.environ.get("PM_MATCH_WINDOW_HOURS", "36"))

STOP = threading.Event()
WRITE_LOCK = threading.Lock()


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


# Au-delà de cette taille, on ouvre une nouvelle partition. Le mur GitHub est à
# 100 Mo PAR FICHIER : un push contenant un fichier plus gros est rejeté, et la
# totalité du commit est perdue. Constaté le 19/08/2026 :
#   "File parts/pm_ticks_2026-08-19.jsonl is 221.29 MB; this exceeds GitHub's
#    file size limit of 100.00 MB -> [remote rejected] (pre-receive hook declined)"
# La limitation de débit rend ce cas improbable, mais une journée très chargée
# pourrait encore l'atteindre. 60 Mo laisse une marge confortable : même en
# ajoutant plusieurs dizaines de Mo avant le prochain contrôle, on reste sous
# les 100 Mo. Même mécanique que current_hist_partition_path() pour les courbes.
TICKS_MAX_MB = float(os.environ.get("PM_TICKS_MAX_MB", "60"))


def ticks_path() -> Path:
    """Partition courante. Recalculée à chaque écriture, donc :
      - un collecteur à cheval sur minuit bascule seul sur le jour suivant ;
      - une partition qui atteint TICKS_MAX_MB est close et remplacée par
        <date>_2, puis _3, etc.
    """
    if TICKS_FILE_OVERRIDE:
        return Path(TICKS_FILE_OVERRIDE)
    jour = utc_now().strftime('%Y-%m-%d')
    # 26/08/2026 : partitions écrites DIRECTEMENT en .jsonl.gz (gz_append) —
    # l'historique git ne stocke plus le brut. Le cap de taille s'applique au
    # gz : à compression ~7:1, une partition contient ~7x plus de lignes,
    # c'est voulu (moins de fichiers, mêmes garanties).
    p = TICKS_DIR / f"pm_ticks_{jour}.jsonl.gz"
    seq = 1
    while p.exists() and p.stat().st_size / 1e6 >= TICKS_MAX_MB:
        seq += 1
        p = TICKS_DIR / f"pm_ticks_{jour}_{seq}.jsonl.gz"
    return p


def iso_now() -> str:
    return utc_now().isoformat(timespec="milliseconds").replace("+00:00", "Z")


def parse_dt(value: Any) -> Optional[datetime]:
    if not value:
        return None
    try:
        s = str(value).replace("Z", "+00:00")
        dt = datetime.fromisoformat(s)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt.astimezone(timezone.utc)
    except Exception:
        return None


def norm_name(value: Any) -> str:
    s = unicodedata.normalize("NFKD", str(value or "")).lower()
    s = "".join(c for c in s if not unicodedata.combining(c))
    s = re.sub(r"[^a-z0-9]+", " ", s).strip()
    return re.sub(r"\s+", " ", s)


def name_tokens(value: Any) -> set[str]:
    return {x for x in norm_name(value).split() if len(x) > 1}


def parse_jsonish(value: Any) -> Any:
    if isinstance(value, (list, dict)):
        return value
    if value is None:
        return None
    s = str(value).strip()
    if not s:
        return None
    try:
        return json.loads(s)
    except Exception:
        try:
            return ast.literal_eval(s)
        except Exception:
            return None


def safe_float(value: Any) -> Optional[float]:
    try:
        if value is None or value == "":
            return None
        x = float(value)
        if x != x:
            return None
        return x
    except Exception:
        return None


def atomic_json_write(path: Path, obj: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)
    os.replace(tmp, path)


def append_jsonl(path: Path, row: Dict[str, Any]) -> None:
    # 26/08/2026 : gzip-append par lots (gz_append.py) — le WRITE_LOCK
    # historique est conservé par ceinture, gz_append a le sien.
    with WRITE_LOCK:
        gz_append.append_ligne(
            str(path),
            json.dumps(row, ensure_ascii=False, separators=(",", ":")))


def http_get(session: requests.Session, path: str, params: Dict[str, Any]) -> Any:
    url = f"{GAMMA_URL}{path}"
    last_error = None
    for attempt in range(3):
        try:
            r = session.get(url, params=params, timeout=HTTP_TIMEOUT)
            r.raise_for_status()
            return r.json()
        except Exception as exc:
            last_error = exc
            if attempt < 2:
                time.sleep(1.5 * (attempt + 1))
    raise RuntimeError(f"GET {url} failed: {last_error}")


def discover_tennis_tag_ids(session: requests.Session) -> List[str]:
    """Utilise /sports pour récupérer les tags associés au sport tennis."""
    data = http_get(session, "/sports", {})
    if not isinstance(data, list):
        return []
    ids: List[str] = []
    for sport in data:
        label = norm_name(sport.get("sport"))
        if "tennis" not in label:
            continue
        raw = sport.get("tags", "")
        for x in re.split(r"[,\s]+", str(raw)):
            x = x.strip()
            if x.isdigit() and x not in ids:
                ids.append(x)
    return ids


def event_is_tennis(event: Dict[str, Any]) -> bool:
    blob = " ".join(
        str(event.get(k, ""))
        for k in ("title", "slug", "category", "subcategory", "sportsMarketType", "sport")
    ).lower()
    tags = event.get("tags") or []
    if isinstance(tags, list):
        blob += " " + " ".join(str(t.get("slug", t.get("label", ""))) for t in tags if isinstance(t, dict))
    return "tennis" in blob or any(x in blob for x in ("atp", "wta", "challenger", "itf"))


def discover_events(session: requests.Session) -> List[Dict[str, Any]]:
    """Découverte active. Priorité aux tags tennis, fallback sur recherche générale."""
    now = utc_now()
    max_dt = now.timestamp() + LOOKAHEAD_HOURS * 3600
    out: Dict[str, Dict[str, Any]] = {}

    def _fallback() -> None:
        """Recherche générale. Déclenchée si /sports ne donne aucun tag tennis,
        MAIS AUSSI si les tags n'ont ramené aucun événement : un tag valide qui
        ne renvoie rien (renommage côté Polymarket, changement de schéma, saison
        creuse) laissait sinon le collecteur repartir à vide, sans rien signaler."""
        for q in ("tennis", "ATP", "WTA"):
            try:
                data = http_get(session, "/public-search", {
                    "q": q, "events_status": "active", "limit_per_type": 100,
                    "page": 1, "search_tags": "true", "search_profiles": "false",
                })
            except Exception as exc:
                print(f"⚠️ /public-search '{q}' : {exc}")
                continue
            for ev in (data.get("events") or []) if isinstance(data, dict) else []:
                if not event_is_tennis(ev):
                    continue
                start = parse_dt(ev.get("eventStartTime") or ev.get("startDate"))
                if start and start.timestamp() > max_dt:
                    continue
                out[str(ev.get("id") or ev.get("slug"))] = ev

    tag_ids = discover_tennis_tag_ids(session)
    if tag_ids:
        for tag_id in tag_ids:
            offset = 0
            while True:
                data = http_get(
                    session,
                    "/events",
                    {
                        "tag_id": tag_id,
                        "active": "true",
                        "closed": "false",
                        "limit": MAX_EVENTS_PER_TAG,
                        "offset": offset,
                        "ascending": "true",
                    },
                )
                if not isinstance(data, list) or not data:
                    break
                for ev in data:
                    if not event_is_tennis(ev):
                        continue
                    start = parse_dt(ev.get("eventStartTime") or ev.get("startDate"))
                    if start and start.timestamp() > max_dt:
                        continue
                    out[str(ev.get("id") or ev.get("slug"))] = ev
                if len(data) < MAX_EVENTS_PER_TAG:
                    break
                offset += MAX_EVENTS_PER_TAG
                if offset >= 1000:
                    break

    if not out:
        if tag_ids:
            print(f"⚠️ {len(tag_ids)} tag(s) tennis mais 0 événement -> repli /public-search")
        _fallback()

    if not out:
        print("❌ aucun événement tennis (ni par tag, ni par recherche).")
    return list(out.values())


def load_local_matches() -> List[Dict[str, Any]]:
    if not MATCHES_FILE.exists():
        return []
    try:
        data = json.loads(MATCHES_FILE.read_text(encoding="utf-8"))
        if isinstance(data, dict):
            data = list(data.values())
        return data if isinstance(data, list) else []
    except Exception as exc:
        print(f"⚠️ impossible de lire {MATCHES_FILE}: {exc}")
        return []


def local_match_rows() -> List[Dict[str, Any]]:
    rows = []
    for m in load_local_matches():
        home = m.get("home_team") or m.get("home")
        away = m.get("away_team") or m.get("away")
        commence = m.get("commence_time") or m.get("start_time") or m.get("event_start_time")
        if home and away:
            rows.append({
                "home": home,
                "away": away,
                "commence": commence,
                "uid": make_uid(commence, home, away),
            })
    return rows


def make_uid(commence: Any, home: Any, away: Any) -> str:
    date = str(commence or "")[:10]
    return f"{date}_{norm_name(home).replace(' ', '_')}_{norm_name(away).replace(' ', '_')}"


def pair_similarity(a: str, b: str) -> float:
    na, nb = norm_name(a), norm_name(b)
    if not na or not nb:
        return 0.0
    if na == nb:
        return 1.0
    tok_a, tok_b = name_tokens(a), name_tokens(b)
    shared = tok_a & tok_b

    # NOM DE FAMILLE SEUL. Polymarket libelle souvent ses marchés en nom de
    # famille (« Tirante / Mensik ») alors que matches_oddspapi.json porte le
    # nom complet (« Thiago Agustin Tirante »). difflib donne 0,48 à ce couple,
    # sous le seuil de 0,62 : tous ces marchés étaient écartés.
    # Règle : un libellé à UN SEUL jeton qui est exactement le nom de famille de
    # l'autre (dernier jeton) vaut correspondance. Le risque d'homonymie (les
    # frères Zverev) est neutralisé en amont : match_local_players exige que
    # LES DEUX joueurs correspondent, et deux frères ne jouent pas le même
    # adversaire le même jour.
    last_a = norm_name(a).split()[-1] if norm_name(a) else ""
    last_b = norm_name(b).split()[-1] if norm_name(b) else ""
    if len(tok_a) == 1 or len(tok_b) == 1:
        if last_a and last_a == last_b:
            return 0.95
        return 0.30 if not shared else 0.60
    # GARDE-FOU PRÉNOM. difflib donne 0,63 à « Tallon Griekspoor » vs « Tallon
    # Tien » -- au-dessus du seuil d'acceptation de 0,62. C'est le bug corrigé
    # le 16/08/2026 dans player_key.py : un seul jeton commun, donc un prénom,
    # suffisait à confondre deux joueurs. Six joueurs du jeu se prénomment
    # « alex », quatre « lorenzo ». Un vrai même joueur partage prénom ET nom.
    if len(tok_a) >= 2 and len(tok_b) >= 2 and len(shared) <= 1:
        return 0.30                      # sous le seuil : refus explicite
    token_score = len(shared) / max(1, len(tok_a | tok_b))
    seq = difflib.SequenceMatcher(None, na, nb).ratio()
    return max(token_score, seq)


def match_local_players(pm_a: str, pm_b: str, event_start: Optional[datetime], locals_: List[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
    if not locals_:
        return None
    best = None
    best_key = (0.0, 0.0)          # (score, proximité temporelle) — score d'abord
    for row in locals_:
        dt = parse_dt(row.get("commence"))
        delta_h = None
        if event_start and dt:
            delta_h = abs((dt - event_start).total_seconds()) / 3600.0
            if delta_h > MATCH_WINDOW_H:
                continue
        # Chaque joueur doit correspondre INDIVIDUELLEMENT. Une moyenne laisse
        # passer un faux appariement quand un seul côté est parfait :
        # « Tallon Tien vs Van de Zandschulp » face à « Griekspoor vs Van de
        # Zandschulp » donnait (0,30 + 1,00) / 2 = 0,65, au-dessus du seuil,
        # alors que le premier joueur n'a rien à voir. Vérifié par test.
        a_h, b_a = pair_similarity(pm_a, row["home"]), pair_similarity(pm_b, row["away"])
        a_a, b_h = pair_similarity(pm_a, row["away"]), pair_similarity(pm_b, row["home"])
        s1 = min(a_h, b_a)          # sens direct  : le plus faible des deux
        s2 = min(a_a, b_h)          # sens inversé : idem
        score = max(s1, s2)
        # Départage : à score égal, le match le plus proche dans le temps.
        proximite = 1.0 / (1.0 + (delta_h if delta_h is not None else 12.0))
        key = (score, proximite)
        if key > best_key:
            best_key = key
            best = row
    return best if best_key[0] >= MATCH_MIN_SCORE else None


DIAG = os.environ.get("PM_DIAG", "0") == "1"
DIAG_FILE = Path(os.environ.get("PM_DIAG_FILE", "polymarket_diag.json"))


_OVER_UNDER = ("over", "under", "yes", "no", "oui", "non")


def est_joueur_vs_joueur(a: str, b: str) -> bool:
    """Vrai si les deux outcomes sont des NOMS DE JOUEURS.

    La sonde a montré que le décompte « joueur-vs-joueur » était pollué par les
    marchés de TOTAL de jeux/sets (« Over 2.5 / Under 2.5 »), binaires et
    non-Yes/No mais sans intérêt pour un lead/lag sur le vainqueur du match.
    """
    na, nb = norm_name(a), norm_name(b)
    for x in (na, nb):
        if not x:
            return False
        if any(x.startswith(k) for k in _OVER_UNDER):
            return False
        if re.search(r"\d", x):          # « Over 2.5 », « 3-0 », scores exacts
            return False
    return True


# ── TYPE DE MARCHÉ ────────────────────────────────────────────────────────
# Le premier run réel a montré que Polymarket propose PLUSIEURS marchés
# binaires pour un même match, avec les MÊMES deux noms en outcomes :
#   « Cincinnati Open: Tirante vs Mensik »        -> vainqueur du MATCH
#   « Set 1 Winner: Tirante vs Mensik »           -> vainqueur du SET 1
#   « Set 2 Winner: Tirante vs Mensik »           -> vainqueur du SET 2
#   « Set Handicap: Tirante (-1.5) vs Mensik »    -> handicap en sets
# Sans classification, ces quatre marchés produisaient des ticks portant le
# MÊME uid et le MÊME côté home/away, mélangeant des prix qui n'ont rien à voir.
# Toute analyse lead/lag construite dessus aurait été inexploitable, et le
# défaut aurait été invisible : les ticks se ressemblent tous.
# Bonne nouvelle : match / set1 / set2 correspondent exactement aux trois
# marchés déjà suivis par Tennis Edge (book_curves, set1_curves, set2_curves).
# Le handicap n'a pas d'équivalent local : exclu par défaut.
MARKET_TYPES = [t.strip() for t in os.environ.get(
    "PM_MARKET_TYPES", "match,set1,set2").split(",") if t.strip()]


def classify_market(question: str, event_title: str = "") -> str:
    q = norm_name(question)
    if "handicap" in q or "spread" in q:
        return "handicap"
    if "set 1 winner" in q or "1st set" in q or "first set" in q:
        return "set1"
    if "set 2 winner" in q or "2nd set" in q or "second set" in q:
        return "set2"
    if "set 3 winner" in q or "3rd set" in q or "third set" in q:
        return "set3"
    if "correct score" in q or "exact score" in q:
        return "score"
    if "total" in q or "games" in q:
        return "total"
    if " vs " in q or " v " in q or "winner" in q or "moneyline" in q:
        return "match"
    return "autre"


def extract_markets(events: Iterable[Dict[str, Any]], use_match_filter: bool = True) -> List[Dict[str, Any]]:
    """Extrait les marchés binaires exploitables.

    COMPTEUR DE REJETS : ce filtre écarte à sept endroits différents, chacun par
    un `continue` silencieux. Un run où 61 événements donnent 0 marché est donc
    indiagnostiquable sans instrumentation -- c'est exactement le mode de panne
    récurrent de ce projet (« rien ne plante, tout est vide »). On compte donc
    chaque motif de rejet, et PM_DIAG=1 écrit en plus un échantillon brut.
    """
    locals_ = local_match_rows() if use_match_filter else []
    results: Dict[str, Dict[str, Any]] = {}
    rej: Dict[str, int] = {}
    echantillon: List[Dict[str, Any]] = []
    joueur_vs_joueur: List[str] = []      # marchés binaires entre deux joueurs
    refus_jvj: List[Dict[str, Any]] = []  # pourquoi un jvj a-t-il été écarté ?
    titres: Dict[str, int] = {}           # inventaire des événements reçus

    def drop(motif: str, ev: Dict[str, Any] = None, mk: Dict[str, Any] = None) -> None:
        rej[motif] = rej.get(motif, 0) + 1
        # Échantillon DIVERSIFIÉ : jusqu'à 3 exemples PAR MOTIF. Un plafond
        # global remplissait la liste avec les 8 premiers rejets, tous du même
        # type (8 fois « US Open Winner »), sans rien montrer des autres motifs.
        if DIAG and sum(1 for e in echantillon if e["motif"] == motif) < 3:
            echantillon.append({
                "motif": motif,
                "event_title": (ev or {}).get("title"),
                "event_slug": (ev or {}).get("slug"),
                "sportsMarketType": (mk or ev or {}).get("sportsMarketType"),
                "question": (mk or {}).get("question"),
                "outcomes": (mk or {}).get("outcomes"),
                "clobTokenIds": (mk or {}).get("clobTokenIds"),
                "gameId": (mk or {}).get("gameId") or (ev or {}).get("gameId"),
                "cles_market": sorted((mk or {}).keys())[:30] if mk else None,
            })

    for ev in events:
        t = str(ev.get("title") or ev.get("slug") or "?")
        titres[t] = titres.get(t, 0) + len(ev.get("markets") or [])
        event_id = str(ev.get("id") or ev.get("slug") or "")
        event_start = parse_dt(ev.get("eventStartTime") or ev.get("startDate"))
        event_title = ev.get("title") or ev.get("slug") or ""
        markets = ev.get("markets") or []
        if not isinstance(markets, list) or not markets:
            drop("evenement_sans_markets", ev)
            continue

        for market in markets:
            if not isinstance(market, dict):
                continue
            if market.get("closed") is True or market.get("active") is False:
                drop("marche_ferme_ou_inactif", ev, market)
                continue

            outcomes = parse_jsonish(market.get("outcomes"))
            token_ids = parse_jsonish(market.get("clobTokenIds") or market.get("clob_token_ids"))
            if not isinstance(outcomes, list) or not isinstance(token_ids, list):
                drop("outcomes_ou_tokens_illisibles", ev, market)
                continue
            if len(outcomes) != 2 or len(token_ids) != 2:
                drop(f"pas_binaire_{len(outcomes)}_outcomes", ev, market)
                continue
            if not all(str(x).strip() for x in outcomes) or not all(str(x).strip() for x in token_ids):
                drop("outcome_ou_token_vide", ev, market)
                continue

            # On ne garde que les marchés binaires qui ressemblent à un match.
            question = str(market.get("question") or market.get("groupItemTitle") or event_title)
            sports_type = str(market.get("sportsMarketType") or ev.get("sportsMarketType") or "")
            blob = f"{question} {event_title} {sports_type}".lower()
            if not any(x in blob for x in ("vs", " v ", "winner", "win", "match", "moneyline")):
                # Pour les sports Polymarket, gameId + 2 outcomes est souvent suffisant.
                if not (market.get("gameId") or ev.get("gameId")):
                    drop("ne_ressemble_pas_a_un_match", ev, market)
                    continue

            a, b = str(outcomes[0]), str(outcomes[1])

            # FUTURES Yes/No : « Will X win the 2026 US Open ? ». Binaires et
            # actifs, ils passaient tous les filtres et finissaient dans
            # "aucun_match_local_correspondant" (623 cas), noyant le vrai motif
            # de rejet des marchés joueur-contre-joueur. Ce ne sont PAS des
            # marchés de match : leur prix est une probabilité de vainqueur de
            # tournoi, sans contrepartie chez les bookmakers de Tennis Edge.
            if {norm_name(a), norm_name(b)} == {"yes", "no"}:
                drop("futures_yes_no", ev, market)
                continue
            if not est_joueur_vs_joueur(a, b):
                drop("marche_total_over_under", ev, market)
                continue

            mtype = classify_market(question, event_title)
            if mtype not in MARKET_TYPES:
                drop(f"type_non_suivi_{mtype}", ev, market)
                continue
            joueur_vs_joueur.append(f'[{mtype}] {a} / {b}  ({market.get("question")})')

            local = match_local_players(a, b, event_start, locals_) if use_match_filter else None
            if use_match_filter and not local:
                drop("aucun_match_local_correspondant", ev, market)
                # Journal CIBLÉ : pourquoi CE marché joueur-vs-joueur est-il
                # écarté ? On enregistre l'horaire vu côté Polymarket et les
                # trois meilleurs candidats locaux avec leur score, pour
                # distinguer un problème de NOMS d'un problème d'HORAIRE.
                if DIAG and len(refus_jvj) < 12:
                    cands = []
                    for row in locals_:
                        dt_l = parse_dt(row.get("commence"))
                        dh = (abs((dt_l - event_start).total_seconds()) / 3600.0
                              if (event_start and dt_l) else None)
                        sc = max(min(pair_similarity(a, row["home"]), pair_similarity(b, row["away"])),
                                 min(pair_similarity(a, row["away"]), pair_similarity(b, row["home"])))
                        cands.append((round(sc, 2), dh if dh is None else round(dh, 1),
                                      f'{row["home"]} vs {row["away"]}'))
                    cands.sort(key=lambda x: -x[0])
                    refus_jvj.append({
                        "outcomes": [a, b],
                        "question": market.get("question"),
                        "event_title": ev.get("title"),
                        "event_start_pm": str(event_start) if event_start else None,
                        "seuil": MATCH_MIN_SCORE,
                        "fenetre_heures": MATCH_WINDOW_H,
                        "top_candidats_locaux": cands[:3],
                    })
                continue

            market_id = str(market.get("id") or market.get("conditionId") or "")
            if not market_id:
                drop("market_id_absent", ev, market)
                continue

            # Quel outcome Polymarket correspond au home local ? Résolu ICI, une
            # seule fois. Sans ça, toute analyse lead/lag devrait refaire
            # l'appariement de noms sur des millions de ticks -- coûteux, et
            # surtout incohérent si la règle d'appariement évolue ensuite.
            outcome_sides = [None, None]
            if local:
                d_a = pair_similarity(a, local["home"]) - pair_similarity(a, local["away"])
                outcome_sides = ["home", "away"] if d_a >= 0 else ["away", "home"]

            row = {
                "market_id": market_id,
                "condition_id": market.get("conditionId"),
                "event_id": event_id,
                "event_slug": ev.get("slug"),
                "event_title": event_title,
                "question": question,
                "slug": market.get("slug"),
                "start_time": market.get("eventStartTime") or ev.get("eventStartTime") or market.get("startDate") or ev.get("startDate"),
                "outcomes": [a, b],
                "token_ids": [str(token_ids[0]), str(token_ids[1])],
                "sports_market_type": sports_type,
                "market_type": mtype,          # match / set1 / set2 (cf. classify_market)
                "game_id": market.get("gameId") or ev.get("gameId"),
                "liquidity": safe_float(market.get("liquidityNum") or market.get("liquidity")),
                "volume": safe_float(market.get("volumeNum") or market.get("volume")),
                "local_match": local,
                "outcome_sides": outcome_sides,
                "discovered_at": iso_now(),
            }
            results[market_id] = row

    if rej:
        print("   rejets :", " · ".join(f"{k}={v}" for k, v in sorted(rej.items(), key=lambda x: -x[1])))
    # LE chiffre qui décide de la faisabilité du projet : combien de marchés
    # binaires joueur-contre-joueur existent, INDÉPENDAMMENT de l'appariement
    # avec matches_oddspapi.json. Si ce nombre est nul, Polymarket ne cote pas
    # les matchs à l'unité et l'étude lead/lag sur les prix de match est
    # impossible en l'état -- ce n'est pas un défaut de filtre.
    print(f"   marchés joueur-vs-joueur détectés (avant filtre local) : {len(joueur_vs_joueur)}")
    for q in joueur_vs_joueur[:5]:
        print(f"      · {q}")
    if use_match_filter and locals_:
        print(f"   ({len(locals_)} matchs locaux dans matches_oddspapi.json)")
    elif use_match_filter:
        print("   ⚠️ AUCUN match local chargé -> le filtre rejette tout par construction")
    if DIAG:
        atomic_json_write(DIAG_FILE, {
            "generated_at": iso_now(),
            "evenements_recus": len(list(events)) if isinstance(events, list) else None,
            "marches_retenus": len(results),
            "rejets": rej,
            "marches_joueur_vs_joueur": joueur_vs_joueur,
            "refus_joueur_vs_joueur": refus_jvj,
            "inventaire_evenements": dict(sorted(titres.items(), key=lambda x: -x[1])),
            "echantillon": echantillon,
            "matchs_locaux": locals_[:10],
        })
        print(f"   🔬 diagnostic écrit dans {DIAG_FILE}")
    return list(results.values())


def save_markets(markets: List[Dict[str, Any]]) -> None:
    """Registre des marchés. FUSION, pas écrasement.

    Les ticks ne portent plus que market_id : si ce fichier était réécrit à
    chaque run avec les seuls marchés du moment, les métadonnées des matchs
    passés (question, titre, joueurs) seraient perdues et les ticks anciens
    deviendraient inexploitables. On conserve donc l'historique des marchés
    déjà vus.
    """
    anciens: Dict[str, Dict[str, Any]] = {}
    for m in load_markets():
        mid = str(m.get("market_id") or "")
        if mid:
            anciens[mid] = m
    for m in markets:
        mid = str(m.get("market_id") or "")
        if mid:
            anciens[mid] = m
    payload = {
        "updated_at": iso_now(),
        "count": len(anciens),
        "actifs": len(markets),
        "markets": list(anciens.values()),
    }
    atomic_json_write(MARKETS_FILE, payload)


def load_markets() -> List[Dict[str, Any]]:
    if not MARKETS_FILE.exists():
        return []
    try:
        data = json.loads(MARKETS_FILE.read_text(encoding="utf-8"))
        return data.get("markets", []) if isinstance(data, dict) else data
    except Exception:
        return []


def save_state(**updates: Any) -> None:
    state: Dict[str, Any] = {}
    if STATE_FILE.exists():
        try:
            state = json.loads(STATE_FILE.read_text(encoding="utf-8"))
        except Exception:
            state = {}
    state.update(updates)
    state["updated_at"] = iso_now()
    atomic_json_write(STATE_FILE, state)


def best_levels(levels: Any) -> Tuple[Optional[float], Optional[float]]:
    bids: List[Tuple[float, float]] = []
    asks: List[Tuple[float, float]] = []
    for level in levels or []:
        if not isinstance(level, dict):
            continue
        p, s = safe_float(level.get("price")), safe_float(level.get("size"))
        if p is None or s is None:
            continue
        side = str(level.get("side", "")).upper()
        if side == "BUY":
            bids.append((p, s))
        elif side == "SELL":
            asks.append((p, s))
    return (max((p for p, _ in bids), default=None), min((p for p, _ in asks), default=None))


def book_summary(message: Dict[str, Any]) -> Dict[str, Any]:
    bids = message.get("bids") or []
    asks = message.get("asks") or []
    bid = max((safe_float(x.get("price")) for x in bids if isinstance(x, dict)), default=None)
    ask = min((safe_float(x.get("price")) for x in asks if isinstance(x, dict)), default=None)
    bid_size = None
    ask_size = None
    if bid is not None:
        bid_size = sum(safe_float(x.get("size")) or 0 for x in bids if isinstance(x, dict) and safe_float(x.get("price")) == bid)
    if ask is not None:
        ask_size = sum(safe_float(x.get("size")) or 0 for x in asks if isinstance(x, dict) and safe_float(x.get("price")) == ask)
    mid = (bid + ask) / 2 if bid is not None and ask is not None and ask >= bid else None
    spread = ask - bid if bid is not None and ask is not None and ask >= bid else None
    return {
        "bid": bid,
        "ask": ask,
        "mid": mid,
        "spread": spread,
        "bid_size": bid_size,
        "ask_size": ask_size,
    }


class Collector:
    def __init__(self, markets: List[Dict[str, Any]]):
        self.markets = markets
        self.by_token: Dict[str, Dict[str, Any]] = {}
        self.by_market: Dict[str, Dict[str, Any]] = {}
        self.last_state: Dict[str, Dict[str, Any]] = {}
        # état du limiteur de débit : (asset_id, event_type) -> (t, dernier prix)
        self._last_write: Dict[Any, Any] = {}
        # événements de service déjà journalisés (type, market_id)
        self._services_vus = set()
        self.ecrits = 0
        self.filtres = 0
        for m in markets:
            self.by_market[str(m["market_id"])] = m
            for idx, token in enumerate(m.get("token_ids", [])):
                self.by_token[str(token)] = {
                    "market": m,
                    "outcome_index": idx,
                    "outcome": m.get("outcomes", [None, None])[idx],
                }

    def subscription_assets(self) -> List[str]:
        return list(self.by_token.keys())

    def handle(self, msg: Dict[str, Any]) -> None:
        if not isinstance(msg, dict):
            return
        event_type = msg.get("event_type")
        if not event_type:
            return

        asset_id = str(msg.get("asset_id") or "")
        if event_type == "price_change":
            changes = msg.get("price_changes") or []
            for change in changes:
                if isinstance(change, dict):
                    self._write_price_change(msg, change)
            return

        if event_type == "book":
            if not asset_id or asset_id not in self.by_token:
                return
            meta = self.by_token[asset_id]
            summary = book_summary(msg)
            self._write_tick(meta, "book", msg, summary)
            return

        if event_type == "best_bid_ask":
            if not asset_id or asset_id not in self.by_token:
                return
            meta = self.by_token[asset_id]
            summary = {
                "bid": safe_float(msg.get("best_bid")),
                "ask": safe_float(msg.get("best_ask")),
                "mid": safe_float(msg.get("midpoint")),
                "spread": None,
                "bid_size": None,
                "ask_size": None,
            }
            if summary["bid"] is not None and summary["ask"] is not None:
                summary["spread"] = summary["ask"] - summary["bid"]
                if summary["mid"] is None:
                    summary["mid"] = (summary["bid"] + summary["ask"]) / 2
            self._write_tick(meta, "best_bid_ask", msg, summary)
            return

        if event_type == "last_trade_price":
            if not asset_id or asset_id not in self.by_token:
                return
            meta = self.by_token[asset_id]
            # LA MISE, pas seulement le prix. Un mouvement de prix sur un carnet
            # mince ne vaut rien : c'est le montant échangé qui dit si le marché
            # « croit » vraiment au mouvement. Sans size, impossible de
            # distinguer un ordre de 5 $ d'un ordre de 5 000 $ -- et donc
            # impossible de juger si un mouvement Polymarket est significatif.
            price = safe_float(msg.get("price"))
            size = safe_float(msg.get("size"))
            self._write_tick(meta, "last_trade_price", msg, {
                "last_trade": price,
                "trade_size": size,
                "trade_side": msg.get("side"),
                "trade_notional": (price * size) if (price is not None and size is not None) else None,
            })
            return

        if event_type in {"tick_size_change", "market_resolved", "new_market"}:
            # ÉVÉNEMENTS DE SERVICE — mesurés le 20/08/2026 sur une partition
            # réelle : 5 532 lignes pour 18,2 Mo, soit 3 284 o par ligne et
            # 67 % du VOLUME TOTAL du fichier, alors qu'ils ne portent aucune
            # information de prix. La cause est le champ "raw", qui recopie le
            # message brut intégral. Sans les événements de service, la même
            # partition tombe de 27,2 à 9,0 Mo.
            # « new_market » est de surcroît répété en boucle : 5 532 occurrences
            # pour quelques dizaines de marchés réellement suivis. On ne garde
            # donc que l'essentiel, et une seule fois par marché et par type.
            cle = (event_type, str(msg.get("market") or msg.get("condition_id") or ""))
            if cle in self._services_vus:
                self.filtres += 1
                return
            self._services_vus.add(cle)
            self.ecrits += 1
            append_jsonl(ticks_path(), {
                "ts": iso_now(),
                "event_type": event_type,
                "market_id": msg.get("market") or msg.get("condition_id"),
            })

    def _write_price_change(self, parent: Dict[str, Any], change: Dict[str, Any]) -> None:
        asset_id = str(change.get("asset_id") or "")
        if asset_id not in self.by_token:
            return
        meta = self.by_token[asset_id]
        bid = safe_float(change.get("best_bid"))
        ask = safe_float(change.get("best_ask"))
        mid = (bid + ask) / 2 if bid is not None and ask is not None else None
        spread = ask - bid if bid is not None and ask is not None else None
        self._write_tick(meta, "price_change", parent, {
            "bid": bid,
            "ask": ask,
            "mid": mid,
            "spread": spread,
            "price": safe_float(change.get("price")),
            "size": safe_float(change.get("size")),
            "side": change.get("side"),
        })

    def _throttle(self, asset_id, event_type, values) -> bool:
        """Faut-il ÉCRIRE ce tick ? (cf. note MIN_INTERVAL_S en tête de fichier)"""
        if event_type == "last_trade_price":
            self.ecrits += 1                  # compté comme les autres : sinon le
            return True                       # bilan sous-estime les écritures
        cle = (asset_id, event_type)
        maintenant = time.monotonic()
        prix = values.get("mid")
        if prix is None:
            prix = values.get("price")
        prec = self._last_write.get(cle)
        if prec is not None:
            t_prec, p_prec = prec
            try:
                bouge = (prix is not None and p_prec is not None
                         and abs(float(prix) - float(p_prec)) >= MIN_DELTA)
            except (TypeError, ValueError):
                bouge = True
            if not bouge and (maintenant - t_prec) < MIN_INTERVAL_S:
                self.filtres += 1
                return False
        self._last_write[cle] = (maintenant, prix)
        self.ecrits += 1
        return True

    def _write_tick(self, meta: Dict[str, Any], event_type: str, raw: Dict[str, Any], values: Dict[str, Any]) -> None:
        m = meta["market"]
        asset_id = (m.get("token_ids") or [None, None])[meta["outcome_index"]]
        if not self._throttle(str(asset_id), event_type, values):
            return
        # Tick VOLONTAIREMENT MAIGRE. La version précédente répétait à chaque
        # ligne event_title, question, slug, start_time et le dict local_match
        # complet -- des métadonnées FIXES par marché, déjà stockées une fois
        # dans polymarket_markets.json. À ~7700 ticks par run de 15 min, soit
        # de l'ordre de 700 000 lignes par jour, ces champs représentaient plus
        # de la moitié du volume écrit et poussé dans git à chaque cycle.
        # market_id suffit à retrouver le reste ; local_uid, local_side et
        # market_type sont conservés car ce sont les clés de jointure de
        # l'analyse.
        # ALLÈGEMENT (20/08/2026). Mesuré sur 40 000 ticks réels : 504 o par
        # ligne, dont 78 o pour le seul asset_id — un identifiant de jeton à
        # 78 chiffres, alors que market_id + outcome_index le désignent déjà
        # sans ambiguïté. S'y ajoutait le bruit de virgule flottante :
        # « spread: 0.020000000000000018 » occupe 20 o au lieu de 4.
        # Résultat : 431 -> 297 o par ligne, soit -31 % sans perte d'information.
        # À ~410 000 lignes par jour, cela représente une soixantaine de Mo
        # quotidiens en moins dans le dépôt.
        row = {
            "ts": iso_now(),
            "event_type": event_type,
            "market_id": m.get("market_id"),
            "outcome_index": meta["outcome_index"],
            "market_type": m.get("market_type"),
            "local_side": (m.get("outcome_sides") or [None, None])[meta["outcome_index"]],
            "local_uid": (m.get("local_match") or {}).get("uid"),
            **{k: (round(v, 4) if isinstance(v, float) else v)
               for k, v in values.items()},
        }
        append_jsonl(ticks_path(), row)


def websocket_loop(markets: List[Dict[str, Any]], max_seconds: Optional[int] = None) -> None:
    if not markets:
        print("⚠️ aucun marché Polymarket à suivre.")
        return

    assets = []
    for m in markets:
        assets.extend(str(x) for x in m.get("token_ids", []))
    assets = list(dict.fromkeys(assets))
    collector = Collector(markets)
    vus_ecrits = vus_filtres = 0        # bornes du dernier bilan affiché

    save_state(connected=False, subscribed_assets=len(assets))
    backoff = 2
    deadline = time.monotonic() + max_seconds if max_seconds else None

    while not STOP.is_set() and (deadline is None or time.monotonic() < deadline):
        ws = None
        pinger_stop = threading.Event()
        try:
            print(f"🔌 connexion CLOB WebSocket | {len(assets)} tokens")
            ws = websocket.create_connection(
                CLOB_WS_URL,
                timeout=30,
                origin="https://polymarket.com",
                enable_multithread=True,
            )
            ws.settimeout(2)
            ws.send(json.dumps({
                "assets_ids": assets,
                "type": "market",
                "custom_feature_enabled": True,
            }))
            save_state(connected=True, connected_at=iso_now(), subscribed_assets=len(assets))
            print("✅ abonnement Polymarket actif")
            backoff = 2

            def ping_loop() -> None:
                while not pinger_stop.wait(10):
                    try:
                        ws.send("PING")
                    except Exception:
                        break

            ping_thread = threading.Thread(target=ping_loop, daemon=True)
            ping_thread.start()

            while not STOP.is_set() and (deadline is None or time.monotonic() < deadline):
                try:
                    raw = ws.recv()
                    if raw is None:
                        raise RuntimeError("WebSocket fermé")
                    if isinstance(raw, bytes):
                        raw = raw.decode("utf-8", errors="replace")
                    if str(raw).strip().upper() == "PONG":
                        continue
                    try:
                        payload = json.loads(raw)
                    except Exception:
                        continue
                    messages = payload if isinstance(payload, list) else [payload]
                    for msg in messages:
                        collector.handle(msg)
                except websocket.WebSocketTimeoutException:
                    continue

        except Exception as exc:
            print(f"⚠️ WebSocket Polymarket: {exc}")
            save_state(connected=False, last_error=str(exc))
            wait_s = backoff
            if deadline is not None:
                wait_s = min(wait_s, max(0, deadline - time.monotonic()))
            if wait_s <= 0 or STOP.wait(wait_s):
                break
            backoff = min(backoff * 2, 60)
        finally:
            pinger_stop.set()
            if ws is not None:
                try:
                    ws.close()
                except Exception:
                    pass
            # Bilan du limiteur : rend visible le sur-échantillonnage évité.
            # Sans ce chiffre, on ne saurait pas si le filtre est trop agressif
            # (signal perdu) ou trop laxiste (dépôt qui explose).
            # Le Collector vit pour TOUTE la session websocket_loop, reconnexions
            # comprises : ecrits/filtres sont donc CUMULATIFS. Afficher la valeur
            # brute à chaque reconnexion donnait des lignes trompeuses -- « 1128 »
            # puis « 1418 » ressemblaient à deux lots indépendants alors que le
            # second contenait le premier. On affiche l'incrément de la connexion
            # qui vient de se terminer, plus le cumul entre parenthèses.
            try:
                de = collector.ecrits - vus_ecrits
                df = collector.filtres - vus_filtres
                print(f"   débit : {de} tick(s) écrit(s), {df} filtré(s) "
                      f"({100 * df / max(1, de + df):.0f} %) "
                      f"— cumul session {collector.ecrits}/{collector.ecrits + collector.filtres}")
                vus_ecrits, vus_filtres = collector.ecrits, collector.filtres
            except Exception:
                pass


def refresh_markets(session: requests.Session, use_match_filter: bool) -> List[Dict[str, Any]]:
    events = discover_events(session)
    markets = extract_markets(events, use_match_filter=use_match_filter)
    save_markets(markets)
    save_state(last_discovery=iso_now(), discovered_events=len(events), tracked_markets=len(markets))
    print(f"🔎 Gamma : {len(events)} événements tennis | {len(markets)} marchés suivis")
    return markets


# ── SONDE DE DÉCOUVERTE ───────────────────────────────────────────────────
# La découverte par tag /sports ne ramène que des FUTURES de vainqueur de
# tournoi (outcomes Yes/No, sportsMarketType et gameId à null). Or l'objet du
# projet est le lead/lag Polymarket -> Pinnacle sur les prix de MATCH : sans
# marché joueur-contre-joueur, l'étude est impossible.
# Cette sonde teste plusieurs voies en parallèle et dit laquelle, s'il y en a
# une, ramène des marchés par match. Elle n'écrit aucune donnée : elle répond à
# une seule question, « où sont les matchs ? ».
def probe_discovery(session: requests.Session) -> None:
    locals_ = local_match_rows()
    print("=" * 72)
    print("SONDE DE DÉCOUVERTE — où sont les marchés par match ?")
    print(f"{len(locals_)} matchs locaux à retrouver")
    print("=" * 72)

    def compte(events: List[Dict[str, Any]], label: str) -> None:
        """Compte les marchés binaires joueur-contre-joueur (hors Yes/No)."""
        jvj, futures, total = [], 0, 0
        for ev in events or []:
            for mk in (ev.get("markets") or []):
                if not isinstance(mk, dict):
                    continue
                total += 1
                outs = parse_jsonish(mk.get("outcomes"))
                if not isinstance(outs, list) or len(outs) != 2:
                    continue
                a, b = str(outs[0]), str(outs[1])
                if {norm_name(a), norm_name(b)} == {"yes", "no"}:
                    futures += 1
                    continue
                jvj.append(f"{a} / {b}")
        print(f"\n▶ {label}")
        print(f"   {len(events or [])} événements · {total} marchés · "
              f"{futures} futures Yes/No · {len(jvj)} joueur-vs-joueur")
        for x in jvj[:8]:
            print(f"      · {x}")

    # Voie A — tags /sports (celle utilisée aujourd'hui)
    try:
        tag_ids = discover_tennis_tag_ids(session)
        print(f"\ntags tennis trouvés via /sports : {tag_ids}")
        evs = []
        for tid in tag_ids:
            d = http_get(session, "/events", {"tag_id": tid, "active": "true",
                                              "closed": "false", "limit": 100})
            if isinstance(d, list):
                evs.extend(d)
        compte(evs, "A. /events?tag_id=<tennis>")
    except Exception as exc:
        print(f"\n▶ A. tags : ÉCHEC {exc}")

    # Voie B — recherche générale
    for q in ("tennis", "ATP", "WTA"):
        try:
            d = http_get(session, "/public-search", {
                "q": q, "events_status": "active", "limit_per_type": 100,
                "page": 1, "search_tags": "true", "search_profiles": "false"})
            compte((d.get("events") or []) if isinstance(d, dict) else [],
                   f"B. /public-search q={q}")
        except Exception as exc:
            print(f"\n▶ B. q={q} : ÉCHEC {exc}")

    # Voie C — recherche par NOM DE JOUEUR de nos propres matchs.
    # La plus décisive : si Polymarket cote « Sinner vs Zverev », chercher
    # « Zverev » doit le ramener. Si aucun des noms de matches_oddspapi.json ne
    # ramène de marché binaire joueur-vs-joueur, c'est que Polymarket ne cote
    # pas ces rencontres à l'unité -- et non que notre filtre est mal réglé.
    print("\n▶ C. recherche par nom de joueur (nos matchs du jour)")
    trouve = 0
    for row in locals_[:8]:
        nom = norm_name(row["home"]).split()[-1]
        try:
            d = http_get(session, "/public-search", {
                "q": nom, "events_status": "active", "limit_per_type": 20,
                "page": 1, "search_tags": "true", "search_profiles": "false"})
        except Exception as exc:
            print(f"   {nom:16} ÉCHEC {exc}")
            continue
        evs = (d.get("events") or []) if isinstance(d, dict) else []
        jvj = []
        for ev in evs:
            for mk in (ev.get("markets") or []):
                outs = parse_jsonish(mk.get("outcomes")) if isinstance(mk, dict) else None
                if isinstance(outs, list) and len(outs) == 2:
                    a, b = str(outs[0]), str(outs[1])
                    if {norm_name(a), norm_name(b)} != {"yes", "no"}:
                        jvj.append(f"{a} / {b}")
        trouve += len(jvj)
        print(f"   {nom:16} {len(evs):3} évts · {len(jvj)} jvj"
              + (f"  -> {jvj[0]}" if jvj else ""))
    print(f"\n   TOTAL joueur-vs-joueur par recherche de nom : {trouve}")

    print("\n" + "=" * 72)
    print("Lecture : si TOUTES les voies donnent 0 joueur-vs-joueur, Polymarket")
    print("ne cote pas les matchs de tennis à l'unité sur cette période. Le")
    print("lead/lag sur prix de match est alors impossible -- ce n'est pas un")
    print("réglage de filtre à corriger.")
    print("=" * 72)


def install_signal_handlers() -> None:
    def stop_handler(signum, frame):
        print("\n🛑 arrêt demandé")
        STOP.set()

    signal.signal(signal.SIGINT, stop_handler)
    signal.signal(signal.SIGTERM, stop_handler)


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Collecteur Polymarket Tennis Edge")
    p.add_argument("--once", action="store_true", help="découverte uniquement, sans WebSocket")
    p.add_argument("--probe", action="store_true", help="sonde : où sont les marchés par match ? (aucune écriture)")
    p.add_argument("--refresh-seconds", type=int, default=REFRESH_SECONDS)
    p.add_argument("--duration-seconds", type=int, default=0, help="durée maximale du collecteur; 0 = fonctionnement continu")
    p.add_argument("--no-match-filter", action="store_true", help="suit tous les marchés tennis détectés")
    return p.parse_args()


def main() -> int:
    args = parse_args()
    install_signal_handlers()
    use_match_filter = not (args.no_match_filter or NO_MATCH_FILTER)

    print("=== Polymarket Collector — Tennis Edge ===")
    save_state(last_run_at=iso_now(), running=True)
    print(f"Gamma      : {GAMMA_URL}")
    print(f"WebSocket  : {CLOB_WS_URL}")
    print(f"Match file : {MATCHES_FILE}")
    print(f"Ticks      : {ticks_path()}")
    print(f"Filtre TE  : {'ON' if use_match_filter else 'OFF'}")

    session = requests.Session()
    session.headers.update({"User-Agent": "TennisEdge-PolymarketCollector/1.0"})

    if args.probe:
        probe_discovery(session)
        return 0

    try:
        markets = refresh_markets(session, use_match_filter)
    except Exception as exc:
        print(f"❌ découverte Gamma impossible : {exc}")
        if args.once:
            return 1
        markets = load_markets()
        print(f"↩️ utilisation du dernier mapping : {len(markets)} marchés")

    if args.once:
        print(f"✅ --once terminé | {len(markets)} marchés enregistrés dans {MARKETS_FILE}")
        return 0

    # La découverte Gamma tourne séparément du WebSocket afin de ne pas interrompre
    # la collecte. Si de nouveaux matchs apparaissent, le prochain cycle reconnecte
    # le WS avec le nouveau set de tokens.
    # SUPPRIMÉ : une boucle de découverte en thread parallèle existait ici.
    # Elle n'était JAMAIS démarrée (aucun thread ne la lançait) et appelait
    # STOP.set() au premier nouveau token, ce qui aurait arrêté TOUT le
    # collecteur au lieu de le faire se reconnecter. La découverte est de toute
    # façon déjà refaite à chaque tour de la boucle principale ci-dessous.

    # Pour éviter une architecture complexe de hot-subscribe, on lance le WS pour
    # une fenêtre de refresh puis on reconnecte. En pratique, refresh=180s est léger
    # et garantit que les nouveaux matchs sont pris en compte.
    run_deadline = (time.monotonic() + args.duration_seconds) if args.duration_seconds > 0 else None

    while not STOP.is_set() and (run_deadline is None or time.monotonic() < run_deadline):
        try:
            markets = refresh_markets(session, use_match_filter)
        except Exception as exc:
            print(f"⚠️ refresh avant WS : {exc}")
            markets = load_markets()

        if not markets:
            print("⏳ aucun marché suivi; nouvelle découverte dans 30s")
            if STOP.wait(30):
                break
            continue

        # Exécute le WS pendant refresh_seconds, puis reconnecte après une nouvelle
        # découverte. Cela évite de perdre les nouveaux marchés et reste simple à opérer.
        ws_seconds = max(30, args.refresh_seconds)
        if run_deadline is not None:
            restant = int(run_deadline - time.monotonic())
            # Un cycle tronqué coûte un scan Gamma complet + une connexion WS pour
            # quelques secondes de collecte. Constaté : dernier cycle à 132 ticks
            # sur 932 messages. En dessous du quart d'un cycle, on s'arrête.
            if restant < max(30, args.refresh_seconds // 4):
                print(f"⏹️ {restant}s restantes — cycle trop court, arrêt propre.")
                break
            ws_seconds = min(ws_seconds, max(30, restant))
        websocket_loop(markets, max_seconds=ws_seconds)
        if STOP.is_set():
            break

    save_state(connected=False, running=False, stopped_at=iso_now())
    print("👋 Polymarket Collector arrêté")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
