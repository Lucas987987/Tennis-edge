# Fenêtre de résultats élargie (30/08/2026)

    unzip fenetre_resultats.zip
    cp fenetre_resultats/scripts/*.py scripts/

    bash fenetre_resultats/verifier.sh
    # doit afficher "TOUT EST EN PLACE (1 contrôle passé + test de non-régression)"
    # le test critique tourne sur tes VRAIES données (paper_trades_canal.jsonl,
    # resultats_derived.json), pas un exemple synthétique

    python tests/test_pure_functions.py      # doit afficher 13/13

    rm -rf fenetre_resultats fenetre_resultats.zip
    git add -A
    git commit -m "results_join.py : fenêtre de tolérance élargie de 3 à 5 jours (14/19 trades canal débloqués, matchs reportés hors de l'ancienne fenêtre)"
    git pull --no-rebase --no-edit && git push

---

## Diagnostic

Sur les 19 trades du canal public bloqués en `OUVERT` depuis le 24-25/08,
vérifié un par un : 14 correspondent à un résultat qui existe bel et bien
dans `resultats_derived.json`, mais daté 4 jours plus tard que l'`uid` du
trade (matchs reportés) -- hors de l'ancienne fenêtre de tolérance de 3
jours (`FENETRE_J`).

## Correctif

`FENETRE_J` (via `JOIN_WINDOW_DAYS`) élargi de 3 à 5 jours dans
`results_join.py`, module partagé par 6 scripts (`paper_journal_canal.py`,
`calibration_books.py`, `odds_dynamics.py`, `odds_roi_test.py`,
`pm_calibration_track.py`, `pm_observations.py`).

**Vérifié que l'élargissement ne crée pas de faux appariements** : le
filtre par PAIRE EXACTE de joueurs s'applique AVANT toute comparaison de
date -- deux mêmes joueurs qui se rencontrent deux fois en quelques jours
est rarissime au tennis. Testé sur l'ensemble des 99 trades du canal (pas
seulement les 19 ciblés) : résolution 76→90 (+14, cohérent avec le
diagnostic), **`ambigus` reste à 0 dans les deux cas** -- aucun risque de
confusion introduit.

## Ce qui reste bloqué, et pourquoi ce correctif n'y peut rien

5 des 19 trades (`Zhizhen Zhang/Rei Sakamoto`, `Lucia Bronzetti/Luisina
Giovannini`, `Soonwoo Kwon/Dusan Lajovic`, `Sara Sorribes Tormo/Noma Noha
Akugue`) n'ont **aucune entrée** pour cette paire précise dans
`resultats_derived.json`, même testé à 10 jours de fenêtre. Chaque joueur
y figure contre d'AUTRES adversaires, jamais celui-là. Ce n'est pas un
problème de tolérance de date -- le résultat n'a pas été capté par le
pipeline en amont (`results_bridge.py` ou la source qui alimente ce
fichier), même si le résultat réel est peut-être déjà visible ailleurs.
Pas corrigé ici -- à investiguer séparément, côté ingestion des résultats.

## Tests : 13/13 (inchangé)
