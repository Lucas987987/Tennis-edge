#!/usr/bin/env bash
# verifier.sh — élargissement de la fenêtre de tolérance des résultats
# (30/08/2026, demande de Lucas sur les 19 trades canal bloqués).
#
# Usage : bash verifier.sh   (à la racine du dépôt, APRÈS le cp)

set -uo pipefail
ECHECS=0

verif() {
    local fichier="$1" motif="$2" description="$3"
    if [ ! -f "$fichier" ]; then
        echo "❌ $fichier : FICHIER ABSENT"
        ECHECS=$((ECHECS+1))
        return
    fi
    if grep -q "$motif" "$fichier"; then
        echo "✅ $fichier : $description"
    else
        echo "❌ $fichier : $description -- MOTIF ABSENT ($motif)"
        ECHECS=$((ECHECS+1))
    fi
}

echo "=== Vérification -- fenêtre de résultats élargie (30/08/2026) ==="
echo

verif scripts/results_join.py "JOIN_WINDOW_DAYS', '5'" "FENETRE_J par défaut passée de 3 à 5 jours"

echo
echo "=== Test critique : sur les vraies données du dépôt, si présentes ici ==="
if [ -f paper_trades_canal.jsonl ] && [ -f resultats_derived.json ]; then
    python3 -c "
import sys; sys.path.insert(0,'scripts')
import os, json, importlib
os.environ['JOIN_WINDOW_DAYS'] = '5'
import results_join
importlib.reload(results_join)
import paper_journal_canal as pjc
idx = results_join.ResultIndex()
blocs = [json.loads(l) for l in open('paper_trades_canal.jsonl')]
n_resolus, n_ambigus = 0, idx.ambigus
for t in blocs:
    parts = str(t['uid']).split('_', 1)
    reste = parts[1] if len(parts) > 1 else ''
    ct = pjc._dt(t['commence'])
    gagnant = None
    for autre in pjc._autres_joueurs(reste, t['joueur']):
        gagnant = idx.winner(t['joueur'], autre, ct)
        if gagnant is not None:
            break
    if gagnant is not None:
        n_resolus += 1
print(f'{n_resolus}/{len(blocs)} résolus, {idx.ambigus} ambigus (doit être 0)')
assert idx.ambigus == 0, 'AMBIGUÏTÉ INTRODUITE -- ne pas committer'
print('✅ aucune ambiguïté introduite par l\'élargissement')
"
else
    echo "⏭️  paper_trades_canal.jsonl / resultats_derived.json absents ici -- test sauté (normal hors du dépôt réel)"
fi

echo
if [ "$ECHECS" -eq 0 ]; then
    echo "✅✅✅ TOUT EST EN PLACE (1 contrôle passé + test de non-régression). Sûr de committer."
    exit 0
else
    echo "❌❌❌ $ECHECS CONTRÔLE(S) EN ÉCHEC. NE PAS COMMITTER avant d'avoir compris pourquoi."
    exit 1
fi
