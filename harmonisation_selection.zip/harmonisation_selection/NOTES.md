# Harmonisation pick_signal / steam_alert (point 8, 30/08/2026)

    unzip harmonisation_selection.zip
    cp harmonisation_selection/scripts/*.py scripts/

    bash harmonisation_selection/verifier.sh
    # doit afficher "TOUT EST EN PLACE (4 contrôles passés + 2 tests critiques)"

    python tests/test_pure_functions.py      # doit afficher 13/13

    rm -rf harmonisation_selection harmonisation_selection.zip
    git add -A
    git commit -m "paper_journal.py:pick_signal() harmonisé sur le critère de steam_alert.py -- EV d'abord, taux historique ensuite (point 8) -- filtre pfair durci au passage"
    git pull --no-rebase --no-edit && git push

---

## Le problème, confirmé mot pour mot

`steam_alert.py` (l'alerte réellement envoyée) :

    best = max(cands, key=lambda c: (c['ev'], c['pct']))
    # meilleur : EV d'abord (c'est elle qui paie), reussite historique ensuite

`paper_journal.py` (le journal censé valider ce signal), avant ce correctif :

    return max(cands, key=lambda c: (c['pct'], c['odds']))

`ev` n'apparaissait même pas dans le tri du journal -- seulement comme
filtre de seuil, jamais comme critère de classement. Aucun commentaire
dans `paper_journal.py` ne justifiait ce choix différent, contrairement à
`steam_alert.py` qui a une justification économique explicite écrite en
toutes lettres. Le journal pouvait donc simuler un pari sur un book
différent de celui que l'alerte réelle aurait choisi, dès qu'il y avait
plusieurs candidats et que leur classement EV divergeait de leur
classement par taux historique -- **la validation forward ne testait pas
nécessairement la stratégie réellement déployée.**

## Le correctif

`pick_signal()` trie maintenant sur `(ev, pct)`, exactement comme
`steam_alert.py`, même ordre, même commentaire repris tel quel.

**Trouvé au passage en comparant les deux fonctions ligne à ligne** : le
filtre EV de `paper_journal.py` (`if pfair and (...) < EV_MIN_NOW`)
laissait passer un candidat SANS AUCUN contrôle d'EV quand `pfair` était
`None`/`0` (le `and` court-circuite, pas de `continue`) -- alors que
`steam_alert.py` exige `pfair_side` AVANT même de calculer l'EV. Durci
pour correspondre : `if not pfair: continue` en amont, comme dans
`steam_alert.py`.

## Vérifié avant de considérer que c'était fini

- Compilation.
- Le nouveau critère de tri, isolé, choisit bien le book à EV la plus
  haute plutôt que celui à taux historique le plus haut, sur un cas
  synthétique où les deux critères divergent réellement (pas un cas
  trivial à un seul candidat).
- `pick_signal()` testée de bout en bout avec des structures de données
  réalistes (courbes Pinnacle + soft book), tourne sans erreur, `ev` est
  bien peuplé dans le résultat.
- Les deux sites d'appel (`main()`, deux fois) gèrent déjà `if not sig:
  continue` de façon générique -- le filtre plus strict ne casse rien,
  les cas qu'il écarte désormais empruntent un chemin déjà géré.

## Ce qui n'a pas été mesuré

Je n'ai pas de backtest complet pour chiffrer combien de trades HISTORIQUES
auraient changé de book (ou de résultat) avec ce nouveau critère -- ça
demanderait de rejouer tout le journal existant, un chantier à part. Le
correctif est correct et testé sur sa logique ; son impact quantitatif sur
les 55 trades déjà réglés du journal forward reste à mesurer si tu veux
aller plus loin.

## Tests : 13/13 (inchangé)
