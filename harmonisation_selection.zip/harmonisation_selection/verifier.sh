#!/usr/bin/env bash
# verifier.sh — harmonisation pick_signal / steam_alert (point 8, 30/08/2026).
#
# Usage : bash verifier.sh   (à la racine du dépôt, APRÈS le cp)

set -uo pipefail
ECHECS=0

verif() {
    local fichier="$1" motif="$2" description="$3"
    if [ ! -f "$fichier" ]; then
        echo "❌ $fichier : FICHIER ABSENT"
        ECHECS=$((ECHECS+1))
        return
    fi
    if grep -q "$motif" "$fichier"; then
        echo "✅ $fichier : $description"
    else
        echo "❌ $fichier : $description -- MOTIF ABSENT ($motif)"
        ECHECS=$((ECHECS+1))
    fi
}

verif_absent() {
    local fichier="$1" motif="$2" description="$3"
    if [ ! -f "$fichier" ]; then
        echo "❌ $fichier : FICHIER ABSENT"
        ECHECS=$((ECHECS+1))
        return
    fi
    if grep -q "$motif" "$fichier"; then
        echo "❌ $fichier : $description -- MOTIF ENCORE PRÉSENT (doit être absent)"
        ECHECS=$((ECHECS+1))
    else
        echo "✅ $fichier : $description"
    fi
}

echo "=== Vérification -- harmonisation pick_signal/steam_alert (30/08/2026) ==="
echo

verif scripts/paper_journal.py "key=lambda c: (c\['ev'\], c\['pct'\])" "tri harmonisé sur (ev, pct), comme steam_alert.py"
verif_absent scripts/paper_journal.py "key=lambda c: (c\['pct'\], c\['odds'\])" "ancien tri (pct, odds) retiré"
verif scripts/paper_journal.py "'ev': ev" "champ ev désormais stocké dans le candidat"
verif scripts/paper_journal.py "if not pfair:" "filtre pfair durci, aligné sur steam_alert.py"

echo
echo "=== Test critique : le nouveau tri choisit bien EV, pas pct, quand ils divergent ==="
python3 -c "
cands = [
    {'book': 'A', 'ev': 0.10, 'pct': 40, 'odds': 2.0},
    {'book': 'B', 'ev': 0.05, 'pct': 70, 'odds': 1.8},
]
gagnant = max(cands, key=lambda c: (c['ev'], c['pct']))
assert gagnant['book'] == 'A', f'attendu A (EV la plus haute), obtenu {gagnant[\"book\"]}'
print('✅ le tri choisit bien le book à EV la plus haute (A), pas celui à pct la plus haute (B)')
"

echo
echo "=== Test critique : pick_signal() tourne de bout en bout sans erreur ==="
python3 -c "
import sys; sys.path.insert(0,'scripts')
import paper_journal as pj
import steam_alert as sa
bk = {
    sa.SHARP: {'h': [(1000, 1.80), (1010, 1.60), (1020, 1.50)],
              'a': [(1000, 2.10), (1010, 2.40), (1020, 2.55)]},
    '_home': 'Joueur A', '_away': 'Joueur B',
    'softbook1': {'h': [(1000, 1.85), (1010, 1.90), (1020, 1.95)],
                 'a': [(1000, 2.00), (1010, 1.95), (1020, 1.90)]},
}
thr_by_book = {'softbook1': (0.03, {'pct': 40, 'n': 50}, 'ok')}
r = pj.pick_signal(bk, ['softbook1'], thr_by_book, entry_at='now')
assert r is not None, 'pick_signal a renvoyé None sur un cas qui devrait produire un signal'
assert 'ev' in r, 'le champ ev est absent du résultat'
print('✅ pick_signal() tourne sans erreur, champ ev présent:', r['ev'])
"

echo
if [ "$ECHECS" -eq 0 ]; then
    echo "✅✅✅ TOUT EST EN PLACE (4 contrôles passés + 2 tests critiques). Sûr de committer."
    exit 0
else
    echo "❌❌❌ $ECHECS CONTRÔLE(S) EN ÉCHEC. NE PAS COMMITTER avant d'avoir compris pourquoi."
    exit 1
fi
