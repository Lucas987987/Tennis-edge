# Journaux atomiques — suite au correctif du 28/08 (29/08/2026)

Trouvé par validation externe, vérifié indépendamment par moi (chaque
affirmation reproduite sur le vrai code et les vraies données avant
d'accepter le périmètre proposé) : deux fichiers plus critiques que
`capture_state.json` (28/08), parce que leur troncature est **invisible**.

    unzip journaux_atomiques.zip
    cp journaux_atomiques/scripts/*.py scripts/
    cat journaux_atomiques/ajout_gitignore.txt >> .gitignore

    bash journaux_atomiques/verifier.sh
    # doit afficher "TOUT EST EN PLACE (6 contrôles passés)"
    # inclut un round-trip sur tes VRAIES données (paper_trades_match.jsonl,
    # paper_trades_canal.jsonl), pas un exemple synthétique

    python tests/test_pure_functions.py      # doit afficher 13/13

    rm -rf journaux_atomiques journaux_atomiques.zip
    git add -A
    git commit -m "Écriture atomique des journaux forward (save_journal x2) + filet .gitignore pour le résidu .tmp en cas de SIGKILL"
    git pull --no-rebase --no-edit && git push

---

## Pourquoi c'est pire que le cas du 28/08

`capture_state.json` vide était détectable en un coup d'œil (`wc -c` = 0).
Ici, `save_journal()` (`paper_journal.py`) et son équivalent
(`paper_journal_canal.py:161`) réécrivent leur fichier ENTIER à chaque
appel -- 6x/cycle pour le premier (3 marchés x 2 workflows). Si le
processus est tué en plein milieu (le déclencheur le plus plausible :
`steam_pipeline.yml` a `timeout-minutes: 45`, que j'ai moi-même ajouté
aujourd'hui comme mesure de sécurité -- `cancel-in-progress: false` écarte
l'annulation concurrente comme cause alternative), le JSONL résultant reste
**syntaxiquement parfait**, juste tronqué. Aucune exception, aucun code de
retour non nul, `|| true` masque même une éventuelle erreur Python côté
workflow. `git add -A` committe un historique de paris amputé sans laisser
de trace.

**Reproduit indépendamment** (pas seulement accepté sur la foi du rapport) :
une troncature à 60% de `paper_trades_match.jsonl` (37 lignes réelles)
reste 100% valide au parsing JSON, ligne par ligne. Ce qui est perdu -- les
cotes d'entrée au moment de la détection -- est irrécupérable : c'est le
track record forward sur lequel repose toute la validation du CLV menée
aujourd'hui.

## Le correctif

`ov.ecriture_atomique_texte()` (nouveau, dans `oddspapi_v5.py`, juste après
`ecriture_atomique()` du 28/08) -- même mécanisme (fichier `.tmp` +
`os.replace()`, nettoyage en cas d'échec), adapté au texte JSONL déjà
sérialisé plutôt qu'à un objet Python unique. Les deux `save_journal`
basculés dessus.

**Testé sur les vraies données, pas des exemples inventés** :
`paper_trades_match.jsonl` (37 lignes) et `paper_trades_canal.jsonl` (96
lignes) -- round-trip identique bit pour bit dans les deux cas, avant et
après l'écriture atomique.

## Le trou dans le correctif du 28/08, colmaté

Le nettoyage du `.tmp` résiduel dans `ecriture_atomique()`/
`ecriture_atomique_texte()` passe par un bloc `except` -- sur un `SIGKILL`
(ou tout arrêt brutal du processus, y compris un `SIGTERM` non intercepté),
ce bloc ne s'exécute jamais, le `.tmp` reste sur disque. `.gitignore`
n'avait aucune règle `*.tmp`. Testé sur un dépôt git jetable : un
`etat.json.tmp` fictif, `git add -A` après ajout de la règle -- `git
status --short` ne renvoie rien, confirmé ignoré.

## Périmètre volontairement resserré

~100 autres sites d'écriture non atomique dans le dépôt sont des rapports
RÉGÉNÉRÉS INTÉGRALEMENT à chaque run -- une troncature s'auto-répare au
cycle suivant, le risque ne justifie pas la surface. Non touchés ce soir,
cohérent avec la discipline déjà appliquée hier sur les ~35 scripts
restants après le premier correctif d'écriture atomique.

## Tests : 13/13 (inchangé)
