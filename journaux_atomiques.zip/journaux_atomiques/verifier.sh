#!/usr/bin/env bash
# verifier.sh — écriture atomique des journaux de paris (29/08/2026).
# Suite au correctif du 28/08 (capture_state.json, closing_lines.json, etc.),
# validation externe a trouvé 2 sites plus graves : le journal forward et
# son équivalent canal se tronquent SILENCIEUSEMENT (JSONL valide malgré
# la perte), contrairement au cas détectable du 28/08.
#
# Usage : bash verifier.sh   (à la racine du dépôt, APRÈS les cp et l'ajout gitignore)

set -uo pipefail
ECHECS=0

verif() {
    local fichier="$1" motif="$2" description="$3"
    if [ ! -f "$fichier" ]; then
        echo "❌ $fichier : FICHIER ABSENT"
        ECHECS=$((ECHECS+1))
        return
    fi
    if grep -q "$motif" "$fichier"; then
        echo "✅ $fichier : $description"
    else
        echo "❌ $fichier : $description -- MOTIF ABSENT ($motif)"
        ECHECS=$((ECHECS+1))
    fi
}

verif_absent() {
    local fichier="$1" motif="$2" description="$3"
    if [ ! -f "$fichier" ]; then
        echo "❌ $fichier : FICHIER ABSENT"
        ECHECS=$((ECHECS+1))
        return
    fi
    if grep -q "$motif" "$fichier"; then
        echo "❌ $fichier : $description -- MOTIF ENCORE PRÉSENT (doit être absent)"
        ECHECS=$((ECHECS+1))
    else
        echo "✅ $fichier : $description"
    fi
}

echo "=== Vérification -- journaux atomiques (29/08/2026) ==="
echo

verif scripts/oddspapi_v5.py "def ecriture_atomique_texte" "variante JSONL créée"
verif scripts/paper_journal.py "ov.ecriture_atomique_texte(JOURNAL" "save_journal() basculé"
verif_absent scripts/paper_journal.py "with open(JOURNAL, 'w'" "ancien motif retiré"
verif scripts/paper_journal_canal.py "ov.ecriture_atomique_texte(OUT" "écriture canal basculée"
verif_absent scripts/paper_journal_canal.py "with open(OUT, 'w'" "ancien motif retiré"
verif .gitignore "^\*\.tmp$" "règle *.tmp ajoutée (filet SIGKILL)"

echo
echo "=== Test critique : round-trip sur les vraies données, pas d'exemple synthétique ==="
python3 -c "
import sys, json; sys.path.insert(0,'scripts')
import oddspapi_v5 as ov

for nom_fichier in ('paper_trades_match.jsonl', 'paper_trades_canal.jsonl'):
    import os
    if not os.path.exists(nom_fichier):
        print(f'⚠️ {nom_fichier} absent ici, saut (normal si testé hors du dépôt réel)')
        continue
    lignes = open(nom_fichier, encoding='utf-8').readlines()
    contenu = ''.join(lignes)
    ov.ecriture_atomique_texte(f'/tmp/_v_{nom_fichier}', contenu)
    relu = open(f'/tmp/_v_{nom_fichier}', encoding='utf-8').readlines()
    assert relu == lignes, f'{nom_fichier}: round-trip différent'
    print(f'✅ {nom_fichier} : {len(lignes)} lignes, round-trip identique bit pour bit')
"

echo
if [ "$ECHECS" -eq 0 ]; then
    echo "✅✅✅ TOUT EST EN PLACE (6 contrôles passés). Sûr de committer."
    exit 0
else
    echo "❌❌❌ $ECHECS CONTRÔLE(S) EN ÉCHEC. NE PAS COMMITTER avant d'avoir compris pourquoi."
    exit 1
fi
