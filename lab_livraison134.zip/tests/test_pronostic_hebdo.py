import os
import subprocess
import sys

ICI = os.path.dirname(__file__)
sys.path.insert(0, os.path.join(ICI, '..', 'simulateur'))
import bilan_algo as B  # noqa: E402


def _aide(script, *args):
    return subprocess.run([sys.executable, os.path.join(ICI, '..', 'simulateur', script), *args, '-h'],
                          capture_output=True, text=True)


def test_racine_en_argument_positionnel():
    # 02/11/2026 : « profils_robustes.py /tmp/sackmann . --max 2000 » → « unrecognized arguments: . »
    for script in ('profils_robustes.py', 'styles_joueurs.py'):
        r = _aide(script, '/tmp/sackmann', '.', '--max', '2000')
        assert r.returncode == 0, r.stderr
        assert 'racine_pos' in r.stdout


def test_texte_telegram_echappe_hors_balises():
    t = B.texte_telegram('<b>Bilan</b>\n+0.0003 < 0.001 & 5 > 3 <i>ok</i> &amp; <a href="https://x.y">lien</a>')
    assert t == ['<b>Bilan</b>\n+0.0003 &lt; 0.001 &amp; 5 &gt; 3 <i>ok</i> &amp; <a href="https://x.y">lien</a>']


def test_texte_telegram_decoupe():
    morceaux = B.texte_telegram('\n'.join(['x' * 100] * 100))
    assert len(morceaux) == 3 and all(len(m) < 4096 for m in morceaux)
    assert ''.join(morceaux).count('x') == 10000
