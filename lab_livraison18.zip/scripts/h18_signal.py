#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
h18_signal.py — 18e hypothèse gelée : Favorite Steam Value.

    Parier le côté steamé au book d'entrée quand pin_open < 1,80 ET que
    le prix d'entrée dépasse de 0 à 3 % ce pin_open.

Gelée le 27/09/2026. Intersection STRICTE de H16 et H17 — aucun seuil
nouveau ajusté après coup. Canal PRIVÉ uniquement.

──────────────────────────────────────────────────────────────────────────
LE MEILLEUR RÉSULTAT DU DISPOSITIF

    n=123 · 96 gains = 78,0 % contre 70,2 % de seuil · écart +7,9
    ROI +11,8 % [+0,9 ; +22,8] · P&L +14,6 u · p exact 0,0322

RÉPLICATION : +12,4 % puis +11,2 %. UN POINT DEUX d'écart — la meilleure
stabilité mesurée, devant H17 (3,5 pts) et H15 (3 pts).

ROBUSTESSE, et c'est là qu'elle se distingue :
    sans le meilleur pari   ROI +11,3 %
    sans les 5 meilleurs    ROI  +9,0 %
    sans les 10 meilleurs   ROI  +6,1 %
Les 5 meilleurs paris font 27 % du P&L, contre 63 % pour H16 seule.

PLACEBO 500 tirages : plage [-9,7 ; +9,8], observé +11,8 % — hors plage.

MÉCANISME. Pinnacle tenait déjà le joueur pour favori net, puis raccourcit
encore sa cote, et un book mou laisse malgré tout un prix proche du niveau
d'ouverture Pinnacle. On achète après confirmation du mouvement tout en
gardant l'ancien prix sharp.

PAS DE VARIANTE SANS LES < 1,30. Découpage par pin_open : < 1,20 donne
+6,3 d'écart, 1,20-1,30 donne +9,5 — les ultra-favoris sont ici parmi les
MEILLEURS. Ce qui les rendait mauvais dans H16 seule, c'est l'absence de
filtre de prix. Ne pas transposer le retrait de H16-B ici.

RÉSERVE. L'IC95 du taux [69,9 ; 84,5] contient le seuil de 70,2 %, de très
peu. Et H18 n'est PAS indépendante de H16 et H17 : elle en est
l'intersection. Holm en tiendra compte.

Env : CURVES, SHARP, THR, MIN_LEAD, TELEGRAM_*, DRY_RUN=1. Les seuils
      viennent de validation_report, source unique.
"""
import os
import sys
import json
import datetime
import urllib.request
import urllib.parse

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import journal_direct              # noqa: E402 — journal complet (schéma 2)
import meilleurs_prix               # noqa: E402 — 3 meilleurs prix (affichage)
import scenarios                    # noqa: E402 — scénarios en sets (affichage)
import lien_joueur                   # noqa: E402 — liens vers les fiches
import oddspapi_v5 as ov      # noqa: E402

CURVES = os.environ.get('CURVES', 'book_curves_live.jsonl')
SHARP = os.environ.get('SHARP', 'pinnacle')
import validation_report as _vr      # noqa: E402 — source unique des
                                     # constantes gelées (bande, books)

# BOOKS D'ENTRÉE : importés de validation_report, comme la bande de cote.
# Ce script vit dans courbes_alertes.yml, move_audit.py dans
# steam_pipeline.yml : deux variables d'environnement séparées auraient
# laissé le détecteur temps réel travailler sur 3 books pendant que
# l'hypothèse se validait sur 7.
SOFTS = list(_vr.H14_SOFTS)
THR = float(os.environ.get('THR', '0.02'))
MIN_LEAD = float(os.environ.get('MIN_LEAD', '5'))
# BANDE : importée de validation_report, JAMAIS redéfinie ici.
# La version précédente la lisait dans l'environnement, ce qui permettait à
# un COTE_MAX=3.5 posé "pour voir" de faire diverger silencieusement ce
# canal de ce que roi_bande_watch() valide. Une seule source de vérité.
ECART_MIN = _vr.H17_ECART_MIN
ECART_MAX = _vr.H17_ECART_MAX
PIN_OPEN_MAX = _vr.H16_PIN_OPEN_MAX
DRY_RUN = os.environ.get('DRY_RUN', '') == '1'

ETAT = 'h18_signal_state.json'      # anti-doublon, un signal par match
LOG = 'h18_signal_log.jsonl'        # journal PERMANENT, append-only
FREEZE = _vr.FREEZE_DATE_H18


def _dt(s):
    try:
        d = datetime.datetime.fromisoformat(
            str(s).replace('Z', '').replace('+00:00', ''))
        return d.replace(tzinfo=None)
    except (ValueError, TypeError):
        return None


def _at(serie, t):
    """Dernière valeur connue À t. Strictement causal : jamais d'interpolation,
    jamais un point postérieur. Copie conforme de move_audit._at()."""
    v = None
    for tt, o in serie:
        if tt <= t:
            v = o
        else:
            break
    return v


def prob_home(oh, oa):
    """Normalisation proportionnelle — identique à move_audit.prob_home().
    Volontairement PAS Shin : la population de l'hypothèse est définie par
    cette formule, en changer changerait ce qu'on mesure."""
    if not oh or not oa or oh <= 1 or oa <= 1:
        return None
    ih, ia = 1 / oh, 1 / oa
    return ih / (ih + ia)


def charger():
    """{uid: {book: {'h': [(t, cote)], 'a': [...]}}, '_ct', '_home', '_away'}"""
    games = {}
    try:
        lignes = ov.open_curves(CURVES)
    except FileNotFoundError as e:
        print(f"  ❌ {e}")
        return games
    for ligne in lignes:
        ligne = ligne.strip()
        if not ligne:
            continue
        try:
            r = json.loads(ligne)
        except ValueError:
            continue
        ct = _dt(r.get('commence_time'))
        if ct is None or not r.get('book'):
            continue
        h = [(t, o) for t, o in
             ((_dt(p[0]), p[1]) for p in (r.get('home_curve') or []))
             if t and o]
        a = [(t, o) for t, o in
             ((_dt(p[0]), p[1]) for p in (r.get('away_curve') or []))
             if t and o]
        if not h or not a:
            continue
        g = games.setdefault(r['uid'], {'_ct': ct, '_home': r.get('home'),
                                        '_away': r.get('away'),
                                        '_tour': r.get('tournament')})
        g[r['book']] = {'h': sorted(h), 'a': sorted(a)}
    return games


def detecter(g, maintenant):
    """(côté, t_det, cote, book, ampleur_pts) ou None.

    Balayage causal : on s'arrête au PREMIER franchissement de THR, quel que
    soit son sens, et le côté est celui du mouvement à cet instant.
    """
    pin = g.get(SHARP)
    if not pin:
        return None
    topen = pin['h'][0][0]
    p_open = prob_home(_at(pin['h'], topen), _at(pin['a'], topen))
    if p_open is None:
        return None
    t_det, steam, p_det = None, None, None
    for t, _ in pin['h']:
        if t > maintenant:
            break                      # on ne lit jamais le futur
        p = prob_home(_at(pin['h'], t), _at(pin['a'], t))
        if p is None:
            continue
        if abs(p - p_open) >= THR:
            t_det, steam, p_det = t, ('h' if p > p_open else 'a'), p
            break
    if t_det is None:
        return None
    lead = (g['_ct'] - t_det).total_seconds() / 60.0
    if lead < MIN_LEAD:
        return None
    # meilleur prix mou sur le côté steamé, AU MOMENT de la détection
    cote, book = None, None
    for b in SOFTS:
        s = g.get(b)
        if not s:
            continue
        pr = _at(s['h'] if steam == 'h' else s['a'], t_det)
        if pr and (cote is None or pr > cote):
            cote, book = pr, b
    if cote is None:
        return None
    # PRIX PINNACLE À L'OUVERTURE du côté steamé — c'est LE filtre de H16.
    # Pris à `topen`, l'instant du premier point Pinnacle : c'est ce que le
    # marché sharp pensait AVANT tout mouvement, et c'est connu bien avant
    # la détection. Rien de rétrospectif ici.
    pin_open = _at(pin['h'] if steam == 'h' else pin['a'], topen)
    if not pin_open:
        return None
    return (steam, t_det, cote, book, abs(p_det - p_open) * 100, lead,
            pin_open)


def envoyer(texte):
    """Canal PRIVÉ uniquement. TELEGRAM_PUBLIC_CHAT_ID n'est pas lu ici, et
    ne doit pas l'être : voir l'en-tête du fichier."""
    token = os.environ.get('TELEGRAM_TOKEN')
    chat = os.environ.get('TELEGRAM_CHAT_ID')
    if DRY_RUN or not token or not chat:
        print(f"  [non envoyé] {texte.splitlines()[0]}")
        return False
    try:
        req = urllib.request.Request(
            f"https://api.telegram.org/bot{token}/sendMessage",
            data=urllib.parse.urlencode(
                {'chat_id': chat, 'text': texte,
                 'parse_mode': 'HTML',
                 'disable_web_page_preview': 'true'}).encode())
        with urllib.request.urlopen(req, timeout=15) as r:
            # On vérifie la RÉPONSE, pas seulement l'absence d'exception :
            # un journal qui enregistre l'intention plutôt que l'envoi ferait
            # croire à des messages reçus qui ne l'ont pas été.
            return r.status == 200
    except Exception as e:
        print(f"  ⚠️ Telegram : {e}")
        return False


def _suivi():
    """Bilan out-of-sample courant, recalculé à chaque alerte.

    C'est le SUIVI INTÉGRÉ : chaque message porte l'état d'avancement de
    l'hypothèse qu'il alimente. Sans ça, il faut attendre le récapitulatif
    quotidien pour savoir où on en est — et on finit par juger une
    hypothèse sur l'impression laissée par les derniers messages.
    """
    try:
        import csv as _csv
        lignes = list(_csv.DictReader(open('moves_detail_hist.csv',
                                           encoding='utf-8')))
    except OSError:
        return None
    k = n = 0
    somme = 0.0
    inv = 0.0
    for r in lignes:
        try:
            cote = float(r['entry'])
            po = float(r['pin_open'])
        except (TypeError, ValueError, KeyError):
            continue
        if not po:
            continue
        if po >= PIN_OPEN_MAX:
            continue
        if not (ECART_MIN <= 100.0 * (cote / po - 1.0) < ECART_MAX):
            continue
        if str(r.get('date') or '')[:10] < FREEZE:
            continue
        gagne = r.get('steame_gagne')
        if gagne not in ('oui', 'non'):
            continue
        try:
            pnl = float(r['pnl'])
        except (TypeError, ValueError, KeyError):
            pnl = (cote - 1.0) if gagne == 'oui' else -1.0
        n += 1
        k += 1 if gagne == 'oui' else 0
        somme += pnl
        inv += 1.0 / cote
    if not n:
        return {'n': 0}
    return {'n': n, 'k': k, 'taux': 100.0 * k / n, 'p0': 100.0 * inv / n,
            'roi': 100.0 * somme / n, 'pnl': somme}


def message(g, steam, cote, book, ampleur, lead, pin_open):
    joueur = g['_home'] if steam == 'h' else g['_away']
    adv = g['_away'] if steam == 'h' else g['_home']
    hh = int(lead // 60)
    lead_txt = f"{int(lead)} min" if lead < 60 else f"{hh}h{int(lead % 60):02d}"
    ecart = 100.0 * (cote / pin_open - 1.0) if pin_open else 0.0
    L = [f"🧪 <b>H18 — Favorite Steam Value</b>",
         f"favori net {pin_open:.2f} → entrée {cote:.2f} (écart {ecart:+.1f} %)",
         f"{g.get('_tour') or '?'} · T-{lead_txt}",
         f"{lien_joueur.duo_html(joueur, adv)}",
         f"📉 mouvement Pinnacle {ampleur:.1f} pts · entrée {book} @ {cote:.2f}"]
    prix = meilleurs_prix.ligne(g, steam)  # 3 meilleurs prix frais (affichage seul)
    if prix:
        L.append(prix)
    sc = scenarios.ligne(g, steam)  # 2-0 / 2-1… depuis la cote Pinnacle (affichage seul)
    if sc:
        L.append(sc)
    s = journal_direct.suivi('H18')  # bilan EN DIRECT (verdicts_direct.json)
    if s and s.get('n'):
        L.append(f"\n📊 <b>Suivi</b> : {s['n']}/150 paris dénoués "
                 f"({100 * s['n'] / 150:.0f} %)")
        L.append(f"gains {s['k']}/{s['n']} = {s['taux']:.1f} % "
                 f"(seuil {s['p0']:.1f} %) · écart {s['taux'] - s['p0']:+.1f} pts")
        L.append(f"ROI {s['roi']:+.1f} % · P&L {s['pnl']:+.1f} u")
    elif s is not None:
        L.append("\n📊 <b>Suivi</b> : aucun pari dénoué depuis le gel.")
    L.append(f"\n<i>Hypothèse gelée le {FREEZE}, NON VALIDÉE. Référence "
             f"in-sample : 96/123 = 78,0 % contre 70,2 % de seuil, "
             f"ROI +11,8 %. Meilleure réplication du dispositif (+12,4 % "
             f"puis +11,2 %) et meilleure robustesse (5 meilleurs paris = "
             f"27 % du P&L). Mais intersection de H16 et H17, donc NON "
             f"indépendante : Holm en tiendra compte. Verdict vers n=150. "
             f"Ne pas diffuser.</i>")
    return '\n'.join(L)


def _deja_signale(uid):
    """Un autre signal a-t-il déjà couvert ce match ?

    La bande 2,40-3,10 recoupe H13 (2,00-3,00) et la zone 2,50-3,20.
    On LOGUE tout — la mesure doit porter sur toute la bande — mais on
    n'envoie pas trois messages pour le même match.
    """
    for fichier, cle in (('h13_signal_state.json', 'h13'),
                         ('zone_signal_state.json', 'zone')):
        try:
            etat = json.load(open(fichier, encoding='utf-8'))
        except (OSError, ValueError):
            continue
        if uid in etat:
            return cle
    return None


def main():
    print(f"H18 SIGNAL (canal privé) — pin<{PIN_OPEN_MAX:.2f} & écart "
          f"{ECART_MIN:.0f}-{ECART_MAX:.0f} % · "
          f"THR {THR:.3f} · softs {','.join(SOFTS)}"
          + ("  [DRY RUN]" if DRY_RUN else ""))
    # utcnow() est déprécié depuis 3.12 ; les courbes portent des
    # horodatages naïfs en UTC, on reste naïf des deux côtés.
    maintenant = datetime.datetime.now(datetime.timezone.utc).replace(tzinfo=None)
    try:
        etat = json.load(open(ETAT, encoding='utf-8'))
    except (OSError, ValueError):
        etat = {}
    games = charger()
    if not games:
        print("  aucune courbe exploitable.")
        return 0

    n_vus, n_bande, n_envoyes = 0, 0, 0
    for uid, g in games.items():
        if g['_ct'] <= maintenant:
            continue                   # match commencé : hors périmètre
        d = detecter(g, maintenant)
        if not d:
            continue
        n_vus += 1
        steam, t_det, cote, book, ampleur, lead, pin_open = d
        ecart = 100.0 * (cote / pin_open - 1.0) if pin_open else -99.0
        if pin_open >= PIN_OPEN_MAX:
            continue
        if not (ECART_MIN <= ecart < ECART_MAX):
            continue
        n_bande += 1
        if uid in etat:
            continue                   # déjà traité par CE script
        doublon = _deja_signale(uid)
        ok = False
        if not doublon:
            ok = envoyer(message(g, steam, cote, book, ampleur, lead, pin_open))
            n_envoyes += 1
        # Journal COMPLET (schéma 2, scripts/journal_direct.py) : TOUTE
        # détection dans la règle est écrite — envoyée, doublon, échec ou
        # non tentée. Champs de décision écrits une fois, jamais modifiés.
        rec = journal_direct.ligne('H18', uid, g, steam, t_det, maintenant,
                                   cote, book, ampleur, lead, ok, doublon)
        etat[uid] = {'t': maintenant.isoformat(timespec='seconds'),
                     'commence': g['_ct'].isoformat(),
                     'cote': round(cote, 2), 'pin_open': rec['pin_open'],
                     'book': book, 'envoye': ok, 'doublon': doublon or ''}
        journal_direct.ecrire(LOG, rec)

    # Purge des états dont le match est passé : sans elle le fichier gonfle
    # indéfiniment et l'anti-doublon finit par coûter plus cher que le calcul.
    etat = journal_direct.purger(etat, maintenant)
    try:
        ov.ecriture_atomique(ETAT, etat, ensure_ascii=False, indent=1)
    except Exception as e:
        print(f"  ℹ️ état non écrit : {e}")

    print(f"  {len(games)} matchs · {n_vus} avec mouvement détecté · "
          f"{n_bande} dans la bande · {n_envoyes} signal(aux) envoyé(s)")
    # DEPUIS LE 16/10/2026 le verdict se rend sur CE journal (suivi_direct.py
    # -> verdicts_direct.json) ; la reconstruction n'est plus qu'un contrôle.
    return 0


if __name__ == '__main__':
    sys.exit(main())
