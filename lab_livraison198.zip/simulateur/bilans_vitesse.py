#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
bilans_vitesse.py — bilan de chaque joueur selon la vitesse du court (06/11/2026, demande de Lucas). DESCRIPTIF SEUL.

Pour chaque joueur, sur ses 3 dernières années (archive Sackmann + feuilles TennisApi), ATP, WTA, Challenger, matchs
complets : victoires, défaites, et victoires ATTENDUES (probabilité Elo d'avant-match, surface comprise), par classe
de court — lent (CPI < 35), moyen (35–40), rapide (≥ 40), CPI officiel sinon estimé (vitesse_courts.json).

L'étude du 06/11/2026 (etude_bilans_contexte.py, règle fixée avant) : ce bilan NE PRÉDIT RIEN au-delà du niveau,
même sur courts rapides (ATP +0,0002 de log loss pour 0,001 exigé). Il n'entre donc pas dans le pronostic : il est
affiché sur la fiche, avec l'attendu et la marge d'erreur, parce que les abonnés aiment le voir.
Sortie : simulateur/bilans_vitesse.json (lu par vitrine.py dans le même run, non publié tel quel).
Usage : python simulateur/bilans_vitesse.py /tmp/sackmann .
"""
import datetime as dt
import json
import os
import sys

ICI = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, ICI)
FENETRE_J = 3 * 365
CIRCUITS = ('ATP', 'WTA', 'CH')
SORTIE = os.path.join('simulateur', 'bilans_vitesse.json')


def classe3(cpi):
    return None if cpi is None else 'lent' if cpi < 35 else 'moyen' if cpi < 40 else 'rapide'


def classe_edition(doc, circuit, tournoi, annee):
    import vitesse_courts as VC
    ed = ((doc or {}).get('tournois') or {}).get(f'{circuit}|{VC.norme(tournoi)}') or {}
    v = ed.get(str(annee)) or ed.get(str(annee - 1))
    if not v:
        return None
    off = v.get('cpi_officiel')
    return classe3(off if off is not None else v.get('cpi_estime'))


def construire(archive, racine, aujourdhui=None):
    import donnees as DN
    import elo as E
    import feuilles as FE
    aujourdhui = aujourdhui or dt.date.today()
    with open(os.path.join(racine, 'simulateur', 'vitesse_courts.json'), encoding='utf-8') as f:
        vdoc = json.load(f)
    M = DN.charger(archive, 2015)
    fin = max(m['date'] for m in M) if M else dt.date(2000, 1, 1)
    M += [m for m in FE.charger(racine) if m['date'] > fin]
    M.sort(key=lambda m: (m['date'], m.get('tour', 0), m.get('num', 0)))
    try:
        with open(os.path.join(racine, 'simulateur', 'elo_etat.json'), encoding='utf-8') as f:
            alias = dict(E.migrer_etat(json.load(f)).get('alias') or {})
    except (OSError, ValueError):
        alias = {}
    k = lambda n: alias.get(E.cle(n), E.cle(n)) if n else None
    debut = aujourdhui - dt.timedelta(days=FENETRE_J)
    el, jour, attente, out = E.Elo(), None, [], {}
    for m in M:
        d = m['date']
        if d != jour:
            for a in attente:
                el.maj(*a)
            attente, jour = [], d
        g, p = k(m.get('nom_g')), k(m.get('nom_p'))
        if not g or not p or g == p:
            continue
        c, s = m['circuit'], m['surface']
        if c in ('CH', 'ITF'):
            el.presenter(g, 1200.0)
            el.presenter(p, 1200.0)
        if c in CIRCUITS and m.get('complet') and not m.get('abandon') and d >= debut:
            cl = classe_edition(vdoc, c, m.get('tournoi') or '', d.year)
            if cl:
                eg = min(max(el.proba(g, p, s), 0.01), 0.99)
                for j, y, e in ((g, 1, eg), (p, 0, 1 - eg)):
                    b = out.setdefault(j, {}).setdefault(cl, [0, 0, 0.0])
                    b[0] += 1
                    b[1] += y
                    b[2] += e
        attente.append((g, p, s, m.get('niveau') == 'G', None))
    return {'genere_le': dt.datetime.now(dt.timezone.utc).isoformat(timespec='seconds'), 'fenetre_jours': FENETRE_J,
            'joueurs': {j: {cl: [n, v, round(e, 2)] for cl, (n, v, e) in d_.items()} for j, d_ in out.items()}}


def main(argv):
    doc = construire(argv[1], argv[2] if len(argv) > 2 else '.')
    with open(os.path.join(argv[2] if len(argv) > 2 else '.', SORTIE), 'w', encoding='utf-8') as f:
        json.dump(doc, f, ensure_ascii=False, separators=(',', ':'))
    print(f"Bilans par vitesse de court : {len(doc['joueurs'])} joueurs")
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv))
