"""Bilans par vitesse de court (06/11/2026, paquet 198) : classes et édition du tournoi."""
import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'simulateur'))
import bilans_vitesse as BV  # noqa: E402


class BilansVitesse(unittest.TestCase):
    def test_classes(self):
        self.assertEqual([BV.classe3(x) for x in (34.9, 35, 39.9, 40, None)], ['lent', 'moyen', 'moyen', 'rapide', None])

    def test_edition(self):
        doc = {'tournois': {'ATP|paris': {'2025': {'cpi_estime': 37.0, 'cpi_officiel': None},
                                          '2026': {'cpi_estime': 30.0, 'cpi_officiel': 47.9}}}}
        self.assertEqual(BV.classe_edition(doc, 'ATP', 'Paris', 2026), 'rapide')   # l'officiel prime
        self.assertEqual(BV.classe_edition(doc, 'ATP', 'Paris', 2027), 'rapide')   # sinon l'édition d'avant
        self.assertIsNone(BV.classe_edition(doc, 'ATP', 'Lyon', 2026))


if __name__ == '__main__':
    unittest.main()
