# -*- coding: utf-8 -*-
"""12/11/2026 (paquet 237) — statistiques annoncées rejouées sur l'archive : l'étude, le contrôle en direct, la variante
« archive » du recalage et son retrait."""
import json
import os
import random
import sys
import tempfile
import unittest

ICI = os.path.dirname(os.path.abspath(__file__))
RACINE = os.path.join(ICI, '..')
sys.path.insert(0, os.path.join(RACINE, 'simulateur'))
import etude_statistiques_annoncees as ES  # noqa: E402
import recalage_stats as RS  # noqa: E402


def cas(n, c, k, annees, demi=3.0, ecart_type=1.5, biais=0.0, graine=1, mois=None):
    """n cas par année : annoncé 10 ± demi, réel = 10 + biais + bruit."""
    rnd, out = random.Random(graine), []
    for an in annees:
        for i in range(n):
            m = mois or (1 + i % 12)
            out.append({'jour': f'{an}-{m:02d}-15', 'c': c, 'k': k, 'moy': 10.0, 'p10': 10.0 - demi, 'p90': 10.0 + demi,
                        'reel': float(round(10.0 + biais + rnd.gauss(0, ecart_type)))})
    return out


class Etude(unittest.TestCase):
    def test_reels_depuis_le_detail_de_l_archive(self):
        w, l = (82, 50, 37, 19, 9, 5, 3, 2, 13), (112, 71, 46, 18, 5, 1, 13, 10, 13)
        self.assertEqual(ES.reels(w, l), {'aces': 9.0, 'doubles_fautes': 5.0, 'premiere_pct': 100 * 50 / 82, 'breaks': 3.0})
        self.assertEqual(ES.reels(l, w)['breaks'], 1.0)                       # breaks OBTENUS : ceux subis par l'adversaire

    def test_une_fourchette_trop_large_est_resserree_et_reglee(self):
        rows = cas(800, 'ATP', 'breaks', (2019, 2020, 2021, 2022, 2023, 2024))  # ± 3 pour un écart type de 1,5 : trop large
        x = ES.juger(rows)['cases']['ATP|breaks']
        self.assertGreater(x['couverture_sans'], 90)
        self.assertLess(x['coefficients']['largeur'], 1.0)
        self.assertTrue(78 <= x['couverture_recalee'] <= 82, x['couverture_recalee'])
        self.assertTrue(x['reglee_sur_l_archive'])
        peu = ES.juger(cas(800, 'ATP', 'breaks', (2019, 2020, 2021, 2022)) + cas(400, 'ATP', 'breaks', (2023,)))['cases']['ATP|breaks']
        self.assertFalse(peu['reglee_sur_l_archive'])                           # moins de 1 000 cas jugés

    def test_le_controle_en_direct_decide(self):
        rows = cas(800, 'ATP', 'breaks', (2019, 2020, 2021, 2022, 2023, 2024))
        directs = cas(300, 'ATP', 'breaks', (2026,), graine=9)                  # nos matchs se comportent comme l'archive
        x = ES.juger(rows, directs, None)['cases']['ATP|breaks']
        self.assertTrue(x['remplace_ce_qui_est_en_place'], x['raisons'])
        x = ES.juger(rows, directs[:100], None)['cases']['ATP|breaks']
        self.assertIn('moins de 150 cas en direct', x['raisons'])
        ailleurs = cas(300, 'ATP', 'breaks', (2026,), ecart_type=3.5, graine=9)   # en direct, bien plus dispersé : resserrer ferait pire
        x = ES.juger(rows, ailleurs, None)['cases']['ATP|breaks']
        self.assertFalse(x['remplace_ce_qui_est_en_place'])

    def test_un_decalage_d_archive_n_est_pas_transpose_si_le_biais_en_direct_est_autre(self):
        rows = cas(800, 'WTA', 'premiere_pct', (2019, 2020, 2021, 2022, 2023, 2024), demi=2.0, biais=0.5)
        directs = cas(300, 'WTA', 'premiere_pct', (2026,), demi=2.0, biais=4.0, graine=9)
        x = ES.juger(rows, directs, None)['cases']['WTA|premiere_pct']
        self.assertTrue(any('source' in r for r in x['raisons']), x['raisons'])

    def test_saison_retenue_si_elle_tient_rejetee_sinon(self):
        def saison(annees, ampl, graine):
            out = []
            for m in range(1, 13):
                out += cas(120, 'ATP', 'premiere_pct', annees, demi=8, ecart_type=5, biais=ampl if m in (1, 10, 11) else (-ampl if m in (7, 8) else 0.0),
                           graine=graine + m, mois=m)
            return out
        tient = ES.juger_saison(saison((2019, 2020, 2021, 2022), 3.0, 1) + saison((2023, 2024, 2025), 3.0, 50))['ATP']
        self.assertTrue(tient['retenu'], tient)
        self.assertGreater(tient['decalages_par_mois']['10'], 1.0)
        self.assertLess(tient['decalages_par_mois']['8'], -1.0)
        absente = ES.juger_saison(saison((2019, 2020, 2021, 2022), 3.0, 1) + saison((2023, 2024, 2025), 0.0, 50))['ATP']
        self.assertFalse(absente['retenu'])

    def test_regles_ecrites_avant_et_rejeu_comme_la_production(self):
        with open(os.path.join(RACINE, 'simulateur', 'etude_statistiques_annoncees.py'), encoding='utf-8') as f:
            src = f.read()
        for mot in ('AVANT DE LANCER LE REJEU', 'AVANT DE JUGER', 'aveu', 'E.de_production(racine)', 'AJ.ajuster(', 'MS.simuler(', "m.get('niveau') != 'D'"):
            self.assertIn(mot, src, mot)
        self.assertEqual((ES.MIN_CAS, ES.BORNES, ES.MIN_CAS_DIRECT), (1000, (78.0, 82.0), 150))


class Rapport(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        with open(os.path.join(RACINE, 'simulateur', 'rapport_statistiques_annoncees.json'), encoding='utf-8') as f:
            cls.R = json.load(f)
        with open(os.path.join(RACINE, 'simulateur', 'recalage_stats_archive.json'), encoding='utf-8') as f:
            cls.A = json.load(f)

    def test_public(self):
        for doc in (self.R, self.A):
            txt = json.dumps(doc, ensure_ascii=False).lower()
            for mot in ('marché', 'pinnacle', 'clôture', 'cote'):
                self.assertNotIn(mot, txt)

    def test_les_verdicts_suivent_la_regle(self):
        self.assertEqual(len(self.R['cases']), 12)
        for cle, x in self.R['cases'].items():
            self.assertEqual(x['reglee_sur_l_archive'], bool(x['cas_juges'] >= 1000 and 78 <= x['couverture_recalee'] <= 82), cle)
            if x['remplace_ce_qui_est_en_place']:
                self.assertTrue(x['reglee_sur_l_archive'], cle)
                self.assertGreaterEqual(x['en_direct']['cas'], 150, cle)
                e = x['en_direct']
                self.assertLessEqual(abs(e['couverture']['archive'] - 80), abs(e['couverture']['en_place'] - 80), cle)
                self.assertLessEqual(e['ecart']['archive'], e['ecart']['en_place'], cle)

    def test_seules_les_cases_qui_passent_le_controle_sont_en_production(self):
        attendu = {cle: x['coefficients'] for cle, x in self.R['cases'].items() if x['remplace_ce_qui_est_en_place']}
        self.assertEqual(self.A['cases'], attendu)
        self.assertEqual(RS.coefs_archive(RACINE), attendu)

    def test_le_modele_n_a_pas_de_biais_d_ensemble_sur_l_archive(self):
        for c in ('ATP', 'WTA', 'CH'):
            self.assertLess(abs(self.R['cases'][f'{c}|premiere_pct']['biais_2023']), 0.5, c)     # la 1re balle : juste sur l'archive
            self.assertGreater(self.R['cases'][f'{c}|premiere_pct']['en_direct']['biais'], 1.0, c)   # trop basse en direct

    def test_la_saison_n_est_en_production_que_si_elle_a_passe(self):
        S = self.R['saison_premieres_balles']
        for c, v in S.items():
            b = v['biais_mensuel_moyen']
            self.assertEqual(v['retenu'], bool(v['cas_juges'] >= 1000 and b['apres'] <= b['avant'] * 2 / 3
                                                and v['ecart_moyen']['apres'] <= v['ecart_moyen']['avant']), c)
        if not any(v['retenu'] for v in S.values()):
            for nom in ('recalage_stats.py', 'vitrine.py', 'pronostics_du_jour.py', 'match_simule.py'):
                with open(os.path.join(RACINE, 'simulateur', nom), encoding='utf-8') as f:
                    self.assertNotIn('decalages_par_mois', f.read(), nom)


class VarianteArchive(unittest.TestCase):
    ARCH = {'WTA|breaks': {'delta': -0.05, 'largeur': 0.8}}

    def test_la_case_prend_la_variante_archive_sauf_si_elle_a_ete_retiree(self):
        cases = {'WTA|breaks': {'variante': 'sans', 'depuis': '2026-11-11'}, 'ATP|aces': {'variante': 'sans'}}
        out = RS.avec_archive(cases, self.ARCH)
        self.assertEqual(out['WTA|breaks'], {'variante': 'archive', 'depuis': RS.ARCHIVE_DEPUIS, 'semaines_pires': 0})
        self.assertEqual(out['ATP|aces'], {'variante': 'sans'})
        retiree = {'WTA|breaks': {'variante': 'sans', 'archive_retiree': True}}
        self.assertEqual(RS.avec_archive(retiree, self.ARCH), retiree)
        self.assertEqual(RS.avec_archive(cases, {}), cases)

    def test_le_site_lit_les_coefficients_fixes(self):
        co = RS.lire_coefs(RACINE)
        for cle, v in RS.coefs_archive(RACINE).items():
            c, k = cle.split('|')
            self.assertEqual(co[c][k], v)
        self.assertEqual(RS.etat_pour_le_site(RACINE)['WTA']['breaks']['variante'], 'archive')
        with tempfile.TemporaryDirectory() as d:
            self.assertEqual(RS.coefs_archive(d), {})

    def test_suivi_cumule_et_retrait(self):
        bons = cas(400, 'WTA', 'breaks', (2027,), demi=3.0, ecart_type=1.5)          # resserrer rapproche de 80 %
        s = RS.suivi_archive(bons, 'WTA', 'breaks', self.ARCH['WTA|breaks'])
        self.assertEqual(s['cas'], 400)
        self.assertFalse(s['retrait'])
        mauvais = cas(400, 'WTA', 'breaks', (2027,), demi=3.0, ecart_type=3.0)       # déjà trop étroite : resserrer éloigne de 80 %
        s = RS.suivi_archive(mauvais, 'WTA', 'breaks', self.ARCH['WTA|breaks'])
        self.assertGreater(abs(s['couverture_archive'] - 80), abs(s['couverture_sans'] - 80) + 5)
        self.assertTrue(s['retrait'])
        self.assertFalse(RS.suivi_archive(mauvais[:299], 'WTA', 'breaks', self.ARCH['WTA|breaks'])['retrait'])   # moins de 300 cas
        avant = [dict(r, jour='2026-11-05') for r in mauvais]                           # avant le départ du suivi : pas compté
        self.assertEqual(RS.suivi_archive(avant, 'WTA', 'breaks', self.ARCH['WTA|breaks']), {'cas': 0, 'retrait': False})

    def test_la_regle_hebdomadaire_ne_touche_pas_une_case_archive_et_le_retrait_tient(self):
        ancien = RS.avec_archive({}, self.ARCH)
        bons = cas(400, 'WTA', 'breaks', (2027,))
        d = RS.decider_cases(ancien, bons[:300], bons[300:], '2027-12-20', self.ARCH)['WTA|breaks']
        self.assertEqual((d['variante'], d['depuis']), ('archive', RS.ARCHIVE_DEPUIS))
        mauvais = cas(400, 'WTA', 'breaks', (2027,), ecart_type=3.0)
        d = RS.decider_cases(ancien, mauvais[:300], mauvais[300:], '2027-12-20', self.ARCH)['WTA|breaks']
        self.assertEqual(d['variante'], 'sans')
        self.assertTrue(d['archive_retiree'])
        self.assertEqual(RS.avec_archive({'WTA|breaks': d}, self.ARCH)['WTA|breaks']['variante'], 'sans')   # ne revient pas


if __name__ == '__main__':
    unittest.main()
