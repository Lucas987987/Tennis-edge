"""Direct en 3D, moteur WebGL maison (13/11/2026, paquet 259) : stade, public, arbitre, ramasseurs, joueurs articulés
et animés, ombres. Rien n'est chargé d'ailleurs ; score, serveur et côté réels ; échanges illustratifs."""
import json
import re
import shutil
import subprocess
import tempfile
import unittest
from pathlib import Path

RACINE = Path(__file__).resolve().parents[1]
HTML = (RACINE / 'algo' / 'index.html').read_text(encoding='utf-8')
DEBUT, FIN = 'const G3D = (() => {', '// Vue du direct choisie par le visiteur'
BLOC = HTML[HTML.index(DEBUT):HTML.index(FIN)]

SCENARIO = r"""
const fs = require('fs');
const src = fs.readFileSync(process.argv[2], 'utf-8');
const a = src.indexOf('const G3D = (() => {'), b = src.indexOf('// Vue du direct choisie par le visiteur');
global.court = n => { const p = String(n).trim().split(/\s+/); return p.length > 1 ? p.slice(1).join(' ') : n; };
global.esc = x => String(x);
eval(src.slice(a, b).replace('const G3D =', 'global.G3D ='));
const HL = 23.77 / 2, W = 10.97;
const out = { cas: [], poses_finies: true, coups: { cd: 0, rv: 0, service: 0 } };
const finie = p => Object.values(p).every(v => Array.isArray(v) ? v.every(Number.isFinite) : Number.isFinite(v));
for (const [inverse, serveur, ph, pa, sh, sa] of [[false, 'home', '0', '0', [6, 3], [4, 2]], [false, 'home', '15', '0', [2], [1]],
    [true, 'home', '30', '15', [4, 2], [6, 3]], [false, 'away', '40', 'A', [6, 5], [4, 5]], [true, 'away', '3', '2', [6, 6], [4, 6]]]) {
  const r = { inverse, x: { serveur, score_home: { sets: sh, point: ph }, score_away: { sets: sa, point: pa } } };
  for (let essai = 0; essai < 30; essai++) {
    G3D._reinit(); G3D._maj({ home: 'Jannik Sinner', away: 'Carlos Alcaraz', surface: 'Clay' }, r, false);
    const E = G3D._etat, o = G3D._simuler(0.01), v0 = o.R.vols[0];
    const cas = { srv: E.srv, droite: E.droite, qui: v0.qui, depart: [v0.a.x, v0.a.z], cible: [v0.b.x, v0.b.z], hors: 0, joueurs_hors: 0 };
    for (let t = 0.05; t < o.R.fin; t += 0.05) {
      const s = G3D._simuler(t);
      if (s.balle && (Math.abs(s.balle.x) > W / 2 + 4 || Math.abs(s.balle.z) > HL + 7 || s.balle.y < -0.01)) cas.hors++;
      for (const j of s.J) if (Math.abs(j.x) > W / 2 + 2.5 || Math.abs(j.z) > HL + 4) cas.joueurs_hors++;
      if (!s.poses.every(finie)) out.poses_finies = false;
    }
    for (const v of o.R.vols) { if (v.type === 'service') out.coups.service++; if (v.cd === true) out.coups.cd++; if (v.cd === false) out.coups.rv++; }
    out.cas.push(cas);
  }
}
console.log(JSON.stringify(out));
"""

RENDU = r"""
import asyncio, sys, json
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch(args=['--no-sandbox', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'], **({'executable_path': sys.argv[2]} if sys.argv[2] else {}))
        pg = await b.new_page(viewport={'width': 400, 'height': 260})
        erreurs = []; pg.on('pageerror', lambda e: erreurs.append(str(e)))
        await pg.set_content('<div id="h" style="width:400px"></div><style>.g3d-cv{display:block;width:100%;aspect-ratio:16/10}</style>')
        await pg.add_script_tag(content=open(sys.argv[1], encoding='utf-8').read())
        res = await pg.evaluate('''() => { window.requestAnimationFrame = () => 0;
          const r = {inverse:false, x:{serveur:'home', score_home:{sets:[6,3], point:'30'}, score_away:{sets:[4,2], point:'15'}}};
          if (!G3D.monter(document.getElementById('h'), {home:'A Un', away:'B Deux', surface:'Grass'}, r, false)) return null;
          G3D._image(1.5);
          const c = document.querySelector('.g3d-cv'), gl = c.getContext('webgl2'), px = new Uint8Array(4 * 64);
          const couleurs = new Set();
          for (let k = 0; k < 64; k++) { gl.readPixels(Math.floor(c.width * (k % 8 + .5) / 8), Math.floor(c.height * (Math.floor(k / 8) + .5) / 8), 1, 1, gl.RGBA, gl.UNSIGNED_BYTE, px.subarray(k * 4)); couleurs.add(px.slice(k * 4, k * 4 + 3).join(',')); }
          return { couleurs: couleurs.size, tableau: document.querySelector('.g3d-tab').textContent }; }''')
        print(json.dumps({'res': res, 'erreurs': erreurs}))
        await b.close()
asyncio.run(main())
"""


@unittest.skipUnless(shutil.which('node'), 'node absent')
class MoteurWebGL(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        with tempfile.NamedTemporaryFile('w', suffix='.js', delete=False, encoding='utf-8') as f:
            f.write(SCENARIO)
        cls.S = json.loads(subprocess.run(['node', f.name, str(RACINE / 'algo' / 'index.html')], capture_output=True, text=True, check=True).stdout)

    def test_serveur_cote_et_service(self):
        attendus = [(0, True), (0, False), (1, False), (1, False), (0, False)]
        for k, (srv, droite) in enumerate(attendus):
            for c in self.S['cas'][k * 30:(k + 1) * 30]:
                self.assertEqual((c['srv'], c['droite'], c['qui']), (srv, droite, srv))
                sens = 1 if srv == 0 else -1
                self.assertTrue(0 < c['cible'][1] * sens < 6.40)                    # dans le carré adverse
                self.assertLess(c['depart'][0] * c['cible'][0], 0)                  # en diagonale
                self.assertEqual(c['depart'][0] * -sens > 0, droite)                # égalité à droite, avantage à gauche

    def test_echanges_et_poses(self):
        for c in self.S['cas']:
            self.assertEqual(c['hors'], 0)
            self.assertEqual(c['joueurs_hors'], 0)
        self.assertTrue(self.S['poses_finies'])
        self.assertGreater(self.S['coups']['cd'], 20)                               # coups droits et revers
        self.assertGreater(self.S['coups']['rv'], 20)

    def test_rien_ne_vient_d_ailleurs(self):
        for motif in ('http', 'fetch(', 'import(', 'XMLHttpRequest', '.glb', 'new Image', 'src='):
            self.assertNotIn(motif, BLOC)
        for mot in ('marché', 'pinnacle'):
            self.assertNotIn(mot, BLOC.lower())
        self.assertIn('G3D.monter(h3, m, r, fini) && !T3D.monter(h3, m, r, fini)', HTML)   # repli sur la 3D simple

    def test_page_valide(self):
        for js in re.findall(r'<script>([\s\S]*?)</script>', HTML):
            with tempfile.NamedTemporaryFile('w', suffix='.js', delete=False, encoding='utf-8') as f:
                f.write(js)
            subprocess.run(['node', '--check', f.name], check=True)

    def test_rendu_webgl(self):
        try:
            import playwright  # noqa: F401
        except ImportError:
            self.skipTest('playwright absent')
        with tempfile.TemporaryDirectory() as d:
            js = Path(d, 'g3d.js')
            js.write_text("function court(n){const p=String(n).trim().split(/\\s+/);return p.length>1?p.slice(1).join(' '):n}\nfunction esc(x){return String(x)}\n"
                          + BLOC.replace('const G3D =', 'window.G3D ='), encoding='utf-8')
            py = Path(d, 'r.py'); py.write_text(RENDU, encoding='utf-8')
            chrome = shutil.which('google-chrome') or ''
            try:
                r = subprocess.run(['python3', str(py), str(js), chrome], capture_output=True, text=True, timeout=120)
            except subprocess.TimeoutExpired:
                self.skipTest('navigateur trop lent')
            if r.returncode != 0:
                self.skipTest('navigateur indisponible : ' + r.stderr[-200:])
            o = json.loads(r.stdout.strip().splitlines()[-1])
        self.assertEqual(o['erreurs'], [])
        if o['res'] is None:
            self.skipTest('WebGL 2 indisponible dans ce navigateur')
        self.assertGreater(o['res']['couleurs'], 20)                                # une vraie image, pas un aplat
        self.assertIn('Un', o['res']['tableau'])


if __name__ == '__main__':
    unittest.main()
