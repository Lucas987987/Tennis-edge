"""Essai GPU (paquet 299, 19/11/2026, Lucas : « Si tout est gratuit et que l'on fait un vrai bond de qualité, on y
va »). Un point de la vidéo du jour est exporté du moteur 3D du site (mouvements exacts) puis rendu par Blender sur une
carte graphique louée chez Modal ; tout part sur le Telegram privé. L'export du moteur ne s'active qu'avec ?export3d=1."""
import json
import math
import py_compile
import sys
import unittest
from pathlib import Path

import numpy as np

RACINE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(RACINE / 'scripts'))
import film_scene as FS  # noqa: E402

HTML = (RACINE / 'algo' / 'index.html').read_text(encoding='utf-8')
BLOC = HTML[HTML.index('const G3D = (() => {'):HTML.index('// Vue du direct choisie par le visiteur')]
YML = (RACINE / '.github' / 'workflows' / 'essai_gpu.yml').read_text(encoding='utf-8')
SCRIPTS = {n: (RACINE / 'scripts' / n).read_text(encoding='utf-8')
           for n in ('film_export.py', 'film_scene.py', 'blender_film.py', 'modal_rendu.py')}


class CaptureDuMoteur(unittest.TestCase):
    def test_inactive_sans_parametre(self):
        self.assertIn("/[?&]video=1(&|$)/.test(location.search) && /[?&]export3d=1(&|$)/.test(location.search)", BLOC)
        self.assertIn('const captM = (o, d) => { if (CAPT.actif)', BLOC)
        self.assertIn('if (CAPT.actif) { t.__cid = ++CAPT.nt;', BLOC)
        self.assertIn('if (CAPT.actif) CAPT.image = {', BLOC)
        self.assertIn("if (Q.get('export3d') === '1') window.__G3D = G3D;", HTML)
        self.assertIn("const VERSION_3D = 'v323';", BLOC)

    def test_api(self):
        for k in ('_export: {', 'image: () => CAPT.image', 'scene() {', 'maillage(id) {', 'texture(id) {', 'cadre:'):
            self.assertIn(k, BLOC)

    def test_rien_d_interdit_dans_le_moteur(self):
        ajout = BLOC[BLOC.index('// paquet 299 : export de la scène'):BLOC.index('function maillage(g, inst)')]
        for mot in ('march', 'cote', 'pinnacle'):
            self.assertNotIn(mot, ajout.lower())


class Calculs(unittest.TestCase):
    def test_repere(self):
        np.testing.assert_allclose(FS.vers_blender([[1, 2, 3]])[0], [1, -3, 2])
        self.assertAlmostEqual(np.linalg.det(FS.C3), 1.0)

    def test_camera_vise_la_cible(self):
        eye, cible = [3, 6, -20], [0, 0.5, 0]
        M = FS.camera(eye, cible)
        uv, z = FS.projeter(M, 0.6, 0.93, FS.vers_blender([cible]))
        np.testing.assert_allclose(uv[0], [0.5, 0.5], atol=1e-9)
        self.assertGreater(z[0], 0)
        uv, _ = FS.projeter(M, 0.6, 0.93, FS.vers_blender([[0, 6.5, 0]]))
        self.assertLess(uv[0][1], 0.5)                                      # plus haut dans le monde = plus haut à l'image

    def test_deformation(self):
        p = np.array([[0.1, 1.0, 0.0], [0.0, 1.5, 0.2]], dtype=np.float32)
        b = np.zeros((2, 4), dtype=np.uint8)
        w = np.array([[1, 0, 0, 0]] * 2, dtype=np.float32)
        S = np.tile(np.eye(4), (24, 1, 1))
        S[0, :3, 3] = [2, 0, -1]
        np.testing.assert_allclose(FS.deformer(p, b, w, S), p + [2, 0, -1], atol=1e-6)
        np.testing.assert_allclose(FS.deformer_normales(np.array([[0, 0, 2.0]]), b[:1], w[:1], S), [[0, 0, 1]])

    def test_regle_des_tenues_identique_au_shader(self):
        rng = np.random.default_rng(7)
        n = 4000
        x, y, z = rng.uniform(-0.5, 0.5, n), rng.uniform(0, 1.9, n), rng.uniform(-0.25, 0.2, n)
        cls = rng.uniform(0, 7, n)
        for t0x, t0y in ((0.6, 1.752), (0.66, 1.705)):
            k1 = FS.classe_tenue(FS.NP(), x, y, z, cls, t0x, t0y)
            k2 = FS.classe_reference(x, y, z, cls, t0x, t0y)
            self.assertTrue(np.array_equal(k1.astype(int), k2))
        self.assertGreater(len(set(k2)), 5)

    def test_public_tourne_vers_la_camera(self):
        base = {'p': np.array([[-0.2, 0, 0], [0.2, 0, 0], [0.2, 1, 0], [-0.2, 1, 0]], dtype=np.float32),
                'u': np.array([[0, 1], [1, 1], [1, 0], [0, 0]], dtype=np.float32), 'i': np.array([[0, 1, 2], [0, 2, 3]])}
        inst = {'pos': np.array([[10, 2, 0, 1.0]], dtype=np.float32), 'col': np.array([[1, 0, 0]], dtype=np.float32)}
        pts, uv, col = FS.public(base, inst, [0, 2, 0], 0, 0, 0)
        largeur = pts[1] - pts[0]
        self.assertAlmostEqual(float(largeur[0]), 0.0, places=6)        # le panneau est face à l'œil (axe x)
        self.assertTrue(np.all((uv[:, 0] >= 0) & (uv[:, 0] <= 1)))
        self.assertEqual(FS.indices_public(base, 3).max(), 11)

    def test_cout(self):
        h = FS.duree_estimee(2.0)
        self.assertAlmostEqual(h, (2.0 * 1875 + 180) / 3600)
        self.assertAlmostEqual(FS.cout_mensuel(1.0, 1, 1.0), 30.0)


class Workflow(unittest.TestCase):
    def test_a_la_main_seulement(self):
        self.assertIn('workflow_dispatch:', YML)
        self.assertNotIn('schedule:', YML)
        self.assertIn('contents: read', YML)
        self.assertIn('concurrency:', YML)

    def test_rien_de_public(self):
        self.assertNotIn('upload-artifact', YML)
        self.assertNotIn('git push', YML)
        self.assertIn('${{ secrets.TELEGRAM_CHAT_ID }}', YML)
        for s in ('MODAL_TOKEN_ID', 'MODAL_TOKEN_SECRET'):
            self.assertIn('${{ secrets.%s }}' % s, YML)
            self.assertNotIn('echo "${%s}' % s, YML)                       # jamais affiché

    def test_regle_ecrite_avant(self):
        self.assertIn('RÈGLE DE DÉCISION, écrite avant', YML)
        self.assertIn('NETTEMENT meilleur', YML)
        self.assertIn('24 $/mois pour 30 $ de crédits', YML)

    def test_enchainement(self):
        self.assertIn('python scripts/film_export.py --point', YML)
        self.assertIn('modal run scripts/modal_rendu.py', YML)
        self.assertIn('hstack=inputs=2', YML)
        self.assertIn('"modal>=1.0,<2"', YML)


class Scripts(unittest.TestCase):
    def test_compilent(self):
        for n in SCRIPTS:
            py_compile.compile(str(RACINE / 'scripts' / n), doraise=True)

    def test_garde_fous_de_cout(self):
        M = SCRIPTS['modal_rendu.py']
        self.assertIn('DUREE_MAX_S = 45 * 60', M)
        self.assertIn('IMAGES_MAX = 400', M)
        self.assertIn('max_containers=1', M)
        self.assertIn("'T4': 0.59, 'L4': 0.80, 'A10G': 1.10", M)

    def test_blender(self):
        B = SCRIPTS['blender_film.py']
        for k in ("for typ in ('OPTIX', 'CUDA')", 'exposition_auto', 'use_motion_blur = True', 'dof.use_dof',
                  "'Coat Weight'", 'FS.classe_tenue(B,', 'normals_split_custom_set_from_vertices'):
            self.assertIn(k, B)

    def test_mots_interdits(self):
        for n, s in SCRIPTS.items():
            for mot in ('march', 'pinnacle', 'workers.dev', 'github.io'):
                self.assertNotIn(mot, s.lower(), n)
            self.assertNotIn('cote', s.lower(), n)

    def test_export_sans_habillage(self):
        E = SCRIPTS['film_export.py']
        self.assertIn(".film > :not(.f3-hote) { visibility: hidden !important; }", E)
        self.assertIn('clip=clip', E)
        self.assertIn('export3d=1', E)


class Rapport(unittest.TestCase):
    def test_public(self):
        d = json.loads((RACINE / 'simulateur' / 'rapport_essai_gpu.json').read_text(encoding='utf-8'))
        self.assertEqual(d['paquet'], 299)
        self.assertIn('regle_decision', d)
        self.assertIn('le % ne change pas', d['note'])
        texte = json.dumps(d, ensure_ascii=False).lower()
        for mot in ('march', 'cote', 'pinnacle'):
            self.assertNotIn(mot, texte)


if __name__ == '__main__':
    unittest.main()
