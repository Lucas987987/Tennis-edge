#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
validation_report.py — Tableau de validation FORWARD du steam-following.

Lit les journaux paper_trades_*.jsonl et dit, avec des INTERVALLES DE CONFIANCE,
si l'edge est prouve ou pas (et combien de paris il reste a accumuler). C'est le
juge objectif : tant que les bornes basses n'excluent pas 0 (ROI) ou 50% (%CLV+),
l'edge n'est PAS confirme, quel que soit le point estime.

Pour chaque surface (match/set1/set2) et par book :
  - CLV vs cloture : mediane, moyenne, %positif + IC95 (Wilson)
  - ROI reel : moyenne/mise + IC95 | taux de reussite + IC95 (Wilson)
  - verdict CLV / ROI + taille d'echantillon estimee pour la significativite
  - tendance (cumul) premiers vs derniers paris

Env : JOURNALS (glob, def 'paper_trades_*.jsonl'). Aucune dependance externe.
"""
import contextlib
import io
import math
import os
import json, sys, glob, json, csv, math, datetime, random, statistics as st
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import oddspapi_v5 as ov
import match_key as mk


def _hist_sources():
    """Sources historiques a scanner : partitions mensuelles VERSIONNÉES
    uniquement -- book_curves.jsonl (monolithique) a ete retire le 14/08/2026
    (140,73 Mo -> GitHub rejetait tout push > 100 Mo) et remplace par
    parts/hist_book_<YYYY-MM>.jsonl -- voir migrate_hist_partitions.py.

    CORRIGÉ LE 27/08/2026 (audit v3 §R) : book_curves_live.jsonl (gitignore,
    reconstruit à chaque cycle, purgé à 5 jours de recul) faisait partie de
    cette liste -- le n de chaque hypothèse variait alors d'un facteur 2 à 9
    selon l'heure du run (mesuré : "ouverture précoce" 75 avec le fichier
    présent, 34 sans). Or N_CIBLE gèle un verdict DÉFINITIVEMENT dès que
    n>=100 : si n dépend d'un fichier éphémère, le MOMENT du gel -- donc le
    k/n figé pour toujours -- dépend de l'heure à laquelle le run est tombé.
    Ce fichier ne sert plus qu'aux alertes temps réel (steam_alert), jamais
    aux verdicts gelés : un n reproductible est une précondition d'un gel
    qui a du sens."""
    # ov.hist_partitions() couvre .jsonl ET .jsonl.gz : depuis la compression
    # du 16/08/2026 un glob sur '*.jsonl' seul ne renvoie plus rien, et les
    # scripts sautant les fichiers absents perdaient TOUT l'historique en
    # silence. Les chemins sont renvoyés sans suffixe .gz, ov.open_any() résout.
    return ov.hist_partitions('book')

JOURNALS = os.environ.get('JOURNALS', 'paper_trades_*.jsonl')
Z = 1.96  # 95%


def _ecart_type(valeurs):
    """Écart-type de population, sans dépendance externe.

    Sert à l'intervalle du ROI. AJOUTÉ LE 25/09/2026 avec le passage au
    ROI réel : l'ancien affichage « ROI implicite » ne donnait aucun
    intervalle, ce qui laissait croire à une précision qu'il n'avait pas.
    """
    n = len(valeurs)
    if n < 2:
        return 0.0
    m = sum(valeurs) / n
    return (sum((v - m) ** 2 for v in valeurs) / n) ** 0.5


def wilson(k, n):
    """IC95 de Wilson pour une proportion (k succes sur n)."""
    if n == 0:
        return (0.0, 0.0, 0.0)
    p = k / n
    d = 1 + Z * Z / n
    c = (p + Z * Z / (2 * n)) / d
    h = Z * math.sqrt(p * (1 - p) / n + Z * Z / (4 * n * n)) / d
    return (p, max(0, c - h), min(1, c + h))


def mean_ci(xs, bootstrap=True, n_boot=3000, graine=1234567):
    """IC95 de la moyenne.

    CORRIGÉ LE 27/08/2026 (audit §3.4), deux défauts cumulés :
    1. pstdev() (écart-type de POPULATION) sous-estimait l'écart-type
       d'échantillon d'un facteur sqrt(n/(n-1)) -- 3,4 % d'erreur à n=30 ;
       remplacé par stdev() (non biaisé).
    2. L'approximation normale donne des IC trop ÉTROITS quand la
       distribution est asymétrique/bimodale -- exactement le profil d'un
       P&L de pari (-1 ou +cote-1, cote moyenne ~2,9) à n<100, le régime où
       ce dispositif se trouve. Le bootstrap percentile (3000 tirages,
       graine FIXE pour la reproductibilité -- deux lectures du même
       fichier doivent donner le même IC) n'a besoin d'aucune hypothèse de
       forme. Défaut : bootstrap=True. Repli sur l'approximation normale UNIQUEMENT
       si bootstrap=False ou n<8 (le bootstrap n'est pas fiable en dessous).
    """
    n = len(xs)
    if n < 2:
        return (xs[0] if xs else 0.0, None, None, 0.0)
    m = st.mean(xs)
    s = st.stdev(xs)
    if not bootstrap or n < 8:
        half = Z * s / math.sqrt(n)
        return (m, m - half, m + half, s)
    rng = random.Random(graine)
    moyennes = []
    for _ in range(n_boot):
        tirage = [xs[rng.randrange(n)] for _ in range(n)]
        moyennes.append(sum(tirage) / n)
    moyennes.sort()
    lo = moyennes[int(0.025 * n_boot)]
    hi = moyennes[int(0.975 * n_boot) - 1]
    return (m, lo, hi, s)


def n_needed(mean, s):
    """Taille d'echantillon estimee pour que l'IC95 de la moyenne exclue 0.

    ORDRE DE GRANDEUR SEULEMENT (audit §3.4) : calcul de puissance POST-HOC
    à partir de la moyenne OBSERVÉE -- répond « combien faudrait-il si
    l'effet observé était le vrai effet », optimiste par construction quand
    l'effet observé n'est pas significatif. À afficher comme repère, jamais
    comme objectif à atteindre.
    """
    if not mean or s == 0:
        return None
    return int(math.ceil((Z * s / abs(mean)) ** 2))


def report_group(name, trades):
    settled = [t for t in trades if t.get('status') == 'SETTLED']
    opens = [t for t in trades if t.get('status') == 'OPEN']
    print(f"\n{'='*60}\n{name}  —  {len(settled)} denoues | {len(opens)} ouverts")
    if not settled:
        print("  (pas encore de pari denoue — rien a juger)"); return

    clv = [t['clv_book'] for t in settled if 'clv_book' in t]
    # CORRIGÉ LE 27/08/2026 (audit v3 §Q) : clv_pin n'est PAS un CLV -- même
    # formule à l'entrée (le filtre EV_MIN_NOW de pick_signal) et à la
    # clôture, corrélation quasi mécanique. Mesuré par l'audit :
    # corr(clv_pin, pnl)=+0,178 sur n=45, %positif à 100% (la signature d'une
    # métrique qui reproduit son propre critère de sélection). Gardé au
    # rapport mais RELABÉLISÉ honnêtement, jamais présenté comme un CLV.
    clv_pin = [t['clv_pin'] for t in settled if 'clv_pin' in t]
    # AJOUTÉ (audit v3 §Q) : le VRAI test du biais de sélection -- contre le
    # book MÉDIAN parmi ceux actifs sur le match, pas contre Pinnacle.
    clv_median = [t['clv_vs_median'] for t in settled if 'clv_vs_median' in t]
    pnl = [t['pnl'] for t in settled if 'pnl' in t]
    won = [1 if t.get('won') else 0 for t in settled if 'won' in t]

    # CLV
    if clv:
        kpos = sum(1 for x in clv if x > 0)
        p, lo, hi = wilson(kpos, len(clv))
        verdict = ("✅ CONFIRME (>50%)" if lo > 0.50 else
                   "⚠ tendance +" if p > 0.50 else "❌ non positif")
        print(f"  CLV vs cloture book : mediane {st.median(clv):+.1f}% | moyenne {st.mean(clv):+.1f}% "
              f"| %positif {p*100:.0f}% (IC95 {lo*100:.0f}-{hi*100:.0f}%)  -> {verdict}")
    if clv_median:
        kpos = sum(1 for x in clv_median if x > 0)
        p, lo, hi = wilson(kpos, len(clv_median))
        print(f"  CLV vs book MEDIAN (test du biais de sélection) : mediane "
              f"{st.median(clv_median):+.1f}% | %positif {p*100:.0f}% "
              f"(IC95 {lo*100:.0f}-{hi*100:.0f}%)")
        if clv and abs(st.median(clv) - st.median(clv_median)) > 5:
            print(f"  ⚠️ écart >5 pts entre clôture book (max) et clôture "
                  f"médiane -- la mesure 'vs cloture book' peut être gonflée "
                  f"par la sélection du book (max sur ~20), pas par un edge réel.")
    if clv_pin:
        p_ = sum(1 for x in clv_pin if x > 0) / len(clv_pin)
        print(f"  EV au filtre d'entrée, relue à la clôture (PAS un CLV -- "
              f"même formule qu'à l'ouverture, corr. quasi mécanique) : "
              f"mediane {st.median(clv_pin):+.1f}% | %positif {p_*100:.0f}%")
    # ROI
    if pnl:
        m, lo, hi, s = mean_ci(pnl)
        roi = m * 100
        if lo is None:
            print(f"  ROI reel       : {roi:+.1f}%/mise (n trop faible pour IC)")
        else:
            sig = "✅ PROFIT CONFIRME (IC>0)" if lo > 0 else \
                  ("⚠ tendance + (IC inclut 0)" if m > 0 else "❌ non profitable")
            print(f"  ROI reel       : {roi:+.1f}%/mise (IC95 {lo*100:+.1f}..{hi*100:+.1f}%)  -> {sig}")
            if lo <= 0 < m:
                nn = n_needed(m, s)
                if nn:
                    print(f"                   ordre de grandeur (optimiste, non un objectif) : "
                          f"~{nn} paris pour confirmer SI l'effet observé est le vrai effet "
                          f"(actuel {len(pnl)})")
    # win rate
    if won:
        p, lo, hi = wilson(sum(won), len(won))
        print(f"  Reussite       : {p*100:.0f}% (IC95 {lo*100:.0f}-{hi*100:.0f}%, n={len(won)})")
    # par book
    # CORRIGÉ LE 27/08/2026 (audit §3.6) : ce découpage n'est PAS dans la
    # famille Holm et n'importe quel run donnait un « meilleur book » lu à
    # tort comme un résultat (vu en test : leovegas n=2 -> ROI +137,5 %,
    # williamhill n=2 -> -20,5 %). Un book sous n=30 est affiché SANS ses
    # statistiques -- juste son effectif, pour qu'on voie qu'il accumule
    # sans jamais publier un chiffre invendable.
    books = sorted(set(t['book'] for t in settled if t.get('book')))
    if len(books) > 1:
        print("  -- par book (n>=30 seulement pour CLV/ROI -- audit §3.6) --")
        for b in books:
            sub = [t for t in settled if t.get('book') == b]
            if len(sub) < 30:
                print(f"     {b:10} n={len(sub):3d} — sous 30, en accumulation")
                continue
            c = [t['clv_book'] for t in sub if 'clv_book' in t]
            pl = [t['pnl'] for t in sub if 'pnl' in t]
            cm = f"{st.median(c):+.1f}%" if c else "n/a"
            rm = f"{100*st.mean(pl):+.1f}%" if pl else "n/a"
            print(f"     {b:10} n={len(sub):3d} | CLV med {cm} | ROI {rm}")
    # tendance (cumul ROI : 1re moitie vs 2e)
    seq = [t['pnl'] for t in settled if 'pnl' in t]
    if len(seq) >= 6:
        half = len(seq) // 2
        r1, r2 = 100 * st.mean(seq[:half]), 100 * st.mean(seq[half:])
        fleche = "↗ s'ameliore" if r2 > r1 else "↘ se degrade" if r2 < r1 else "→ stable"
        print(f"  Tendance ROI   : 1re moitie {r1:+.1f}% -> 2e moitie {r2:+.1f}%  {fleche}")



# ── Suivi de l'hypothèse OUT-OF-SAMPLE "calibration 2,20-3,50" ────────────────
# Figée le 03/08/2026 après analyse : sur juin-août 2026 (n=925 matchs), les
# côtés clôturant 2,20-3,50 (Pinnacle, devig Shin) gagnaient +5,8 pts de plus
# que leur proba (z≈+2,7), miroir -5,1 sur les favoris 1,20-1,80. Hypothèses
# concurrentes : biais réel vs été à surprises vs artefact de fouille. Cette
# section suit le résidu mois par mois SUR LES NOUVELLES DONNÉES UNIQUEMENT :
# s'il retombe à ~0, c'était du bruit ; s'il persiste, on en reparle.
FREEZE_DATE = '2026-08-04'
FREEZE_DATE_MARGIN = '2026-08-09'
FREEZE_DATE_ROUND  = '2026-08-10'
FREEZE_DATE_BIGMOVE = '2026-08-10'
FREEZE_DATE_EARLYOPEN = '2026-08-13'  # hypothèse 'book ouvert avant Pinnacle' gelée ce jour
FREEZE_DATE_REINFORCE = '2026-08-14'  # hypothèse 'renforcement de l'outsider d'ouverture' gelée ce jour
FREEZE_DATE_REACTIVE = '2026-08-14'  # hypothèse 'book rapide en anomalie > book lent chronique' gelée ce jour
FREEZE_DATE_BETFAIR = '2026-08-16'  # hypothèse 'confirmation Betfair Exchange' gelée ce jour
FREEZE_DATE_MOVEAGE = '2026-08-16'  # hypothèse 'âge du mouvement à ampleur fixée (5%)' gelée ce jour
FREEZE_DATE_KXLEAD = '2026-09-05'   # hypothèse 'Kalshi mène Pinnacle (+45 min)' gelée ce jour
FREEZE_DATE_ROIBANDE = '2026-09-06'  # hypothèse 'ROI, bande de cote 2,0-3,0' gelée ce jour
# BANDE GELÉE — source de vérité UNIQUE.
# h13_signal.py (canal privé) et h13_recap.py (suivi quotidien) importent
# ces constantes plutôt que de les redéfinir. Sans ça, un COTE_MAX=3.5
# posé un jour "pour voir" ferait diverger silencieusement ce qu'on suit
# de ce qu'on valide — et rien ne le signalerait.
H13_COTE_MIN = 2.0
H13_COTE_MAX = 3.0

# REGELÉE LE 12/09/2026. Le gel du 07/09 portait sur `mag_cote_pct`, colonne
# alors calculée sur pin_close : le critère « mouvement > 5 % » n'était pas
# connaissable à l'instant du pari. Une hypothèse qu'aucun détecteur temps
# réel ne peut appliquer ne se valide pas -- même si elle sort à 87 % de
# CLV>0. Les chiffres fondateurs (A n=275 ROI +20,9 %, B et C) sont issus de
# cette colonne et ne sont PLUS des références, ni in-sample ni ailleurs.
#
# La règle est reprise à l'identique -- même seuil 5 %, même fenêtre 8-24 h,
# aucun paramètre retouché -- sur l'ampleur mesurée à la détection. Ne rien
# réoptimiser est délibéré : réajuster le seuil « pour retrouver le volume »
# rouvrirait l'espace de recherche que le gel du 07/09 avait fermé. Le volume
# baisse, c'est une conséquence de la correction, pas un choix.
#
# Mesuré sur l'historique avant regel (donc in-sample, cité comme repère et
# pas comme preuve) : la règle propre donne 71 % de CLV>0 [57 ; 82] contre
# 66 % [61 ; 71] pour le témoin -- IC recouvrants, pas de séparation.
FREEZE_DATE_AMPLI_V1 = '2026-09-07'  # gel INVALIDÉ (critère look-ahead)
FREEZE_DATE_AMPLI_V2 = '2026-09-12'  # gel INVALIDÉ lui aussi — voir ci-dessous
FREEZE_DATE_AMPLI = '2026-10-02'     # 3e gel : mag_cote_pct enfin causale
#
# POURQUOI UN TROISIÈME GEL
#
# Le gel du 12/09 corrigeait le look-ahead de `mag_proba_pts`. Il a OUBLIÉ
# `mag_cote_pct`, qui est pourtant le critère de H14 (`mag_cote_pct > 5`)
# et qui contenait toujours le raccourcissement jusqu'à la CLÔTURE.
#
# Mesuré le 02/10 sur 1 648 lignes, avant correction de move_audit :
#     corr(mag_cote_pct          ; amplitude de clôture) = +0,593
#     corr(mag_proba_pts         ; idem, causale)        = +0,213
#     corr(mag_proba_pts_POSTHOC ; idem, rétrospective)  = +0,716
#
# mag_cote_pct se rangeait du côté rétrospectif, et sa médiane (5,10)
# collait à l'amplitude de clôture (6,07) plutôt qu'à la détection (2,50).
#
# H14 selectionnait donc ses paris sur une grandeur inconnue au moment du
# pari. Les chiffres accumules depuis le 12/09 — in-sample +22,0 %,
# hors-echantillon -4,5 % — portent sur une population biaisee et ne
# valent rien. Le hors-echantillon ne corrige pas ce biais : il le
# partage.
#
# L'accumulation repart donc de zero. C'est le prix d'un critere qui
# n'etait pas causal, et c'est exactement ce que la methode est censee
# detecter — elle l'a fait, avec trois semaines de retard.
# STRATÉGIE A — paramètres gelés, source de vérité unique.
# Volontairement UN SEUL degré de liberté par dimension, et AUCUN filtre de
# cote : voir roi_ampli_watch() pour le raisonnement.
H14_MOVE_MIN_PCT = 5.0        # raccourcissement Pinnacle minimal, en %
H14_LEAD_MIN = 480.0          # 8 h avant le match
H14_LEAD_MAX = 1440.0         # 24 h avant le match

# BOOKS D'ENTRÉE — source de vérité UNIQUE, partagée par move_audit.py
# (qui produit moves_detail_hist.csv, donc la population jugée) et par
# h13_signal.py (qui envoie les alertes temps réel).
#
# POURQUOI ICI. Le 09/09, la config à 7 books a été posée en variable
# d'environnement sur la seule étape « Audit des moves » de
# steam_pipeline.yml. h13_signal.py vit dans courbes_alertes.yml : il serait
# resté à 3 books pendant que l'hypothèse se validait sur 7. Le détecteur
# temps réel et le juge auraient regardé deux populations différentes, sans
# qu'aucune erreur ne se déclenche.
#
# C'est le même défaut que pour la bande de cote, fermé le 06/09 en
# important H13_COTE_MIN/MAX depuis ce module. Deux variables
# d'environnement séparées finissent toujours par diverger ; une constante
# importée, non.
#
# CHOIX DES 7. Mesuré en rejouant move_audit sur tout l'historique (même
# détection, même règle, seul le book d'entrée change) :
#     3 books   n=1118  CLV +3,7 %  ROI +2,0 %  [-5,0 ; +8,9]
#     7 books   n=1126  CLV +4,3 %  ROI +2,7 %  [-4,4 ; +9,7]
# Le gain reste dans l'intervalle : ce n'est pas un edge, c'est un meilleur
# point d'entrée sur le même signal.
#
# Écartés volontairement :
#   1xbet, 22bet  non agréés en France — une marge basse sur un book où
#                 l'on ne peut pas jouer ne vaut rien.
#   coolbet       marge la PLUS BASSE de toutes (3,24 %) mais le CLV le plus
#                 FAIBLE du lot (+2,2 %), quand bet365 à 5,69 % de marge
#                 donne +7,7 %. Un book serré en permanence gagne souvent le
#                 « meilleur prix » sans jamais être en retard : il attire le
#                 détecteur sans apporter d'edge. La marge d'un book et la
#                 qualité de son signal sont deux choses différentes.
#   versions .fr  unibet.fr 11,6 %, winamax.fr 11,1 %, bet365.fr 10,2 % de
#                 marge, soit le double des versions internationales.
# AMENDEMENT DU 22/10/2026 (décision de Lucas) : leovegas retiré des books d'entrée, pour les
# alertes à venir. Effet passé négligeable : aucune ligne leovegas dans moves_detail_hist.csv
# (patcher_softs.py), 8 paris sur 249 dans le journal H13 (le meilleur prix passe au book suivant).
H14_SOFTS = ['unibet', 'bwin', 'betsson', 'bet365', '888sport',
             'betway']

FREEZE_DATE_H15 = '2026-09-25'
# BANDE DE COTE H15 — source de vérité unique, partagée avec h15_signal.py.
H15_COTE_MIN = 2.40
H15_COTE_MAX = 3.10

FREEZE_DATE_H16 = '2026-09-25'
# H16 — seuil sur le PRIX PINNACLE À L'OUVERTURE du côté steamé, pas sur
# la cote d'entrée. Les deux sont causaux, mais ce sont deux filtres
# différents : voir bande_favori_watch() pour pourquoi celui-ci.
H16_PIN_OPEN_MAX = 1.80

FREEZE_DATE_H17 = '2026-09-25'
# H17 — écart entre le prix d'ENTRÉE et le prix PINNACLE À L'OUVERTURE,
# en pourcentage. Strictement causal : les deux termes sont connus au
# moment du pari. NE PAS confondre avec clv_vs_pin_pct, qui utilise
# pin_close et n'existe qu'après le coup d'envoi.
H17_ECART_MIN = 0.0
H17_ECART_MAX = 3.0

FREEZE_DATE_H18 = '2026-09-27'
# H18 = intersection stricte de H16 et H17. Aucun seuil nouveau : les
# deux bornes viennent des hypothèses existantes.
FREEZE_DATE_H16B = '2026-09-27'
# H16-B = H16 privée des ultra-favoris. Le SEUL seuil ajouté est 1,30.
H16B_PIN_OPEN_MIN = 1.30
# Critère PRIMAIRE : CLV du groupe alerté vs groupe témoin.
# REQUALIFIÉ LE 27/08/2026 (audit §3.1) : un gel rétroactif n'est PAS un
# pré-enregistrement -- le 25/08, ce critère avait déjà été vu sur les
# données d'août, donc son statut « hors famille, jugé seul » n'était pas
# défendable. Choix retenu (2 options proposées par l'audit) : requalifié
# EXPLORATOIRE à partir d'aujourd'hui. Le résultat du test de contrôle
# d'août (+11,2 pts) reste une observation descriptive utile, mais n'est
# plus cité comme preuve confirmatoire tant qu'il n'est pas revalidé sur des
# données POSTÉRIEURES à cette date, avec un protocole écrit avant lecture.
# N_CIBLE : gel à un n PRÉ-ENREGISTRÉ, pas au premier franchissement du
# plancher (audit v2 §C, 27/08/2026). Le seuil maison n>=30 est un plancher
# de PUISSANCE MINIMALE, pas une cible -- geler dès qu'il est franchi fige
# le verdict au point où l'échantillon est le plus faible et jette toute
# l'information accumulée ensuite. Constaté sur "ouverture précoce" : gelé
# à n=34 le jour même du gel, alors que n=75 le lendemain matin -- le
# rapport affichait deux pourcentages contradictoires dans le même run
# (97,1 % gelé vs 88,0 % mesuré). 100 est un nombre rond, choisi maintenant,
# identique pour toutes les hypothèses -- pas un choix a posteriori par
# hypothèse (qui serait une resucée du même biais à un cran au-dessus).
N_CIBLE = 100

FREEZE_DATE_PRIMAIRE = '2026-08-27 (requalifié exploratoire, ex-hors-famille)'

def _shin_ph(oh, oa):
    ih, ia = 1/oh, 1/oa; ssum = ih + ia
    if ssum <= 1: return ih/ssum
    z = 0.02
    for _ in range(50):
        ph = (math.sqrt(z*z + 4*(1-z)*ih*ih/ssum) - z) / (2*(1-z))
        pa = (math.sqrt(z*z + 4*(1-z)*ia*ia/ssum) - z) / (2*(1-z))
        t = ph + pa
        if abs(t-1) < 1e-9: break
        z = min(max(z + (t-1), 0.0), 0.3)
    return ph/(ph+pa)

def calibration_watch():
    import datetime as _dtm
    def _d(x):
        try: return _dtm.datetime.fromisoformat(str(x).replace('Z','').replace('+00:00',''))
        except Exception: return None
    try:
        sr = json.load(open('set_results.json', encoding='utf-8'))
    except Exception:
        return
    sides = []
    seen = set()
    for src in _hist_sources():
        try:
            _f = ov.open_any(src)
        except FileNotFoundError:
            continue
        for line in _f:
            line = line.strip()
            if not line: continue
            try: c = json.loads(line)
            except Exception: continue
            if c.get('book') != 'pinnacle' or c.get('uid') in seen: continue
            ct = _d(c.get('commence_time'))
            if not ct or ct < _dtm.datetime.fromisoformat(FREEZE_DATE): continue   # OUT-OF-SAMPLE only
            res = (sr.get(c['uid']) or {}).get('match')
            if res not in ('home', 'away'): continue
            def _pre(seq):
                pts = [(_d(p[0]), p[1]) for p in (seq or []) if _d(p[0]) and p[1]]
                return sorted(x for x in pts if x[0] < ct)
            h, a = _pre(c.get('home_curve')), _pre(c.get('away_curve'))
            if len(h) < 3 or len(a) < 3: continue
            oh, oa = h[-1][1], a[-1][1]
            if min(oh, oa) <= 1: continue
            seen.add(c['uid'])
            ph = _shin_ph(oh, oa); hw = (res == 'home')
            sides.append((oh, ph, hw)); sides.append((oa, 1-ph, not hw))
    band = [(o, p, w) for o, p, w in sides if 2.20 <= o < 3.50]
    print(f"\n{'='*60}\nSUIVI HYPOTHÈSE — calibration cotes 2,20-3,50 (out-of-sample depuis {FREEZE_DATE})")
    if len(band) < 30:
        print(f"  n={len(band)} côtés — trop tôt pour juger (seuil 30). Référence gelée : +5,8 pts.")
        return
    wr = sum(1 for *_ , w in band if w) / len(band)
    ex = st.mean(p for _, p, _ in band)
    se = (wr*(1-wr)/len(band))**0.5
    verdict = "PERSISTE (à surveiller)" if (wr-ex) - 1.96*se > 0 else ("retombé -> bruit probable" if abs(wr-ex) < se else "indéterminé")
    print(f"  n={len(band)} | réel {100*wr:.1f}% vs attendu Shin {100*ex:.1f}% | résidu {100*(wr-ex):+.1f} pts (±{196*se:.0f}) -> {verdict}")
    print(f"  (référence in-sample juin-août: +5,8 pts ; si le résidu retombe ~0, c'était un été à surprises)")
    return sum(1 for *_, w in band if w), len(band), ex

def hour_watch():
    """Suivi OUT-OF-SAMPLE de l'hypothèse 'heure du match'. Constat in-sample
    (07/08/2026, n=729, sur tous les matchs jusqu'à FREEZE_DATE) : le côté
    steamé (celui vers qui Pinnacle se raccourcit) gagne plus souvent quand le
    match est tard dans la journée (Spearman heure~résultat = +0,204, le seul
    facteur testé -ampleur/durée/jour/tournoi- à dépasser le seuil de
    significativité). Hypothèse à un seul test parmi plusieurs -> à confirmer
    strictement out-of-sample avant d'y accorder du crédit (cf. calibration
    2,20-3,50 : même précaution)."""
    import datetime as _dtm
    def _d(x):
        try: return _dtm.datetime.fromisoformat(str(x).replace('Z','').replace('+00:00',''))
        except Exception: return None
    try:
        sr = json.load(open('set_results.json', encoding='utf-8'))
    except Exception:
        return
    rows, seen = [], set()
    for src in _hist_sources():
        try:
            _f = ov.open_any(src)
        except FileNotFoundError:
            continue
        for line in _f:
            line = line.strip()
            if not line: continue
            try: c = json.loads(line)
            except Exception: continue
            if c.get('book') != 'pinnacle' or c.get('uid') in seen: continue
            ct = _d(c.get('commence_time'))
            if not ct or ct < _dtm.datetime.fromisoformat(FREEZE_DATE): continue   # OUT-OF-SAMPLE only
            res = (sr.get(c['uid']) or {}).get('match')
            if res not in ('home', 'away'): continue
            def _pre(seq):
                pts = [(_d(p[0]), p[1]) for p in (seq or []) if _d(p[0]) and p[1]]
                return sorted(x for x in pts if x[0] < ct)
            h, a = _pre(c.get('home_curve')), _pre(c.get('away_curve'))
            if len(h) < 3 or len(a) < 3: continue
            oh0, oa0 = h[0][1], a[0][1]
            oh1, oa1 = h[-1][1], a[-1][1]
            if min(oh0, oa0, oh1, oa1) <= 1: continue
            seen.add(c['uid'])
            p0, p1 = _shin_ph(oh0, oa0), _shin_ph(oh1, oa1)
            steam_h = p1 > p0
            won = (res == 'home') if steam_h else (res == 'away')
            pfair = p1 if steam_h else 1 - p1
            rows.append((ct.hour, won, pfair))
    print(f"\n{'='*60}\nSUIVI HYPOTHÈSE — heure du match (out-of-sample depuis {FREEZE_DATE})")
    if len(rows) < 30:
        print(f"  n={len(rows)} matchs — trop tôt pour juger (seuil 30). "
              f"Référence in-sample : rho=+0.20 (heure tardive -> steamé gagne plus).")
        return
    late = [(w, p) for h, w, p in rows if h >= 18]
    early = [(w, p) for h, w, p in rows if h < 18]
    for label, grp in (('tard (>=18h)', late), ('tôt (<18h)', early)):
        if len(grp) < 10:
            print(f"  {label:14} n={len(grp)} (trop petit)"); continue
        wr = sum(1 for w, _ in grp if w) / len(grp)
        ex = st.mean(p for _, p in grp)
        se = (wr*(1-wr)/len(grp))**0.5
        print(f"  {label:14} n={len(grp):3} | réel {100*wr:.1f}% vs attendu {100*ex:.1f}% "
              f"| résidu {100*(wr-ex):+.1f} pts (±{196*se:.0f})")
    print(f"  (in-sample : le steamé gagnait davantage tard -> ici on vérifie si l'écart tard/tôt se confirme)")
    # p-value : « tard » bat-il son attendu Shin ? (proxy unilatéral du
    # différentiel tard/tôt — le test à 2 échantillons viendra si n grossit)
    if len(late) >= 30:
        return (sum(1 for w, _ in late if w), len(late),
                st.mean(p for _, p in late))


def margin_watch():
    """Suivi OUT-OF-SAMPLE de l'hypothèse 'variation de marge'. Constat in-sample
    (08/08/2026, n=37 écarts publiés) : quand la marge de l'opérateur signalé
    S'ÉLARGIT entre le signal et la clôture, l'écart s'est refermé dans 100% des
    cas (CLV médian +26,4%, n=7) contre 23% quand la marge reste stable
    (corrélation marge~CLV : r=+0,65).
    Lecture proposée : le book n'élargit pas symétriquement, il rabaisse le côté
    sur lequel il est exposé -> l'élargissement est la signature de la correction
    en cours, pas de la prudence.
    RÉSERVES : n=7 sur la cellule clé, et risque de circularité (la marge finale
    et le CLV sont tous deux mesurés à la clôture). D'où ce suivi strictement
    out-of-sample avant toute exploitation."""
    import datetime as _dtm
    def _d(x):
        try: return _dtm.datetime.fromisoformat(str(x).replace('Z','').replace('+00:00',''))
        except Exception: return None
    log = 'canal_public_log.jsonl'
    if not os.path.exists(log):
        return
    curves = {}
    for src in _hist_sources():
        try:
            _f = ov.open_any(src)
        except FileNotFoundError:
            continue
        for line in _f:
            line = line.strip()
            if not line: continue
            try: r = json.loads(line)
            except Exception: continue
            ct = _d(r.get('commence_time'))
            if not ct: continue
            def _pre(seq):
                pts = [(_d(p[0]), p[1]) for p in (seq or []) if _d(p[0]) and p[1] and p[1] > 1]
                return sorted(x for x in pts if x[0] < ct)
            h, a = _pre(r.get('home_curve')), _pre(r.get('away_curve'))
            if h and a:
                curves[(r.get('uid'), r.get('book'))] = (h, a,
                    r.get('home_team') or r.get('home'), ct)

    def _val(seq, t):
        v = None
        for tt, o in seq:
            if tt <= t: v = o
            else: break
        return v

    def _marge(h, a, t):
        oh, oa = _val(h, t), _val(a, t)
        return (1/oh + 1/oa) if (oh and oa and oh > 1 and oa > 1) else None

    groups = {'élargie': [], 'stable': [], 'resserrée': []}
    for line in open(log, encoding='utf-8'):
        line = line.strip()
        if not line: continue
        try: m = json.loads(line)
        except Exception: continue
        tsig = _d(m.get('t'))
        if not tsig or tsig < _dtm.datetime.fromisoformat(FREEZE_DATE_MARGIN):
            continue                                   # OUT-OF-SAMPLE only
        for entry in (m.get('retards') or []):
            try: book, prix = entry[0], float(entry[1])
            except Exception: continue
            key = (m.get('uid'), book)
            if key not in curves: continue
            h, a, home, ct = curves[key]
            joueur = (m.get('joueur') or '').strip()
            seq = h if (home and home.strip() == joueur) else a
            if not seq: continue
            close = seq[-1][1]
            ms, mc = _marge(h, a, tsig), _marge(h, a, ct)
            if not close or ms is None or mc is None: continue
            clv = (prix/close - 1) * 100
            d = (mc - ms) * 100
            key2 = 'élargie' if d > 0.5 else ('resserrée' if d < -0.5 else 'stable')
            groups[key2].append(clv)

    n_tot = sum(len(v) for v in groups.values())
    print("\n" + "=" * 60)
    print(f"SUIVI HYPOTHÈSE — variation de marge (out-of-sample depuis {FREEZE_DATE_MARGIN})")
    if n_tot < 30:
        print(f"  n={n_tot} écarts — trop tôt pour juger (seuil 30). "
              f"Référence in-sample : marge élargie -> 100% refermés (n=7), stable -> 23%.")
        return
    for lab in ('élargie', 'stable', 'resserrée'):
        g = groups[lab]
        if len(g) < 5:
            print(f"  marge {lab:10} n={len(g):3} (trop petit)"); continue
        pos = 100 * sum(1 for x in g if x > 0) / len(g)
        print(f"  marge {lab:10} n={len(g):3} | CLV médian {st.median(g):+6.1f}% | refermés {pos:3.0f}%")
    print("  (si 'élargie' ne se distingue plus de 'stable', l'effet était du bruit)")
    g = groups['élargie']
    if g:
        return sum(1 for x in g if x > 0), len(g), 'temoin'


def round_watch():
    """Suivi OUT-OF-SAMPLE de l'hypothèse 'phase de tournoi'. Constat in-sample
    (09/08/2026, n=84 écarts) : le CLV décroît quand le tournoi avance --
    premiers tours (>=16 matchs/jour) +16,0% et 100% refermés, contre
    demies/finale (<4 matchs/jour) +10,2% et 77% refermés. Gradient monotone.
    Lecture : les books tiennent mieux leurs prix sur les phases finales
    (plus de volume, plus d'attention) ; l'inattention du marché -- donc l'edge
    -- se concentre sur les premiers tours.
    Proxy du tour : nombre de matchs du MEME tournoi le MEME jour (32 matchs =
    premiers tours, 2 = demi-finales). Pas de champ 'round' dans l'API."""
    import datetime as _dtm
    from collections import defaultdict as _dd
    def _d(x):
        try: return _dtm.datetime.fromisoformat(str(x).replace('Z','').replace('+00:00',''))
        except Exception: return None
    log = 'canal_public_log.jsonl'
    if not os.path.exists(log):
        return
    # date + tournoi de chaque match, depuis les courbes
    meta, per_day = {}, _dd(set)
    for src in _hist_sources():
        try:
            _f = ov.open_any(src)
        except FileNotFoundError:
            continue
        for line in _f:
            line = line.strip()
            if not line: continue
            try: r = json.loads(line)
            except Exception: continue
            ct = _d(r.get('commence_time'))
            if not ct: continue
            uid = r.get('uid')
            meta[uid] = (r.get('tournament') or '', ct)
            per_day[(r.get('tournament') or '', ct.date())].add(uid)
    curves = {}
    for src in _hist_sources():
        try:
            _f = ov.open_any(src)
        except FileNotFoundError:
            continue
        for line in _f:
            line = line.strip()
            if not line: continue
            try: r = json.loads(line)
            except Exception: continue
            ct = _d(r.get('commence_time'))
            if not ct: continue
            def _pre(seq):
                pts = [(_d(x[0]), x[1]) for x in (seq or []) if _d(x[0]) and x[1] and x[1] > 1]
                return sorted(q for q in pts if q[0] < ct)
            h, a = _pre(r.get('home_curve')), _pre(r.get('away_curve'))
            if h and a:
                curves[(r.get('uid'), r.get('book'))] = (h, a,
                    r.get('home_team') or r.get('home'))
    buckets = {'premiers tours': [], 'milieu': [], 'phases finales': []}
    for line in open(log, encoding='utf-8'):
        line = line.strip()
        if not line: continue
        try: m = json.loads(line)
        except Exception: continue
        t = _d(m.get('t'))
        if not t or t < _dtm.datetime.fromisoformat(FREEZE_DATE_ROUND):
            continue                                    # OUT-OF-SAMPLE only
        uid = m.get('uid')
        if uid not in meta: continue
        tour, ct = meta[uid]
        nday = len(per_day[(tour, ct.date())])
        lab = ('premiers tours' if nday >= 16 else
               ('milieu' if nday >= 4 else 'phases finales'))
        for entry in (m.get('retards') or []):
            try: book, prix = entry[0], float(entry[1])
            except Exception: continue
            key = (uid, book)
            if key not in curves: continue
            h, a, home = curves[key]
            joueur = (m.get('joueur') or '').strip()
            seq = h if (home and home.strip() == joueur) else a
            if not seq: continue
            close = seq[-1][1]
            if close:
                buckets[lab].append((prix/close - 1) * 100)
    n_tot = sum(len(v) for v in buckets.values())
    print("\n" + "=" * 60)
    print(f"SUIVI HYPOTHÈSE — phase de tournoi (out-of-sample depuis {FREEZE_DATE_ROUND})")
    if n_tot < 30:
        print(f"  n={n_tot} écarts — trop tôt pour juger (seuil 30). Référence in-sample : "
              f"premiers tours +16,0% / 100% refermés, phases finales +10,2% / 77%.")
        return
    for lab in ('premiers tours', 'milieu', 'phases finales'):
        g = buckets[lab]
        if len(g) < 5:
            print(f"  {lab:16} n={len(g):3} (trop petit)"); continue
        pos = 100 * sum(1 for x in g if x > 0) / len(g)
        print(f"  {lab:16} n={len(g):3} | CLV médian {st.median(g):+6.1f}% | refermés {pos:3.0f}%")
    print("  (si le gradient premiers tours > phases finales disparaît, l'effet était du bruit)")
    g = buckets['premiers tours']
    if g:
        return sum(1 for x in g if x > 0), len(g), 'temoin'


def bigmove_watch():
    """Suivi OUT-OF-SAMPLE : un gros mouvement (>=15pts) SANS retard détecté au
    moment du signal a-t-il quand même de la valeur ? Constat in-sample
    (09/08/2026) : à ampleur égale 3-10pts, un retard détecté fait passer le
    CLV de +3,3% (sans) à +13,5% (avec) -- n=475. Sur les moves >=15pts,
    échantillon insuffisant pour trancher (n=0) : c'est précisément ce que ce
    suivi va combler avec les prochaines semaines de collecte.
    Cas déclencheur : Baez/Brooksby (04/08) -- move ~30pts, aucun retard
    détecté au moment du signal, donc non publiés sur le canal principal."""
    import datetime as _dtm
    def _d(x):
        try: return _dtm.datetime.fromisoformat(str(x).replace('Z','').replace('+00:00',''))
        except Exception: return None
    log = 'canal_public_log.jsonl'
    if not os.path.exists(log):
        return
    curves = {}
    for src in _hist_sources():
        try:
            _f = ov.open_any(src)
        except FileNotFoundError:
            continue
        for line in _f:
            line = line.strip()
            if not line: continue
            try: r = json.loads(line)
            except Exception: continue
            ct = _d(r.get('commence_time'))
            if not ct: continue
            def _pre(seq):
                pts = [(_d(x[0]), x[1]) for x in (seq or []) if _d(x[0]) and x[1] and x[1] > 1]
                return sorted(q for q in pts if q[0] < ct)
            h, a = _pre(r.get('home_curve')), _pre(r.get('away_curve'))
            if h and a:
                curves[(r.get('uid'), r.get('book'))] = (h, a,
                    r.get('home_team') or r.get('home'))
    buckets = {'grand mouvement, sans retard': [], 'grand mouvement, avec retard': []}
    for line in open(log, encoding='utf-8'):
        line = line.strip()
        if not line: continue
        try: m = json.loads(line)
        except Exception: continue
        t = _d(m.get('t'))
        if not t or t < _dtm.datetime.fromisoformat(FREEZE_DATE_BIGMOVE):
            continue                                    # OUT-OF-SAMPLE only
        mag_pts = abs(m.get('cote_ref_avant', 1) and
                     (1/m['cote_ref_apres'] - 1/m['cote_ref_avant'])) * 100 if m.get('cote_ref_apres') else 0
        if mag_pts < 15:
            continue                                    # seuil 'gros mouvement'
        lags = m.get('retards') or []
        lab = 'grand mouvement, avec retard' if lags else 'grand mouvement, sans retard'
        joueur = (m.get('joueur') or '').strip()
        uid = m.get('uid')
        # CLV du meilleur prix dispo (même sans retard >=5%, on veut voir ce qu'il y avait)
        best_book, best_price = None, None
        for b, (h, a, home) in curves.items():
            if b[0] != uid: continue
            seq = h if (home and home.strip() == joueur) else a
            if not seq: continue
            pr = seq[-1][1] if b[1] != 'pinnacle' else None   # ignore pinnacle lui-même
        # on utilise directement les retards loggés s'il y en a, sinon on ne peut
        # pas juger le CLV (aucun prix mou capté) -> on compte juste la fréquence
        if lags:
            book, prix = lags[0][0], float(lags[0][1])
            key = (uid, book)
            if key in curves:
                h, a, home = curves[key]
                seq = h if (home and home.strip() == joueur) else a
                if seq and seq[-1][1]:
                    buckets[lab].append((prix / seq[-1][1] - 1) * 100)
        else:
            buckets[lab].append(None)   # pas de prix mou loggé : fréquence seulement

    n_tot = sum(len(v) for v in buckets.values())
    print("\n" + "=" * 60)
    print(f"SUIVI HYPOTHÈSE — gros mouvement sans retard détecté (depuis {FREEZE_DATE_BIGMOVE})")
    if n_tot < 15:
        print(f"  n={n_tot} gros mouvements (>=15pts) — trop tôt pour juger (seuil 15). "
              f"Cas déclencheur : Baez/Brooksby, 0 retard détecté malgré ~30pts de move.")
        return
    for lab in buckets:
        g = [x for x in buckets[lab] if x is not None]
        n_all = len(buckets[lab])
        if g:
            pos = 100 * sum(1 for x in g if x > 0) / len(g)
            print(f"  {lab:32} n={n_all:3} (CLV mesurable sur {len(g)}) | "
                  f"CLV médian {st.median(g):+6.1f}% | refermés {pos:3.0f}%")
        else:
            print(f"  {lab:32} n={n_all:3} (aucun prix mou loggé pour mesurer le CLV)")
    g = [x for vals in buckets.values() for x in vals if x is not None]
    if g:
        return sum(1 for x in g if x > 0), len(g), 'temoin'


def earlyopen_watch():
    """Suivi OUT-OF-SAMPLE de l'hypothèse 'book ouvert avant Pinnacle' (voir
    scripts/early_open_signal.py pour le contexte complet). Constat IN-SAMPLE
    (1042 matchs, formulé le 13/08) : au moment où Pinnacle publie son 1er
    prix, un book déjà ouvert depuis des heures avec un écart >=5% a un CLV
    médian de +8,6% et se referme dans 81% des cas (n=144) -- mais le ROI
    reste non concluant (IC95 [-32%,+4%]).
    Source : early_open_log.jsonl (écrit par early_open_signal.py), qui
    contient déjà le prix signalé + le book -- il suffit de retrouver la
    clôture réelle du même book dans les courbes pour mesurer le CLV réalisé,
    exactement comme canal_clv.py le fait pour les écarts du canal public."""
    import datetime as _dtm
    log = 'early_open_log.jsonl'
    if not os.path.exists(log):
        return
    def _d(x):
        try: return _dtm.datetime.fromisoformat(str(x).replace('Z', '').replace('+00:00', ''))
        except Exception: return None

    closes = {}
    for src in _hist_sources():
        try:
            _f = ov.open_any(src)
        except FileNotFoundError:
            continue
        for line in _f:
            line = line.strip()
            if not line: continue
            try: r = json.loads(line)
            except Exception: continue
            ct = _d(r.get('commence_time'))
            if not ct: continue
            home = r.get('home_team') or r.get('home') or ''
            away = r.get('away_team') or r.get('away') or ''
            for key, name in (('home_curve', home), ('away_curve', away)):
                pts = [(_d(p[0]), p[1]) for p in (r.get(key) or []) if _d(p[0]) and p[1] and p[1] > 1]
                pts = sorted(p for p in pts if p[0] < ct)
                if pts and name:
                    closes[(r.get('uid'), r.get('book'), name)] = pts[-1][1]

    rows = []
    for line in open(log, encoding='utf-8'):
        line = line.strip()
        if not line: continue
        try: m = json.loads(line)
        except Exception: continue
        t = _d(m.get('t'))
        if not t or t < _dtm.datetime.fromisoformat(FREEZE_DATE_EARLYOPEN):
            continue                                    # OUT-OF-SAMPLE only
        joueur = m['home'] if m.get('side') == 'home' else m.get('away')
        cl = closes.get((m.get('uid'), m.get('book'), joueur))
        if cl:
            rows.append((m['price'] / cl - 1) * 100)

    print(f"\n{'='*60}")
    print(f"SUIVI HYPOTHÈSE — book ouvert avant Pinnacle (out-of-sample depuis {FREEZE_DATE_EARLYOPEN})")
    if len(rows) < 30:
        print(f"  n={len(rows)} signaux mesurables — trop tôt pour juger (seuil 30). "
              f"Référence in-sample : CLV médian +8,6%, 81% refermés (n=144).")
        return
    pos = 100 * sum(1 for x in rows if x > 0) / len(rows)
    print(f"  n={len(rows)} | CLV médian {st.median(rows):+.1f}% | refermés {pos:.0f}%")
    print("  (si ces chiffres tiennent près des références in-sample, l'hypothèse est confirmée ;")
    print("   s'ils s'effondrent vers 0%/50%, c'était du bruit -- comme la marge et l'heure du match)")
    return sum(1 for x in rows if x > 0), len(rows), 'temoin'


def reinforce_watch():
    """Suivi OUT-OF-SAMPLE de l'hypothèse 'renforcement de l'outsider
    d'ouverture'. Question testée : entre l'ouverture et la clôture Pinnacle,
    l'outsider d'ouverture a-t-il tendance à s'enfoncer encore, ou le marché
    corrige-t-il vers lui (l'écart d'ouverture était souvent trop large) ?

    Constat IN-SAMPLE (1040 matchs, formulé le 14/08) : sur les matchs avec
    mouvement net, l'outsider d'ouverture se RENFORCE (le marché corrige vers
    lui) dans 56,1% des cas -- z=-3,74, significatif -- avec un gradient net
    selon l'ampleur de l'écart d'ouverture : 49% (serré) -> 65% (écrasant).
    ATTENTION : ceci porte sur le MOUVEMENT DE PRIX, pas sur le résultat du
    match. Le ROI d'une stratégie 'miser l'outsider écrasant à l'ouverture'
    a été testé et est NON CONCLUANT (n=118, ROI -5,6% IC95[-48%,+37%]) --
    ce suivi ne sert donc qu'à confirmer/infirmer le mouvement de prix,
    jamais une recommandation de mise.

    Contrairement aux autres suivis (qui relisent les alertes publiées),
    celui-ci scanne TOUS les matchs (mouvement Pinnacle open->close),
    puisque la question porte sur le comportement général du marché, pas
    sur des écarts de retard spécifiques."""
    import datetime as _dtm
    def _d(x):
        try: return _dtm.datetime.fromisoformat(str(x).replace('Z', '').replace('+00:00', ''))
        except Exception: return None

    rows = []
    for src in _hist_sources():
        # CORRIGÉ LE 29/08/2026 (trouvé en construisant l'optimisation des
        # requêtes) : os.path.exists(src) + open(src) ignore SILENCIEUSEMENT
        # toute partition n'existant qu'en .gz -- vérifié, les 10 partitions
        # actuelles le sont TOUTES. Ce watcher lisait zéro donnée à chaque
        # appel, masqué par le gel de verdict (un verdict gelé n'est plus
        # jamais recalculé). ov.open_any() résout .gz comme les 8 autres
        # watchers le font déjà.
        try:
            _fsrc = ov.open_any(src)
        except FileNotFoundError:
            continue
        games = {}
        _recs = []
        for line in _fsrc:
            line = line.strip()
            if not line: continue
            try: r = json.loads(line)
            except Exception: continue
            ct = _d(r.get('commence_time'))
            if not ct or ct < _dtm.datetime.fromisoformat(FREEZE_DATE_REINFORCE):
                continue                                    # OUT-OF-SAMPLE only
            def pre(seq):
                pts = [(_d(p[0]), p[1]) for p in (seq or []) if _d(p[0]) and p[1] and p[1] > 1]
                return sorted(x for x in pts if x[0] < ct)
            h, a = pre(r.get('home_curve')), pre(r.get('away_curve'))
            if len(h) < 3 or len(a) < 3: continue
            _recs.append(r)
            g = games.setdefault(r['uid'], {})
            g[r['book']] = {'h': h, 'a': a}
        # DÉDUPLICATION CANONIQUE : deux conventions d'uid ont coexisté du 11/06
        # au 09/08/2026, et l'horaire annoncé bouge selon la source -> 208 uid
        # désignent un match DÉJÀ compté. Sans ça, n surévalué d'environ 10 %
        # sur juin-août et IC trop étroits. Voir match_key.py.
        _idx = mk.build_index(_recs)
        _vus = set()
        for uid, g in games.items():
            _k = _idx.key_of(uid)
            if _k in _vus:
                continue
            _vus.add(_k)
            pin = g.get('pinnacle')
            if not pin: continue
            p_open = _shin_ph(pin['h'][0][1], pin['a'][0][1])
            p_close = _shin_ph(pin['h'][-1][1], pin['a'][-1][1])
            delta = p_close - p_open
            if abs(delta) < 0.005: continue                # quasi-stable, ignoré
            fav_open_home = p_open > 0.5
            reinforced = (delta > 0) if fav_open_home else (delta < 0)
            gap_open = abs(p_open - 0.5) * 200
            rows.append((reinforced, gap_open))

    print("\n" + "=" * 60)
    print(f"SUIVI HYPOTHÈSE — renforcement de l'outsider d'ouverture (depuis {FREEZE_DATE_REINFORCE})")
    if len(rows) < 30:
        print(f"  n={len(rows)} matchs — trop tôt pour juger (seuil 30). "
              f"Référence in-sample : 56,1% global, gradient 49%->65% selon l'écart d'ouverture.")
        return
    n_reinf = sum(1 for r, _ in rows if r)
    pct = 100 * n_reinf / len(rows)
    print(f"  n={len(rows)} | outsider d'ouverture renforcé : {pct:.1f}% (référence 56,1%)")
    for lo, hi, lab in ((0, 15, 'serré'), (15, 35, 'modéré'), (35, 60, 'net'), (60, 200, 'écrasant')):
        g = [r for r, gp in rows if lo <= gp < hi]
        if len(g) >= 15:
            p = 100 * sum(1 for x in g if x) / len(g)
            print(f"    {lab:10} n={len(g):4} | renforcé {p:.0f}%")
    print("  (si le gradient disparaît ou repasse sous 50% partout, c'était du bruit)")
    # CORRIGÉ LE 27/08/2026 (audit v2 §D) : le commentaire du 25/08 disait
    # « hors famille, pas testable contre p0 témoin ni 0,5 » -- confusion
    # entre deux choses différentes. p0_temoin (le taux de base CLV>0) n'a
    # effectivement aucun sens ici, CE N'EST PAS UN CLV. Mais un événement
    # BINAIRE (renforcé / pas renforcé) a bien un null naturel à 50% par
    # symétrie -- exactement comme round ou marge, qui utilisent aussi 0,5
    # sans que ce soit leur "témoin CLV". Sans ce retour, reinforce_watch ne
    # pouvait JAMAIS entrer dans Holm : une réfutation à n=324 (52,2% contre
    # une référence in-sample de 56,1%) n'était jamais formellement actée.
    return n_reinf, len(rows), 0.5


def reactive_watch():
    """Suivi OUT-OF-SAMPLE de l'hypothèse 'book habituellement RAPIDE en
    anomalie > book habituellement LENT chronique'. Question testée : quand
    deux books affichent un écart ≥5%, celui qui est normalement réactif
    (score de fiabilité sous la médiane, voir book_reliability.py) referme-
    t-il mieux son écart que celui qui est structurellement lent ?

    Constat IN-SAMPLE (123 écarts, formulé le 14/08) : CONTRE-INTUITIF -- le
    book habituellement RAPIDE bat systématiquement le book habituellement
    LENT sur les 3 comparaisons testées (CLV +18,7% vs +9,1% à ampleur
    égale ; 92% vs 73% de refermeture). Hypothèse explicative : un book
    rapide qui montre un écart vit une vraie ANOMALIE ponctuelle (son
    système va "rattraper" son comportement habituel) ; un book lent qui
    montre un écart est peut-être juste dans son état normal (marge large
    en continu), donc rien ne le pousse à converger.
    RÉSERVE : direction cohérente sur 3 comparaisons indépendantes (pas une
    coïncidence isolée), mais échantillons individuels modestes (10 à 70).
    book_scores.json étant recalculé chaque nuit sur une fenêtre glissante
    de 45 jours, la médiane de référence évolue avec le temps -- c'est
    voulu, elle doit refléter l'état ACTUEL des books, pas un instantané figé."""
    import datetime as _dtm
    def _d(x):
        try: return _dtm.datetime.fromisoformat(str(x).replace('Z', '').replace('+00:00', ''))
        except Exception: return None
    log = 'canal_public_log.jsonl'
    scores_file = 'book_scores.json'
    if not os.path.exists(log) or not os.path.exists(scores_file):
        return
    try:
        with open(scores_file, encoding='utf-8') as f:
            scores = json.load(f).get('scores', {})
    except Exception:
        return
    reliab = {b: v.get('reliability_score', 0) for b, v in scores.items()}
    if len(reliab) < 4:
        return                                          # trop peu de books scorés pour un split médian utile
    med = st.median(reliab.values())

    curves = {}
    for src in _hist_sources():
        try:
            _f = ov.open_any(src)
        except FileNotFoundError:
            continue
        for line in _f:
            line = line.strip()
            if not line: continue
            try: r = json.loads(line)
            except Exception: continue
            ct = _d(r.get('commence_time'))
            if not ct: continue
            def _pre(seq):
                pts = [(_d(p[0]), p[1]) for p in (seq or []) if _d(p[0]) and p[1] and p[1] > 1]
                return sorted(x for x in pts if x[0] < ct)
            h, a = _pre(r.get('home_curve')), _pre(r.get('away_curve'))
            if h and a:
                curves[(r.get('uid'), r.get('book'))] = (h, a, r.get('home_team') or r.get('home'))

    groups = {'rapide (< médiane)': [], 'lent (>= médiane)': []}
    for line in open(log, encoding='utf-8'):
        line = line.strip()
        if not line: continue
        try: m = json.loads(line)
        except Exception: continue
        t = _d(m.get('t'))
        if not t or t < _dtm.datetime.fromisoformat(FREEZE_DATE_REACTIVE):
            continue                                    # OUT-OF-SAMPLE only
        joueur = (m.get('joueur') or '').strip()
        for entry in (m.get('retards') or []):
            try: book, prix = entry[0], float(entry[1])
            except Exception: continue
            if book not in reliab:
                continue                                # book pas encore scoré (trop peu d'historique)
            key = (m.get('uid'), book)
            if key not in curves: continue
            h, a, home = curves[key]
            seq = h if (home and home.strip() == joueur) else a
            if not seq: continue
            close = seq[-1][1]
            if not close: continue
            clv = (prix / close - 1) * 100
            lab = 'rapide (< médiane)' if reliab[book] < med else 'lent (>= médiane)'
            groups[lab].append(clv)

    n_tot = sum(len(v) for v in groups.values())
    print("\n" + "=" * 60)
    print(f"SUIVI HYPOTHÈSE — book rapide en anomalie vs book lent chronique (depuis {FREEZE_DATE_REACTIVE})")
    if n_tot < 30:
        print(f"  n={n_tot} écarts — trop tôt pour juger (seuil 30). Référence in-sample : "
              f"rapide +18,7%/92% refermés vs lent +9,1%/73% (à ampleur égale, 3-10pts).")
        return
    for lab in groups:
        g = groups[lab]
        if len(g) < 8:
            print(f"  {lab:20} n={len(g):3} (trop petit)"); continue
        pos = 100 * sum(1 for x in g if x > 0) / len(g)
        print(f"  {lab:20} n={len(g):3} | CLV médian {st.median(g):+6.1f}% | refermés {pos:3.0f}%")
    print("  (si 'rapide' ne bat plus 'lent', l'effet était du bruit malgré la cohérence in-sample)")
    g = [x for lab, vals in groups.items() if lab.startswith('rapide')
         for x in vals]
    if g:
        return sum(1 for x in g if x > 0), len(g), 'temoin'


def adaptive_threshold_watch():
    """9e hypothèse gelée : le seuil adaptatif par book (best_threshold(),
    steam_alert.py) est-il un vrai signal, ou en partie un artefact de
    sur-ajustement (data snooping) ? Une revue externe du projet (ChatGPT,
    15/08/2026) a identifié ce risque précis : le seuil est choisi en
    cherchant, sur 90 jours glissants, celui qui maximise le %CLV+ observé
    -- puis ce MÊME %CLV+ sert de preuve de performance affichée dans les
    alertes. C'est structurellement circulaire (une forme de data snooping).

    Ce suivi fige la sélection ACTUELLE (frozen_thresholds.json, écrit une
    fois par freeze_thresholds.py -- SANS TOUCHER au système en production,
    qui continue de se ré-optimiser en continu comme avant) et mesure, sur
    des matchs STRICTEMENT POSTÉRIEURS au gel, si le book continue de
    performer au niveau annoncé -- avec le MÊME seuil, jamais re-choisi.
    Si l'OOS s'effondre vers ~50%, c'était en partie du sur-ajustement.
    Si l'OOS tient, la méthode de sélection est validée.

    Réutilise DIRECTEMENT detect()/_at()/load_curves() de steam_alert.py
    (import, pas réimplémentation) pour garantir une fidélité totale à ce
    qui tourne réellement en production."""
    if not os.path.exists('frozen_thresholds.json'):
        print("\n" + "=" * 60)
        print("SUIVI HYPOTHÈSE — seuils adaptatifs gelés")
        print("  frozen_thresholds.json absent -- lancer freeze_thresholds.py une première fois.")
        return
    try:
        import steam_alert as sa
    except Exception as e:
        print(f"  ⚠️ impossible d'importer steam_alert.py : {e}")
        return
    try:
        frozen_all = json.load(open('frozen_thresholds.json', encoding='utf-8'))
    except Exception:
        return
    if not frozen_all:
        return
    _pool_adaptatif = []
    freeze = frozen_all[0]   # premier gel (walk-forward futur : historique complet dans le fichier)
    import datetime as _dtm
    try:
        frozen_at_ts = _dtm.datetime.fromisoformat(freeze['frozen_at']).replace(
            tzinfo=_dtm.timezone.utc).timestamp()
    except Exception as e:
        print(f"  ⚠️ frozen_at illisible : {e}")
        return

    print("\n" + "=" * 60)
    print(f"SUIVI HYPOTHÈSE — seuils adaptatifs gelés (out-of-sample depuis {freeze['frozen_at'][:10]})")

    MARKET_TRACK = {'match': 'book_curves.jsonl', 'set1': 'set1_curves.jsonl', 'set2': 'set2_curves.jsonl'}
    for market, frozen_books in freeze.get('markets', {}).items():
        if not frozen_books:
            continue
        track = sa.load_curves(MARKET_TRACK[market])
        oos_matches = {u: bk for u, bk in track.items()
                      if bk.get('_commence') and bk['_commence'] >= frozen_at_ts}
        print(f"\n  [{market}] {len(oos_matches)} matchs strictement postérieurs au gel")
        for sb, info in sorted(frozen_books.items()):
            thr = info['threshold']
            clvs = []
            for uid, bk in oos_matches.items():
                if sa.SHARP not in bk or sb not in bk:
                    continue
                d = sa.detect(bk[sa.SHARP], thr)
                if not d:
                    continue
                t_e, side = d
                commence = bk.get('_commence')
                if commence is not None and (commence - t_e) / 60.0 < sa.MIN_LEAD:
                    continue
                ser = bk[sb]['h'] if side == 'home' else bk[sb]['a']
                entry = sa._at(ser, t_e)
                if not entry or entry <= 1 or not ser:
                    continue
                close = ser[-1][1]
                if close and close > 1:
                    clvs.append((entry / close - 1) * 100)
            if len(clvs) < 10:
                print(f"    {sb:14} seuil {thr*100:.0f}pt | OOS n={len(clvs):2} — trop tôt "
                      f"(réf in-sample {info['in_sample_pct']}%, n={info['in_sample_n']})")
                continue
            oos_pct = round(100 * sum(1 for x in clvs if x > 0) / len(clvs))
            _pool_adaptatif.extend(clvs)
            oos_med = round(st.median(clvs), 1)
            drift = oos_pct - info['in_sample_pct']
            flag = (" ⚠ dégradation nette (sur-ajustement probable)" if drift <= -15
                    else (" ✅ tient" if drift >= -5 else " (à surveiller)"))
            print(f"    {sb:14} seuil {thr*100:.0f}pt | in-sample {info['in_sample_pct']}% "
                  f"(n={info['in_sample_n']}) -> OOS {oos_pct}% (n={len(clvs)}, méd {oos_med:+.1f}%){flag}")
    print("\n  (si la plupart des books s'effondrent vers ~50%, la sélection de seuil était")
    print("   en partie du sur-ajustement -- si ça tient, la méthode est validée)")
    if _pool_adaptatif:
        return (sum(1 for x in _pool_adaptatif if x > 0),
                len(_pool_adaptatif), 'temoin')


def betfair_confirm_watch():
    """10e hypothèse gelée : quand Betfair Exchange CONFIRME le mouvement
    Pinnacle (même sens, amplitude non-négligeable, sur la même fenêtre),
    l'écart détecté sur un book mou referme-t-il mieux qu'quand Betfair ne
    confirme pas ?

    Origine : axe n°4 d'une revue externe du projet (ChatGPT, 15/08/2026),
    qui proposait de distinguer "steam confirmé" / "steam suspect" /
    "mouvement épuisé" via plusieurs critères (dont la confirmation par
    Betfair). Testé isolément (les autres critères de la revue -- âge du
    mouvement, best vs médiane soft -- n'ont rien donné ou étaient
    contradictoires sur nos données).

    Constat IN-SAMPLE (32 signaux, formulé le 16/08/2026) : Betfair confirme
    -> CLV médian +11,4%, 95% refermés (n=22) ; ne confirme pas -> CLV
    médian +6,8%, 90% refermés (n=10). Cohérent sur les deux mesures à la
    fois (contrairement au test best-vs-médiane), mais IC95 des taux de
    refermeture qui se chevauchent largement [78-99%] vs [60-98%] --
    encore possiblement du bruit, à confirmer sur davantage de données.

    Réutilise DIRECTEMENT detect()/_fair()/_at() de steam_alert.py (import,
    pas réimplémentation) pour garantir la fidélité à la méthode déjà
    validée ailleurs dans ce fichier (adaptive_threshold_watch)."""
    try:
        import steam_alert as sa
    except Exception as e:
        print(f"  ⚠️ impossible d'importer steam_alert.py : {e}")
        return
    import datetime as _dtm

    def _ts(x):
        """Timestamp FLOTTANT (pas un objet datetime) -- convention de
        steam_alert.py (_dt() y renvoie .timestamp()). detect()/_fair()/_at()
        exigent ce format ; les mélanger avec des objets datetime casse les
        comparaisons/soustractions silencieusement ou avec une TypeError."""
        try:
            return _dtm.datetime.fromisoformat(
                str(x).replace('Z', '').replace('+00:00', '')).timestamp()
        except Exception:
            return None

    def val_at(seq, t):
        v = None
        for tt, o in seq:
            if tt <= t:
                v = o
            else:
                break
        return v

    freeze_ts = _ts(FREEZE_DATE_BETFAIR)
    games = {}
    _recs = []
    for src in _hist_sources():
        # CORRIGÉ LE 29/08/2026 (trouvé en construisant l'optimisation des
        # requêtes) : os.path.exists(src) + open(src) ignore SILENCIEUSEMENT
        # toute partition n'existant qu'en .gz -- vérifié, les 10 partitions
        # actuelles le sont TOUTES. Même correctif que reinforce_watch.
        try:
            _fsrc = ov.open_any(src)
        except FileNotFoundError:
            continue
        for line in _fsrc:
            line = line.strip()
            if not line:
                continue
            try:
                r = json.loads(line)
            except Exception:
                continue
            ct = _ts(r.get('commence_time'))
            if not ct or ct < freeze_ts:
                continue                                    # OUT-OF-SAMPLE only
            def pre(seq):
                pts = [(_ts(p[0]), p[1]) for p in (seq or []) if _ts(p[0]) and p[1] and p[1] > 1]
                return sorted(x for x in pts if x[0] < ct)
            h, a = pre(r.get('home_curve')), pre(r.get('away_curve'))
            if h and a:
                _recs.append(r)
                games.setdefault(r['uid'], {'_ct': ct})[r['book']] = {'h': h, 'a': a}

    rows = []
    # DÉDUPLICATION CANONIQUE : deux conventions d'uid ont coexisté du 11/06
    # au 09/08/2026, et l'horaire annoncé bouge selon la source -> 208 uid
    # désignent un match DÉJÀ compté. Sans ça, n surévalué d'environ 10 %
    # sur juin-août et IC trop étroits. Voir match_key.py.
    _idx = mk.build_index(_recs)
    _vus = set()
    for uid, bk in games.items():
        _k = _idx.key_of(uid)
        if _k in _vus:
            continue
        _vus.add(_k)
        if sa.SHARP not in bk or 'betfair-ex' not in bk:
            continue
        pin, bf = bk[sa.SHARP], bk['betfair-ex']
        commence = bk['_ct']
        d = sa.detect(pin, 0.03)
        if not d:
            continue
        t_e, side = d
        if (commence - t_e) / 60.0 < sa.MIN_LEAD:
            continue
        times = sorted(set(t for t, _ in pin['h']))
        f0, fe = sa._fair(pin, times[0]), sa._fair(pin, t_e)
        bf0, bfe = sa._fair(bf, times[0]), sa._fair(bf, t_e)
        if None in (f0, fe, bf0, bfe):
            continue
        pin_move, bf_move = fe - f0, bfe - bf0
        confirms = (pin_move * bf_move > 0) and abs(bf_move) >= 0.01

        fair = fe if side == 'home' else 1 - fe
        fair_odds = 1 / fair
        best = None
        for b, sb in bk.items():
            if b.startswith('_') or b in ('pinnacle', 'betfair-ex'):
                continue
            ser = sb['h'] if side == 'home' else sb['a']
            entry = val_at(ser, t_e)
            if not entry or entry <= 1 or not ser:
                continue
            close = ser[-1][1]
            if not close or close <= 1:
                continue
            gap = (entry / fair_odds - 1) * 100
            if gap >= 5 and (best is None or gap > best[0]):
                best = (gap, entry, close)
        if not best:
            continue
        clv = (best[1] / best[2] - 1) * 100
        rows.append((confirms, clv))

    print("\n" + "=" * 60)
    print(f"SUIVI HYPOTHÈSE — confirmation Betfair Exchange (depuis {FREEZE_DATE_BETFAIR})")
    if len(rows) < 30:
        print(f"  n={len(rows)} signaux — trop tôt pour juger (seuil 30). Référence in-sample : "
              f"confirme +11,4%/95% refermés (n=22) vs ne confirme pas +6,8%/90% (n=10).")
        return
    for label, cond in (('Betfair confirme', lambda r: r[0]), ('Betfair ne confirme pas', lambda r: not r[0])):
        g = [r[1] for r in rows if cond(r)]
        if len(g) < 8:
            print(f"  {label:24} n={len(g):3} (trop petit)")
            continue
        pos = 100 * sum(1 for x in g if x > 0) / len(g)
        print(f"  {label:24} n={len(g):3} | CLV médian {st.median(g):+6.1f}% | refermés {pos:3.0f}%")
    print("  (si 'confirme' ne bat plus 'ne confirme pas', c'était du bruit malgré la cohérence in-sample)")
    g = [r[1] for r in rows if r[0]]
    if g:
        return sum(1 for x in g if x > 0), len(g), 'temoin'


def move_age_watch():
    """11e hypothèse gelée : à AMPLITUDE FIXÉE (~5%, seuil de détection), le
    CLV varie-t-il selon l'ÂGE du mouvement (temps écoulé depuis son tout
    premier frémissement, pas depuis la détection elle-même) ?

    Origine : axe n°2 d'une revue externe du projet (ChatGPT, 15/08/2026).
    Un premier test (14/08, toutes amplitudes mélangées) n'avait montré
    AUCUN signal d'âge -- mais en FIXANT l'amplitude à 5% précisément
    (16/08), un vrai écart apparaît sur les deux extrêmes les mieux
    peuplés : mélanger les amplitudes masquait probablement un effet réel
    propre à ce palier.

    Constat IN-SAMPLE (221 signaux à ~5%, formulé le 16/08/2026) :
      <5min  (n=92) : CLV médian +11,4%, 88% refermés [80-93]
      >2h    (n=73) : CLV médian  +6,4%, 81% refermés [70-88]
    Les paliers intermédiaires (5-15min, 30-60min, n=10-19) ne suivent PAS
    un escalier propre -- trop peu de données pour leur faire confiance
    individuellement, seuls les deux extrêmes sont considérés fiables.

    Réutilise DIRECTEMENT detect()/_fair()/_at() de steam_alert.py (import,
    pas réimplémentation)."""
    try:
        import steam_alert as sa
    except Exception as e:
        print(f"  ⚠️ impossible d'importer steam_alert.py : {e}")
        return
    import datetime as _dtm

    def _ts(x):
        try:
            return _dtm.datetime.fromisoformat(
                str(x).replace('Z', '').replace('+00:00', '')).timestamp()
        except Exception:
            return None

    def val_at(seq, t):
        v = None
        for tt, o in seq:
            if tt <= t:
                v = o
            else:
                break
        return v

    AGE_BUCKETS = [(0, 5, '<5min'), (5, 15, '5-15min'), (15, 30, '15-30min'),
                   (30, 60, '30-60min'), (60, 120, '1-2h'), (120, 999999, '>2h')]

    def age_bucket(v):
        for lo, hi, lab in AGE_BUCKETS:
            if lo <= v < hi:
                return lab
        return None

    freeze_ts = _ts(FREEZE_DATE_MOVEAGE)
    games = {}
    _recs = []
    for src in _hist_sources():
        # CORRIGÉ LE 29/08/2026 (trouvé en construisant l'optimisation des
        # requêtes) : os.path.exists(src) + open(src) ignore SILENCIEUSEMENT
        # toute partition n'existant qu'en .gz -- vérifié, les 10 partitions
        # actuelles le sont TOUTES. Même correctif que reinforce_watch et
        # betfair_confirm_watch -- les 3 derniers watchers non alignés sur
        # ov.open_any(), maintenant tous les 11 le sont.
        try:
            _fsrc = ov.open_any(src)
        except FileNotFoundError:
            continue
        for line in _fsrc:
            line = line.strip()
            if not line:
                continue
            try:
                r = json.loads(line)
            except Exception:
                continue
            ct = _ts(r.get('commence_time'))
            if not ct or ct < freeze_ts:
                continue                                    # OUT-OF-SAMPLE only
            def pre(seq):
                pts = [(_ts(p[0]), p[1]) for p in (seq or []) if _ts(p[0]) and p[1] and p[1] > 1]
                return sorted(x for x in pts if x[0] < ct)
            h, a = pre(r.get('home_curve')), pre(r.get('away_curve'))
            if h and a:
                _recs.append(r)
                games.setdefault(r['uid'], {'_ct': ct})[r['book']] = {'h': h, 'a': a}

    rows = []
    # DÉDUPLICATION CANONIQUE : deux conventions d'uid ont coexisté du 11/06
    # au 09/08/2026, et l'horaire annoncé bouge selon la source -> 208 uid
    # désignent un match DÉJÀ compté. Sans ça, n surévalué d'environ 10 %
    # sur juin-août et IC trop étroits. Voir match_key.py.
    _idx = mk.build_index(_recs)
    _vus = set()
    for uid, bk in games.items():
        _k = _idx.key_of(uid)
        if _k in _vus:
            continue
        _vus.add(_k)
        if sa.SHARP not in bk:
            continue
        pin = bk[sa.SHARP]
        commence = bk['_ct']
        d5 = sa.detect(pin, 0.05)
        if not d5:
            continue
        t_5, side = d5
        if (commence - t_5) / 60.0 < sa.MIN_LEAD:
            continue
        d_start = sa.detect(pin, 0.005)
        if not d_start:
            continue
        t_start, side_start = d_start
        if side_start != side:
            continue
        age_min = (t_5 - t_start) / 60.0
        if age_min < 0:
            continue
        ab = age_bucket(age_min)
        if not ab:
            continue
        fe = sa._fair(pin, t_5)
        if fe is None:
            continue
        fair = fe if side == 'home' else 1 - fe
        fair_odds = 1 / fair
        best = None
        for b, sb in bk.items():
            if b.startswith('_') or b == sa.SHARP:
                continue
            ser = sb['h'] if side == 'home' else sb['a']
            entry = val_at(ser, t_5)
            if not entry or entry <= 1 or not ser:
                continue
            close = ser[-1][1]
            if not close or close <= 1:
                continue
            gap = (entry / fair_odds - 1) * 100
            if best is None or gap > best[0]:
                best = (gap, entry, close)
        if not best or best[0] < 0:
            continue
        clv = (best[1] / best[2] - 1) * 100
        rows.append((ab, clv))

    print("\n" + "=" * 60)
    print(f"SUIVI HYPOTHÈSE — âge du mouvement à amplitude fixée ~5% (depuis {FREEZE_DATE_MOVEAGE})")
    if len(rows) < 30:
        print(f"  n={len(rows)} signaux — trop tôt pour juger (seuil 30). Référence in-sample : "
              f"<5min +11,4%/88% refermés (n=92) vs >2h +6,4%/81% (n=73).")
        return
    grid = {}
    for ab, clv in rows:
        grid.setdefault(ab, []).append(clv)
    for _, _, lab in AGE_BUCKETS:
        vals = grid.get(lab, [])
        if len(vals) < 8:
            print(f"  {lab:10} n={len(vals):3} (trop petit)")
            continue
        pos = 100 * sum(1 for x in vals if x > 0) / len(vals)
        print(f"  {lab:10} n={len(vals):3} | CLV médian {st.median(vals):+6.1f}% | refermés {pos:3.0f}%")
    print("  (si <5min ne bat plus >2h, c'était du bruit malgré l'écart in-sample)")
    g = grid.get(AGE_BUCKETS[0][2], [])
    if g:
        return sum(1 for x in g if x > 0), len(g), 'temoin'


def _p_binomial_unilateral(k, n, p0=0.5):
    """P(X >= k) sous H0 p=p0 — binomial exact unilatéral, sans dépendance.

    p0=0,5 : test de signe (« refermés » vs pile ou face). p0 quelconque :
    nécessaire pour calibration/heure, où l'hypothèse nulle est le taux
    ATTENDU PAR SHIN — tester ces suivis contre 50 % serait faux.
    Fonction pure, couverte par tests/test_pure_functions.py."""
    if n <= 0:
        return 1.0
    if not 0 < p0 < 1:
        return 1.0 if k > n * p0 else 0.0
    # Log-espace : math.comb(n, i) déborde le float dès n ~ 1030
    # (OverflowError constaté sur le renforcement outsider, n=1287).
    lp, l1p = math.log(p0), math.log(1 - p0)
    lg = math.lgamma
    total = 0.0
    for i in range(max(k, 0), n + 1):
        total += math.exp(lg(n + 1) - lg(i + 1) - lg(n - i + 1)
                          + i * lp + (n - i) * l1p)
    return min(total, 1.0)


_P0_TEMOIN_CACHE = None


def p0_temoin(chemin='moves_detail_hist.csv'):
    """Taux de base de CLV>0 sur la POPULATION des moves détectés.

    (audit du 25/08 soir) : « sans edge, 50 % de CLV>0 » est faux — la
    dérive asymétrique des outsiders déplace le point d'équilibre, et le
    dispositif POSSÈDE son étalon : les 800+ moves de moves_detail_hist.
    Chaque hypothèse sélectionne un sous-groupe de cette activité ; son
    H0 honnête est « pas mieux que le move moyen », pas « pas mieux
    qu'une pièce ». Mesuré le 25/08 : 593/821 = 0,722 — contre 0,5 en
    dur, les verdicts changent du tout au tout.
    Réserve assumée : les sous-groupes issus d'autres détecteurs
    (ouverture précoce, seuils par book) sont comparés au même étalon —
    l'hypothèse de comparabilité est « tout ceci est du steam-following ».
    Renvoie (p0, n) ; repli (0.5, 0) SIGNALÉ si le fichier manque.
    """
    global _P0_TEMOIN_CACHE
    if _P0_TEMOIN_CACHE is not None:
        return _P0_TEMOIN_CACHE
    import csv
    vals = []
    try:
        for r in csv.DictReader(open(chemin, encoding='utf-8')):
            try:
                vals.append(float(r['clv_book_pct']))
            except (TypeError, ValueError, KeyError):
                continue
    except OSError:
        pass
    if len(vals) < 100:
        print(f"⚠️ p0_temoin : {chemin} absent ou trop maigre "
              f"({len(vals)} CLV) — repli p0=0,5, verdicts à lire avec "
              f"prudence.")
        _P0_TEMOIN_CACHE = (0.5, 0)
    else:
        pos = sum(1 for v in vals if v > 0)
        _P0_TEMOIN_CACHE = (pos / len(vals), len(vals))
    return _P0_TEMOIN_CACHE


def _p_deux_proportions(k1, n1, k2, n2):
    """Test à DEUX échantillons (Wald, variance groupée), unilatéral :
    H1 = la proportion 1 (sous-groupe) DÉPASSE la proportion 2 (référence).

    AJOUTÉ LE 27/08/2026 (audit §3.2) : p0_temoin() traite le taux de base
    comme une CONSTANTE connue, alors que c'est une estimation à erreur-type
    ~1,5 pt (n=891). Un test à un échantillon (binomial vs p0 fixe) sous-
    estime l'incertitude -- à n=30-60 pour le sous-groupe, ça peut faire
    basculer un verdict. Ce test à deux échantillons propage l'incertitude
    des DEUX proportions. Repli sur une approximation normale (pas de
    scipy) ; n1,n2 >= 30 dans tous les cas d'usage ici, la normale tient.
    RÉSERVE ASSUMÉE (non résolue ce soir) : la référence (k2,n2) INCLUT le
    sous-groupe testé -- l'auto-référencement partiel décrit par l'audit
    reste présent. L'exclusion complète demanderait de retracer, pour
    CHAQUE hypothèse, quelles lignes de moves_detail_hist.csv composent son
    sous-groupe -- pas toutes ne sourcent de ce fichier. Amélioration
    future, documentée plutôt que cachée.
    """
    if n1 <= 0 or n2 <= 0:
        return 1.0
    p1, p2 = k1 / n1, k2 / n2
    p_pool = (k1 + k2) / (n1 + n2)
    if p_pool in (0, 1):
        # CORRIGÉ LE 27/08/2026 (audit v2 §K) : les deux branches valaient
        # 1.0, ternaire mort. p_pool ne vaut 0 ou 1 QUE si k1=n1=k2=n2 (100%
        # des deux côtés) ou k1=k2=0 (0% des deux côtés) -- p1=p2 dans les
        # deux cas, donc p=1,0 est le résultat correct, pas un repli faute
        # de mieux.
        return 1.0
    se = math.sqrt(p_pool * (1 - p_pool) * (1 / n1 + 1 / n2))
    if se == 0:
        return 1.0
    z = (p1 - p2) / se
    # queue supérieure de la normale standard, sans scipy (erf de math)
    return 0.5 * math.erfc(z / math.sqrt(2))


def holm(pvals, alpha=0.05):
    """Correction de Holm (step-down). pvals -> liste de booléens alignée :
    True = rejet de H0 en contrôlant le risque global à alpha.

    Principe : on trie les p-values ; la plus petite doit battre alpha/m, la
    suivante alpha/(m-1), etc. Dès qu'une échoue, toutes les suivantes
    échouent (procédure séquentielle). Moins brutal que Bonferroni, aucune
    hypothèse d'indépendance requise — valide même sur nos tests corrélés.
    Fonction pure, couverte par tests/test_pure_functions.py."""
    m = len(pvals)
    if m == 0:
        return []
    ordre = sorted(range(m), key=lambda i: pvals[i])
    rejets = [False] * m
    for rang, i in enumerate(ordre):
        if pvals[i] <= alpha / (m - rang):
            rejets[i] = True
        else:
            break                      # step-down : le premier échec arrête tout
    return rejets




def bilan_tests_multiples(resultats):
    """Le filtre opérationnel : comptages OOS -> p-values -> Holm.

    resultats = [(nom, gel, (k, n, p0) | None)] ; p0 vaut un nombre
    (attendu Shin) ou 'temoin' (taux de base CLV>0 de la population de
    moves). Plancher n>=30 EN AMONT de la famille : la règle maison est
    pré-enregistrée et indépendante du résultat, donc l'exclure avant
    Holm est légitime — une hypothèse à n=6 ne peut jamais rejeter mais
    durcirait le seuil de toutes les autres.
    """
    m = len(resultats)
    p0t, nt = p0_temoin()
    print(f"\n{'=' * 60}")
    print(f"BILAN TESTS MULTIPLES — {m} hypothèses gelées suivies "
          f"(Holm, alpha=0,05, plancher n>=30)")
    print(f"  p0 témoin = {100 * p0t:.1f}% de CLV>0 sur la population "
          f"de moves (n={nt}) — l'étalon des hypothèses CLV.")
    print(f"  Critère PRIMAIRE (EXPLORATOIRE depuis le 27/08, requalifié — "
          f"gel {FREEZE_DATE_PRIMAIRE}) : le +11,2 pts d'août est descriptif, "
          f"non confirmatoire tant qu'il n'est pas revalidé sur données "
          f"postérieures à ce gel.")
    # LECTURE UNIQUE PAR HYPOTHÈSE (audit §3.3), CORRIGÉ LE 27/08/2026
    # (audit v2 §C) : geler à N_CIBLE (n pré-enregistré), pas au premier
    # n>=30 -- voir la constante N_CIBLE pour le raisonnement complet.
    GELES_FICHIER = 'verdicts_geles.json'
    try:
        geles = json.load(open(GELES_FICHIER, encoding='utf-8'))
    except (OSError, ValueError):
        geles = {}
    resolus = []
    for idx, (nom, gel, r) in enumerate(resultats):
        if not r:
            resolus.append((idx, None))
            continue
        k, n, p0 = r
        resolus.append((idx, (k, n, p0t if p0 == 'temoin' else p0, nt if p0 == 'temoin' else None)))
    # GARDE (16/10/2026) : une hypothèse « en attente de résultats » (plus de
    # 10 % de ses détections en direct sans résultat) ne se verrouille pas.
    attente = {nom: getattr(w, 'attente', None) for nom, _, w in HYPOTHESES}
    a_geler = []
    for idx, r in resolus:
        nom = resultats[idx][0]
        if nom in geles:
            continue                              # déjà gelé, jamais recalculé
        if attente.get(nom):
            continue                              # résultats incomplets : jamais verrouillé
        if r is not None and r[1] >= N_CIBLE:
            a_geler.append((idx, r))
    for idx, (k, n, p0, n_ref) in a_geler:
        nom = resultats[idx][0]
        if n_ref is not None:
            k_ref = round(p0 * n_ref)
            p = _p_deux_proportions(k, n, k_ref, n_ref)
        else:
            p = _p_binomial_unilateral(k, n, p0)
        geles[nom] = {'k': k, 'n': n, 'p0': p0, 'p_value': p,
                     'date_lecture': datetime.date.today().isoformat()}
    if a_geler:
        json.dump(geles, open(GELES_FICHIER, 'w', encoding='utf-8'),
                  ensure_ascii=False, indent=1)
    # Holm s'applique à TOUTES les hypothèses gelées à ce jour (anciennes
    # et nouvelles) -- la famille grandit au fil des gels, jamais un même
    # verdict individuel n'est recalculé.
    noms_geles = [nom for nom, _, _ in resultats if nom in geles]
    pvals = [geles[nom]['p_value'] for nom in noms_geles]
    rejets = holm(pvals, alpha=0.05)
    verdicts = dict(zip(noms_geles, rejets))
    for idx, (nom, gel, r) in enumerate(resultats):
        if nom in geles:
            g = geles[nom]
            k, n, p0, p = g['k'], g['n'], g['p0'], g['p_value']
            rej = verdicts[nom]
            if rej:
                v = 'REJETTE H0 sous Holm ✅'
            elif k / n < p0:
                v = 'ne rejette pas H0 (SOUS le taux de base témoin ⚠️)'
            else:
                v = 'ne rejette pas H0'
            print(f"  {nom:24} gel {str(gel)[:10]} | lu le "
                  f"{g['date_lecture']} (verrouillé) | {k}/{n} vs "
                  f"p0={p0:.3f} | p={p:.4f} -> {v}")
        elif r is not None and attente.get(nom):
            k, n = r[0], r[1]
            print(f"  {nom:24} gel {str(gel)[:10]} | {k}/{n} — {attente[nom]} : "
                  f"verdict NI verrouillé NI déclaré")
        elif r is not None and r[1] < 30:
            k, n = r[0], r[1]
            print(f"  {nom:24} gel {str(gel)[:10]} | {k}/{n} — n<30 : "
                  f"suivi, HORS famille (seuil maison pré-enregistré)")
        elif r is not None and r[1] < N_CIBLE:
            # AJOUTÉ LE 27/08/2026 (audit v2 §C) : entre le plancher (30) et
            # la cible de gel (N_CIBLE), la puissance existe déjà mais la
            # lecture N'EST PAS ENCORE ACTÉE -- distinct du cas n<30
            # (aucune conclusion possible) et du cas gelé (verdict figé).
            k, n = r[0], r[1]
            print(f"  {nom:24} gel {str(gel)[:10]} | {k}/{n} — en "
                  f"accumulation (cible n>={N_CIBLE}, {N_CIBLE - n} restants "
                  f"avant lecture)")
        else:
            print(f"  {nom:24} gel {str(gel)[:10]} | — pas de comptage "
                  f"OOS (n insuffisant, hors périmètre binomial, ou trop tôt)")
    n_rej = sum(1 for v in verdicts.values() if v)
    print(f"  Famille : {len(pvals)} verdict(s) gelé(s) au total, {n_rej} "
          f"rejet(s) au risque global 5 % (chaque verdict lu UNE SEULE FOIS, "
          f"à sa qualification n>={N_CIBLE} pré-enregistrée).")
    print('  Verdict CONFIRMATOIRE = hypothèse gelée AVANT ses données '
          'de test, jugée out-of-sample puis passée dans holm().')
    print('  Tout angle exploré in-sample reste EXPLORATOIRE : il peut '
          'motiver un nouveau gel daté, jamais justifier une décision.')
    print('  Un « survivant » in-sample non répliqué out-of-sample sous '
          'ce filtre doit être lu comme du bruit.')

# Une SEULE source de vérité (audit du 25/08 soir, consolidée le soir
# même : la première version vivait dans main() pendant que l'ancienne
# liste parallèle servait encore l'en-tête — la duplication supprimée
# était revenue par la fenêtre). Nom, date de gel et fonction voyagent
# ENSEMBLE, au niveau module, lus par l'en-tête ET par la boucle.
def kalshi_lead_watch():
    """13e hypothèse gelée : l'écart Kalshi − Pinnacle dévigé prédit-il le
    SENS du mouvement de Pinnacle dans les 45 minutes suivantes ?

    Gelée le 2026-09-05. Le collecteur scripts/kalshi_lead_track.py porte la
    spécification complète et le raisonnement du gel ; ici on ne fait que
    juger.

    POURQUOI ELLE SEULE. L'exploration du 05/09/2026 sur 7 jours de ticks
    (3,3 M de points, 730 matchs Kalshi) a écarté tout le reste :
      - Kalshi et Pinnacle affichent LE MÊME PRIX : écart moyen +0,00 pt,
        écart-type 0,89 pt sur 21 000 instants liquides. Un aller-retour
        Kalshi coûte ~2,2 pts (0,5 de demi-fourchette + ~1,7 de frais) :
        l'écart dépasse ce seuil dans 1,3 % des instants. Aucun arbitrage.
      - Aucune découverte de prix : entre T-240 et T-10, dérive médiane
        0,00 pt, |dérive| > 5 pts dans 0 % des 177 matchs, et log-loss
        identique aux deux bouts (0,5511 vs 0,5518).
      - 33 tests de calibration par zone sur observations indépendantes,
        Holm-Bonferroni : ZÉRO survivant (plus petit p = 0,063 pour un
        seuil à 0,0015).
    Seule la corrélation écart -> mouvement futur a dépassé le bruit :
    +0,163, IC95 [+0,012 ; +0,306], n=170. Borne basse frôlant zéro et
    gradient plat par tranche : le profil d'un artefact autant que celui
    d'un signal. D'où le gel, et non l'exploitation.

    H0 N'EST PAS 50 %. Le groupe témoin (|écart| < 1 pt) affiche déjà
    57,3 % de succès : il existe une tendance de fond à ce que le mouvement
    suive le signe de l'écart, même minuscule. Tester contre une pièce
    rejetterait H0 pour cette seule raison. p0 est donc le taux du groupe
    témoin, recalculé à chaque lecture sur les données out-of-sample —
    même parti pris que p0_temoin() pour les hypothèses CLV.

    Retourne (k, n, p0) ou None si pas encore testable.
    """
    import datetime as _dtm

    OBS = 'kalshi_lead_obs.jsonl'
    SEUIL = 1.0        # GELÉ. Voir kalshi_lead_track.py : 1,5 pt donnait
                       # 86,7 % mais sur n=15, et aurait été choisi APRÈS
                       # avoir vu le résultat. 1,0 pt vaut ~1 écart-type de
                       # la divergence Kalshi-Pinnacle (0,89 pt), mesurée
                       # indépendamment et AVANT ce test.

    def _ts(x):
        try:
            return _dtm.datetime.fromisoformat(
                str(x).replace('Z', '').replace('+00:00', ''))
        except (ValueError, TypeError):
            return None

    freeze = _ts(FREEZE_DATE_KXLEAD)
    lignes = []
    try:
        for ligne in open(OBS, encoding='utf-8'):
            ligne = ligne.strip()
            if not ligne:
                continue
            try:
                lignes.append(json.loads(ligne))
            except ValueError:
                continue
    except OSError:
        print(f"  {OBS} absent — scripts/kalshi_lead_track.py a-t-il tourné ?")
        return None

    signal, temoin, n_in = [], [], 0
    for r in lignes:
        t = _ts(r.get('t'))
        if not t or t < freeze:
            n_in += 1
            continue                      # OUT-OF-SAMPLE STRICT
        e, m = r.get('ecart_pts'), r.get('mvt_pts')
        if not isinstance(e, (int, float)) or not isinstance(m, (int, float)):
            continue
        # Un mouvement Pinnacle NUL n'a pas de signe : ni succès ni échec.
        # L'écarter des DEUX groupes, sans quoi il gonflerait le
        # dénominateur du seul groupe où il est fréquent.
        if m == 0:
            continue
        succes = (m > 0) == (e > 0)
        (signal if abs(e) >= SEUIL else temoin).append(succes)

    print(f"  journal : {len(lignes)} observation(s), dont {n_in} in-sample "
          f"(écartée(s))")
    if not signal or not temoin:
        print(f"  out-of-sample : signal n={len(signal)} · témoin n={len(temoin)}"
              f" — les deux groupes ne sont pas encore peuplés.")
        return None

    k, n = sum(signal), len(signal)
    kt, nt = sum(temoin), len(temoin)
    p0 = kt / nt
    _, lo, hi = wilson(k, n)
    print(f"  SIGNAL |écart| >= {SEUIL:.1f} pt : {k}/{n} = {100 * k / n:.1f} % "
          f"IC95 [{100 * lo:.1f} ; {100 * hi:.1f}]")
    print(f"  TÉMOIN |écart| <  {SEUIL:.1f} pt : {kt}/{nt} = {100 * p0:.1f} %  (= p0)")
    print(f"  référence in-sample au gel, NON confirmatoire : "
          f"signal 60,8 % (n=51) · témoin 57,3 % (n=117)")
    if n < 30:
        print(f"  n={n} < 30 — trop tôt pour juger (règle maison). Il faut "
              f"~600 observations pour distinguer une corrélation de 0,16 de "
              f"zéro ; à 64 matchs Kalshi/jour, compter un mois.")
    return (k, n, p0)


def roi_bande_watch():
    """13e hypothèse gelée : les mouvements joués dans la bande de cote
    2,00-3,00 dégagent-ils un ROI POSITIF ?

        « Parier le côté steamé au book d'entrée, cote comprise entre 2,00
          et 3,00, SANS aucun autre filtre. »

    Gelée le 2026-09-06. PREMIÈRE hypothèse du projet portant sur le ROI et
    non sur le CLV.

    ── BANDE RESSERRÉE DE 2,00-5,00 À 2,00-3,00, LE JOUR MÊME ───────────
    La première formulation reposait sur un moves_detail_hist.csv produit
    AVANT le correctif de look-ahead de move_audit.py (le côté parié y était
    choisi avec la clôture Pinnacle : 96,7 % des paris portaient sur un côté
    dont la cote avait baissé -- par construction, pas par performance).
    Sur les données causales, ce taux tombe à 82,1 %, ce qui est le
    comportement attendu d'un détecteur temps réel : ~18 % des mouvements se
    retournent après détection.

    Aucune donnée out-of-sample n'avait encore été accumulée : resserrer la
    bande le jour du gel n'a donc aucun coût méthodologique. La laisser à
    5,00 en aurait eu un.

    ── CE QUE LES DONNÉES CORRIGÉES DISENT ──────────────────────────────
    1032 paris dénoués, 07/06 -> 06/09. ROI global +2,1 %,
    IC95 [-5,0 ; +9,3]. Par cote :
        < 1,50      n=221  ROI  +1,6 %
        1,50-2,00   n=291  ROI  -3,0 %
        2,00-3,00   n=316  ROI +13,7 %  IC95 [+0,3 ; +27,0]  <- exclut zéro
        3,00-5,00   n=145  ROI  +5,2 %  IC95 [-22,4 ; +32,9]
        5,00-10     n= 52  ROI -32,2 %
    La zone utile est encadrée des DEUX côtés : les favoris sous 2,00 sont
    négatifs, les outsiders au-delà de 5,00 le sont franchement.

    ── POURQUOI 3,00 ET NON 5,00 : LA RÉPLICATION, PAS L'OPTIMISATION ───
    Découpage temporel en deux moitiés indépendantes :
        cote 2,00-3,00   1re +11,3 %   2e +16,6 %   <- réplique
        cote 3,00-5,00   1re +17,5 %   2e  +0,6 %   <- s'effondre
    La tranche 3,00-5,00 était celle que le look-ahead gonflait le plus :
    plus la cote est haute, plus choisir le côté après coup rapporte. C'est
    exactement l'artefact que le correctif a retiré.

    La borne de 3,00 reste issue de l'exploration, comme l'était celle de
    5,00. Ce qui la rend crédible n'est pas sa valeur mais le fait qu'elle
    survive à un test qu'elle ne pouvait pas anticiper.

    ── AUCUN CRITÈRE SUPPLÉMENTAIRE ─────────────────────────────────────
    Douze critères testés sur la PREMIÈRE moitié seulement, puis contrôlés
    sur la seconde. Aucun ne bat la règle simple de façon réplicable. Le
    seul qui améliorait vraiment -- CLV vs Pinnacle > +5 % -- se calcule sur
    `pin_close`, connue APRÈS le coup d'envoi : look-ahead, inutilisable en
    filtre d'entrée. Son analogue actionnable (prix d'entrée contre juste
    prix Pinnacle AU MOMENT DU PARI, déjà calculé par canal_public.py sous
    le nom `juste_prix`) est une piste pour un gel ultérieur.

    ── LE ROI DANS LE CADRE BINOMIAL ────────────────────────────────────
    ROI > 0  <=>  taux de gain > taux d'équilibre implicite des cotes.
    Donc k = paris gagnés, n = paris, p0 = moyenne de 1/cote sur la
    sélection. Aucune adaptation du dispositif : Holm et le plancher n>=30
    s'appliquent tels quels.

    Référence in-sample au gel, NON confirmatoire :
        n=316 · 150 gains · taux 47,5 % · p0 42,2 % · ROI +13,7 %

    ATTENTION : N_CIBLE est déjà atteint sur l'historique. Le filtre
    out-of-sample est la SEULE chose qui empêche cette hypothèse de se
    valider elle-même sur les données qui l'ont fait naître.

    Retourne (k, n, p0) ou None si pas encore testable.
    """
    import datetime as _dtm

    SRC = 'moves_detail_hist.csv'
    COTE_MIN, COTE_MAX = H13_COTE_MIN, H13_COTE_MAX   # GELÉES (module)

    lignes = []
    try:
        with open(SRC, encoding='utf-8') as fh:
            for r in csv.DictReader(fh):
                lignes.append(r)
    except OSError:
        print(f"  {SRC} absent.")
        return None

    freeze = FREEZE_DATE_ROIBANDE
    retenus, n_in, n_bande = [], 0, 0
    for r in lignes:
        try:
            cote = float(r['entry'])
        except (ValueError, TypeError, KeyError):
            continue
        if not (COTE_MIN <= cote <= COTE_MAX):
            continue
        n_bande += 1
        # OUT-OF-SAMPLE STRICT sur la date du match. Comparaison de chaînes
        # ISO : sûre et sans dépendance au fuseau.
        d = str(r.get('date') or '')[:10]
        if not d or d < freeze:
            n_in += 1
            continue
        g = r.get('steame_gagne')
        if g not in ('oui', 'non'):
            continue                     # pari non dénoué : ni gain ni perte
        # Le P&L RÉEL est lu dans le fichier, pas recalculé : c'est lui qui
        # porte le rendement effectif, cote par cote.
        try:
            pnl = float(r.get('pnl'))
        except (TypeError, ValueError):
            pnl = (cote - 1.0) if g == 'oui' else -1.0
        retenus.append((1 if g == 'oui' else 0, cote, pnl))

    print(f"  {SRC} : {len(lignes)} lignes · {n_bande} dans la bande "
          f"{COTE_MIN:.1f}-{COTE_MAX:.1f} · {n_in} in-sample (écartés)")
    if not retenus:
        print("  aucun pari out-of-sample dénoué — trop tôt.")
        return None

    k = sum(w for w, _, _ in retenus)
    n = len(retenus)
    p0 = sum(1.0 / c for _, c, _ in retenus) / n   # seuil de rentabilité
    _, lo, hi = wilson(k, n)
    pnls = [p for _, _, p in retenus]
    roi = 100.0 * (sum(pnls) / n)                  # ROI RÉEL, pari par pari
    ic = 196.0 * _ecart_type(pnls) / math.sqrt(n) if n > 1 else 0.0
    print(f"  OUT-OF-SAMPLE : {k}/{n} = {100 * k / n:.1f} % de gains "
          f"IC95 [{100 * lo:.1f} ; {100 * hi:.1f}]")
    print(f"  seuil de rentabilité p0 = {100 * p0:.1f} % (moyenne de 1/cote)")
    # LE VERDICT se lit sur le TAUX DE GAIN contre p0 (cadre binomial, c'est
    # lui qui porte Holm). Le ROI est affiché à part, comme grandeur
    # économique — les deux ne coïncident QUE si toutes les cotes sont
    # égales, ce qui n'est jamais le cas.
    print(f"  ROI RÉEL {roi:+.1f} % [{roi - ic:+.1f} ; {roi + ic:+.1f}] "
          f"· P&L {sum(pnls):+.1f} u")
    print(f"  référence in-sample au gel, NON confirmatoire : "
          f"150/316 = 47,5 % · p0 42,2 % · ROI +13,7 %")
    if n < 30:
        print(f"  n={n} < 30 — trop tôt pour juger (règle maison). "
              f"Débit observé : ~105 paris/mois dans la bande, "
              f"~300 paris pour que l'intervalle exclue franchement "
              f"zéro, soit environ 3 mois.")
    return (k, n, p0)


def roi_ampli_watch():
    """14e hypothèse gelée : un mouvement Pinnacle > 5 % détecté entre 8 h et
    24 h avant le match dégage-t-il un ROI POSITIF, toutes cotes confondues ?

        « Parier le côté steamé au book d'entrée, mouvement Pinnacle > 5 %,
          détection entre 8 h et 24 h avant le coup d'envoi, SANS filtre de
          cote. »

    Gelée le 2026-09-07, à partir du rapport de robustesse externe.
    REGELÉE LE 2026-09-12 sur l'ampleur mesurée à la détection : le critère
    du 07/09 lisait une colonne calculée sur la clôture Pinnacle. TOUS les
    chiffres cités plus bas dans cette docstring (A/B/C, ROI +20,9 % etc.)
    viennent de ce critère contaminé -- ils sont conservés pour mémoire du
    raisonnement de sélection A vs B vs C, ils ne valent plus comme mesures.

    ── POURQUOI LA STRATÉGIE A SEULE ────────────────────────────────────
    Le rapport proposait trois règles à geler : A (celle-ci), B (A + cote
    2,50-4,00, ROI +47,9 %) et C (move > 10 % + cote 2,50-4,00).

    Reproduit sur moves_detail_hist.csv corrigé du look-ahead :
        A  n=275  ROI +20,9 %   IC95 [ +4,7 ;  +37,1]
        B  n= 75  ROI +50,8 %   IC95 [+16,6 ;  +84,9]
        C  n= 58  ROI +50,3 %   IC95 [+11,0 ;  +89,6]
    Les chiffres du rapport sont donc justes (il annonçait n=283 / +21,5 %
    et n=79 / +47,9 %).

    B et C sont malgré tout écartées, pour trois raisons.

    1. ESPACE DE RECHERCHE. En balayant 8 seuils x 8 fenêtres x 7 bandes de
       cote = 448 combinaisons sur la PREMIÈRE moitié seulement, 33 % d'entre
       elles ressortent « significatives » au sens de l'IC95. Trouver une
       zone à +50 % dans cet espace n'a rien d'exceptionnel. La zone B y est
       classée 85e sur 347 : le top 5 atteint +102 %.
    2. VOLUME. B ne compte que 23 paris sur la période récente, C en compte
       12. Aucune des cinq meilleures règles de la première moitié n'atteint
       20 observations sur la seconde : elles sont trop étroites pour être
       testables.
    3. CORRÉLATION. B et C sont des sous-ensembles de A. Les geler ensemble,
       c'est tester trois hypothèses non indépendantes sur le même flux —
       Holm en ferait payer le prix aux trois sans qu'aucune n'atteigne son
       volume.

    A a 275 observations, un seul degré de liberté par dimension, et surtout
    elle RÉPLIQUE sur deux moitiés temporelles indépendantes :
        1re moitié (07/06 -> 11/08)  +21,7 %  n=167
        2e  moitié (11/08 -> 06/09)  +19,6 %  n=108
    2,1 points d'écart. C'est ce qui la distingue d'un artefact de recherche,
    pas sa valeur.

    ── CE QUE LE RAPPORT PRÉSENTAIT À TORT COMME DE LA ROBUSTESSE ───────
    Ses sections 3, 4 et 5 ne sont pas des tests indépendants :
      - les 7 seuils sont des SOUS-ENSEMBLES emboîtés (>6 % partage 90 % de
        ses observations avec >5 %) : la stabilité du ROI y est arithmétique ;
      - les 3 fenêtres se recouvrent massivement avec 8-24 h ;
      - retirer les meilleurs paris fait baisser le ROI par construction ;
        qu'il reste positif arriverait aussi sur des données aléatoires.
    Rien de tout cela n'est une preuve de robustesse. Le découpage temporel,
    lui, en est une — et le rapport ne l'avait pas fait.

    ── LE ROI DANS LE CADRE BINOMIAL ────────────────────────────────────
    ROI > 0  <=>  taux de gain > taux d'équilibre implicite des cotes.
    k = paris gagnés, n = paris, p0 = moyenne de 1/cote. Holm et le plancher
    n>=30 s'appliquent sans adaptation.

    Référence in-sample au gel, NON confirmatoire :
        n=275 · 146 gains · taux 53,1 % · p0 46,0 % · ROI +20,9 %
        CLV médian +7,8 % · cote médiane 2,27

    Volume attendu : ~91 paris/mois, ~166 paris pour que l'IC95 exclue zéro,
    soit moins de deux mois. C'est l'hypothèse la plus rapide à trancher du
    dispositif.

    ATTENTION : N_CIBLE est déjà atteint sur l'historique. Le filtre
    out-of-sample est la SEULE chose qui empêche cette hypothèse de se
    valider sur les données qui l'ont fait naître.

    Retourne (k, n, p0) ou None si pas encore testable.
    """
    import datetime as _dtm

    SRC = 'moves_detail_hist.csv'
    freeze = FREEZE_DATE_AMPLI
    try:
        fh = open(SRC, encoding='utf-8')
    except OSError:
        print(f"  {SRC} absent.")
        return None

    retenus, n_in, n_zone = [], 0, 0
    with fh:
        lecteur = csv.DictReader(fh)
        # GARDE DE VERSION (12/09/2026) — voir FREEZE_DATE_AMPLI plus haut.
        # Sans elle, un CSV antérieur au correctif ferait tourner
        # l'hypothèse regelée sur l'ancien critère contaminé, et le rapport
        # afficherait un verdict apparemment propre sur des chiffres qui ne
        # le sont pas. On préfère ne rien afficher.
        if 'mag_cote_pct_POSTHOC' not in (lecteur.fieldnames or []):
            print(f"  {SRC} antérieur au correctif du 12/09/2026 "
                  f"(colonne mag_cote_pct_POSTHOC absente) : `mag_cote_pct` y "
                  f"contient la clôture. Relancer move_audit.py.")
            return None
        for r in lecteur:
            try:
                cote = float(r['entry'])
                # mag_cote_pct : raccourcissement de la cote Pinnacle À LA
                # DÉTECTION depuis le correctif du 12/09/2026 (la garde de
                # version plus haut refuse tout CSV antérieur, où cette même
                # colonne contenait la clôture).
                move = float(r['mag_cote_pct'])
                lead = float(r['lead_min'])
            except (TypeError, ValueError, KeyError):
                continue
            if move <= H14_MOVE_MIN_PCT:
                continue
            if not (H14_LEAD_MIN <= lead <= H14_LEAD_MAX):
                continue
            n_zone += 1
            d = str(r.get('date') or '')[:10]
            if not d or d < freeze:
                n_in += 1
                continue
            g = r.get('steame_gagne')
            if g not in ('oui', 'non'):
                continue
            try:
                pnl = float(r.get('pnl'))
            except (TypeError, ValueError):
                pnl = (cote - 1.0) if g == 'oui' else -1.0
            retenus.append((1 if g == 'oui' else 0, cote, pnl))

    print(f"  {SRC} : {n_zone} pari(s) dans la zone "
          f"(move>{H14_MOVE_MIN_PCT:.0f}%, {H14_LEAD_MIN/60:.0f}-{H14_LEAD_MAX/60:.0f} h) "
          f"· {n_in} in-sample (écartés)")
    if not retenus:
        print("  aucun pari out-of-sample dénoué — trop tôt.")
        return None

    k = sum(w for w, _, _ in retenus)
    n = len(retenus)
    p0 = sum(1.0 / c for _, c, _ in retenus) / n
    _, lo, hi = wilson(k, n)
    pnls = [p for _, _, p in retenus]
    roi = 100.0 * (sum(pnls) / n)
    ic = 196.0 * _ecart_type(pnls) / math.sqrt(n) if n > 1 else 0.0
    print(f"  OUT-OF-SAMPLE : {k}/{n} = {100 * k / n:.1f} % de gains "
          f"IC95 [{100 * lo:.1f} ; {100 * hi:.1f}]")
    print(f"  seuil de rentabilité p0 = {100 * p0:.1f} %")
    print(f"  ROI RÉEL {roi:+.1f} % [{roi - ic:+.1f} ; {roi + ic:+.1f}] "
          f"· P&L {sum(pnls):+.1f} u")
    print(f"  référence in-sample au gel, NON confirmatoire : "
          f"146/275 = 53,1 % · p0 46,0 % · ROI +20,9 %")
    if n < 30:
        print(f"  n={n} < 30 — trop tôt (règle maison). ~91 paris/mois "
              f"attendus, ~166 pour que l'IC95 exclue zéro.")
    return (k, n, p0)


def bande_240_310_watch():
    """15e hypothèse gelée : parier le côté steamé quand sa cote d'entrée
    se situe entre 2,40 et 3,10.

        « Parier le côté steamé au book d'entrée, cote comprise entre
          2,40 et 3,10, sans autre filtre. »

    Gelée le 2026-09-25.

    ── CE QUI L'A FAIT RETENIR ─────────────────────────────────────────
    Découpage du portefeuille par tranche de cote, 1 543 paris :

        cote        n     gains   seuil   écart     ROI
        < 1,50     321    80,4 %  77,4 %   +3,0    +3,9 %
        1,50-2,00  421    59,6 %  58,8 %   +0,8    +0,9 %
        2,00-2,50  280    47,1 %  45,2 %   +1,9    +4,1 %
        2,50-3,00  166    45,2 %  37,1 %   +8,1   +22,8 %
        3,00-4,00  164    31,1 %  29,7 %   +1,4    +5,6 %
        4,00-6,00  117    22,2 %  21,9 %   +0,3    +1,0 %
        > 6,00      63     7,9 %  11,5 %   -4,1   -34,1 %

    Six tranches entre -4,1 et +3,0, une seule à +8,1. Un balayage en
    bandes glissantes montre un gradient net : +1,8 sur 2,30-2,80, +7,0
    sur 2,40-2,90, +8,1 sur 2,50-3,00, +10,9 sur 2,70-3,20, puis
    redescente à +1,4 sur 3,00-3,50.

    RÉPLICATION TEMPORELLE (deux moitiés sans recouvrement) :
        2,40-3,10   +24,7 % (n=121)  ->  +21,8 % (n=104)
    Trois points d'écart, effectifs corrects des deux côtés.

    ── POURQUOI CETTE BANDE ET PAS UNE AUTRE ───────────────────────────
    L'effet est porté par un noyau de 80 paris sur 2,70-2,90 : écart
    +16,3, ROI +45,2 %, p exact 0,0021. Le reste de la bande 2,50-3,00
    fait +0,4 point d'écart, soit rien.

    Geler le noyau serait geler le maximum d'un balayage — la façon la
    plus sûre de figer du bruit. La bande LARGE 2,40-3,10 est retenue
    parce qu'elle n'a pas été choisie pour maximiser l'effet, qu'elle
    compte 104 paris sur la période récente contre 29 pour le noyau, et
    qu'elle réplique à trois points près.

    ATTENTION : les bandes 2,40-3,10 / 2,45-3,05 / 2,50-3,00 / 2,55-2,95
    / 2,60-2,90 contiennent TOUTES les mêmes 80 paris du noyau. Ce ne
    sont pas cinq confirmations mais une mesure vue cinq fois — le piège
    des sous-ensembles emboîtés déjà relevé le 07/09. Ne pas les citer
    comme cinq preuves.

    ── RÉSERVE HONNÊTE ─────────────────────────────────────────────────
    La bande a été trouvée APRÈS avoir vu les résultats, sur une
    vingtaine de découpages testés. Le p de 0,0065 devient ~0,13 après
    Bonferroni. C'est la réplication, pas la significativité, qui
    justifie ce gel — et elle ne vaut que sur 121 puis 104 paris.

    Référence in-sample au gel, NON confirmatoire :
        n=225 · 103 gains · 45,8 % · seuil 37,5 % · écart +8,3
        ROI +23,4 % · P&L +52,6 u · CLV médian +5,3 % · cote médiane 2,70

    Volume : ~63 paris/mois. L'IC95 franchit le seuil dès n=150, soit
    environ 2,5 mois.

    Retourne (k, n, p0) ou None si pas encore testable.
    """
    SRC = 'moves_detail_hist.csv'
    try:
        fh = open(SRC, encoding='utf-8')
    except OSError:
        print(f"  {SRC} absent.")
        return None

    retenus, n_in, n_bande = [], 0, 0
    with fh:
        for r in csv.DictReader(fh):
            try:
                cote = float(r['entry'])
            except (TypeError, ValueError, KeyError):
                continue
            if not (H15_COTE_MIN <= cote < H15_COTE_MAX):
                continue
            n_bande += 1
            d = str(r.get('date') or '')[:10]
            if not d or d < FREEZE_DATE_H15:
                n_in += 1
                continue
            g = r.get('steame_gagne')
            if g not in ('oui', 'non'):
                continue
            try:
                pnl = float(r['pnl'])
            except (TypeError, ValueError, KeyError):
                pnl = (cote - 1.0) if g == 'oui' else -1.0
            retenus.append((1 if g == 'oui' else 0, cote, pnl))

    print(f"  {SRC} : {n_bande} pari(s) dans la bande "
          f"{H15_COTE_MIN:.2f}-{H15_COTE_MAX:.2f} · {n_in} in-sample (écartés)")
    if not retenus:
        print("  aucun pari out-of-sample dénoué — trop tôt.")
        return None

    k = sum(w for w, _, _ in retenus)
    n = len(retenus)
    p0 = sum(1.0 / c for _, c, _ in retenus) / n
    _, lo, hi = wilson(k, n)
    pnls = [p for _, _, p in retenus]
    roi = 100.0 * (sum(pnls) / n)
    ic = 196.0 * _ecart_type(pnls) / math.sqrt(n) if n > 1 else 0.0
    print(f"  OUT-OF-SAMPLE : {k}/{n} = {100 * k / n:.1f} % de gains "
          f"IC95 [{100 * lo:.1f} ; {100 * hi:.1f}]")
    print(f"  seuil de rentabilité p0 = {100 * p0:.1f} % · "
          f"écart {100 * k / n - 100 * p0:+.1f} points")
    print(f"  ROI RÉEL {roi:+.1f} % [{roi - ic:+.1f} ; {roi + ic:+.1f}] "
          f"· P&L {sum(pnls):+.1f} u")
    print(f"  référence in-sample au gel, NON confirmatoire : "
          f"103/225 = 45,8 % · seuil 37,5 % · ROI +23,4 %")
    if n < 30:
        print(f"  n={n} < 30 — trop tôt (règle maison). ~63 paris/mois "
              f"attendus, l'IC95 franchit le seuil vers n=150.")
    return (k, n, p0)


def bande_favori_watch():
    """16e hypothèse gelée : le côté steamé partait-il favori net ?

        « Parier le côté steamé au book d'entrée quand le prix PINNACLE
          À L'OUVERTURE de ce côté est inférieur à 1,80. »

    Gelée le 2026-09-25.

    ── CE QUI L'A FAIT RETENIR ─────────────────────────────────────────
    Référence in-sample : n=580 · 429 gains = 74,0 % contre 70,2 % de
    seuil · écart +3,8 · ROI +5,5 % · P&L +31,8 u.

    Quatre tests indépendants :
        IC95 du taux   [70,2 ; 77,4]   exclut le seuil
        IC95 du ROI    [+0,2 ; +10,8]  exclut zéro
        binomial exact p = 0,0246
        placebo 500 tirages : plage [-4,31 ; +4,64], observé +5,48 %

    RÉPLICATION à effectifs rigoureusement égaux :
        1re moitié  écart +3,0  ROI +4,3 %  (n=290)
        2e  moitié  écart +4,6  ROI +6,6 %  (n=290)
    L'effet AUGMENTE sur la période récente. Aucune autre hypothèse du
    dispositif n'a une réplication à 290 contre 290.

    ── POURQUOI 1,80 ET PAS 1,65 ───────────────────────────────────────
    Le balayage donne :
        < 1,60   n=387  écart +3,7  p=0,0491
        < 1,65   n=437  écart +4,6  p=0,0149   <- meilleur
        < 1,70   n=480  écart +3,9  p=0,0286
        < 1,75   n=532  écart +2,8  p=0,0801
        < 1,80   n=580  écart +3,8  p=0,0246

    1,65 a le meilleur p ET le meilleur écart — c'est précisément pour
    cela qu'il est écarté : c'est le maximum d'un balayage. 1,80 est le
    seuil de DÉPART, choisi avant tout découpage, avec le plus gros
    volume et le meilleur P&L.

    Point rassurant : l'effet ne dépend PAS du seuil. Il reste entre
    +2,8 et +4,6 sur toute la plage 1,60-1,80. C'est ce qui distingue
    cette hypothèse de la zone 1,50-1,65 (cote d'entrée), écartée le même
    jour : celle-là passait de +5,7 à +1,0 en décalant une borne de 0,05.

    ── OÙ EST L'EFFET, ET OÙ IL N'EST PAS ──────────────────────────────
    Par cote d'entrée, à l'intérieur du groupe :
        < 1,20       n= 63  écart +2,4
        1,20-1,35    n=116  écart +3,2
        1,35-1,50    n=140  écart +2,6
        1,50-1,65    n=150  écart +7,6
        1,65-1,80    n= 96  écart -0,6

    L'effet est présent PARTOUT sous 1,65, plus fort sur 1,50-1,65, et
    absent au-delà. En retirant 1,50-1,65, les 430 paris restants gardent
    +2,5 d'écart — non significatif faute d'effectif, mais pas nul.

    ── RÉSERVES ────────────────────────────────────────────────────────
    L'effet est MODESTE : +3,8 points, et l'IC du ROI frôle zéro (+0,2 %).
    La concentration est forte : les 25 meilleurs paris font 63 % du P&L.
    À cote médiane 1,44, un gain rapporte 0,44 u et une perte coûte 1,00 —
    le résultat tient à quelques dizaines de gros outsiders battus.

    ATTENTION au filtre : il porte sur pin_open, le prix PINNACLE à
    l'ouverture, PAS sur la cote d'entrée. Un filtre sur la cote d'entrée
    < 1,80 donne n=608 et p=0,0933, soit un résultat NON significatif. Ne
    pas confondre les deux.

    Volume : ~161 paris/mois. L'IC95 franchit le seuil vers n=600, soit
    environ 3,7 mois. C'est l'hypothèse la plus exigeante du dispositif —
    effet faible, donc volume élevé.

    Retourne (k, n, p0) ou None si pas encore testable.
    """
    SRC = 'moves_detail_hist.csv'
    try:
        fh = open(SRC, encoding='utf-8')
    except OSError:
        print(f"  {SRC} absent.")
        return None

    retenus, n_in, n_zone = [], 0, 0
    with fh:
        for r in csv.DictReader(fh):
            try:
                cote = float(r['entry'])
                pin_open = float(r['pin_open'])
            except (TypeError, ValueError, KeyError):
                continue
            if pin_open >= H16_PIN_OPEN_MAX:
                continue
            n_zone += 1
            d = str(r.get('date') or '')[:10]
            if not d or d < FREEZE_DATE_H16:
                n_in += 1
                continue
            g = r.get('steame_gagne')
            if g not in ('oui', 'non'):
                continue
            try:
                pnl = float(r['pnl'])
            except (TypeError, ValueError, KeyError):
                pnl = (cote - 1.0) if g == 'oui' else -1.0
            retenus.append((1 if g == 'oui' else 0, cote, pnl))

    print(f"  {SRC} : {n_zone} pari(s) avec pin_open < {H16_PIN_OPEN_MAX:.2f} "
          f"· {n_in} in-sample (écartés)")
    if not retenus:
        print("  aucun pari out-of-sample dénoué — trop tôt.")
        return None

    k = sum(w for w, _, _ in retenus)
    n = len(retenus)
    p0 = sum(1.0 / c for _, c, _ in retenus) / n
    _, lo, hi = wilson(k, n)
    pnls = [p for _, _, p in retenus]
    roi = 100.0 * (sum(pnls) / n)
    ic = 196.0 * _ecart_type(pnls) / math.sqrt(n) if n > 1 else 0.0
    print(f"  OUT-OF-SAMPLE : {k}/{n} = {100 * k / n:.1f} % de gains "
          f"IC95 [{100 * lo:.1f} ; {100 * hi:.1f}]")
    print(f"  seuil de rentabilité p0 = {100 * p0:.1f} % · "
          f"écart {100 * k / n - 100 * p0:+.1f} points")
    print(f"  ROI RÉEL {roi:+.1f} % [{roi - ic:+.1f} ; {roi + ic:+.1f}] "
          f"· P&L {sum(pnls):+.1f} u")
    print(f"  référence in-sample au gel, NON confirmatoire : "
          f"429/580 = 74,0 % · seuil 70,2 % · ROI +5,5 %")
    if n < 30:
        print(f"  n={n} < 30 — trop tôt (règle maison). ~161 paris/mois "
              f"attendus, l'IC95 franchit le seuil vers n=600.")
    return (k, n, p0)


def ecart_entree_watch():
    """17e hypothèse gelée : l'écart du prix d'entrée au prix Pinnacle
    d'ouverture, entre 0 et 3 %.

        « Parier le côté steamé au book d'entrée quand son prix dépasse
          de 0 à 3 % le prix PINNACLE À L'OUVERTURE du même côté. »

    Gelée le 2026-09-25.

    ── CORRECTION DU 27/09/2026 : L'ARGUMENT INITIAL ÉTAIT FAUX ────────
    Cette hypothèse a d'abord été justifiée par une corrélation de +0,59
    entre l'écart d'entrée et le CLV — présentée comme « de loin le
    meilleur prédicteur jamais mesuré, contre 0,06 à 0,24 pour le reste ».

    C'EST UN ARTEFACT DE CONSTRUCTION :

        écart = entry / pin_open  - 1
        CLV   = entry / pin_close - 1

    `entry` figure au numérateur des DEUX, et sa variance représente 96 %
    de celle du CLV. Les deux quantités sont presque la même chose vue
    sous deux angles ; leur corrélation ne mesure pas un lien, elle
    mesure un terme partagé.

    En retirant ce terme — écart contre mouvement PINNACLE seul
    (pin_open/pin_close), où `entry` ne figure plus :

        corrélation brute (écart ; CLV)          +0,5866
        écart vs mouvement Pinnacle seul         -0,5173   <- SIGNE INVERSÉ

    Le lien réel est NÉGATIF : un écart d'entrée élevé va de pair avec un
    mouvement Pinnacle défavorable. L'argument initial ne tient pas.

    CE QUI JUSTIFIE LE GEL, C'EST LA SEULE RÉPLICATION DU ROI :
        1re moitié  +10,6 %
        2e  moitié  +14,1 %
    3,5 points d'écart. Rien d'autre. L'hypothèse repose sur une jambe,
    pas deux — et il faut le savoir en lisant son verdict.

    ── LE GRADIENT DU CLV RESTE VRAI, MAIS N'EST PAS UN ARGUMENT ───────
        écart      n      CLV vs Pin médian   CLV>0
        < 0 %    1108           +0,90 %       54,9 %
        0-3 %     255           +4,30 %       83,9 %
        3-6 %      87           +8,50 %       93,1 %
        6-10 %     49          +13,40 %       89,8 %
        > 10 %     42          +28,90 %       97,6 %

    Il est monotone, mais mécanique : un prix très au-dessus du marché
    sharp a peu de chances d'être rattrapé. C'est une tautologie, pas une
    découverte.

    ── MAIS LE ROI, LUI, NE SUIT PAS LE GRADIENT ───────────────────────
        < 0 %    ROI  -2,4 %      3-6 %   ROI  +4,3 %
        -3 à 0   ROI  +3,3 %      6-10 %  ROI -19,5 %
        0-3 %    ROI +12,4 %      > 10 %  ROI +74,6 %

    Aucune monotonie. C'est la dissociation CLV/ROI, déjà démontrée par
    la tranche de cote > 6,00 (+23 % de CLV, -34 % de ROI).

    ── POURQUOI 0-3 % ET PAS > 10 % ────────────────────────────────────
    > 10 % affiche +74,6 % de ROI et p=0,0222, avec une réplication
    apparente (+93,0 % puis +56,2 %). Mais sur 42 paris, soit 21 par
    moitié : à ce volume, +93 % signifie « deux ou trois gros outsiders
    sont passés ». Écartée.

    0-3 % est retenue pour sa RÉPLICATION :
        1re moitié  ROI +10,6 %
        2e  moitié  ROI +14,1 %
    3,5 points d'écart — la meilleure réplication du dispositif, devant
    H15 (+24,7 -> +21,8) et H16 (+4,3 -> +6,6).

    Et son mécanisme est intelligible : un prix 0 à 3 % au-dessus de
    Pinnacle est un décalage réel mais modéré. Au-delà, on entre dans les
    situations où le marché a probablement raison d'offrir mieux.

    ── RÉSERVES ────────────────────────────────────────────────────────
    p = 0,0439, juste sous le seuil, sur SIX tranches testées. Après
    Bonferroni il remonte à 0,26. C'est la réplication qui justifie ce
    gel, pas la significativité — comme pour H15 et H16.

    Le croisement avec la cote ne donne rien de net : quatre sous-groupes
    entre +5,7 % et +22,1 %, tous avec p > 0,20 sur 36 à 75 paris.

    Référence in-sample, NON confirmatoire :
        n=255 · 152 gains · 59,6 % · seuil 54,1 % · écart +5,5
        ROI +12,4 % · P&L +31,6 u · CLV médian +6,1 % · cote médiane 1,85

    Volume : ~71 paris/mois. L'IC95 franchit le seuil vers n=350, soit
    environ 5 mois.

    Retourne (k, n, p0) ou None si pas encore testable.
    """
    SRC = 'moves_detail_hist.csv'
    try:
        fh = open(SRC, encoding='utf-8')
    except OSError:
        print(f"  {SRC} absent.")
        return None

    retenus, n_in, n_zone = [], 0, 0
    with fh:
        for r in csv.DictReader(fh):
            try:
                cote = float(r['entry'])
                pin_open = float(r['pin_open'])
            except (TypeError, ValueError, KeyError):
                continue
            if not pin_open:
                continue
            # ÉCART CAUSAL : prix payé vs prix Pinnacle à l'OUVERTURE.
            # pin_open, pas pin_close — voir la note sur H17 plus haut.
            ecart = 100.0 * (cote / pin_open - 1.0)
            if not (H17_ECART_MIN <= ecart < H17_ECART_MAX):
                continue
            n_zone += 1
            d = str(r.get('date') or '')[:10]
            if not d or d < FREEZE_DATE_H17:
                n_in += 1
                continue
            g = r.get('steame_gagne')
            if g not in ('oui', 'non'):
                continue
            try:
                pnl = float(r['pnl'])
            except (TypeError, ValueError, KeyError):
                pnl = (cote - 1.0) if g == 'oui' else -1.0
            retenus.append((1 if g == 'oui' else 0, cote, pnl))

    print(f"  {SRC} : {n_zone} pari(s) avec écart "
          f"{H17_ECART_MIN:.0f}-{H17_ECART_MAX:.0f} % · {n_in} in-sample (écartés)")
    if not retenus:
        print("  aucun pari out-of-sample dénoué — trop tôt.")
        return None

    k = sum(w for w, _, _ in retenus)
    n = len(retenus)
    p0 = sum(1.0 / c for _, c, _ in retenus) / n
    _, lo, hi = wilson(k, n)
    pnls = [p for _, _, p in retenus]
    roi = 100.0 * (sum(pnls) / n)
    ic = 196.0 * _ecart_type(pnls) / math.sqrt(n) if n > 1 else 0.0
    print(f"  OUT-OF-SAMPLE : {k}/{n} = {100 * k / n:.1f} % de gains "
          f"IC95 [{100 * lo:.1f} ; {100 * hi:.1f}]")
    print(f"  seuil de rentabilité p0 = {100 * p0:.1f} % · "
          f"écart {100 * k / n - 100 * p0:+.1f} points")
    print(f"  ROI RÉEL {roi:+.1f} % [{roi - ic:+.1f} ; {roi + ic:+.1f}] "
          f"· P&L {sum(pnls):+.1f} u")
    print(f"  référence in-sample au gel, NON confirmatoire : "
          f"152/255 = 59,6 % · seuil 54,1 % · ROI +12,4 %")
    if n < 30:
        print(f"  n={n} < 30 — trop tôt (règle maison). ~71 paris/mois "
              f"attendus, l'IC95 franchit le seuil vers n=350.")
    return (k, n, p0)


def _watch_generique(lib, freeze, garde, desc, ref, cible, debit):
    """Moteur commun aux watchers définis par un simple filtre cote /
    pin_open. Évite de recopier une cinquième fois la même boucle — et
    surtout d'y introduire une divergence silencieuse d'une hypothèse à
    l'autre.

    `garde(cote, pin_open)` renvoie True si le pari appartient à
    l'hypothèse. Tout le reste — séparation in/out-of-sample, Wilson,
    ROI réel, P&L — est identique pour toutes.
    """
    SRC = 'moves_detail_hist.csv'
    try:
        fh = open(SRC, encoding='utf-8')
    except OSError:
        print(f"  {SRC} absent.")
        return None

    retenus, n_in, n_zone = [], 0, 0
    with fh:
        for r in csv.DictReader(fh):
            try:
                cote = float(r['entry'])
                pin_open = float(r['pin_open'])
            except (TypeError, ValueError, KeyError):
                continue
            if not pin_open or not garde(cote, pin_open):
                continue
            n_zone += 1
            d = str(r.get('date') or '')[:10]
            if not d or d < freeze:
                n_in += 1
                continue
            g = r.get('steame_gagne')
            if g not in ('oui', 'non'):
                continue
            try:
                pnl = float(r['pnl'])
            except (TypeError, ValueError, KeyError):
                pnl = (cote - 1.0) if g == 'oui' else -1.0
            retenus.append((1 if g == 'oui' else 0, cote, pnl))

    print(f"  {SRC} : {n_zone} pari(s) — {desc} · {n_in} in-sample (écartés)")
    if not retenus:
        print("  aucun pari out-of-sample dénoué — trop tôt.")
        return None

    k = sum(w for w, _, _ in retenus)
    n = len(retenus)
    p0 = sum(1.0 / c for _, c, _ in retenus) / n
    _, lo, hi = wilson(k, n)
    pnls = [p for _, _, p in retenus]
    roi = 100.0 * (sum(pnls) / n)
    ic = 196.0 * _ecart_type(pnls) / math.sqrt(n) if n > 1 else 0.0
    print(f"  OUT-OF-SAMPLE : {k}/{n} = {100 * k / n:.1f} % de gains "
          f"IC95 [{100 * lo:.1f} ; {100 * hi:.1f}]")
    print(f"  seuil de rentabilité p0 = {100 * p0:.1f} % · "
          f"écart {100 * k / n - 100 * p0:+.1f} points")
    print(f"  ROI RÉEL {roi:+.1f} % [{roi - ic:+.1f} ; {roi + ic:+.1f}] "
          f"· P&L {sum(pnls):+.1f} u")
    print(f"  référence in-sample au gel, NON confirmatoire : {ref}")
    print(f"  avancement {n}/{cible} ({100 * n / cible:.0f} %) · "
          f"~{debit} paris/mois attendus")
    if n < 30:
        print(f"  n={n} < 30 — trop tôt (règle maison).")
    return (k, n, p0)


def favorite_steam_value_watch():
    """18e hypothèse gelée : favori déjà net ET prix soft encore proche
    de l'ouverture Pinnacle.

        « Parier le côté steamé au book d'entrée quand pin_open < 1,80
          ET que le prix d'entrée dépasse de 0 à 3 % ce pin_open. »

    Gelée le 2026-09-27. Intersection STRICTE de H16 et H17 : aucun
    seuil nouveau n'a été ajusté après coup.

    ── POURQUOI ELLE EST LE MEILLEUR RÉSULTAT DU DISPOSITIF ────────────
    Référence in-sample : n=123 · 96 gains = 78,0 % contre 70,2 % de
    seuil · écart +7,9 · ROI +11,8 % · P&L +14,6 u · p exact 0,0322.

    RÉPLICATION : +12,4 % puis +11,2 %. UN POINT DEUX d'écart — la
    meilleure stabilité mesurée, devant H17 (3,5 pts) et H15 (3 pts).

    ROBUSTESSE, et c'est là qu'elle se distingue vraiment :
        sans le meilleur pari   ROI +11,3 %
        sans les 3 meilleurs    ROI +10,1 %
        sans les 5 meilleurs    ROI  +9,0 %
        sans les 10 meilleurs   ROI  +6,1 %
    Les 5 meilleurs paris ne font que 27 % du P&L, contre 63 % pour H16
    seule. Le résultat ne tient pas à une poignée de coups.

    PLACEBO (500 tirages) : plage [-9,7 ; +9,8], observé +11,8 % — hors
    plage.

    ── MÉCANISME ───────────────────────────────────────────────────────
    Pinnacle tenait déjà le joueur pour favori net, puis raccourcit
    encore sa cote — et un book mou laisse malgré tout un prix proche du
    niveau d'ouverture Pinnacle. On achète après confirmation du
    mouvement tout en conservant l'ancien prix sharp.

    ── POURQUOI PAS DE VARIANTE SANS LES < 1,30 ────────────────────────
    Découpage de H18 par pin_open :
        < 1,20       n=16  écart  +6,3  ROI  +7,6 %
        1,20-1,30    n=17  écart  +9,5  ROI +12,3 %
        1,30-1,50    n=39  écart  +2,5  ROI  +3,6 %
        1,50-1,80    n=51  écart +12,0  ROI +19,3 %

    Les ultra-favoris sont ici PARMI LES MEILLEURS. Ce qui les rendait
    mauvais dans H16 seule, c'est l'absence de filtre de prix : la marge
    du book écrase tout sur une cote à 1,15. Le filtre d'écart 0-3 %
    garantit déjà un bon prix, et les ultra-favoris redeviennent bons.
    Les exclure ici serait une erreur.

    ── RÉSERVE ─────────────────────────────────────────────────────────
    L'IC95 du taux de gain [69,9 ; 84,5] CONTIENT le seuil de 70,2 % —
    de très peu. p=0,0322 sur un croisement choisi après coup ; H18 n'est
    pas indépendante de H16 et H17, dont elle est un sous-ensemble. Holm
    en tiendra compte.

    Volume : ~34 paris/mois. L'IC95 franchit le seuil vers n=150, soit
    environ 4,4 mois.

    Retourne (k, n, p0) ou None si pas encore testable.
    """
    return _watch_generique(
        lib='H18', freeze=FREEZE_DATE_H18,
        garde=lambda cote, pin_open: (
            pin_open < H16_PIN_OPEN_MAX
            and H17_ECART_MIN <= 100.0 * (cote / pin_open - 1.0) < H17_ECART_MAX),
        desc=f"pin_open < {H16_PIN_OPEN_MAX:.2f} & écart "
             f"{H17_ECART_MIN:.0f}-{H17_ECART_MAX:.0f} %",
        ref="96/123 = 78,0 % · seuil 70,2 % · ROI +11,8 %",
        cible=150, debit=34)


def favori_sans_ultra_watch():
    """19e hypothèse gelée : H16 privée des ultra-favoris.

        « Parier le côté steamé au book d'entrée quand le prix PINNACLE
          À L'OUVERTURE se situe entre 1,30 et 1,80. »

    Gelée le 2026-09-27. Le seul seuil ajouté à H16 est la borne basse
    1,30.

    ── CE QUE LE RETRAIT APPORTE ───────────────────────────────────────
                          n     écart    ROI      P&L      p
        H16 (< 1,80)     580     +3,8   +5,5 %  +31,8 u  0,0246
        H16-B (1,30-1,80) 463    +4,7   +7,0 %  +32,6 u  0,0163
        zone retirée      117     -0,0   -0,7 %   -0,8 u  0,5650

    Le retrait améliore TOUT — écart, ROI, p — et même le P&L absolu
    malgré 117 paris en moins. La zone retirée a un écart de EXACTEMENT
    zéro et une réplication qui s'inverse (+3,4 % puis -4,7 %).

    RÉPLICATION de H16-B : +3,8 % puis +10,3 %.

    ── L'ARGUMENT N'EST PAS QUE STATISTIQUE ────────────────────────────
    Sur 2 915 matchs, la dérive du favori d'ouverture vers la clôture
    croît avec sa force :
        proba 50-60 %   renforcement 41,2 %  dérive 36,7 %
        proba 60-70 %   renforcement 35,0 %  dérive 41,6 %
        proba 70-80 %   renforcement 34,0 %  dérive 41,7 %
        proba > 80 %    renforcement 23,4 %  dérive 47,4 %

    Les très gros favoris dérivent deux fois plus souvent qu'ils ne se
    renforcent. Il y a donc une RAISON de les exclure, pas seulement un
    chiffre favorable — c'est ce qui distingue ce raffinement d'un
    découpage opportuniste.

    ── RÉSERVE ─────────────────────────────────────────────────────────
    H16-B est un SOUS-ENSEMBLE de H16, gelée deux jours plus tôt. Les
    deux ne sont pas indépendantes et Holm en tiendra compte. Le seuil
    1,30 a été choisi APRÈS avoir vu le découpage.

    ATTENTION : ce retrait vaut pour H16 SEULE. Dans H18, les
    ultra-favoris sont parmi les meilleurs (+6,3 et +9,5 d'écart sous
    1,30) parce que le filtre d'écart garantit déjà un bon prix. Ne pas
    transposer.

    Volume : ~129 paris/mois. L'IC95 franchit le seuil vers n=400, soit
    environ 3,1 mois.

    Retourne (k, n, p0) ou None si pas encore testable.
    """
    return _watch_generique(
        lib='H16-B', freeze=FREEZE_DATE_H16B,
        garde=lambda cote, pin_open: (
            H16B_PIN_OPEN_MIN <= pin_open < H16_PIN_OPEN_MAX),
        desc=f"pin_open {H16B_PIN_OPEN_MIN:.2f}-{H16_PIN_OPEN_MAX:.2f}",
        ref="330/463 = 71,3 % · seuil 66,5 % · ROI +7,0 %",
        cible=400, debit=129)


FREEZE_DATE_CANAL = '2026-10-26'   # 20e hypothèse : les alertes MISER elles-mêmes
CANAL_JOURNAL = 'paper_trades_canal.jsonl'


def canal_miser_watch():
    """20e hypothèse gelée : les ALERTES MISER du canal public.

        « Parier ce que le canal envoie, tel qu'il l'envoie : EV >= 5 %
          contre le fair Shin-Pinnacle, palier 5 points, au book retenu
          par le dispositif. »

    Gelée le 2026-10-26. AUCUN seuil nouveau — on gèle la règle TELLE
    QU'ELLE TOURNE, sans retoucher l'EV ni le palier.

    ── POURQUOI UNE HYPOTHÈSE SÉPARÉE ──────────────────────────────────
    Les 19 autres portent sur moves_detail_hist, la RECONSTRUCTION des
    mouvements. Les alertes envoyées sont une population DISTINCTE —
    mesuré le 25/09 sur 77 matchs communs :

        côtés steamés différents   31 %
        books différents           68 %
        lead médian  alerte 391 min  vs  reconstruction 759 min

    Aucune des 19 ne décrit donc ce que le canal envoie réellement.

    ── RÉFÉRENCE AU GEL (04/08 -> 02/10) ───────────────────────────────
        239 alertes · 176 dénouées
        gains   86/176 = 48,9 %   (seuil 41,1 %)
        écart   +7,7 pts · IC95 du taux [41,6 ; 56,2]
        ROI     +24,3 % [+0,7 ; +48,0] · P&L +42,83 u
        binomial p = 0,0229 · cote médiane 2,50

    NON CONFIRMATOIRE : le seuil d'EV, le palier et les filtres ont été
    ajustés PENDANT que ces 176 paris s'accumulaient.

    ── DEUX RÉSERVES, INSCRITES AU GEL ─────────────────────────────────
    CONCENTRATION — 72 % du P&L sur CINQ paris, tous au-dessus de 2,50.
    C'est la pire du dispositif (H16-B 15 %, H18 27 %). Sans eux, la
    tranche > 2,50 tombe à -1,0 % de ROI sur 85 paris, et l'ensemble à
    +7,0 %.

    RÉPLICATION QUI MONTE — +15,0 % puis +33,7 %, écart +1,0 puis +14,5.
    Une seconde moitié bien meilleure que la première est le profil d'un
    résultat porté par quelques coups récents, pas d'un effet régulier.
    On attend l'inverse d'une hypothèse solide : deux moitiés proches.

    ── CE QU'ON NE FAIT PAS ────────────────────────────────────────────
    On NE retire PAS les cotes > 2,50, alors même qu'on vient de voir
    que tout le résultat vient de là. Choisir la borne APRÈS avoir vu
    le résultat, c'est exactement le biais que le gel existe pour
    empêcher. Si la zone doit tomber, elle tombera hors échantillon.

    Cible 400 (et non 300) : avec une concentration pareille il faut du
    volume pour que cinq paris cessent de dominer. Débit ~89 dénouées
    par mois, soit un verdict vers janvier 2027.

    Retourne (k, n, p0) ou None si pas encore testable.
    """
    try:
        lignes = [json.loads(x) for x in open(CANAL_JOURNAL, encoding='utf-8')
                  if x.strip()]
    except (OSError, ValueError):
        print('  H20 : journal du canal illisible.')
        return None

    oos = []
    for r in lignes:
        if r.get('gagne') is None or r.get('pnl') is None:
            continue
        t = str(r.get('alerte_t') or '')[:10]
        if t < FREEZE_DATE_CANAL:
            continue
        try:
            oos.append((float(r['cote']), 1 if r['gagne'] else 0, float(r['pnl'])))
        except (TypeError, ValueError):
            continue

    n = len(oos)
    k = sum(g for _, g, _ in oos)
    print(f"\n  H20 — alertes MISER du canal (gel {FREEZE_DATE_CANAL})")
    print(f"     référence : 86/176 = 48,9 % · seuil 41,1 % · ROI +24,3 %")
    if n < 30:
        print(f"     hors échantillon {n}/400 — pas encore testable (n<30)")
        return None
    p0 = sum(1.0 / c for c, _, _ in oos) / n
    roi = 100 * sum(p for _, _, p in oos) / n
    print(f"     hors échantillon {n}/400 ({100*n/400:.0f} %) · "
          f"{k}/{n} = {100*k/n:.1f} % · seuil {100*p0:.1f} % · ROI {roi:+.1f} %")
    return (k, n, p0)


# ══ VERDICTS EN DIRECT (décision du 16/10/2026) ══════════════════════════
# Les hypothèses H13…H18 se jugent désormais sur les ALERTES EN DIRECT
# (h*_signal_log.jsonl, champs de décision écrits une fois) complétées par
# scripts/suivi_direct.py -> verdicts_direct.json. La reconstruction
# (moves_detail_hist.csv, fonctions *_watch ci-dessus) n'est plus affichée
# qu'en ligne « contrôle ».
#
# NOMS NOUVEAUX (« … (direct) ») : un verdict déjà verrouillé dans
# verdicts_geles.json sur la reconstruction n'est JAMAIS réécrit ; la lecture
# en direct sera verrouillée à part, à N_CIBLE paris dénoués EN DIRECT.
VERDICTS_DIRECT = 'verdicts_direct.json'


def _direct(code, controle):
    def watch():
        try:
            doc = json.load(open(VERDICTS_DIRECT, encoding='utf-8'))
        except (OSError, ValueError):
            print(f"  {VERDICTS_DIRECT} absent : lancer scripts/suivi_direct.py.")
            doc = {'hypotheses': []}
        h = next((x for x in doc.get('hypotheses', []) if x.get('code') == code), None)
        o = (h or {}).get('out_of_sample') or {}
        print(f"  EN DIRECT ({VERDICTS_DIRECT}, {doc.get('genere_le', '?')}) : "
              f"{o.get('n_detectees', 0)} détectée(s) · {o.get('n_envoyees', 0)} envoyée(s) · "
              f"{o.get('n', 0)} dénouée(s)")
        if o.get('n'):
            print(f"  gains {o['gains']}/{o['n']} = {o['taux']} % (seuil {o['seuil']} %) · "
                  f"écart {o['ecart']:+} pts · ROI {o['roi']:+} % · CLV Pinnacle "
                  f"{o.get('clv_pin_moyen')} % IC95 {o.get('clv_pin_ic95')}")
        with contextlib.redirect_stdout(io.StringIO()):
            c = controle()
        if c:
            print(f"  contrôle (reconstruction moves_detail_hist, NE JUGE PAS) : "
                  f"{c[0]}/{c[1]} · seuil {100 * c[2]:.1f} % · écart {100 * (c[0] / c[1] - c[2]):+.1f} pts")
        # GARDE (16/10/2026) : pas de verrouillage tant que > 10 % des
        # détections de matchs commencés sont sans résultat, quel que soit n.
        watch.attente = None if o.get('verrouillable', True) else o.get('statut')
        print(f"  statut : {o.get('statut', '—')}")
        if not o.get('n'):
            return None
        return (o['gains'], o['n'], o['seuil'] / 100.0)
    watch.attente = None
    watch.__name__ = f'direct_{code.lower()}'
    return watch


HYPOTHESES = [
    ('calibration 2,20-3,50', FREEZE_DATE,           calibration_watch),
    ('heure du match',        FREEZE_DATE,           hour_watch),
    ('variation de marge',    FREEZE_DATE_MARGIN,    margin_watch),
    ('round',                 FREEZE_DATE_ROUND,     round_watch),
    ('gros move',             FREEZE_DATE_BIGMOVE,   bigmove_watch),
    ('ouverture précoce',     FREEZE_DATE_EARLYOPEN, earlyopen_watch),
    ('renforcement outsider', FREEZE_DATE_REINFORCE, reinforce_watch),
    ('book réactif',          FREEZE_DATE_REACTIVE,  reactive_watch),
    ('seuil adaptatif',       FREEZE_DATE,           adaptive_threshold_watch),
    ('confirmation Betfair',  FREEZE_DATE_BETFAIR,   betfair_confirm_watch),
    ('âge du mouvement',      FREEZE_DATE_MOVEAGE,   move_age_watch),
    # AJOUTÉE LE 05/09/2026. Tant qu'elle n'a pas 30 observations
    # out-of-sample, le filtre `testables` de bilan_tests_multiples
    # l'exclut : elle ne consomme pas de créneau Holm et ne durcit
    # donc pas le seuil des douze autres.
    ('Kalshi mène Pinnacle',  FREEZE_DATE_KXLEAD,    kalshi_lead_watch),
    # AJOUTÉE LE 06/09/2026. PREMIÈRE hypothèse portant sur le ROI et non
    # sur le CLV. N_CIBLE est déjà atteint sur l'historique : le filtre
    # out-of-sample est la SEULE chose qui l'empêche de se valider sur
    # les données qui l'ont fait naître.
    ('ROI bande cote 2-3 (direct)', FREEZE_DATE_ROIBANDE, _direct('H13', roi_bande_watch)),
    # AJOUTÉE LE 07/09/2026, depuis le rapport de robustesse externe.
    # Seule la stratégie A est gelée : B et C (bande de cote 2,50-4,00)
    # sont des sous-ensembles corrélés, à 23 et 12 observations
    # récentes, issus d'un espace de 448 combinaisons dont 33 %
    # ressortent significatives par pure recherche.
    ('amplitude + timing (direct)', FREEZE_DATE_AMPLI, _direct('H14', roi_ampli_watch)),
    # AJOUTÉE LE 25/09/2026. Bande LARGE volontairement : le noyau
    # 2,70-2,90 fait mieux (+16,3 d'écart, p=0,0021) mais c'est le
    # maximum d'un balayage de ~20 découpages, sur 29 paris récents.
    ('bande cote 2,40-3,10 (direct)', FREEZE_DATE_H15, _direct('H15', bande_240_310_watch)),
    # AJOUTÉE LE 25/09/2026. Filtre sur pin_open (prix PINNACLE à
    # l'ouverture), PAS sur la cote d'entrée : le même seuil sur la
    # cote d'entrée donne p=0,0933, soit rien. Disjointe de H15 :
    # recouvrement 0/580.
    ('favori net (pin<1,80) (direct)', FREEZE_DATE_H16, _direct('H16', bande_favori_watch)),
    # AJOUTÉE LE 25/09/2026. Écart CAUSAL entrée/Pinnacle ouverture.
    # Ne pas confondre avec clv_vs_pin_pct, qui utilise pin_close et
    # n'existe qu'après le coup d'envoi — ce serait du look-ahead.
    ('écart entrée 0-3 % (direct)', FREEZE_DATE_H17, _direct('H17', ecart_entree_watch)),
    # AJOUTÉES LE 27/09/2026. NI L'UNE NI L'AUTRE N'EST INDÉPENDANTE :
    # H18 est l'intersection de H16 et H17, H16-B un sous-ensemble de
    # H16. Holm doit en tenir compte — quatre hypothèses corrélées.
    ('favorite steam value (direct)', FREEZE_DATE_H18, _direct('H18', favorite_steam_value_watch)),
    ('favori sans ultra (direct)', FREEZE_DATE_H16B, _direct('H16B', favori_sans_ultra_watch)),
    # AJOUTÉE LE 26/10/2026 — 20e hypothèse. Les 19 autres mesurent la
    # RECONSTRUCTION des mouvements ; celle-ci mesure ce que le canal
    # ENVOIE. Deux populations distinctes (31 % de côtés différents,
    # 68 % de books différents, T-391 contre T-759 min).
    ('alertes MISER canal',  FREEZE_DATE_CANAL,     canal_miser_watch),
]


def rappel_value_clv(fichier='value_clv_report.json'):
    """AJOUTÉ LE 27/08/2026 (audit §3.7) : une réfutation propre mérite
    autant de visibilité qu'un signal qui survit -- sinon le rapport ne
    montre que ce qui a marché, ce qui est exactement le biais que tout ce
    dispositif existe pour combattre. Le détecteur de « value » sélectionne
    des paris dont le CLV est MOINS bon que celui des matchs non
    sélectionnés (corrélation score/CLV légèrement négative, n=374)."""
    if not os.path.exists(fichier):
        return
    try:
        d = json.load(open(fichier, encoding='utf-8'))
    except (OSError, ValueError):
        return
    print(f"\n{'=' * 60}\nRÉFUTATION (à garder visible, pas seulement les signaux qui "
          f"survivent) — détecteur de value")
    print(f"  candidats     : CLV moyen {d.get('candidats_clv_moyen', 0):+.2f}% | "
          f"%positif {d.get('candidats_clv_pct_positif', 0):.1f}% "
          f"(n={d.get('n_candidats_avec_clv', '?')})")
    print(f"  non-candidats : CLV moyen {d.get('non_candidats_clv_moyen', 0):+.2f}%")
    print(f"  corr(score, CLV) = {d.get('corr_score_clv', 0):+.3f}")
    print("  Le détecteur sélectionne des paris au CLV MOINS bon que le "
          "tout-venant -- réfutation propre, à ne pas retester sous une "
          "autre forme sans nouveau protocole daté.")


def report_canal(fichier='paper_trades_canal.jsonl',
                 clv_fichier='canal_clv_detail.csv'):
    """Lecteur DÉDIÉ pour le journal canal (audit §1.2, 27/08/2026).

    Schéma différent du journal forward : statut='REGLE' (pas status=
    'SETTLED'), gagne (pas won), pas de clv_book natif -- le CLV est joint
    depuis canal_clv_detail.csv (indexé uid+book) plutôt que reconstruit
    approximativement. C'est le SEUL journal avec de vrais résultats ET,
    avant ce correctif, le SEUL sans CLV dans le verdict -- la règle « le
    CLV est la métrique de validation » ne s'appliquait nulle part où il y
    avait de quoi la vérifier.
    """
    if not os.path.exists(fichier):
        return
    trades = [json.loads(l) for l in open(fichier, encoding='utf-8') if l.strip()]
    regles = [t for t in trades if t.get('statut') == 'REGLE']
    ouverts = [t for t in trades if t.get('statut') != 'REGLE']
    print(f"\n{'=' * 60}\nJOURNAL CANAL (produit réellement publié aux abonnés) "
          f"— {len(regles)} réglés | {len(ouverts)} ouverts")
    if not regles:
        print("  (pas encore de pari réglé)")
        return
    clv_par_cle = {}
    if os.path.exists(clv_fichier):
        import csv
        for r in csv.DictReader(open(clv_fichier, encoding='utf-8')):
            try:
                clv_par_cle[(r['uid'], r['book'])] = float(r['clv'])
            except (KeyError, ValueError):
                continue
    clv = [clv_par_cle[(t['uid'], t['book'])] for t in regles
           if (t['uid'], t['book']) in clv_par_cle]
    pnl = [t['pnl'] for t in regles if 'pnl' in t]
    won = [1 if t.get('gagne') else 0 for t in regles]
    if clv:
        pos = sum(1 for x in clv if x > 0)
        p, lo, hi = wilson(pos, len(clv))
        print(f"  CLV (joint via {clv_fichier}) : n={len(clv)} | moyen "
              f"{st.mean(clv):+.2f}% | médian {st.median(clv):+.2f}% | "
              f"positif {100 * p:.0f}% (IC95 {100 * lo:.0f}-{100 * hi:.0f}%)")
    else:
        print(f"  ⚠️ aucun CLV apparié via {clv_fichier} (uid+book absents "
              f"du fichier de calibration)")
    if pnl:
        n = len(pnl)
        # CORRIGÉ LE 27/08/2026 (audit v2 §F) : cette fonction recalculait
        # son IC à la main (approximation normale) alors que mean_ci() a été
        # réécrite en bootstrap précisément pour ce cas -- un P&L de pari
        # bimodal/asymétrique à cote moyenne ~2,9, sur LE journal qui a de
        # vrais résultats. L'ancien calcul manuel n'était pas faux (le x100
        # était correct), juste redondant avec un outil déjà construit pour
        # être plus fiable ici.
        m, lo, hi, _sd = mean_ci(pnl)
        roi, ic_lo, ic_hi = 100 * m, 100 * lo, 100 * hi
        wr = 100 * sum(won) / len(won) if won else 0
        print(f"  ROI RÉEL : n={n} | {roi:+.1f}% [IC95 {ic_lo:+.1f}%, "
              f"{ic_hi:+.1f}%] | {wr:.0f}% gagnés")


def main():
    files = sorted(glob.glob(JOURNALS))
    if not files:
        print(f"Aucun journal trouve ({JOURNALS}). Le pipeline n'a pas encore ouvert/denoue de pari.")
        return
    print("TABLEAU DE VALIDATION FORWARD — steam-following")
    print(f"{len(HYPOTHESES)} hypothèses gelées suivies — verdicts individuels à lire à travers le filtre Holm-Bonferroni (bilan en fin de rapport).")
    print("Regle : un edge n'est CONFIRME que si la borne basse de l'IC95 exclut 0 (ROI) / 50% (CLV+).")
    for f in files:
        # CORRIGÉ LE 27/08/2026 (audit §1.2) : paper_trades_canal.jsonl a un
        # schéma différent (statut/gagne vs status/won) — report_group() le
        # filtrait sur 'status' == 'SETTLED', qui n'existe jamais dans ce
        # fichier, donc affichait silencieusement « pas encore dénoué » alors
        # que 77 paris y sont réglés. C'est le SEUL journal qui reflète ce
        # que reçoivent vraiment les abonnés (68 alertes canal vs 17 au
        # journal forward le 24/08) -- il a désormais son lecteur dédié,
        # appelé séparément plus bas.
        if os.path.basename(f) == 'paper_trades_canal.jsonl':
            continue
        name = os.path.basename(f).replace('paper_trades_', 'surface ').replace('.jsonl', '')
        trades = []
        for line in open(f, encoding='utf-8'):
            line = line.strip()
            if line:
                try: trades.append(json.loads(line))
                except Exception: pass
        report_group(name, trades)
    report_canal()
    rappel_value_clv()
    print(f"\n{'='*60}\nRappel : CLV+ = prix battu ; le ROI net subit encore marge + gubbing.")
    resultats = []
    for i, (nom, gel, w) in enumerate(HYPOTHESES, 1):
        print(f"\n─── hypothèse {i}/{len(HYPOTHESES)} : {nom} (gel {gel}) ───")
        resultats.append((nom, gel, w()))
    bilan_tests_multiples(resultats)


if __name__ == '__main__':
    main()
