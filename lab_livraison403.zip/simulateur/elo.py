#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
elo.py — force de chaque joueur, tirée des RÉSULTATS (21/10/2026).

Classement Elo général + Elo par surface, mélangés à parts égales pour prédire
(méthode FiveThirtyEight pour le tennis, décrite par Kovalchik, JQAS 2016 ;
mélange surface/général à 50/50 de Tennis Abstract ; paramètres repris TELS
QUELS, jamais réglés sur nos données) :
    p(A bat B) = 1 / (1 + 10^((elo_B − elo_A) / 400))
    K du joueur = 250 / (matchs joués + 5)^0,4   (un nouveau bouge vite, un ancien lentement)
    K × 1,1 en Grand Chelem
Tout joueur commence à 1500, ATP comme ITF : ce sont les résultats qui placent
chacun à son niveau.

Alimentation : archive Sackmann (jusqu'en juin 2026, tous niveaux), puis NOS
résultats (set_results.json) chaque nuit : aucune source extérieure à jour
n'est nécessaire.

22/10/2026 — OPTIONS (étudiées par backtest_pronostic.py, choisies sur 2023 seulement,
adoptées seulement si elles aident sur 2024–2026) ; par défaut, l'Elo ci-dessus à l'identique :
  — poids_surface : part de l'Elo de la surface dans le mélange (0,5 par défaut) ;
  — welo : Elo pondéré par le score (Angelini, Candila & De Angelis, EJOR 2022) — le
    déplacement est multiplié par la part des jeux gagnés par le vainqueur ; « norme » :
    divisée par sa moyenne d'avant 2023 (0,661), si bien qu'un match au score inconnu
    compte comme dans l'Elo classique ; « brut » : la version publiée (score inconnu : 0,661) ;
  — incertitude c : un joueur peu vu est moins sûr (principe de Glicko) — l'écart de
    niveau est réduit : logit p × 1/√(1 + c·(1/(n_A+5) + 1/(n_B+5))).

Les joueurs sont reconnus par leur NOM, sous une clé insensible à l'ordre des
mots, aux accents, tirets, apostrophes et « Jr » (cle()) : « Christopher
O'Connell », « O Connell Christopher » et « christopher_o_connell » donnent la
même clé.
"""
import math
import re
import unicodedata

SURFACES = ('Hard', 'Clay', 'Grass')
SUFFIXES = {'jr', 'sr', 'ii', 'iii', 'iv'}
PART_JEUX_MOY = 0.661       # part moyenne des jeux du vainqueur, archive Sackmann avant 2023


def cle(nom):
    """Clé insensible à l'ordre des MOTS, jamais à l'ordre de leurs lettres."""
    return ''.join(sorted(mots(nom)))


def _par_collage(court, long_):
    """23/11/2026 (paquet 371) — `court` s'obtient en collant des mots VOISINS de `long_`, dans l'ordre
    (« Soonwoo Kwon » = « Soon Woo Kwon ») : même joueur, l'espace seul diffère."""
    if len(court) >= len(long_):
        return False
    i = 0
    for w in court:
        acc = ''
        while i < len(long_) and len(acc) < len(w):
            acc += long_[i]
            i += 1
        if acc != w:
            return False
    return i == len(long_)


def _meme_ecriture(a, b):
    return tuple(sorted(a)) == tuple(sorted(b)) or _par_collage(a, b) or _par_collage(b, a)


def collisions_identite(noms):
    """Noms réellement différents qui partageraient une clé ; les permutations sont des alias volontaires,
    les mots voisins collés aussi (« Soon Woo Kwon » / « Soonwoo Kwon », paquet 371 : le match était écarté)."""
    groupes = {}
    for nom in noms:
        k = cle(nom)
        if k:
            groupes.setdefault(k, set()).add(tuple(mots(nom)))
    out = []
    for k, toks in groupes.items():
        L = sorted(toks)
        if any(not _meme_ecriture(L[i], L[j]) for i in range(len(L)) for j in range(i + 1, len(L))):
            out.append({'cle': k, 'noms': sorted(' '.join(t) for t in toks)})
    return out


def migrer_etat(etat):
    """Convertit les anciennes clés triées par lettres, sans fusion silencieuse en cas de collision."""
    etat = dict(etat or {})
    joueurs, vus = {}, {}
    for ancienne, v in (etat.get('joueurs') or {}).items():
        nouvelle = cle(v.get('nom')) or ancienne
        if nouvelle in joueurs:
            raise ValueError(f"Collision d'identité pendant la migration Elo : {nouvelle}")
        joueurs[nouvelle] = v
        vus[nouvelle] = v.get('nom', nouvelle)
    etat['joueurs'] = joueurs
    # Les anciennes cibles d'alias ne sont plus fiables : unifier() les reconstruit à partir des noms.
    etat['alias'] = {}
    return etat


def part_jeux(sets):
    """Part des jeux gagnés par le vainqueur, depuis [(jeux vainqueur, jeux perdant), …] ; None si inconnu."""
    try:
        a = sum(int(x) for x, _ in sets)
        t = a + sum(int(y) for _, y in sets)
        return a / t if t else None
    except (TypeError, ValueError):
        return None


class Elo:
    def __init__(self, depart=1500.0, poids_surface=0.5, welo=None, incertitude=0.0):
        self.depart = depart
        self.poids_surface, self.welo, self.incertitude = float(poids_surface), welo, float(incertitude)
        self.g, self.s, self.n, self.ns, self.dep = {}, {}, {}, {}, {}
        self.vit = {}          # 11/11/2026 (paquet 229) : {joueur: multiplicateur de la vitesse K}, vide = 1 pour tous

    def options(self):
        return {'poids_surface': self.poids_surface, 'welo': self.welo, 'incertitude': self.incertitude}

    def presenter(self, j, valeur):
        """Note de départ d'un joueur jamais vu (ex. 1200 s'il débute en Challenger/ITF)."""
        if j not in self.g and j not in self.dep:
            self.dep[j] = valeur

    def regler_vitesse(self, j, v):
        """11/11/2026 (paquet 229) — vitesse propre à un joueur : ses notes bougent v fois plus vite (1 = inchangé).
        Sert à donner une vitesse à tout un circuit (etude_vitesse_elo.py) ; sans appel, rien ne change."""
        if v and v != 1.0:
            self.vit[j] = float(v)
        else:
            self.vit.pop(j, None)

    def _g(self, j):
        return self.g.get(j, self.dep.get(j, self.depart))

    def _s(self, j, surface):
        return self.s.get((j, surface), self.dep.get(j, self.depart))

    def note(self, j, surface=None):
        g = self._g(j)
        if surface not in SURFACES:
            return g
        return (1 - self.poids_surface) * g + self.poids_surface * self._s(j, surface)

    def proba(self, a, b, surface=None):
        """Probabilité que A batte B."""
        z = (self.note(a, surface) - self.note(b, surface)) / 400 * math.log(10)
        if self.incertitude:
            z /= math.sqrt(1 + self.incertitude * (1 / (self.n.get(a, 0) + 5) + 1 / (self.n.get(b, 0) + 5)))
        return 1 / (1 + math.exp(-max(min(z, 50), -50)))

    def matchs(self, j):
        return self.n.get(j, 0)

    @staticmethod
    def _k(n):
        return 250 / (n + 5) ** 0.4

    def maj(self, gagnant, perdant, surface=None, grand_chelem=False, part=None):
        """Met à jour après un match (à appeler APRÈS la prédiction de ce match).
        part : part des jeux gagnés par le vainqueur (option welo)."""
        w, l = gagnant, perdant
        f = 1.1 if grand_chelem else 1.0
        if self.welo == 'brut':
            f *= part if part is not None else PART_JEUX_MOY
        elif self.welo == 'norme' and part is not None:
            f *= part / PART_JEUX_MOY
        gw, gl = self._g(w), self._g(l)
        e = 1 / (1 + 10 ** ((gl - gw) / 400))
        fw, fl = f * self.vit.get(w, 1.0), f * self.vit.get(l, 1.0)
        kw, kl = fw * self._k(self.n.get(w, 0)), fl * self._k(self.n.get(l, 0))
        self.g[w] = gw + kw * (1 - e)
        self.g[l] = gl - kl * (1 - e)
        self.n[w] = self.n.get(w, 0) + 1
        self.n[l] = self.n.get(l, 0) + 1
        if surface in SURFACES:
            sw, sl = (w, surface), (l, surface)
            vw, vl = self._s(w, surface), self._s(l, surface)
            e = 1 / (1 + 10 ** ((vl - vw) / 400))
            kw, kl = fw * self._k(self.ns.get(sw, 0)), fl * self._k(self.ns.get(sl, 0))
            self.s[sw] = vw + kw * (1 - e)
            self.s[sl] = vl - kl * (1 - e)
            self.ns[sw] = self.ns.get(sw, 0) + 1
            self.ns[sl] = self.ns.get(sl, 0) + 1

    def exporter(self, noms):
        """{clé: {'nom', 'elo', 'surfaces': {...}, 'matchs'}} pour les pronostics du jour."""
        out = {}
        for j, g in self.g.items():
            out[j] = {'nom': noms.get(j, j), 'elo': round(g, 1), 'matchs': self.n.get(j, 0),
                      'surfaces': {s: round(self.s[(j, s)], 1) for s in SURFACES if (j, s) in self.s}}
        return out

    @classmethod
    def importer(cls, doc, options=None):
        e = cls(**(options or {}))
        doc = migrer_etat({'joueurs': doc})['joueurs']
        for j, v in doc.items():
            e.g[j] = v['elo']
            e.n[j] = v.get('matchs', 0)
            for s, x in (v.get('surfaces') or {}).items():
                e.s[(j, s)] = x
        return e


def log_loss(p, y):
    p = min(max(p, 1e-6), 1 - 1e-6)
    return -math.log(p if y else 1 - p)


# ------------------------------------------------------------------ identité des joueurs
def mots(nom):
    s = unicodedata.normalize('NFKD', str(nom or '')).encode('ascii', 'ignore').decode().lower()
    return [m for m in re.split(r'[^a-z]+', s) if m and m not in SUFFIXES]


def _sous_suite(court, long_):
    """Les mots de `court` apparaissent dans `long_`, dans le même ordre."""
    i = 0
    for w in long_:
        if i < len(court) and w == court[i]:
            i += 1
    return i == len(court)


def _meme_prenom(x, y):
    """Même premier mot, ou l'un est l'initiale de l'autre (« b » / « benjamin »)."""
    return x == y or (len(x) == 1 and y.startswith(x)) or (len(y) == 1 and x.startswith(y))


def unifier_strict(connus, nouveaux, sexe_connus=None, sexe_nouveaux=None):
    """28/10/2026 — version STRICTE de unifier(), pour les noms venus des résultats ITF (données seulement).
    Audit du 28/10 : sur 52 liens créés par les noms ITF, plusieurs fusionnaient deux joueurs différents
    (« Jose Moreno » → « Maria Jose Luque Moreno », « Pedro Gomes » → « Joao Pedro Gomes Leme », « Yu-Chen Chiu » →
    « Yu Chen »…). Une fusion à tort abîme le classement d'un vrai joueur ; un lien manqué laisse seulement quelques
    résultats ITF de côté. Règle : le nom court est contenu dans le long DANS LE MÊME ORDRE, même premier et même
    dernier mot, au moins deux mots, même sexe (si connu), et un SEUL joueur connu possible ; si le nom court n'a que
    DEUX mots, son nom de famille doit être rare (porté par 5 joueurs connus au plus : « Daniel Silva », « Jose
    Rodriguez », « Raul Garcia » ne sont plus reliés au premier homonyme venu).
    sexe_connus : {clé: 'H'/'F'} ; sexe_nouveaux : {nom: 'H'/'F'}."""
    sexe_connus, sexe_nouveaux = sexe_connus or {}, sexe_nouveaux or {}
    par_mot, toks, nom_famille = {}, {}, {}
    for k, n in connus.items():
        t = mots(n)
        toks[k] = t
        for w in set(t):
            par_mot.setdefault(w, set()).add(k)
        if t:
            nom_famille[t[-1]] = nom_famille.get(t[-1], 0) + 1
    alias = {}
    for n in nouveaux:
        k = cle(n)
        if k in connus or k in alias:
            continue
        t = mots(n)
        if len(t) < 2:
            continue
        cands = set()
        for w in set(t):
            cands |= par_mot.get(w, set())
        bons = set()
        for c in cands:
            a_, b_ = (t, toks[c]) if len(t) <= len(toks[c]) else (toks[c], t)
            # 05/11/2026 : prénom abrégé en initiale (« B. Perez Mora » des résultats ITF = « Benjamín Pérez Mora »)
            if len(a_) < 2 or not _meme_prenom(a_[0], b_[0]) or a_[-1] != b_[-1] or not _sous_suite(a_[1:], b_[1:]):
                continue
            # avec une initiale, TOUS les autres mots du nom abrégé doivent être dans le nom complet
            # (« R. Ferro Duarte » n'est pas « Rodrigo Duarte »)
            ab_, pl_ = (t, toks[c]) if len(t[0]) == 1 and len(toks[c][0]) > 1 else \
                (toks[c], t) if len(toks[c][0]) == 1 and len(t[0]) > 1 else (None, None)
            if ab_ is not None and not _sous_suite(ab_[1:], pl_[1:]):
                continue
            if len(a_) == 2 and nom_famille.get(a_[-1], 0) > 5:
                continue
            sx, sc = sexe_nouveaux.get(n), sexe_connus.get(c)
            if sx and sc and sx != sc:
                continue
            bons.add(c)
        if len(bons) == 1:
            alias[k] = next(iter(bons))
    return alias


def unifier(connus, nouveaux):
    """Relie un nom écrit autrement au joueur déjà connu (22/10/2026).

    « Leylah Fernandez » (OddsPapi) et « Leylah Annie Fernandez » (Sackmann) ont
    des clés différentes : sans ce lien, le même joueur aurait DEUX classements,
    chacun nourri d'une partie de ses résultats. Règle : les mots d'un nom sont
    inclus dans ceux de l'autre (un prénom en plus ou en moins), au moins deux
    mots en commun, et un SEUL joueur connu possible — sinon on ne relie pas.
    connus : {clé: nom} ; nouveaux : noms -> {clé du nouveau: clé du connu}."""
    par_mot, toks = {}, {}
    for k, n in connus.items():
        t = set(mots(n))
        toks[k] = t
        for w in t:
            par_mot.setdefault(w, set()).add(k)
    alias = {}
    for n in nouveaux:
        k = cle(n)
        if k in connus or k in alias:
            continue
        t = set(mots(n))
        if len(t) < 2:
            continue
        cands = set()
        for w in t:
            cands |= par_mot.get(w, set())
        bons = {c for c in cands if (t <= toks[c] or toks[c] <= t) and len(t & toks[c]) >= 2}
        if len(bons) == 1:
            alias[k] = next(iter(bons))
    return alias


# ------------------------------------------------------------------ Départ propre à un niveau (11/11/2026, paquet 230)
# etude_depart_itf.py : un joueur vu d'abord en ITF hommes partait à 1200, comme un joueur vu d'abord en Challenger,
# alors que le niveau est plus bas. À 1000, le Challenger gagne 0,0057 ± 0,0007 de log loss sur 7 722 matchs jugés
# (01/10/2025 → juin 2026), l'ATP ne bouge pas. Lu par le classement de production (backtest_pronostic.py), par
# l'étude hebdomadaire de l'ITF (etude_itf_elo.py) et par les études qui rejouent l'ITF.
# RETRAIT (écrit le 11/11/2026, avant tout match suivi) : à chaque passage, le classement est rejoué une fois de plus
# avec l'ancien départ (1200) ; sur nos matchs Challenger joués à partir du 12/11/2026, dès 300 matchs, si le gain
# cumulé de log loss est négatif de plus de 2 erreurs types, le départ revient à 1200 (backtest_pronostic.py, étape 5).
DEPARTS_PAR_NIVEAU = {'ITFH': 1000.0}
DEPARTS_SUIVI_DEPUIS = '2026-11-12'
DEPARTS_RETRAIT_MIN_MATCHS, DEPARTS_RETRAIT_ERREURS_TYPES = 300, 2.0


def depart_du_niveau(circuit, depart_bas, departs=None):
    """Note de départ d'un joueur vu d'abord à ce niveau : celle du niveau s'il en a une, sinon le départ bas commun.
    departs : {niveau: note} ; None = DEPARTS_PAR_NIVEAU ; {} = aucun départ propre (l'ancien réglage)."""
    return (DEPARTS_PAR_NIVEAU if departs is None else departs).get(circuit, depart_bas)


def departs_en_place(racine=None):
    """Départs propres à un niveau RÉELLEMENT en place : ceux que le dernier classement a écrits dans elo_etat.json
    (vides s'il les a retirés). État absent ou d'avant le paquet 230 : DEPARTS_PAR_NIVEAU."""
    import json
    import os
    chemin = os.path.join(racine, 'simulateur', 'elo_etat.json') if racine else \
        os.path.join(os.path.dirname(os.path.abspath(__file__)), 'elo_etat.json')
    try:
        with open(chemin, encoding='utf-8') as f:
            d = json.load(f).get('departs_par_niveau')
    except (OSError, ValueError):
        d = None
    return dict(DEPARTS_PAR_NIVEAU) if d is None else {k: float(v) for k, v in d.items()}


def suivi_departs(avec, sans, depuis=DEPARTS_SUIVI_DEPUIS):
    """Gain cumulé du départ propre à un niveau. avec, sans : [(date ISO, p du vainqueur)] des MÊMES matchs, dans le
    même ordre, avec le départ en place et avec l'ancien. Renvoie matchs, gain de log loss, erreur type, Brier, retrait."""
    D, b0, b1 = [], 0.0, 0.0
    for (d, p1), (_d, p0) in zip(avec, sans):
        if str(d) < depuis:
            continue
        D.append(log_loss(p0, 1) - log_loss(p1, 1))
        b0 += (1 - p0) ** 2
        b1 += (1 - p1) ** 2
    n = len(D)
    out = {'depuis': depuis, 'matchs': n}
    if n:
        g = sum(D) / n
        se = math.sqrt(sum((x - g) ** 2 for x in D) / (n - 1) / n) if n > 1 else 0.0
        out.update({'gain_log_loss': round(g, 5), 'erreur_type': round(se, 5),
                    'brier_avant': round(b0 / n, 5), 'brier': round(b1 / n, 5)})
        out['retrait'] = bool(n >= DEPARTS_RETRAIT_MIN_MATCHS and g < -DEPARTS_RETRAIT_ERREURS_TYPES * se)
    else:
        out['retrait'] = False
    return out


# ------------------------------------------------------------------ Elo réglé comme la production (11/11/2026, paquet 227)
# Audit du 11/11/2026 : 19 études rejouaient l'archive avec « Elo() » sans réglage (surface 0,5, sans score pondéré ni
# incertitude), alors que la production tourne avec les options de elo_etat.json (surface 0,3, score pondéré,
# incertitude 5). Un signal appris contre l'un puis ajouté à l'autre est mal dosé (favori / outsider : β appris 1,2 à
# 1,5, β juste 0,5 à 0,7 sur 2016–2022). Toute NOUVELLE étude sur l'archive prend donc son Elo ici ; le test
# tests/test_parite_elo.py refuse un « Elo() » sans réglage dans une étude qui n'est pas dans sa liste figée.
def options_production(racine=None):
    """(options, départ bas) de l'Elo EN PLACE, lus dans simulateur/elo_etat.json.
    options : {'poids_surface', 'welo', 'incertitude'} ; départ bas : note de départ des joueurs vus d'abord en
    Challenger ou en ITF (None si la variante en place ne l'utilise pas)."""
    import json
    import os
    racine = racine or os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')
    with open(os.path.join(racine, 'simulateur', 'elo_etat.json'), encoding='utf-8') as f:
        etat = json.load(f)
    return dict(etat.get('options') or {}), etat.get('depart_bas')


def de_production(racine=None):
    """(Elo vide, départ bas) : un classement neuf, réglé comme celui de la production, à rejouer sur l'archive.
    À mettre à jour APRÈS CHAQUE MATCH (maj() juste après la prédiction), comme la production : la date de l'archive
    est celle du début du tournoi, attendre le changement de date fige l'Elo pendant tout le tournoi.
    Usage :
        el, bas = E.de_production(racine)
        if bas and circuit in ('CH', 'ITF'):
            el.presenter(joueur, bas)
        p = el.proba(a, b, surface)
        el.maj(gagnant, perdant, surface, grand_chelem, E.part_jeux(sets) if complet else None)"""
    options, depart_bas = options_production(racine)
    return Elo(**options), depart_bas
