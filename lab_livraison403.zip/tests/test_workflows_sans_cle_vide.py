# -*- coding: utf-8 -*-
"""24/11/2026 (paquet 402) — un « env: » laissé vide (valeur nulle) fait refuser le fichier par GitHub : le workflow
n'apparaît plus que sous son chemin (book_index.yml, elo.yml, player_profiles.yml) et ne tourne plus. Aucune clé
d'étape, de job ou de premier niveau ne doit être vide."""
import glob
import os

import yaml

RACINE = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')


def test_aucune_cle_vide_dans_les_workflows():
    fautes = []
    for f in sorted(glob.glob(os.path.join(RACINE, '.github', 'workflows', '*.yml'))):
        with open(f, encoding='utf-8') as fh:
            d = yaml.safe_load(fh)
        nom = os.path.basename(f)
        for k, v in d.items():
            if v is None and k is not True:          # « on » est lu True par PyYAML ; « on: » vide n'existe pas ici
                fautes.append(f"{nom} : {k}")
        for jn, j in (d.get('jobs') or {}).items():
            for k in ('env', 'steps', 'runs-on'):
                if k in j and j[k] is None:
                    fautes.append(f"{nom} / {jn} : {k}")
            for s in j.get('steps') or []:
                for k, v in s.items():
                    if v is None:
                        fautes.append(f"{nom} / {jn} / {s.get('name')} : {k}")
    assert not fautes, fautes
