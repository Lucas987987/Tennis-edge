"""Paquet 485 : l'étude 457 (styles de jeu approfondie) a besoin de Tennis_Edge_Lab/books.py (import de
backtest_pronostic → nos_resultats) ; le run du 26/11 était rouge sans lui. Même liste que l'étude 456."""
import os
import unittest

import yaml

R = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')


def chemins(nom):
    d = yaml.safe_load(open(os.path.join(R, '.github', 'workflows', nom), encoding='utf-8'))
    for job in d['jobs'].values():
        for s in job['steps']:
            sc = (s.get('with') or {}).get('sparse-checkout')
            if sc:
                return {l.strip() for l in sc.splitlines() if l.strip()}
    return set()


class Checkout(unittest.TestCase):
    def test_books_present(self):
        a = chemins('etude_styles_approfondie.yml')
        self.assertIn('/Tennis_Edge_Lab/books.py', a)
        self.assertTrue(chemins('etude_irregularite.yml') <= a)


if __name__ == '__main__':
    unittest.main()
