# Note de fiabilité (mode ombre) — application (codespace, racine)

    unzip note_fiabilite.zip
    cp note_fiabilite/scripts/fiabilite_score.py scripts/
    cp note_fiabilite/scripts/shadow_sizing_study.py scripts/
    cp note_fiabilite/scripts/paper_journal.py scripts/
    cp note_fiabilite/frozen_pistes.json .
    cp note_fiabilite/.github/workflows/pistes_weekly.yml .github/workflows/
    PYTHONPATH=scripts python scripts/shadow_sizing_study.py   # doit dire "0 paris... TROP TÔT"
    rm -rf note_fiabilite note_fiabilite.zip
    git add scripts/fiabilite_score.py scripts/shadow_sizing_study.py scripts/paper_journal.py frozen_pistes.json .github/workflows/pistes_weekly.yml
    git commit -m "Note de fiabilité en mode ombre (gel 26/08) — aucune mise réelle pilotée"
    git pull --no-rebase --no-edit && git push

## Ce qui change concrètement
- Chaque NOUVEAU pari ouvert par paper_journal.py reçoit un fiabilite_score
  (-3 à +3) et son détail, journalisés dans paper_trades_*.jsonl.
- `pnl` (le P&L réel) reste calculé à 1 UNITÉ, exactement comme avant —
  AUCUNE mise n'est modifiée. Le score est un passager, pas un pilote.
- Chaque dimanche, shadow_sizing_study.py compare (en ombre) ce qu'aurait
  donné une mise 0,5/1/1,5u pilotée par la note, vs la mise plate — verdict
  seulement quand n>=30 paris NOTÉS sont dénoués (donc pas avant plusieurs
  semaines, le score vient d'être activé).
- Si un jour les IC95 se séparent clairement : décision de sizing séparée,
  datée, documentée — jamais automatique, jamais silencieuse.
