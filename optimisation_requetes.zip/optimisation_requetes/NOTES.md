# Optimisation des requêtes (29/08/2026) — application (codespace, racine)

⚠️ `verifier.sh` reste obligatoire.

    unzip optimisation_requetes.zip
    cp optimisation_requetes/scripts/*.py scripts/
    cp optimisation_requetes/.github/workflows/*.yml .github/workflows/

    # ── ÉTAPE OBLIGATOIRE ──
    bash optimisation_requetes/verifier.sh
    # doit afficher "TOUT EST EN PLACE (9 contrôles passés)"

    python tests/test_pure_functions.py      # doit afficher 13/13
    rm -f verdicts_geles.json                # 3 watchers réparés, n change

    rm -rf optimisation_requetes optimisation_requetes.zip
    git add -A
    git commit -m "Optimisation requêtes : passe étendue sur état (piste B), cache fixtures/today (piste A), blob:none+timeout steam_pipeline (§7), 3 watchers .gz réparés (bug trouvé en chemin)"
    git pull --no-rebase --no-edit && git push

---

## Ce qui est fait, par ordre de priorité du document

**Piste B (§4)** — la passe étendue se déclenchait sur l'horloge (heure
paire, minute<12), pas sur un état réel. Corrigé : `capture_state.json`
porte désormais `last_extended_at`, relu au début de chaque run.
`_is_extended_pass()` compare l'écart réel écoulé, plus l'horloge. Testé
sur 5 cas : premier run (force), passe récente (refuse), exactement 2h
(déclenche), rattrapage après un cron manqué de 3h (déclenche), et le vrai
bug d'origine -- un dispatch tombant par hasard dans l'ancienne fenêtre
horaire (ne redéclenche plus). Gain attendu : ~-9% du budget API.

**Piste C (§5)** — **découverte en vérifiant** : le document suppose
`FIDS_PER_REQUEST=40`, mais `capture_closing.yml` le fixe déjà à **80** en
production (ligne 66). Le gain restant en testant 100 est donc plus petit
que l'estimation du document (qui calculait depuis une base de 40, pas 80).
Rien codé ici -- ça reste un test manuel à faire toi-même (un appel avec
`FIDS_PER_REQUEST=100`, vérifier que le nombre de fixtures renvoyées est
bien celui demandé), juste avec une base de départ corrigée.

**Piste A (§3)** — `fixtures_today()` était appelée sans cache à chaque
passe standard (~99 requêtes/jour). `fixtures_today_cached()` (30 min,
même motif que `_tournaments_stale` déjà dans le dépôt) plus un cache
GitHub Actions (`actions/cache@v4`, clé par fenêtre de 30 min -- pas de TTL
natif dans `actions/cache`, donc la clé elle-même change toutes les 1800s).
Testé : cache frais -> aucun appel API ; cache périmé -> rappel réel.
Fichier volontairement non committé (`/tmp`), pour ne pas ajouter une
écriture au `git add` de chaque run. Gain attendu : ~-11% du budget API.

**§7** — `steam_pipeline.yml` était le seul workflow lourd sans
`timeout-minutes` (défaut GitHub 6h) et sans `filter: blob:none` (10 autres
l'ont déjà). Ajoutés tous les deux. Pas de nouveau sparse-checkout : ce job
lit trop de fichiers dispersés à la racine pour restreindre sans risque
sous pression ce soir -- `blob:none` seul reste sûr et utile.

## Ce qui a été testé, puis retiré

**Piste 1 (§1, le chargeur unique)** -- la plus grosse optimisation du
document (-105s/run), mais aussi la plus risquée. Testée réellement :
charger les 752 Mo décompressés de `parts/hist_book_*` en dictionnaires
Python **a tué le processus par manque de mémoire** dans ce bac à sable
(3,9 Go disponibles). Je ne peux pas vérifier si le runner GitHub réel
(plus de mémoire, mais je ne connais pas la marge exacte) tiendrait le
coup -- livrer une optimisation de temps de runner qui risque de FAIRE
PERDRE tout un run par OOM serait pire que le problème qu'elle résout,
exactement la classe d'incident traitée ce matin (audit v10). Retirée,
non livrée. Le document lui-même classe cette piste en dernière priorité
("le temps de runner n'est pas encore la contrainte dure") -- cohérent
avec ce choix.

## Le vrai bug trouvé en travaillant sur la piste 1

En examinant les 11 sites d'appel à `_hist_sources()` pour préparer le
chargeur unique, 3 sur 11 (`reinforce_watch`, `betfair_confirm_watch`,
`move_age_watch`) utilisaient `os.path.exists(src) + open(src)` direct au
lieu de `ov.open_any(src)` (le motif correct, déjà utilisé par les 8
autres). Ce motif ignore SILENCIEUSEMENT toute partition n'existant qu'en
`.gz`. Vérifié : **les 10 partitions actuelles le sont toutes** -- ces
trois hypothèses lisaient zéro donnée à chaque appel, masqué par le
mécanisme de gel de verdict (un verdict gelé n'est plus jamais recalculé,
donc le bug ne se voyait que si `verdicts_geles.json` était purgé).

Corrigé (même remplacement mécanique, sûr, pas de mise en cache) et
**testé sur les vraies données** : `reinforce_watch` passe de zéro
résultat exploitable à `n=272` avec un vrai gradient par tranche ;
`betfair_confirm_watch` à `n=17`/`n=24` ; `move_age_watch` à des comptes
non triviaux par tranche d'âge. Les trois apparaissent maintenant dans le
rapport complet, testé de bout en bout (`exit=0`).

## Tests : 13/13 (inchangé)
