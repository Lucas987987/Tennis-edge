#!/usr/bin/env bash
# verifier.sh — contrôle automatique post-application (29/08/2026).
# Optimisation des requêtes (piste B, piste A, §7, + 3 watchers .gz réparés).
#
# Usage : bash verifier.sh   (à la racine du dépôt, APRÈS les cp)

set -uo pipefail
ECHECS=0

verif() {
    local fichier="$1" motif="$2" description="$3"
    if [ ! -f "$fichier" ]; then
        echo "❌ $fichier : FICHIER ABSENT"
        ECHECS=$((ECHECS+1))
        return
    fi
    if grep -q "$motif" "$fichier"; then
        echo "✅ $fichier : $description"
    else
        echo "❌ $fichier : $description -- MOTIF ABSENT ($motif)"
        ECHECS=$((ECHECS+1))
    fi
}

verif_absent() {
    local fichier="$1" motif="$2" description="$3"
    if [ ! -f "$fichier" ]; then
        echo "❌ $fichier : FICHIER ABSENT"
        ECHECS=$((ECHECS+1))
        return
    fi
    if grep -q "$motif" "$fichier"; then
        echo "❌ $fichier : $description -- MOTIF ENCORE PRÉSENT (doit être absent)"
        ECHECS=$((ECHECS+1))
    else
        echo "✅ $fichier : $description"
    fi
}

echo "=== Vérification -- optimisation des requêtes (29/08/2026) ==="
echo

verif scripts/capture_closing.py "dernier_extended" "piste B : passe étendue basée sur l'état, pas l'horloge"
verif scripts/capture_closing.py "fixtures_today_cached" "piste A : cache fixtures/today"
verif scripts/capture_closing.py "last_extended_at" "piste B : persistance de l'état"
verif .github/workflows/capture_closing.yml "actions/cache@v4" "piste A : cache GitHub Actions branché"
verif .github/workflows/capture_closing.yml "fixtures-today-" "piste A : clé de cache par fenêtre 30 min"
verif .github/workflows/steam_pipeline.yml "timeout-minutes: 45" "§7 : garde-fou de temps ajouté"
verif .github/workflows/steam_pipeline.yml "filter: blob:none" "§7 : checkout allégé"
verif_absent scripts/validation_report.py "for line in open(src, encoding='utf-8'):" "3 watchers réparés : plus de lecture .gz-aveugle"
verif scripts/validation_report.py "ov.open_any(src)" "3 watchers réparés : open_any partout"

echo
if [ "$ECHECS" -eq 0 ]; then
    echo "✅✅✅ TOUT EST EN PLACE (9 contrôles passés). Sûr de committer."
    exit 0
else
    echo "❌❌❌ $ECHECS CONTRÔLE(S) EN ÉCHEC. NE PAS COMMITTER avant d'avoir compris pourquoi."
    exit 1
fi
