# Analyse d'ensemble + 2 correctifs (02/09/2026)

    cp permissions_et_canal/scripts/*.py scripts/
    cp permissions_et_canal/.github/workflows/*.yml .github/workflows/
    python tests/test_pure_functions.py      # doit afficher 13/13

    git add -A
    git commit -m "health_check.yml : bloc permissions manquant (gh api indisponible + push impossible) -- canal_public.py : écriture atomique du fichier de déduplication (correctif du 30/08 non appliqué)"
    git pull --no-rebase --no-edit && git push

---

## État général : sain

- **129 scripts Python** : tous compilent, 0 erreur
- **50 workflows YAML** : tous valides, 0 erreur
- **Tests** : 13/13
- **Journaux de paris** : 38 + 17 + 0 + 99 lignes, toutes valides
- **Fichiers d'état** : tous présents, non vides, JSON valide (le motif de
  troncature du 28/08 ne s'est pas reproduit)

**Les correctifs récents ont produit leurs effets mesurables en production :**
- Les 5 paris qui n'avaient jamais eu `closed_no_result_depuis` l'ont reçu
  le 30/08 -- leur horloge de 7 jours vers ABANDONNED tourne enfin.
- Le canal est passé à 90 réglés / 9 ouverts (contre 76/23 avant le
  correctif de fenêtre à 5 jours), exactement ce qui était prédit.

## Correctif 1 — health_check.yml n'avait aucun bloc `permissions:`

`repo_size_status.json` affichait `zone: "indisponible"` avec le message
« gh: To use GitHub CLI in a GitHub Actions workflow, set the GH_TOKEN
environment variable » -- alors que le workflow passe bien
`GH_TOKEN: ${{ secrets.GH_TOKEN }}` à l'étape.

**Le secret existe et fonctionne** : le watchdog de `capture_closing.yml`
l'utilise avec succès (il a relancé Kalshi et Polymarket via l'API
aujourd'hui même). La différence : `capture_closing.yml` déclare
`permissions: contents: write`, `health_check.yml` ne déclarait rien --
il tournait donc avec les permissions par défaut du dépôt.

Deuxième conséquence, pas encore visible : l'étape de commit que j'ai
ajoutée le 30/08 (push de `repo_size_status.json`) aurait échoué pour la
même raison.

**Conséquence pratique** : la surveillance de la taille du dépôt -- « le
seul point avec une date limite » selon ton rapport consolidé -- est
AVEUGLE depuis sa mise en place. Ce correctif la rend opérationnelle.

## Correctif 2 — canal_public.py, correctif du 30/08 non appliqué

Le paquet `canal_public_atomique.zip` livré le 30/08 n'a pas été appliqué :
`json.dump(state, open(STATE, 'w'))` était toujours là. Réappliqué. Sans
lui, une interruption pendant cette écriture vide toute la mémoire de
déduplication et fait republier les mêmes alertes aux abonnés.

Testé : mémoire intacte malgré une panne simulée, aucun résidu `.tmp`.

## Deux points à surveiller, sans action de code

**Taille du dépôt** : `repo_size_status.json` ne pourra donner un vrai
chiffre qu'après ce correctif. À regarder au prochain run de
`health_check.yml` (07h37 UTC) -- si la zone passe à `vigilance` ou
`alarme`, c'est l'urgence n°1 de ton rapport consolidé qui devient
mesurable.

**Cadence des requêtes** : `active_tournaments.json` contient **5 tournois
actifs**, donc `R = ceil(5/5) = 1` dans le worker -- la cadence calculée
devrait être de 5 min, pas 30. Le multiplicateur `R` n'est donc PAS la
cause de l'écart observé hier (~30 min réels). La cause restante la plus
probable est la fréquence propre du cron Cloudflare qui appelle
`scheduled()`, réglée dans le tableau de bord Cloudflare -- hors du code
que je peux voir. À vérifier de ton côté quand le quota reviendra.

## Tests : 13/13 (inchangé)
