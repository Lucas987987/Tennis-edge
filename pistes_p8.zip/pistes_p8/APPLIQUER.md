# Piste 8 : confirmation Pinnacle — application (codespace, racine)
    unzip pistes_p8.zip
    cp pistes_p8/scripts/confirmation_pinnacle_study.py scripts/
    cp pistes_p8/frozen_pistes.json .
    cp pistes_p8/.github/workflows/pistes_weekly.yml .github/workflows/
    PYTHONPATH=scripts python scripts/confirmation_pinnacle_study.py   # doit afficher "0 signaux postérieurs au gel"
    rm -rf pistes_p8 pistes_p8.zip
    git add scripts/confirmation_pinnacle_study.py frozen_pistes.json .github/workflows/pistes_weekly.yml
    git commit -m "Piste 8 : confirmation Pinnacle sur signal ouverture précoce (gel 26/08)"
    git pull --no-rebase --no-edit && git push
Verdict attendu début septembre (n>=30 au rythme actuel), automatique dans
pistes_report.md chaque dimanche.
