# Pistes exploratoires v1 — application (codespace, racine)
    unzip pistes_v1.zip
    cp pistes_v1/scripts/*.py scripts/
    cp pistes_v1/frozen_pistes.json .
    cp pistes_v1/.github/workflows/pistes_weekly.yml .github/workflows/
    PYTHONPATH=scripts python scripts/segments_study.py     # fumée : doit afficher le témoin 72,5 %
    rm -rf pistes_v1 pistes_v1.zip
    git add scripts frozen_pistes.json .github/workflows/pistes_weekly.yml
    git commit -m "7 pistes exploratoires gelées + rapport hebdo (frozen_pistes 25/08)"
    git pull --no-rebase --no-edit && git push
Premier rapport automatique : dimanche 6h40, dans pistes_report.md.
