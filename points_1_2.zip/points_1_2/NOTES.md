# Points 1 et 2 du rapport consolidé (30/08/2026)

    unzip points_1_2.zip
    cp points_1_2/scripts/*.py scripts/
    cp points_1_2/.github/workflows/*.yml .github/workflows/

    bash points_1_2/verifier.sh
    # doit afficher "TOUT EST EN PLACE (7 contrôles passés)"

    python tests/test_pure_functions.py      # doit afficher 13/13

    rm -rf points_1_2 points_1_2.zip
    git add -A
    git commit -m "Point 1 : taille du dépôt rendue visible (repo_size_status.json, commit ajouté à health_check.yml, --strict) -- Point 2 : timeout polymarket_flow enfin compté comme échec réel"
    git pull --no-rebase --no-edit && git push

---

## Point 1 traité intégralement

`repo_sentinel.py` mesurait déjà la taille du dépôt tous les jours, mais
son verdict ne vivait que dans un log derrière `|| true`. Écrit maintenant
dans `repo_size_status.json` (écriture atomique), rendu dans
`pipeline_status.md` (4e bloc, après Q3/CLV/Polymarket), zone alarme
branchée sur `--strict`.

**Trou trouvé en vérifiant** : `health_check.yml` n'avait **aucune étape
de commit** -- même corrigé, le fichier aurait été écrit sur le runner puis
perdu à la fin du job. Ajoutée, même motif éprouvé que
`polymarket_studies.yml` (retry fetch/merge/push).

Testé sur les 4 zones (ok, vigilance, alarme, indisponible) dans le rendu
Markdown, et sur `--strict` qui échoue bien en zone alarme.

## Point 2 traité intégralement

`⚠️ ${s}.py EN ÉCHEC` pour un code de retour non nul (timeout inclus) --
corrigé en `❌`. Ce bug préexistait au correctif d'hier (audit v9-v10) qui
sépare `n_echecs` (bloquant) de `n_avertissements` (info) ; avant cette
séparation, les deux symboles étaient comptés ensemble et l'erreur ne
portait pas à conséquence. En les séparant, j'ai rendu ce bug préexistant
réellement dangereux -- un timeout quotidien de `polymarket_flow` restait
invisible. Testé : le compteur détecte maintenant correctement un échec
réel.

## Point 4 -- volontairement pas réimplémenté

Le chargeur unique (`index_book()`) proposé est quasi identique à ce que
j'ai tenté hier soir (`_hist_records()`) et **abandonné après un OOM
mesuré** dans un bac à sable à 3,9 Go, sur les mêmes 752 Mo décompressés.
Sans savoir si le design proposé cette fois évite la matérialisation
complète en mémoire (une seule liste Python de tous les enregistrements),
je ne le réimplémente pas à l'aveugle -- même risque, même conséquence
possible (un job qui plante et perd tout un run, pire que les 162s qu'il
vise à économiser).

## Points laissés à ton arbitrage (voir le message)

- Sort des ticks Polymarket/Kalshi (point 1 + point 3 combinés)
- index_book() : design mémoire-sûr à valider avant réimplémentation
- Autres points mineurs (5, 6, 7) : pas traités ce soir, volume déjà
  conséquent sur les points 1/2/4

## Tests : 13/13 (inchangé)
