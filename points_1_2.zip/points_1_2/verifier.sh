#!/usr/bin/env bash
# verifier.sh — points 1 (taille dépôt rendue visible) et 2 (timeout mal
# compté) du rapport consolidé, 30/08/2026.
#
# Usage : bash verifier.sh   (à la racine du dépôt, APRÈS les cp)

set -uo pipefail
ECHECS=0

verif() {
    local fichier="$1" motif="$2" description="$3"
    if [ ! -f "$fichier" ]; then
        echo "❌ $fichier : FICHIER ABSENT"
        ECHECS=$((ECHECS+1))
        return
    fi
    if grep -q "$motif" "$fichier"; then
        echo "✅ $fichier : $description"
    else
        echo "❌ $fichier : $description -- MOTIF ABSENT ($motif)"
        ECHECS=$((ECHECS+1))
    fi
}

echo "=== Vérification -- points 1 et 2 (30/08/2026) ==="
echo

verif scripts/repo_sentinel.py "def _ecrire_statut" "point 1 : repo_sentinel écrit un statut"
verif scripts/repo_sentinel.py "import oddspapi_v5 as ov" "point 1 : écriture atomique importée"
verif scripts/pipeline_status.py "Taille du dépôt" "point 1 : rendu dans pipeline_status.md"
verif scripts/pipeline_status.py "zone') == 'alarme'" "point 1 : zone alarme branchée sur --strict"
verif .github/workflows/health_check.yml "Committer le statut de taille du dépôt" "point 1 : étape de commit ajoutée (elle n'existait pas du tout)"
verif .github/workflows/polymarket_studies.yml 'echo "❌ \${s}.py EN ÉCHEC' "point 2 : timeout marqué ❌, plus ⚠️"

echo
echo "=== Test critique : le timeout quotidien de polymarket_flow est-il enfin détecté ? ==="
cat > /tmp/_v_repro.md << 'EOF'
--- polymarket_flow ---
❌ polymarket_flow.py EN ÉCHEC (code 124)
--- polymarket_leadlag ---
⚠️ historique tronqué : 6 partition(s) archivée(s) hors git
EOF
n_echecs=$(grep -c "❌" /tmp/_v_repro.md || true)
if [ "$n_echecs" -ge 1 ]; then
    echo "✅ le timeout (code 124) est compté comme un échec réel, plus comme un avertissement"
else
    echo "❌ le timeout n'est toujours pas détecté"
    ECHECS=$((ECHECS+1))
fi

echo
if [ "$ECHECS" -eq 0 ]; then
    echo "✅✅✅ TOUT EST EN PLACE (7 contrôles passés). Sûr de committer."
    exit 0
else
    echo "❌❌❌ $ECHECS CONTRÔLE(S) EN ÉCHEC. NE PAS COMMITTER avant d'avoir compris pourquoi."
    exit 1
fi
