# Points restants du rapport consolidé (30/08/2026)

    unzip points_restants.zip
    cp points_restants/scripts/*.py scripts/
    cp points_restants/.github/workflows/*.yml .github/workflows/

    bash points_restants/verifier.sh
    # doit afficher "TOUT EST EN PLACE (6 contrôles passés)"

    python tests/test_pure_functions.py      # doit afficher 13/13

    rm -rf points_restants points_restants.zip
    git add -A
    git commit -m "Point 5 : idempotence rapport Telegram + détection changement de jour avant court-circuit -- Point 7 : closed_no_result_depuis posé même sans bk (7 trades bloqués débloqués)"
    git pull --no-rebase --no-edit && git push

---

## Point 4 — confirmé : non, ne pas réimplémenter

Mesure précise cette fois (pas une supposition) : ~3,77 Go extrapolés pour
matérialiser l'historique complet en mémoire. Mais surtout -- le "Killed"
observé en testant est un **SIGKILL du noyau**, pas une `MemoryError`
Python interceptable. Aucun design "essayer, intercepter l'échec, retomber
sur le chemin lent" ne peut fonctionner ici : il n'y a rien à intercepter.
Même avec de la marge apparente sur un runner à 7 Go, une variation de
charge ou la croissance normale de l'historique peuvent faire basculer un
run entier dans ce mur, sans avertissement. Non réimplémenté.

## Point 5 — traité intégralement

**Idempotence** : `rapport_envoye_pour` empêche un rejeu sur le même état
périmé de renvoyer le message. Testé sur la VRAIE fonction (pas une copie
de sa logique) : premier envoi OK, rejeu bloqué.

**Détection de changement de jour indépendante du court-circuit** :
extraite en `_verifier_et_envoyer_rapport_si_besoin()`, appelée en tête de
`main()`, avant toute décision de court-circuiter le cron de secours.
Testé : le rapport part même dans un scénario qui aurait autrement
déclenché le court-circuit (worker actif depuis 5 min).

**shadow_sizing_study** : vérifié, **n'est pas orphelin** -- déjà câblé
dans `pistes_weekly.yml`. Le rapport avait tort sur ce point précis. En
revanche, trouvé et corrigé en vérifiant : le même bug de symbole
(`⚠️`/`❌`) que le point 2, présent dans ce même fichier -- sans
conséquence fonctionnelle ici (rien ne compte ce rapport), corrigé pour la
cohérence.

**65 scripts non-atomiques** : réserve assumée, pas traité ce soir (déjà
noté hier).

## Point 6 — rien à faire

`mins_before` vs la file du cron */15 : à surveiller, pas à corriger.
Aucune action de code.

## Point 7 — les deux anomalies

**`set2` vide** : investigué en profondeur (volume de données comparable à
`set1` -- 5674 vs 6487 enregistrements récents, donc pas "pas de données" ;
`set2_open` absent à 100% sur la partition testée, mais probablement
orthogonal). Test direct de `detect()` sur 200 vraies courbes : 0
détection -- **mais 0 détection aussi sur `set1` avec la même méthode**,
qui pourtant fonctionne en production (34 détections réelles). Ma méthode
de test ne reproduit donc pas le mécanisme réel (probablement incrémental,
avec état entre appels, pas un test isolé sur courbe complète). **Non
résolu**, signalé honnêtement plutôt que de proposer un correctif non
vérifié.

**7 paris bloqués en `CLOSED_NO_RESULT`** : cause trouvée et corrigée.
`settle_trade()` (qui pose `closed_no_result_depuis`, le point de départ
du délai d'abandon à 7 jours) n'est rappelé que si la courbe du match
(`bk`) est encore trouvable dans `data` ou `track`. Pour les matchs trop
anciens (le pire cas : 22 jours), `bk` devient introuvable dans les deux
-- `settle_trade()` n'est plus jamais appelé, donc le champ ne se pose
jamais, donc l'horloge des 7 jours ne démarre jamais. Vérifié sur les
vraies données : 5 des 7 trades bloqués n'avaient jamais eu ce champ posé.
Corrigé : le champ se pose maintenant même quand `bk` est indisponible, dès
lors que le statut est déjà `CLOSED_NO_RESULT`. Testé sur les deux cas
(champ absent -> posé ; champ déjà présent -> préservé).

## Le bug trouvé dans mon propre `verifier.sh`, en le testant

Le premier test critique 1 réimplémentait sa propre copie de la logique
d'idempotence au lieu d'appeler la vraie fonction du code -- sabotage du
vrai code, test resté vert. Retrouvé en testant volontairement le
sabotage (un premier essai a même saboté la MAUVAISE ligne -- une
vérification redondante ailleurs dans `main()`, pas celle réellement
testée). Corrigé pour appeler `cc._verifier_et_envoyer_rapport_si_besoin()`
directement ; le sabotage du vrai site fait maintenant échouer le test
comme attendu (`exit=1` confirmé), et l'application propre reste verte.

## Tests : 13/13 (inchangé)
