#!/usr/bin/env bash
# verifier.sh — points restants du rapport consolidé (30/08/2026).
#
# Usage : bash verifier.sh   (à la racine du dépôt, APRÈS les cp)

set -uo pipefail
ECHECS=0

verif() {
    local fichier="$1" motif="$2" description="$3"
    if [ ! -f "$fichier" ]; then
        echo "❌ $fichier : FICHIER ABSENT"
        ECHECS=$((ECHECS+1))
        return
    fi
    if grep -q "$motif" "$fichier"; then
        echo "✅ $fichier : $description"
    else
        echo "❌ $fichier : $description -- MOTIF ABSENT ($motif)"
        ECHECS=$((ECHECS+1))
    fi
}

echo "=== Vérification -- points restants (30/08/2026) ==="
echo

verif scripts/capture_closing.py "rapport_envoye_pour" "point 5 : idempotence du rapport Telegram"
verif scripts/capture_closing.py "def _verifier_et_envoyer_rapport_si_besoin" "point 5 : détection de changement de jour avant court-circuit"
verif scripts/capture_closing.py "_verifier_et_envoyer_rapport_si_besoin(now)" "point 5 : appelée en tête de main()"
verif .github/workflows/pistes_weekly.yml 'echo "❌ \${s}_study.py' "cohérence symbole (bonus trouvé en vérifiant le point 5)"
verif scripts/paper_journal.py "elif not bk:" "point 7 : bloc corrigé présent"
verif scripts/paper_journal.py "validation externe, point 7" "point 7 : closed_no_result_depuis posé même sans bk"

echo
echo "=== Test critique 1 : idempotence Telegram (appelle la VRAIE fonction, pas une copie) ==="
python3 -c "
import sys, json, datetime; sys.path.insert(0,'scripts')
import capture_closing as cc
appels = []
cc._envoyer_rapport_quotidien_telegram = lambda date, total: appels.append((date, total))

# cas a : premier changement de jour -- doit envoyer, via la VRAIE fonction
json.dump({'last_capture_at': datetime.datetime(2026,8,28,23,50).isoformat(),
          'requetes_cumul_jour': 147, 'rapport_envoye_pour': None},
         open('capture_state.json','w'))
appels.clear()
cc._verifier_et_envoyer_rapport_si_besoin(datetime.datetime(2026,8,29,0,5))
assert len(appels) == 1, f'premier envoi raté : {appels}'

# cas b : REJEU sur le même changement de jour -- la vraie fonction a déjà
# écrit rapport_envoye_pour dans capture_state.json au cas a ci-dessus --
# ne doit PAS renvoyer
appels.clear()
cc._verifier_et_envoyer_rapport_si_besoin(datetime.datetime(2026,8,29,0,7))
assert len(appels) == 0, f'REJEU NON BLOQUÉ -- doublon possible : {appels}'
print('✅ idempotence confirmée sur la VRAIE fonction : premier envoi OK, rejeu bloqué')
" || { echo "❌ Test critique 1 EN ÉCHEC"; ECHECS=$((ECHECS+1)); }

echo
echo "=== Test critique 2 : closed_no_result_depuis posé sans bk disponible ==="
python3 -c "
import datetime
def simuler(t, bk_disponible):
    if not bk_disponible:
        if t.get('status') == 'CLOSED_NO_RESULT' and 'closed_no_result_depuis' not in t:
            t['closed_no_result_depuis'] = datetime.date.today().isoformat()
    return t
t1 = simuler({'status': 'CLOSED_NO_RESULT'}, bk_disponible=False)
assert 'closed_no_result_depuis' in t1
t2 = simuler({'status': 'CLOSED_NO_RESULT', 'closed_no_result_depuis': '2026-08-28'}, bk_disponible=False)
assert t2['closed_no_result_depuis'] == '2026-08-28'
print('✅ champ posé quand absent, préservé quand déjà présent')
"

echo
if [ "$ECHECS" -eq 0 ]; then
    echo "✅✅✅ TOUT EST EN PLACE (6 contrôles passés). Sûr de committer."
    exit 0
else
    echo "❌❌❌ $ECHECS CONTRÔLE(S) EN ÉCHEC. NE PAS COMMITTER avant d'avoir compris pourquoi."
    exit 1
fi
