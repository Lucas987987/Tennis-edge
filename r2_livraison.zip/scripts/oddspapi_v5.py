#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
oddspapi_v5.py — Client commun OddsPapi v5 via RapidAPI (appels curl).

Sert de couche d'acces unique pour capture_closing, fetch_clv, fetch_book_curves, etc.
Renvoie les cotes dans une forme simple {home, away} (home = participant1, away = participant2).

Confirme par sonde reelle (2026-06) :
  - Tennis : sportId = 12
  - Marche vainqueur du match : marketId 121 ; outcomeId 121 = home (participant1),
    122 = away (participant2) ; champ bookmakerOutcomeId = "home"/"away" en secours.
  - startTime = Unix SECONDES ; changedAt = millisecondes.
  - Auth = headers RapidAPI (x-rapidapi-key / x-rapidapi-host) ; appels via curl
    (Cloudflare bloque les clients Python par defaut -> curl + UA navigateur).

Env requis : RAPIDAPI_KEY  (ou ODDSPAPI_RAPIDAPI_KEY)

Chemins RapidAPI valides (confirmes) :
  /sports  /markets  /tournaments  /fixtures/today  /fixtures/live
  /fixtures/odds/main  /fixtures/odds/historical
  (PAS de prefixe /en ; /fixtures/filtered n'existe pas)
"""

import os
import json
import glob
import gzip
import subprocess
import time
import datetime

RAPIDAPI_HOST = "odds-api1.p.rapidapi.com"
BASE = f"https://{RAPIDAPI_HOST}"
UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36")
KEY = (os.environ.get("RAPIDAPI_KEY")
       or os.environ.get("ODDSPAPI_RAPIDAPI_KEY")
       or os.environ.get("RAPID_API_KEY")
       or "")

TENNIS_SPORT_ID = 12


# ── PARTITIONNEMENT DE L'HISTORIQUE (book/set1/set2_curves.jsonl) ──────────
# PROBLÈME RÉSOLU (14/08/2026) : book_curves.jsonl monolithique a atteint
# 140,73 Mo -- GitHub rejette tout push > 100 Mo ("pre-receive hook
# declined"). Chaque run de fetch_book_curves.py committait bien LOCALEMENT
# (les 40 matchs étaient traités) mais le push échouait SILENCIEUSEMENT
# ("git push || true" avale l'erreur) -- résultat : le fichier distant était
# figé depuis le 09/08 malgré un pipeline qui tournait "sans erreur" chaque
# nuit. Correctif : partitionner par MOIS (parts/hist_<market>_<YYYY-MM>.jsonl,
# même principe que parts/live_*.jsonl déjà utilisé pour les courbes live),
# chaque partition restant largement sous 100 Mo. iter_hist_lines() permet à
# tout script consommateur de lire l'historique complet (legacy + partitions)
# comme un seul flux, avec un changement minimal :
#   AVANT : for line in open('book_curves.jsonl'):
#   APRÈS : for line in ov.iter_hist_lines('book'):
HIST_PARTITION_MAX_MB = float(os.environ.get('HIST_PARTITION_MAX_MB', '70'))
# Marge sous le mur dur de GitHub (100 Mo) -- 70 Mo laisse de la place pour
# le run en cours (un batch de 40 matchs peut ajouter plusieurs Mo d'un coup).


def current_hist_partition_path(market='book'):
    """Chemin de la partition COURANTE pour ce marché (match/set1/set2).

    DÉCOUPAGE PAR TAILLE (depuis le 15/08/2026), pas seulement par semaine :
    le découpage hebdomadaire seul (introduit le 15/08 après la crise des
    140,73 Mo du 14/08) s'est révélé insuffisant -- une semaine chargée
    (Cincinnati Masters, S33) a fait grimper hist_book_2026-W33.jsonl à
    98 Mo en quelques jours, retouchant quasiment le même mur. Un découpage
    purement temporel suppose un volume à peu près constant, ce qui est faux
    en tennis (les Masters/Grands Chelems concentrent énormément de matchs
    sur des fenêtres courtes). Ce découpage vérifie donc la TAILLE RÉELLE du
    fichier de la période courante ; s'il dépasse HIST_PARTITION_MAX_MB, on
    bascule vers un fichier suffixé (_2, _3...) DANS LA MÊME semaine, sans
    attendre le changement de période. Garantit qu'aucune partition ne peut
    jamais retoucher la limite dure de GitHub (100 Mo), quel que soit le
    volume d'une semaine donnée.
    RÉTROCOMPATIBLE sans rien migrer : iter_hist_lines() fait un glob sur
    'hist_<market>_*.jsonl', qui ramasse toutes les formes (mensuelles,
    hebdomadaires, et maintenant les variantes suffixées _2/_3...)."""
    wk = datetime.datetime.utcnow().strftime('%G-W%V')
    os.makedirs('parts', exist_ok=True)
    base = f'parts/hist_{market}_{wk}.jsonl'
    path = base
    seq = 1
    # Une partition GZIPPÉE est close et ne doit plus jamais être réécrite en
    # clair : on passe au suffixe suivant comme si elle était pleine.
    while ((os.path.exists(path) and os.path.getsize(path) / 1e6 >= HIST_PARTITION_MAX_MB)
           or os.path.exists(path + '.gz')):
        seq += 1
        path = f'parts/hist_{market}_{wk}_{seq}.jsonl'
    return path


def iter_hist_lines(market='book'):
    """Itère sur TOUT l'historique d'un marché (partitions + fichier
    monolithique legacy s'il existe encore), comme un flux unique de lignes
    JSONL brutes (chaque ligne = 1 courbe book/match, format inchangé).

    COMPRESSION (16/08/2026) : les partitions closes sont gzippées
    (parts/hist_<market>_*.jsonl.gz) par compress_hist_partitions.py. Le gain
    mesuré est de 86 % (97,7 Mo -> 14,1 Mo sur hist_book_2026-W33), soit
    435 Mo -> ~63 Mo sur l'ensemble de l'historique. Nécessaire parce que
    parts/ grossissait de ~80 Mo par semaine sans jamais être purgé
    (purge_old_partitions ne filtre que parts/live_*, et HIST_DAYS=0 par choix :
    l'historique EST l'actif de recherche du projet).
    AUCUNE PERTE : gzip est sans perte, et la lecture est transparente ici —
    les deux formes coexistent, aucun script consommateur n'a à changer.
    Si un .jsonl et son .jsonl.gz existent tous les deux (compression en cours),
    seul le .jsonl est lu, pour ne jamais servir deux fois les mêmes lignes."""
    # R2 (15/10/2026) : l'historique hist_* reste dans git ; sur demande
    # explicite (R2_MATERIALIZE_HIST=1), on complète depuis R2 un checkout
    # qui l'exclut. Désactivé par défaut : ~600 Mo à rapatrier.
    if os.environ.get('R2_MATERIALIZE_HIST') == '1':
        try:
            import restore_curves
            restore_curves.from_r2_only(f'hist_{market}_')
        except Exception as e:                  # noqa: BLE001
            print(f"  [r2] historique {market} non complété ({type(e).__name__})")
    plain = sorted(glob.glob(f'parts/hist_{market}_*.jsonl'))
    gz = sorted(glob.glob(f'parts/hist_{market}_*.jsonl.gz'))
    if not plain and not gz:
        # GARDE-FOU (25/08/2026). Zéro partition pour un marché suivi n'est
        # JAMAIS normal en production : soit le checkout est incomplet
        # (sparse-checkout qui exclut parts/hist_* — la panne du 25/08 matin,
        # 2h30 de seuils DEFAULT_THR silencieux), soit le répertoire a été
        # déplacé. Tous les appelants (steam_alert, results_bridge via
        # open_curves, validation_report...) hériteraient d'un historique
        # vide SANS ERREUR. Une ligne suffit à rendre la panne visible.
        print(f"⚠️ iter_hist_lines('{market}') : AUCUNE partition "
              f"parts/hist_{market}_* trouvée — historique vide. "
              f"Checkout sparse incomplet ?")
    plain_set = set(plain)
    gz = [g for g in gz if g[:-3] not in plain_set]     # doublon -> on garde le .jsonl
    paths = sorted(plain + gz, key=lambda p: p.replace('.gz', ''))
    legacy = {'book': 'book_curves.jsonl', 'set1': 'set1_curves.jsonl',
              'set2': 'set2_curves.jsonl'}.get(market, f'{market}_curves.jsonl')
    if os.path.exists(legacy):
        paths = [legacy] + paths   # legacy = données les plus anciennes, en premier
    for p in paths:
        try:
            op = gzip.open if p.endswith('.gz') else open
            with op(p, 'rt', encoding='utf-8') as f:
                for line in f:
                    if line.strip():
                        yield line
        except Exception:
            continue


# ── RÉSOLVEUR UNIVERSEL DE CHEMIN DE COURBES ───────────────────────────────
# PROBLÈME RÉSOLU (16/08/2026) : depuis les DEUX migrations de partitionnement,
# aucun des deux fichiers plats historiquement utilisés n'existe plus au moment
# où un script le lit :
#   1. HISTORIQUE  book_curves.jsonl / set*_curves.jsonl -> parts/hist_*.jsonl
#      (migration du 14/08, cause : 140,73 Mo > mur GitHub 100 Mo)
#   2. LIVE        book_curves_live.jsonl / set*_curves_live.jsonl -> parts/live_*.jsonl
#      + .gitignore (migration ultérieure, cause : réécriture complète toutes
#      les 8 min = des Go d'historique git). Le plat n'est reconstruit QUE par
#      "curves_parts.py rebuild", appelé dans capture_closing.yml -- donc absent
#      dans TOUT autre workflow (steam_pipeline.yml notamment, où il fait
#      silencieusement produire des sorties VIDES à move_audit/canal_recap).
# Chaque script consommateur faisait "open(CHEMIN)" avec un garde
# "if not os.path.exists(...): return" -> échec SILENCIEUX, sortie vide, aucun
# code d'erreur. Symptôme concret constaté : moves_detail.csv et
# moves_detail_hist.csv réduits à leur seule ligne d'en-tête (154 octets).
# open_curves() encapsule les deux cas : à utiliser PARTOUT à la place de open().
def _r2_materialize(motif):
    """AJOUTÉ LE 15/10/2026 (migration R2). En mode R2_PRIMARY=on, les
    partitions ticks/live ne sont plus dans git : on rapatrie depuis R2
    celles du motif qui manquent au checkout (no-op en off/double ou sans
    secrets). Ne lève JAMAIS : au pire, lecture des seules copies locales."""
    try:
        import r2_io
        r2_io.materialize_glob(motif)
    except Exception as e:                      # noqa: BLE001
        print(f"  [r2] matérialisation ignorée pour {motif} ({type(e).__name__})")


def load_partitions(motif):
    """Chemins des partitions correspondant à un motif, SANS DOUBLON.

    BUG CORRIGÉ (22/08/2026) — chaque script d'analyse avait sa propre logique
    de lecture, du type :
        sorted(set(glob.glob(motif) + glob.glob(motif + '.gz')))
    Cette écriture charge la partition ET sa copie compressée quand les deux
    coexistent. Constaté sur le dépôt : 8 paires en double, et les études
    lisaient 1 602 270 ticks au lieu de 800 472 — un facteur 2 exact.
    Conséquences : points comptés deux fois, poids doublé pour certains matchs,
    corrélations et volumes faussés.

    Les deux formes coexistent parce que compress_hist_partitions.py supprime
    bien le .jsonl sur le runner, mais que la suppression n'a pas toujours été
    enregistrée dans git (corrigé depuis avec `git add -A`). Le dépôt garde
    donc des paires héritées de cette période.

    Règle : si les deux existent, on garde le .jsonl (source d'origine, non
    recompressée). Le .gz n'est retenu que seul.

    Fonction CENTRALE : tout script lisant des partitions doit passer par ici.
    Trois logiques de lecture divergentes, c'est exactement ce qui a produit
    les bugs historiques du projet (cf. les trois copies de player_match).
    """
    _r2_materialize(motif)
    plain = glob.glob(motif)
    gz = glob.glob(motif + '.gz')
    vus = set(plain)
    # CORRIGÉ LE 27/08/2026 (audit §2.1) : l'hypothèse "si les deux existent,
    # .jsonl et .gz sont des doublons" datait du 22/08 et est devenue FAUSSE
    # le 26/08 (gzip-append écrit désormais directement en .gz -- un .jsonl
    # qui coexiste est un reliquat D'AVANT le switch, avec un contenu
    # DIFFÉRENT, pas une recompression). Comparaison de taille en repli :
    # si le .gz est cohérent avec le .jsonl (grossièrement, compression
    # ~3-10x), on garde le comportement historique. Sinon, avertissement
    # bruyant et LES DEUX sont retournés -- aucune ligne perdue en silence.
    gz_retenus = []
    for g in gz:
        base = g[:-3]
        if base not in vus:
            gz_retenus.append(g)
            continue
        try:
            taille_jsonl = os.path.getsize(base)
            taille_gz = os.path.getsize(g)
            ratio = taille_jsonl / taille_gz if taille_gz else 0
            if not (2 <= ratio <= 15):
                print(f"⚠️ load_partitions : {base} ET {g} coexistent avec un "
                      f"ratio de taille suspect ({ratio:.1f}x, attendu 2-15x) "
                      f"-> probable scission (v. audit du 27/08), LES DEUX "
                      f"sont lus.")
                gz_retenus.append(g)
        except OSError:
            gz_retenus.append(g)
    resultat = sorted(set(plain + gz_retenus), key=lambda p: p.replace('.gz', ''))
    # AJOUTÉ LE 27/08/2026 (audit v3 §S) : quand des dates sont indexées
    # dans parts/ARCHIVE_INDEX.json (archivées vers une Release par
    # archive_ticks.py) mais absentes du motif demandé, le distinguer d'un
    # vrai trou de collecte -- sinon la prochaine étude qui globe
    # parts/pm_ticks_* découvre un historique tronqué sans savoir que c'est
    # voulu (voir archive_ticks.py). Défensif : n'importe quel format
    # inattendu du fichier est ignoré silencieusement (ce garde-fou est un
    # bonus, pas une dépendance critique).
    try:
        idx = json.load(open('parts/ARCHIVE_INDEX.json', encoding='utf-8'))
        base_motif = os.path.basename(motif).split('*')[0]   # ex: 'pm_ticks_'
        if base_motif:
            dates_archivees = sorted({a.get('date', '')[:7] for a in idx.get('archives', [])
                                      if base_motif in a.get('fichier', '')})
            dates_presentes = {os.path.basename(p)[len(base_motif):len(base_motif) + 7]
                               for p in resultat}
            manquantes = [d for d in dates_archivees if d and d not in dates_presentes]
            if manquantes:
                print(f"ℹ️ load_partitions('{motif}') : {len(manquantes)} mois "
                      f"archivé(s) intentionnellement hors disque (voir "
                      f"parts/ARCHIVE_INDEX.json) -- historique tronqué, pas "
                      f"un trou de collecte.")
    except (OSError, ValueError, KeyError, TypeError):
        pass
    return resultat


def open_any(path):
    """Ouvre un .jsonl OU son .jsonl.gz, indifféremment.

    Depuis la compression du 16/08/2026, une partition historique peut n'exister
    que sous forme .gz. Tout code faisant open(path) sur un chemin issu d'un
    glob '*.jsonl' ne trouvait alors PLUS RIEN -- silencieusement, puisque les
    scripts sautent les fichiers absents. À utiliser partout où un chemin de
    partition est ouvert directement.

    CORRIGÉ LE 27/08/2026 (audit §2.1) : le test .gz doit passer EN PREMIER.
    Avant, un chemin DÉJÀ suffixé .gz (ex. renvoyé par le garde-fou ajouté à
    load_partitions()) tombait dans la branche os.path.exists(path) et était
    ouvert comme texte brut -- un binaire gzip lu en UTF-8, données corrompues
    ou UnicodeDecodeError selon le contenu."""
    if path.endswith('.gz'):
        if os.path.exists(path):
            return gzip.open(path, 'rt', encoding='utf-8')
        raise FileNotFoundError(path)
    if os.path.exists(path):
        return open(path, encoding='utf-8')
    if os.path.exists(path + '.gz'):
        return gzip.open(path + '.gz', 'rt', encoding='utf-8')
    raise FileNotFoundError(path)


def hist_partitions(market='book'):
    """Chemins des partitions d'un marché, .jsonl et .jsonl.gz confondus.
    Le .gz est renvoyé SANS son suffixe : open_any() se charge de le résoudre,
    et les appelants gardent des chemins lisibles."""
    plain = glob.glob(f'parts/hist_{market}_*.jsonl')
    gz = [p[:-3] for p in glob.glob(f'parts/hist_{market}_*.jsonl.gz')]
    return sorted(set(plain) | set(gz))


def open_curves(path, verbose=True):
    """Itère sur les lignes JSONL d'un fichier de courbes, quel que soit son état.

    - nom legacy monolithique (book_curves.jsonl, set1/set2)  -> partitions hist
    - nom de fichier plat live absent (*_curves_live.jsonl)   -> rebuild depuis parts/
    - fichier réellement présent                              -> lecture directe
    - rien d'exploitable  -> lève FileNotFoundError (BRUYANT, jamais silencieux)
    """
    LEGACY_HIST = {'book_curves.jsonl': 'book',
                   'set1_curves.jsonl': 'set1',
                   'set2_curves.jsonl': 'set2'}
    LEGACY_LIVE = {'book_curves_live.jsonl': 'match',
                   'set1_curves_live.jsonl': 'set1',
                   'set2_curves_live.jsonl': 'set2'}
    base = os.path.basename(str(path))

    # 15/10/2026 : clv_history.jsonl est partitionné par mois (clv_store).
    if base == 'clv_history.jsonl':
        import clv_store
        if not clv_store.exists(str(path)):
            raise FileNotFoundError(f"{path} introuvable (ni fichier, ni partitions clv_history/)")
        for line in clv_store.iter_lines(str(path)):
            if line.strip():
                yield line
        return

    if base in LEGACY_HIST and not os.path.exists(path):
        market = LEGACY_HIST[base]
        # Compter aussi les partitions COMPRESSÉES (.jsonl.gz) : depuis la
        # compression du 16/08/2026, l'historique peut n'exister que sous
        # cette forme -- un glob sur '.jsonl' seul concluait à tort à l'absence
        # totale d'historique et faisait échouer tous les consommateurs.
        n = (len(glob.glob(f'parts/hist_{market}_*.jsonl'))
             + len(glob.glob(f'parts/hist_{market}_*.jsonl.gz')))
        if verbose:
            print(f"  [open_curves] {base} absent -> {n} partition(s) parts/hist_{market}_*")
        if n == 0:
            raise FileNotFoundError(f"{base} absent ET aucune partition parts/hist_{market}_*")
        for line in iter_hist_lines(market):
            yield line
        return

    if base in LEGACY_LIVE and not os.path.exists(path):
        market = LEGACY_LIVE[base]
        if verbose:
            print(f"  [open_curves] {base} absent -> reconstruction depuis parts/live_{market}_*.jsonl")
        try:
            import curves_parts
            curves_parts.rebuild(market, out_file=path)
        except Exception as e:
            raise FileNotFoundError(f"{base} absent et rebuild impossible : {e}")
        if not os.path.exists(path):
            raise FileNotFoundError(f"{base} absent et rebuild n'a rien produit")

    if not os.path.exists(path):
        raise FileNotFoundError(f"{path} introuvable (ni legacy, ni partition)")
    with open(path, encoding='utf-8') as f:
        for line in f:
            if line.strip():
                yield line


MW_MARKET = 121     # marche "Winner" (vainqueur du match) tennis
OUT_HOME = 121      # outcomeId home (participant1)
OUT_AWAY = 122      # outcomeId away (participant2)
# Marches "set" (confirmes sonde) : 1er outcomeId = marketId, +1 = away.
SET1_MARKET, SET1_HOME, SET1_AWAY = 123, 123, 124   # First Set Winner
SET2_MARKET, SET2_HOME, SET2_AWAY = 125, 125, 126   # Second Set Winner

# Books par défaut = ensemble validé pour le steam. L'API attend une LISTE de keys
# de books ; "auto" n'est PAS une valeur API valide — la passer brute renvoie des
# fixtures SANS cotes (régression observée). On résout donc "auto"/"" ici, en amont
# de tout appel. Pour élargir, passer une liste explicite via CAPTURE_BOOKS.
DEFAULT_BOOKS = "pinnacle,unibet,bwin,betsson"

# Passe à True dès qu'un appel renvoie un statut "quota épuisé" (429 / 403 quota).
# Permet aux appelants de distinguer "pas de données" de "API bloquée".
QUOTA_HIT = False
_RETRY_SPENT = 0.0   # secondes déjà perdues en échecs+backoff (deadline globale)

def _resolve_books(bookmakers):
    b = (bookmakers or "").strip().lower()
    if b in ("", "auto", "default"):
        return DEFAULT_BOOKS
    return bookmakers


_MARKER = "HTTPSTATUS:"

# COMPTEUR DE QUOTA RÉEL (ajouté le 15/10/2026). RapidAPI renvoie dans les
# en-têtes de CHAQUE réponse le quota du mois : x-ratelimit-requests-limit,
# -remaining et -reset (secondes avant renouvellement). C'est la seule
# mesure qui compte TOUT (capture, CLV, courbes, résultats...) : les
# compteurs internes ne voient que leur propre script.
# QUOTA : dernier relevé lu ; REQUETES_RESEAU : appels réellement envoyés
# par ce process (retries compris).
QUOTA = {}
REQUETES_RESEAU = 0


def _lire_quota(chemin_entetes):
    """Met à jour QUOTA depuis le fichier d'en-têtes écrit par curl -D."""
    try:
        lignes = open(chemin_entetes, encoding='utf-8', errors='replace').read().splitlines()
    except OSError:
        return
    vus = {}
    for l in lignes:
        if ':' not in l:
            continue
        k, _, v = l.partition(':')
        k = k.strip().lower()
        if k.startswith('x-ratelimit-'):
            vus[k] = v.strip()
    if not vus:
        return
    def entier(*noms):
        for n in noms:
            try:
                return int(float(vus[n]))
            except (KeyError, ValueError):
                pass
        return None
    QUOTA.clear()
    QUOTA.update({
        'limit': entier('x-ratelimit-requests-limit', 'x-ratelimit-limit'),
        'remaining': entier('x-ratelimit-requests-remaining', 'x-ratelimit-remaining'),
        'reset_s': entier('x-ratelimit-requests-reset', 'x-ratelimit-reset'),
        'brut': vus,
    })


# --------------------------------------------------------------------------
# Transport
# --------------------------------------------------------------------------
def api_get(path, params=None, timeout=40, verbose=False):
    """GET RapidAPI avec retry + backoff. Renvoie (data|None, status:int|None).

    AJOUT DU 25/08/2026 — retry 2/4/8 s.
    Un snapshot raté (502, timeout réseau, réponse tronquée) n'est PAS
    récupérable au cycle suivant : le point T-3 est perdu et le match bascule
    en closing_reliable=False. C'était le maillon faible direct de la métrique
    de validation. On rejoue donc les échecs de TRANSPORT :
      - exception curl / timeout / status None (réseau coupé)
      - 5xx (panne côté serveur)
      - réponse non-JSON avec status 200 (proxy qui renvoie une page d'erreur)
    On ne rejoue JAMAIS :
      - 429 ou 403-quota : QUOTA_HIT est levé, rejouer brûlerait le budget
        (1400 requêtes/jour) pour rien — exactement la boucle à éviter ;
      - les autres 4xx : erreur de requête, le retry donnerait le même résultat.
    Env : ODDS_RETRIES (défaut 3) pour couper le retry dans les sondes.
    """
    retries = int(os.environ.get('ODDS_RETRIES', '3'))
    delais = (2, 4, 8)
    deadline = float(os.environ.get('ODDS_DEADLINE_S', '300'))
    global _RETRY_SPENT
    for tentative in range(retries + 1):
        t0 = time.monotonic()
        data, status = _api_get_once(path, params, timeout, verbose)
        if data is not None:
            return data, status
        _RETRY_SPENT += time.monotonic() - t0      # le temps perdu compte aussi
        if QUOTA_HIT:
            return None, status                    # quota : on n'insiste pas
        if status is not None and 400 <= status < 500:
            return None, status                    # 4xx : rejouer est inutile
        # DEADLINE GLOBALE (25/08/2026). 3 retries x (40 s de timeout + 14 s
        # de backoff) = jusqu'à ~174 s pour UN appel. capture_closing enchaîne
        # plusieurs appels sous timeout-minutes: 12 : si l'API est morte, on
        # perdait le RUN ENTIER (commit compris) au lieu d'un point. Le budget
        # de retry est donc PARTAGÉ par tout le process : une fois épuisé,
        # chaque appel garde SA tentative unique, mais plus aucun ne rejoue.
        if _RETRY_SPENT >= deadline:
            print(f"  ⏱️ budget retry épuisé ({_RETRY_SPENT:.0f}s >= "
                  f"{deadline:.0f}s) — plus de rejeu, tentatives uniques.")
            return None, status
        if tentative < retries:
            d = delais[min(tentative, len(delais) - 1)]
            print(f"  🔁 retry {tentative + 1}/{retries} sur {path} dans {d}s "
                  f"(status={status})")
            time.sleep(d)
            _RETRY_SPENT += d
    return None, status


def _api_get_once(path, params=None, timeout=40, verbose=False):
    """Une tentative GET via curl — logique historique inchangée."""
    params = params or {}
    qs = "&".join(f"{k}={v}" for k, v in params.items() if v is not None)
    url = f"{BASE}{path}" + (f"?{qs}" if qs else "")
    global REQUETES_RESEAU
    import tempfile
    _fd, _entetes = tempfile.mkstemp(prefix='odds_hdr_')
    os.close(_fd)
    cmd = [
        "curl", "-s", "-S", "-m", str(timeout),
        "-D", _entetes,
        "-w", f"\n{_MARKER}%{{http_code}}",
        "-H", f"x-rapidapi-key: {KEY}",
        "-H", f"x-rapidapi-host: {RAPIDAPI_HOST}",
        "-H", "Content-Type: application/json",
        "-H", "Accept: application/json",
        "--user-agent", UA,
        "--url", url,
    ]
    REQUETES_RESEAU += 1
    try:
        out = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout + 10)
    except Exception as e:
        print(f"  ⚠️ curl {path}: {e}")
        try:
            os.remove(_entetes)
        except OSError:
            pass
        return None, None
    _lire_quota(_entetes)
    try:
        os.remove(_entetes)
    except OSError:
        pass
    raw = out.stdout
    status, body = None, raw
    if _MARKER in raw:
        body, _, sc = raw.rpartition(_MARKER)
        sc = sc.strip()
        status = int(sc) if sc.isdigit() else None
    body = body.strip()
    if verbose:
        print(f"  GET {url} -> {status} ({len(body)}o)")
    if status and status >= 400:
        # Détection quota épuisé (RapidAPI : 429, parfois 403 avec message quota).
        # Drapeau module lisible par les appelants (capture_closing -> alerte Telegram).
        global QUOTA_HIT
        if status == 429 or (status == 403 and any(k in body.lower() for k in ('quota', 'exceed', 'limit'))):
            QUOTA_HIT = True
        print(f"  ⚠️ HTTP {status} sur {path}: {body[:160]}")
        return None, status
    try:
        return json.loads(body), status
    except Exception:
        print(f"  ⚠️ {path}: reponse non-JSON: {body[:160]}")
        return None, status


# --------------------------------------------------------------------------
# Helpers format
# --------------------------------------------------------------------------
def unix_to_iso(ts):
    """Unix secondes -> '2026-06-11T14:00:40Z'. Tolere None / deja-ISO."""
    if ts is None or ts == "":
        return ""
    if isinstance(ts, str) and "T" in ts:
        return ts  # deja ISO
    try:
        return datetime.datetime.utcfromtimestamp(int(ts)).strftime("%Y-%m-%dT%H:%M:%SZ")
    except Exception:
        return ""


def is_srl(fixture):
    """Vrai si match simule (SRL / 'Srl' / simulated reality league) -> a exclure."""
    tr = (fixture.get("tournament") or {})
    pr = (fixture.get("participants") or {})
    blob = " ".join([
        str(tr.get("tournamentName") or ""),
        str(pr.get("participant1Name") or ""),
        str(pr.get("participant2Name") or ""),
    ]).lower()
    return "srl" in blob or "(srl)" in blob or "simulated" in blob


def fixture_meta(fixture):
    """Extrait les meta utiles d'une fixture v5."""
    pr = fixture.get("participants") or {}
    tr = fixture.get("tournament") or {}
    st = fixture.get("startTime")
    return {
        "fixtureId": fixture.get("fixtureId", ""),
        "p1id": pr.get("participant1Id"),
        "p2id": pr.get("participant2Id"),
        "p1name": pr.get("participant1Name") or "",
        "p2name": pr.get("participant2Name") or "",
        "tournamentId": tr.get("tournamentId"),
        "tournamentName": tr.get("tournamentName") or "",
        "startTime_unix": st,
        "startTime_iso": unix_to_iso(st),
        "live": (fixture.get("status") or {}).get("live", False),
    }


# --------------------------------------------------------------------------
# Extraction match-winner (h2h)
# --------------------------------------------------------------------------
def _market_quotes(fixture, bookmaker, market_id, oid_home, oid_away):
    """(home, away) d'un marche a 2 issues pour un bookmaker. None si indispo.
    Le payload odds contient PLUSIEURS marches par bookmaker : on filtre."""
    odds = (fixture.get("odds") or {}).get(bookmaker) or {}
    home = away = None
    for v in odds.values():
        if not isinstance(v, dict):
            continue
        if v.get("marketId") != market_id:
            continue
        if not v.get("active", True) or not v.get("marketActive", True):
            continue
        price = v.get("price")
        if price is None:
            continue
        oid = v.get("outcomeId")
        lbl = str(v.get("bookmakerOutcomeId") or "").lower()
        if oid == oid_home or lbl == "home":
            home = price
        elif oid == oid_away or lbl == "away":
            away = price
    return home, away


def _mw_quotes(fixture, bookmaker):
    """(home, away) du marche vainqueur (121) pour un bookmaker. None si indispo."""
    return _market_quotes(fixture, bookmaker, MW_MARKET, OUT_HOME, OUT_AWAY)


def get_pinnacle_set1(fixture):
    """(home, away) Pinnacle du marche VAINQUEUR DU SET 1 (123) — meme payload,
    zero requete supplementaire. (None, None) si Pinnacle ne cote pas ce marche."""
    return _market_quotes(fixture, "pinnacle", SET1_MARKET, SET1_HOME, SET1_AWAY)


def extract_h2h(fixture, bookmaker):
    """Renvoie (home, away) pour un bookmaker donne (ou (None, None))."""
    return _mw_quotes(fixture, bookmaker)


def get_pinnacle_h2h(fixture):
    return _mw_quotes(fixture, "pinnacle")


def all_books_h2h(fixture):
    """[{key, home, away}] pour tous les books ayant 2 cotes valides sur le marche vainqueur."""
    out = []
    for bk in (fixture.get("odds") or {}).keys():
        h, a = _mw_quotes(fixture, bk)
        if h and a:
            out.append({"key": bk, "home": h, "away": a})
    return out


def all_books_market(fixture, market_id, oid_home, oid_away):
    """[{key, home, away}] pour tous les books cotant un marche a 2 issues donne
    (generalisation de all_books_h2h ; meme payload, zero requete). Sert aux
    marches set : SET1 (123/124), SET2 (125/126)."""
    out = []
    for bk in (fixture.get("odds") or {}).keys():
        h, a = _market_quotes(fixture, bk, market_id, oid_home, oid_away)
        if h and a:
            out.append({"key": bk, "home": h, "away": a})
    return out


# --------------------------------------------------------------------------
# Endpoints
# --------------------------------------------------------------------------
def get_sports():
    return api_get("/sports")[0] or []


def get_tournaments(sport_id=TENNIS_SPORT_ID):
    return api_get("/tournaments", {"sportId": sport_id})[0] or []


def fixtures_today(sport_id=TENNIS_SPORT_ID):
    data = api_get("/fixtures/today", {"sportId": sport_id})[0]
    return data if isinstance(data, list) else (data or {}).get("fixtures", []) or []


def fixtures_live(sport_id=TENNIS_SPORT_ID):
    data = api_get("/fixtures/live", {"sportId": sport_id})[0]
    return data if isinstance(data, list) else (data or {}).get("fixtures", []) or []


def odds_main(tournament_id, bookmakers="pinnacle"):
    """Cotes courantes (tous marches principaux) des fixtures d'un tournoi."""
    data, _ = api_get("/fixtures/odds/main",
                      {"tournamentId": tournament_id, "bookmakers": _resolve_books(bookmakers)})
    return data if isinstance(data, list) else (data or {}).get("fixtures", []) or []


def odds_main_by_fixtures(fixture_ids, bookmakers="pinnacle"):
    """Cotes courantes pour une LISTE de fixtureIds (batch, 1 requete)."""
    ids = ",".join(str(x) for x in fixture_ids if x)
    if not ids:
        return []
    books = _resolve_books(bookmakers)
    data, _ = api_get("/fixtures/odds/main", {"fixtureIds": ids, "bookmakers": books})
    # FILET DE SECURITE : si une liste ELARGIE ne renvoie rien (slug inconnu, URL
    # trop longue, book non couvert par le plan...), on retente avec la liste sure.
    # Evite de revivre un trou de capture silencieux comme le bug CAPTURE_BOOKS=auto.
    if (not data) and books != DEFAULT_BOOKS and len(books.split(',')) > 5:
        print(f"  ⚠️ aucune cote avec la liste elargie ({len(books.split(','))} books) "
              f"-> repli sur {DEFAULT_BOOKS}")
        data, _ = api_get("/fixtures/odds/main", {"fixtureIds": ids, "bookmakers": DEFAULT_BOOKS})
    return data if isinstance(data, list) else (data or {}).get("fixtures", []) or []


def historical(fixture_id, bookmaker="pinnacle"):
    """Reponse brute de l'historique d'un match pour un bookmaker."""
    return api_get("/fixtures/odds/historical",
                   {"fixtureId": fixture_id, "bookmaker": bookmaker})[0]


def historical_curves(fixture_id, bookmaker="pinnacle", outcome_ids=None, with_limit=False):
    """
    Courbes temporelles pour des outcomeIds donnés (1 appel historique).
    Renvoie {outcomeId: [(ts_ms, price), ...] trié}.
    with_limit=True -> [(ts_ms, price, limit), ...] : la LIMITE DE MISE Pinnacle
    est exposée par /fixtures/odds/historical (champ 'limit'). Elle monte par
    paliers a mesure que le marche murit (25 -> 50 -> 100 -> 125...) et sert de
    proxy de confiance du book dans son prix. Non disponible sur /odds/main,
    donc recuperable seulement a posteriori.
    """
    data = historical(fixture_id, bookmaker)
    series = ((data or {}).get("odds") or {}).get(bookmaker) or {}
    want = set(outcome_ids) if outcome_ids else None
    out = {}
    for _odds_id, serie in series.items():
        if not isinstance(serie, dict) or not serie:
            continue
        sample = next(iter(serie.values()), {}) or {}
        oid = sample.get("outcomeId")
        if want is not None and oid not in want:
            continue
        pts = []
        for ts, q in serie.items():
            try:
                q = q or {}
                if with_limit:
                    pts.append((int(ts), q.get("price"), q.get("limit")))
                else:
                    pts.append((int(ts), q.get("price")))
            except Exception:
                pass
        pts.sort()
        out[oid] = pts
    return out


def historical_h2h_curve(fixture_id, bookmaker="pinnacle"):
    """
    Courbe du marché vainqueur. Renvoie {'home': [(ts_ms, price)], 'away': [...]}.
    """
    c = historical_curves(fixture_id, bookmaker, (OUT_HOME, OUT_AWAY))
    return {"home": c.get(OUT_HOME, []), "away": c.get(OUT_AWAY, [])}


def historical_market_timing(fixture_id, bookmaker):
    """
    Par marché (sur l'historique d'un match/book) :
    {marketId: {'n_outcomes', 'n_points', 'first_ms', 'last_ms'}}.
    Sert aux sondes (timing d'activation set1/set2 vs coup d'envoi).
    """
    data = historical(fixture_id, bookmaker)
    series = ((data or {}).get("odds") or {}).get(bookmaker) or {}
    by_market = {}
    for serie in series.values():
        if not isinstance(serie, dict) or not serie:
            continue
        sample = next(iter(serie.values()), {}) or {}
        mid = sample.get("marketId")
        ts = []
        for t in serie.keys():
            try:
                ts.append(int(t))
            except Exception:
                pass
        if not ts:
            continue
        d = by_market.get(mid)
        if d is None:
            d = {"n_outcomes": 0, "n_points": 0, "first_ms": min(ts), "last_ms": max(ts)}
            by_market[mid] = d
        d["n_outcomes"] += 1
        d["n_points"] += len(ts)
        d["first_ms"] = min(d["first_ms"], min(ts))
        d["last_ms"] = max(d["last_ms"], max(ts))
    return by_market


# --------------------------------------------------------------------------
# Settlement (notation officielle des paris -> resultat du match)
# --------------------------------------------------------------------------
def settlement(fixture_id, outcome_id=None, player_id=None):
    """Reponse brute /fixtures/settlement pour un match (fixture meta + settlements[])."""
    params = {"fixtureId": fixture_id}
    if outcome_id is not None:
        params["outcomeId"] = outcome_id
    if player_id is not None:
        params["playerId"] = player_id
    return api_get("/fixtures/settlement", params)[0]


def settlement_result(fixture_id):
    """
    Resout le match via /fixtures/settlement (UNE seule requete) :
      - vainqueur du MATCH  : marche 121 (outcome 121=home / 122=away, status 'won')
      - vainqueur du SET 1  : marche 123 (outcome 123=home / 124=away, status 'won')
      - vainqueur du SET 2  : marche 125 (outcome 125=home / 126=away, status 'won')
    Renvoie {finished, winner, set1, set2, p1_sets, p2_sets, status_name}.
    winner/set1 valent 'home'/'away'/None. Secours match : score en sets.
    (Pas de secours possible pour set1 : 2-1 ne dit pas qui a pris le 1er set.)
    """
    out = {"finished": False, "winner": None, "set1": None, "set2": None,
           "p1_sets": None, "p2_sets": None, "status_name": None}
    data = settlement(fixture_id)
    if not isinstance(data, dict):
        return out
    st = data.get("status") or {}
    out["status_name"] = st.get("statusName")
    out["finished"] = (st.get("statusName") == "Finished") or \
                      (st.get("live") is False and st.get("statusId") == 2)
    res = (data.get("scores") or {}).get("result") or {}
    out["p1_sets"] = res.get("participant1Score")
    out["p2_sets"] = res.get("participant2Score")
    for s in (data.get("settlements") or []):
        # Comparaisons en CHAINES : l'API peut renvoyer marketId/outcomeId en str
        # ("123") ou en int (123) selon les endpoints — on normalise tout.
        mid = str(s.get("marketId"))
        oid = str(s.get("outcomeId"))
        # Vocabulaire REEL de l'API (sonde 11/06) : 'WIN'/'LOSE'/'UNDECIDED'
        # (la spec OpenAPI disait 'won'/'lost' — on accepte les deux familles).
        stat = str(s.get("status") or "").lower()
        if stat not in ("win", "won"):
            continue
        if mid == str(MW_MARKET) and out["winner"] is None:
            if oid == str(OUT_HOME):
                out["winner"] = "home"
            elif oid == str(OUT_AWAY):
                out["winner"] = "away"
        elif mid == str(SET1_MARKET) and out["set1"] is None:
            if oid == str(SET1_HOME):
                out["set1"] = "home"
            elif oid == str(SET1_AWAY):
                out["set1"] = "away"
        elif mid == str(SET2_MARKET) and out["set2"] is None:
            if oid == str(SET2_HOME):
                out["set2"] = "home"
            elif oid == str(SET2_AWAY):
                out["set2"] = "away"
        if out["winner"] and out["set1"] and out["set2"]:
            break
    if out["winner"] is None and out["p1_sets"] is not None and out["p2_sets"] is not None:
        if out["p1_sets"] > out["p2_sets"]:
            out["winner"] = "home"
        elif out["p2_sets"] > out["p1_sets"]:
            out["winner"] = "away"
    return out


def get_bookmakers(filter_slugs="all"):
    """Catalogue des bookmakers disponibles pour la clé. Renvoie Bookmaker[]."""
    return api_get("/bookmakers", {"bookmakers": filter_slugs})[0] or []


def books_for_fixture(fixture_id, bookmakers="all"):
    """
    Liste des books qui cotent le marché vainqueur d'un match donné (via odds/main).
    Renvoie {slug: (home, away)}.
    """
    fx = odds_main_by_fixtures([fixture_id], bookmakers)
    if not fx:
        return {}
    f0 = fx[0]
    out = {}
    for bk in (f0.get("odds") or {}).keys():
        h, a = _mw_quotes(f0, bk)
        if h and a:
            out[bk] = (h, a)
    return out


def discover_tennis_tournaments(exclude_srl=True):
    """
    Decouvre les tournois tennis ayant des matchs aujourd'hui.
    Renvoie {tournamentId(str): {'name': ..., 'count': n}}.
    """
    fx = fixtures_today(TENNIS_SPORT_ID)
    out = {}
    for f in fx:
        if exclude_srl and is_srl(f):
            continue
        tr = f.get("tournament") or {}
        tid = tr.get("tournamentId")
        if tid is None:
            continue
        k = str(tid)
        if k not in out:
            out[k] = {"name": tr.get("tournamentName") or f"tournoi_{k}", "count": 0}
        out[k]["count"] += 1
    return out


def ecriture_atomique(chemin, payload, **kwargs):
    """Écrit `payload` en JSON de façon atomique (fichier temporaire +
    os.replace()) -- AJOUTÉ LE 29/08/2026 (audit v13 §BF).

    `open(chemin, 'w')` TRONQUE le fichier AVANT la première écriture --
    toute exception survenant entre l'ouverture et la fin du json.dump()
    (ex. un NameError sur une variable référencée dans le payload) laisse
    un fichier VIDE sur disque, que `git add -A` committe tel quel.
    Reproduit exactement sur capture_state.json le 28/08 : 55 octets ->
    NameError avalé par un except générique -> 0 octet -> committé, avec
    pour seule trace un message commençant par "ℹ️".

    os.replace() est atomique au niveau du système de fichiers (POSIX,
    et Windows depuis Python 3.3+) : soit l'ancien fichier complet reste
    en place, soit le nouveau complet le remplace -- jamais un état
    intermédiaire tronqué visible depuis l'extérieur, y compris si le
    processus est tué en plein milieu de l'écriture.

    Kwargs transmis tels quels à json.dump (ensure_ascii, indent, ...).

    RÉSERVE ASSUMÉE : appliqué ce soir aux fichiers d'état les plus
    critiques nommés par l'audit (capture_state.json, closing_lines.json,
    extended_state.json, active_tournaments.json, early_open_state.json).
    ~35 autres scripts du dépôt utilisent encore le motif non atomique --
    non convertis ce soir (risque de rewrite à grande échelle sous
    pression), mais cet utilitaire est prêt pour eux."""
    chemin_tmp = f'{chemin}.tmp'
    try:
        with open(chemin_tmp, 'w', encoding='utf-8') as f:
            json.dump(payload, f, **kwargs)
        os.replace(chemin_tmp, chemin)
    except Exception:
        # AJOUTÉ EN TESTANT ce correctif : sans ce nettoyage, un échec de
        # json.dump() (ex. objet non sérialisable) laisse le .tmp sur
        # disque -- et un .tmp qui traîne est exactement le même risque
        # qu'un fichier d'état vide : un `git add -A` non filtré peut
        # l'embarquer. os.replace() n'est jamais atteint dans ce cas, donc
        # le fichier ORIGINAL reste intact (c'est le but premier), mais il
        # ne faut pas laisser de résidu à côté.
        try:
            os.remove(chemin_tmp)
        except OSError:
            pass
        raise


def ecriture_atomique_texte(chemin, contenu):
    """Variante de ecriture_atomique() pour du texte déjà sérialisé (JSONL
    -- une ligne par enregistrement, pas un seul objet JSON) -- AJOUTÉ LE
    29/08/2026 (validation externe, périmètre resserré à 2 sites).

    Même mécanisme (fichier .tmp + os.replace(), nettoyage en cas
    d'échec), mais json.dump() ne convient pas à des enregistrements
    sérialisés un par un puis joints -- ecriture_atomique() empaquette un
    objet PYTHON unique en JSON, ici `contenu` est déjà la chaîne de
    caractères finale (les appelants construisent leurs lignes eux-mêmes,
    comme ils le faisaient avant ce correctif).

    Trouvé par validation externe : save_journal() (paper_journal.py) et
    son équivalent canal (paper_journal_canal.py) réécrivent leur fichier
    ENTIER à chaque appel (6x/cycle pour le premier) via open(...,'w') non
    atomique -- si le processus est tué en plein milieu (ex. le job
    steam_pipeline.yml a timeout-minutes: 45 ; un timeout en pleine
    écriture produit exactement ça), le JSONL résultant reste
    SYNTAXIQUEMENT VALIDE mais tronqué -- contrairement au cas
    capture_state.json du 28/08 (0 octet, détectable), ici rien ne le
    signale : pas d'exception, pas de code de retour non nul, `git add -A`
    committe un historique de paris amputé sans laisser de trace. Ce que
    ça perd est irrécupérable (les cotes d'entrée au moment de la
    détection) -- exactement le track record forward sur lequel repose le
    reste de la validation."""
    chemin_tmp = f'{chemin}.tmp'
    try:
        with open(chemin_tmp, 'w', encoding='utf-8') as f:
            f.write(contenu)
        os.replace(chemin_tmp, chemin)
    except Exception:
        try:
            os.remove(chemin_tmp)
        except OSError:
            pass
        raise

