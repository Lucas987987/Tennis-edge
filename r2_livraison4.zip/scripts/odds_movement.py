#!/usr/bin/env python3
"""
Détecteur de mouvement de cote (capteur défensif) + journal d'étude.

Deux mécanismes DISSOCIÉS :

1. ALERTE Telegram (en direct) : envoyée quand l'amplitude >= ALERT_PCT.
   But : te faire voir passer les mouvements notables. Défensif, jamais un
   signal d'entrée. Anti-spam via odds_alerts_state.json.

2. LOG d'étude (permanent) : UNE ligne par match, écrite une seule fois quand
   le match entre dans la fenêtre closing (<= LOG_AT_MINS avant le coup
   d'envoi). On logge TOUS les matchs, même ceux qui n'ont pas bougé (amplitude
   0%), car l'analyse a besoin des non-mouvements autant que des mouvements.
   Fichier odds_alerts_log.jsonl, append-only, jamais effacé.
   Clé de jointure 'uid' commune avec backtest_tennis.csv et le CLV.

PHILOSOPHIE : on mesure tout, on ne conclut rien tant qu'on n'a pas de volume.
"""
import os, json, urllib.request, urllib.parse, datetime
import lien_joueur                   # noqa: E402 — liens vers les fiches
import closing_store   # closing_lines chaud + archives mensuelles (16/10/2026)
import alerts_store   # odds_alerts_log découpé par mois (16/10/2026)

CLOSING_FILE = 'closing_lines.json'
ALERTS_FILE = 'odds_alerts_state.json'   # état anti-spam des alertes (éphémère)
ALERTS_LOG = 'odds_alerts_log.jsonl'     # journal d'étude (append-only, permanent)
LOGGED_FILE = 'odds_logged_state.json'   # mémorise quels matchs sont déjà loggés

ALERT_PCT = 3.0         # seuil d'ALERTE Telegram (%)
RE_ALERT_PCT = 5.0      # ré-alerte si le mouvement s'aggrave encore de ce % 
LOG_AT_MINS = 35        # on logge le match quand il est <= 35 min avant le coup d'envoi
MIN_POINTS = 2          # au moins 2 points d'historique pour calculer un mouvement
MAX_AMP_PCT = float(os.environ.get('MAX_AMP_PCT', '35'))  # garde-fou anti-corruption (voir _compute_move)
TRAJ_POINTS = int(os.environ.get('TRAJ_POINTS', '8'))  # nb max de points montrés dans la trajectoire


def _pct_move(first, last):
    """Mouvement relatif d'une cote entre premier et dernier point, en %."""
    if not first or not last:
        return None
    try:
        return (last - first) / first * 100.0
    except ZeroDivisionError:
        return None


def _compute_move(uid, m):
    """Calcule le mouvement complet d'un match (premier point -> dernier point).
    PRE-MATCH UNIQUEMENT : les matchs deja commences sont ignores, et les points
    in-play (mins_before < 0, anciens historiques pollues) sont ecartes — sinon
    on compare une cote pre-match a une cote live et on alerte sur du faux
    "mouvement" (ex: +394% sur un match en cours). Retourne None si pas assez
    de donnees."""
    # Match deja commence -> aucune alerte de mouvement (c'est du live, pas du marche pre-match)
    ct = m.get('commence_time', '')
    if ct:
        try:
            # Comparaison en AWARE des deux côtés. La version précédente
            # forçait .replace(tzinfo=None) puis comparait à utcnow() : juste,
            # mais reposant sur deux conventions implicites qui devaient rester
            # d'accord, et sur utcnow() qui disparaîtra. Ce garde-fou empêche
            # d'alerter sur un match DÉJÀ EN COURS (+394% observé) : il ne doit
            # pas casser en silence le jour d'une montée de version.
            start = datetime.datetime.fromisoformat(str(ct).replace('Z', '+00:00'))
            if start.tzinfo is None:
                start = start.replace(tzinfo=datetime.timezone.utc)
            if start <= datetime.datetime.now(datetime.timezone.utc):
                return None
        except (ValueError, TypeError):
            pass
    hist = [p for p in (m.get('history') or [])
            if p.get('mins_before') is None or p.get('mins_before') >= 0]
    if len(hist) < MIN_POINTS:
        return None
    first, last = hist[0], hist[-1]
    mv_home = _pct_move(first.get('home'), last.get('home'))
    mv_away = _pct_move(first.get('away'), last.get('away'))
    if mv_home is None or mv_away is None:
        return None
    amp = max(abs(mv_home), abs(mv_away))

    # GARDE-FOU ANTI-CORRUPTION : un mouvement PRE-MATCH > MAX_AMP_PCT n'est
    # (quasi) jamais reel -- signature connue d'un decalage entre l'heure
    # officielle (commence_time) et le vrai debut du match (le match a
    # commence "en avance" sur le planning), ou d'un point de capture
    # corrompu. Meme protection que celle deja validee sur canal_public.py
    # (cas Hurkacz/Popyrin) : un plafond de sanite independant de toute
    # logique de date/heure, donc robuste meme si mins_before/commence_time
    # sont eux-memes faux. Cas declencheur : Perricard vs Svajda, alerte a
    # "T-9 min" affichant +111.6% alors que le match etait deja en cours.
    if amp > MAX_AMP_PCT:
        return None

    return {
        'uid': uid,
        'home': m.get('home', '?'),
        'away': m.get('away', '?'),
        'tournament': m.get('tournament', ''),
        'sport_key': m.get('sport_key', ''),
        'niveau': m.get('niveau', ''),
        'commence_time': m.get('commence_time', ''),
        'n_points': len(hist),
        'o_home_first': first.get('home'),
        'o_home_last': last.get('home'),
        'o_away_first': first.get('away'),
        'o_away_last': last.get('away'),
        'mv_home': round(mv_home, 1),
        'mv_away': round(mv_away, 1),
        'amp': round(amp, 1),
        'mins_before': last.get('mins_before'),
        'history': hist,
    }


def send_telegram(token, chat_id, text, copie_x=None):
    """Envoie l'alerte. `copie_x` : texte prêt pour X, mis derrière un bouton
    « Copier pour X » sous le message.

    POURQUOI UN BOUTON (09/10/2026)
    -------------------------------
    Sur X, un nom ne peut pas être un lien : seule une adresse écrite en
    entier est cliquable. Or dans Telegram on ne veut PAS d'adresse visible
    (les noms y sont cliquables). Essayé d'abord : l'adresse en spoiler en
    fin de message. Ça ne marche pas — Telegram Android ne copie pas le
    texte des spoilers.

    Le bouton à copie (copy_text, Bot API 7.11) règle les deux : le message
    reste propre, et un appui met dans le presse-papiers un texte COURT,
    écrit pour X, qui se termine par l'adresse de la fiche. X en fait un
    lien cliquable et affiche la carte d'aperçu de la page.

    REPLI : si Telegram refuse le message à cause du bouton (client ou API
    trop ancien, texte trop long), on renvoie le même message SANS bouton.
    Une alerte ne doit jamais être perdue pour un bouton.
    """
    url = f"https://api.telegram.org/bot{token}/sendMessage"

    def _envoi(avec_bouton):
        champs = {
            'chat_id': chat_id,
            'text': text,
            'parse_mode': 'HTML',
            'disable_web_page_preview': 'true',
        }
        if avec_bouton:
            champs['reply_markup'] = json.dumps({'inline_keyboard': [[{
                'text': '📋 Copier pour X',
                'copy_text': {'text': copie_x},
            }]]}, ensure_ascii=False)
        data = urllib.parse.urlencode(champs).encode()
        req = urllib.request.Request(
            url, data=data, headers={'User-Agent': 'tennis-edge/1.0'})
        with urllib.request.urlopen(req, timeout=15) as r:
            return r.status == 200

    if copie_x:
        try:
            return _envoi(True)
        except Exception as e:
            print(f"  ⚠️ Telegram a refusé le bouton ({e}) — renvoi sans bouton")
    try:
        return _envoi(False)
    except Exception as e:
        print(f"  ⚠️ Telegram: {e}")
        return False


# Telegram limite le texte d'un bouton à copie à 256 caractères, comptés en
# unités UTF-16 : un emoji en vaut deux. On mesure donc comme Telegram.
COPIE_X_MAX = 256


def _longueur_tg(t):
    return len(t.encode('utf-16-le')) // 2


def texte_pour_x(mv):
    """Version COURTE de l'alerte, pour X, terminée par l'adresse de la fiche.

    Tient dans 256 caractères. Si ça déborde, on retire d'abord le détail
    des cotes, puis le nom du tournoi — jamais l'adresse ni la mention 18+.
    Sans adresse de fiche (FICHES_BASE vide), pas de bouton du tout.
    """
    u = lien_joueur.lien_duo(mv['home'], mv['away'])
    if not u:
        return None

    def cote(nom, first, last, pct):
        if pct is None or not pct:
            return None
        return f"{'📉' if pct < 0 else '📈'} {nom} {first} → {last}"

    tete = f"⚡ Mouvement de cote · {mv['home']} vs {mv['away']}"
    tournoi = f"({mv['tournament']})" if mv.get('tournament') else ''
    cotes = [x for x in (
        cote(mv['home'], mv['o_home_first'], mv['o_home_last'], mv['mv_home']),
        cote(mv['away'], mv['o_away_first'], mv['o_away_last'], mv['mv_away']),
    ) if x]
    tags = hashtags_x(mv.get('tournament')).strip() or '18+'

    for avec_cotes, avec_tournoi in ((True, True), (False, True), (False, False)):
        lignes = [tete + (f" {tournoi}" if avec_tournoi and tournoi else '')]
        if avec_cotes:
            lignes += cotes
        lignes += [tags, u]
        t = "\n".join(lignes)
        if _longueur_tg(t) <= COPIE_X_MAX:
            return t
    return None


def x_search_url(home, away):
    """Lien de recherche X pre-rempli sur les deux joueurs, tri 'Recent'.
    Gratuit, zero API -- meme fonction que dans steam_alert.py/canal_public.py."""
    def last(name):
        parts = [p for p in (name or '').split() if p]
        return parts[-1] if parts else (name or '')
    q = f'"{last(home)}" OR "{last(away)}"'
    return "https://x.com/search?q=" + urllib.parse.quote(q) + "&f=live"


def format_alert(mv):
    """Message défensif, neutre. N'incite jamais à parier.
    Montre le mouvement RÉEL de chaque joueur : 📉 baisse = se renforce,
    📈 hausse = se fragilise. Affiche les deux côtés pour ne rien cacher."""
    def ligne(nom, first, last, pct):
        if pct is None:
            return None
        if pct < 0:
            # cote baisse → joueur se renforce
            return f"📉 {nom} se renforce ({first} → {last}, {pct:+.1f}%)"
        elif pct > 0:
            # cote monte → joueur se fragilise
            return f"📈 {nom} se fragilise ({first} → {last}, {pct:+.1f}%)"
        else:
            return f"➡️ {nom} stable ({first})"

    l_home = ligne(mv['home'], mv['o_home_first'], mv['o_home_last'], mv['mv_home'])
    l_away = ligne(mv['away'], mv['o_away_first'], mv['o_away_last'], mv['mv_away'])
    sens = "\n".join(x for x in (l_home, l_away) if x)

    t = ""
    if mv['mins_before'] is not None:
        t = f" · T-{mv['mins_before']} min"
    traj = format_trajectory(mv.get('history') or [], mv['home'], mv['away'])
    return (
        f"⚡ <b>Mouvement de cote</b> ({mv['amp']}%)\n"
        f"{mv['tournament']}{t}\n"
        f"{lien_joueur.duo_html(mv['home'], mv['away'])}\n"
        f"{sens}"
        f"{hashtags_x(mv['tournament'])}\n"
        f"{traj}"
        f"\n"
        f"🔎 Posts X sur ce match : {x_search_url(mv['home'], mv['away'])}\n"
        f"<i>Le marché a réagi à quelque chose. Si tu avais un pari prévu ici, "
        f"réévalue avant de jouer. Ceci n'est pas un signal d'entrée.</i>"
    )


# ── Hashtags X ───────────────────────────────────────────────────────────
# AJOUTÉ LE 05/09/2026. Ces messages sont copiés-collés vers X, mais SEUL le
# bloc d'entête l'est (mouvement + joueurs) — pas le tableau de trajectoire ni
# le lien de recherche. Des hashtags en pied de message ne suivraient donc
# jamais le copier-coller : ils sont placés juste après les lignes de joueurs,
# à la fin de ce qui est réellement repris.
#
# DEUX hashtags, pas plus : au-delà X dégrade la portée et le post lit comme
# du spam. Volontairement PAS de #pronostic / #value / #pari — ils rangeraient
# le canal dans une catégorie qu'il refuse d'être, et attireraient un public
# qui cherche un pronostic là où on publie une observation de marché.
#
# `18+` est ajouté ici et pas seulement en pied de page : sur Telegram la
# mention vit dans la description du canal, sur X chaque post est autonome et
# peut être vu par n'importe qui, hors de tout contexte.
#
# Classement sur le NOM DU TOURNOI et non sur sport_key (identifiants
# opaques : oddspapi_2591...) ni sur niveau (deux valeurs seulement :
# 'grand_chelem' / 'autre', ce qui ne distingue ni ATP de WTA ni les
# Challengers).
HASHTAGS_ACTIFS = os.environ.get('HASHTAGS_X', '1') != '0'

def hashtags_x(tournoi):
    """Deux hashtags + mention 18+, choisis d'après le nom du tournoi."""
    if not HASHTAGS_ACTIFS:
        return ""
    t = (tournoi or '').lower()
    if 'challenger' in t:
        premier = '#ATPChallenger'      # communauté active et bien ciblée
    elif t.startswith('wta') or ' women' in t:
        premier = '#WTA'
    elif 'itf' in t:
        premier = '#ITF'
    elif t.startswith('atp') or ' men' in t:
        premier = '#ATPTour'
    else:
        premier = '#Tennis'             # repli : mieux que rien, mais générique
    # #TennisOdds : niche paris/trading anglophone, nettement plus large que
    # la francophone, et sans connotation d'incitation.
    return f"\n{premier} #TennisOdds · 18+"


def format_trajectory(hist, home, away):
    """Tableau compact de l'évolution des cotes (triées par horodatage), pour voir
    la trajectoire globale du match en un coup d'oeil. Sous-échantillonne si besoin."""
    pts = [p for p in hist if p.get('home') and p.get('away') and p.get('t')]
    pts.sort(key=lambda p: p['t'])
    if len(pts) < 2:
        return ""
    if len(pts) > TRAJ_POINTS:                       # garder 1er, dernier + répartis
        step = (len(pts) - 1) / (TRAJ_POINTS - 1)
        keep = sorted(set(round(i * step) for i in range(TRAJ_POINTS)))
        pts = [pts[i] for i in keep]
    rows = [f"{'date/heure':<11} {'cote1':>6} {'cote2':>6}"]
    for p in pts:
        dh = str(p['t'])[5:16].replace('T', ' ')   # MM-DD HH:MM
        rows.append(f"{dh:<11} {p['home']:>6} {p['away']:>6}")
    return (f"\n📊 Évolution (cote1={home}, cote2={away}, {len(hist)} pts) :\n"
            f"<pre>" + "\n".join(rows) + "</pre>\n")


def log_entry(mv):
    """Append UNE ligne d'étude (un match). Permanent, jamais effacé.
    Conçu pour être croisé avec backtest_tennis.csv et le CLV via 'uid'."""
    entry = {
        # utcnow() est déprécié depuis Python 3.12 et sera retiré ; les
        # workflows sont sur 3.11, donc pas d'urgence, mais autant ne pas
        # laisser une bombe à retardement dans un journal PERMANENT.
        'logged_at': datetime.datetime.now(datetime.timezone.utc)
                             .isoformat(timespec='seconds'),
        'uid': mv['uid'],
        'home': mv['home'],
        'away': mv['away'],
        'tournament': mv['tournament'],
        'sport_key': mv.get('sport_key', ''),
        'niveau': mv.get('niveau', ''),
        'commence_time': mv['commence_time'],
        'mins_before': mv['mins_before'],
        'n_points': mv['n_points'],
        'o_home_first': mv['o_home_first'],
        'o_home_last': mv['o_home_last'],
        'o_away_first': mv['o_away_first'],
        'o_away_last': mv['o_away_last'],
        'mv_home_pct': mv['mv_home'],
        'mv_away_pct': mv['mv_away'],
        'amplitude_pct': mv['amp'],
    }
    try:
        # 16/10/2026 : partition du mois courant (alerts_store) ; avant la
        # migration, alerts_store renvoie encore odds_alerts_log.jsonl.
        with open(alerts_store.append_path(), 'a', encoding='utf-8') as f:
            f.write(json.dumps(entry, ensure_ascii=False) + '\n')
        return True
    except Exception as e:
        print(f"  ⚠️ Écriture journal: {e}")
        return False


def _load_json(path, default):
    if os.path.exists(path):
        try:
            with open(path, encoding='utf-8') as f:
                return json.load(f)
        except Exception:
            return default
    return default


def run_movement_detector():
    token = os.environ.get('TELEGRAM_TOKEN', '')
    chat_id = os.environ.get('TELEGRAM_CHAT_ID', '')

    closing = closing_store.load_all_or(CLOSING_FILE, None)
    if not closing:
        return

    sent = _load_json(ALERTS_FILE, {})      # {uid: amplitude dernière alerte}
    logged = _load_json(LOGGED_FILE, {})    # {uid: True} matchs déjà loggés

    n_alert, n_log = 0, 0
    live_uids = set(closing.keys())

    for uid, m in closing.items():
        mv = _compute_move(uid, m)
        if mv is None:
            continue

        # ---- LOG d'étude : une seule fois, quand le match entre en fenêtre closing ----
        mb = mv['mins_before']
        if uid not in logged and mb is not None and mb <= LOG_AT_MINS:
            if log_entry(mv):
                logged[uid] = True
                n_log += 1

        # ---- ALERTE Telegram : si amplitude >= ALERT_PCT (et Telegram configuré) ----
        if token and chat_id and mv['amp'] >= ALERT_PCT:
            prev = sent.get(uid)
            if prev is None or (mv['amp'] - prev) >= RE_ALERT_PCT:
                if send_telegram(token, chat_id, format_alert(mv),
                                 copie_x=texte_pour_x(mv)):
                    sent[uid] = mv['amp']
                    n_alert += 1
                    print(f"  📨 Alerte: {mv['home']} vs {mv['away']} ({mv['amp']}%)")

    # Nettoyage des états éphémères (pas le log, lui est permanent)
    sent = {k: v for k, v in sent.items() if k in live_uids}
    logged = {k: v for k, v in logged.items() if k in live_uids}

    with open(ALERTS_FILE, 'w', encoding='utf-8') as f:
        json.dump(sent, f, ensure_ascii=False, indent=2)
    with open(LOGGED_FILE, 'w', encoding='utf-8') as f:
        json.dump(logged, f, ensure_ascii=False, indent=2)

    if not token or not chat_id:
        print(f"  ℹ️ Telegram non configuré — {n_log} match(s) loggé(s), alertes désactivées.")
    else:
        print(f"  ⚡ {n_log} match(s) loggé(s), {n_alert} alerte(s) envoyée(s).")


if __name__ == '__main__':
    run_movement_detector()
