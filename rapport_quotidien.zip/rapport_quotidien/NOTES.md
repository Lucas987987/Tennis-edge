# Rapport quotidien Telegram des requêtes (29/08/2026)

    unzip rapport_quotidien.zip
    cp rapport_quotidien/scripts/*.py scripts/

    bash rapport_quotidien/verifier.sh
    # doit afficher "TOUT EST EN PLACE (5 contrôles passés)"

    python tests/test_pure_functions.py      # doit afficher 13/13

    rm -rf rapport_quotidien rapport_quotidien.zip
    git add -A
    git commit -m "Rapport quotidien Telegram : total réel de requêtes OddsPapi de la veille, envoyé au changement de journée UTC"
    git pull --no-rebase --no-edit && git push

---

## Ce que ça fait

Un message Telegram par jour, sur ton canal admin (`TELEGRAM_CHAT_ID`,
jamais `TELEGRAM_PUBLIC_CHAT_ID`) :

    📊 Requêtes OddsPapi le 2026-08-29 : 147 requête(s).

Aucune configuration supplémentaire nécessaire : `TELEGRAM_TOKEN` et
`TELEGRAM_CHAT_ID` sont déjà passés en variables d'environnement à l'étape
de capture dans `capture_closing.yml`.

## Pourquoi ce déclenchement précis

Le message part depuis `capture_closing.py` lui-même, exactement au moment
où il détecte un changement de journée UTC (le même code qui gère déjà le
cumul `requetes_cumul_jour`) -- pas un workflow séparé sur un cron à
minuit, qui risquerait de manquer la fenêtre ou de lire un compteur déjà
remis à zéro par un autre run entre-temps. C'est mécaniquement le premier
run de la nouvelle journée qui envoie le total FINAL de la veille, avant
que son propre compteur ne reparte à zéro.

Testé sur les deux cas : aucun envoi en cours de journée (le cumul
continue silencieusement), un seul envoi au changement de jour, avec le
bon total et la bonne date.

## Sur ton estimation du volume mensuel

Deux chiffres, et un écart entre eux qu'il vaut mieux connaître :

- **Modèle théorique** (à partir de `decide()` dans le Worker, 5 tournois
  actifs, cadence 5 min le jour / 15 min la nuit) : ~540 req/jour, ~16 200
  req/mois.
- **Recalé sur l'observation réelle** de ce 29/08 (`requetes_cumul_jour`
  =62 à 14h20 UTC) : ~150 req/jour, ~4 400 req/mois.

L'écart (~3,5x) vient très probablement de la fréquence propre du cron
Cloudflare qui déclenche `scheduled()` dans le Worker -- un paramètre que
je ne peux pas voir depuis le code du Worker seul (il vit dans le tableau
de bord Cloudflare ou `wrangler.toml`). Ce rapport quotidien remplace
justement cette estimation par un fait mesuré, chaque jour -- garde les
messages des prochains jours, tu sauras vite lequel des deux chiffres (ou
un troisième) est le bon, et comment il varie avec le nombre de tournois
actifs.

## Tests : 13/13 (inchangé)
