#!/usr/bin/env bash
# verifier.sh — rapport quotidien Telegram des requêtes (29/08/2026).
#
# Usage : bash verifier.sh   (à la racine du dépôt, APRÈS les cp)

set -uo pipefail
ECHECS=0

verif() {
    local fichier="$1" motif="$2" description="$3"
    if [ ! -f "$fichier" ]; then
        echo "❌ $fichier : FICHIER ABSENT"
        ECHECS=$((ECHECS+1))
        return
    fi
    if grep -q "$motif" "$fichier"; then
        echo "✅ $fichier : $description"
    else
        echo "❌ $fichier : $description -- MOTIF ABSENT ($motif)"
        ECHECS=$((ECHECS+1))
    fi
}

echo "=== Vérification -- rapport quotidien Telegram (29/08/2026) ==="
echo

verif scripts/capture_closing.py "def _envoyer_rapport_quotidien_telegram" "fonction d'envoi créée"
verif scripts/capture_closing.py "TELEGRAM_CHAT_ID" "canal admin utilisé (pas TELEGRAM_PUBLIC_CHAT_ID)"
n_occ=$(grep -c "_envoyer_rapport_quotidien_telegram" scripts/capture_closing.py 2>/dev/null || echo 0)
if [ "$n_occ" -ge 2 ]; then
    echo "✅ scripts/capture_closing.py : appelé au changement de jour (def + appel, $n_occ occurrences)"
else
    echo "❌ scripts/capture_closing.py : appelé au changement de jour -- seulement $n_occ occurrence(s), le site d'appel manque"
    ECHECS=$((ECHECS+1))
fi
verif scripts/capture_closing.py "import urllib.request, urllib.parse" "import urllib ajouté"

echo
echo "=== Test critique : le déclencheur ne se trompe jamais de jour ==="
python3 -c "
import sys, json, datetime, re; sys.path.insert(0,'scripts')
import capture_closing as cc
appels = []
cc._envoyer_rapport_quotidien_telegram = lambda date, total: appels.append((date, total))

def simuler(now, prec_ts, prec_cumul):
    json.dump({'last_capture_at': prec_ts.isoformat(), 'requetes_cumul_jour': prec_cumul}, open('/tmp/_v_cs.json','w'))
    nreq_ce_run = 3
    requetes_cumul_jour = nreq_ce_run
    _prec = json.load(open('/tmp/_v_cs.json'))
    _prec_ts = datetime.datetime.fromisoformat(_prec.get('last_capture_at', ''))
    if _prec_ts.date() == now.date():
        requetes_cumul_jour += _prec.get('requetes_cumul_jour', 0)
    else:
        cc._envoyer_rapport_quotidien_telegram(_prec_ts.date(), _prec.get('requetes_cumul_jour', 0))
    return requetes_cumul_jour

appels.clear()
simuler(datetime.datetime(2026,8,29,14,0), datetime.datetime(2026,8,29,10,0), 47)
assert len(appels) == 0, 'FAUX POSITIF : rapport envoyé en cours de journée'

appels.clear()
simuler(datetime.datetime(2026,8,29,0,5), datetime.datetime(2026,8,28,23,50), 147)
assert appels == [(datetime.date(2026,8,28), 147)], f'contenu incorrect: {appels}'
print('✅ pas de rapport en cours de journée, un seul rapport au bon changement de jour, bon total')
" || ECHECS=$((ECHECS+1))

echo
if [ "$ECHECS" -eq 0 ]; then
    echo "✅✅✅ TOUT EST EN PLACE (5 contrôles passés). Sûr de committer."
    exit 0
else
    echo "❌❌❌ $ECHECS CONTRÔLE(S) EN ÉCHEC. NE PAS COMMITTER avant d'avoir compris pourquoi."
    exit 1
fi
