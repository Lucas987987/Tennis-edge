# Retry de push renforcé — 25 workflows

    bash appliquer.sh          # simulation
    bash appliquer.sh POSER    # écrit, commit et pousse

## Le problème

    ❌ PUSH ÉCHOUÉ après 3 tentatives — le commit local est perdu
       avec le runner.

    cannot lock ref 'refs/heads/main': is at 79eef178...
                                       but expected 4ba600f6...

Un autre workflow avait poussé entre le `fetch` et le `push`, **trois fois
de suite**. Le travail du run est jeté avec le runner.

C'est ce qui a figé `hist_curves_meta.json` pendant **538 heures** — un
échec détecté seulement par `audit_qa`, à l'âge du fichier.

## Pourquoi maintenant

La contention a augmenté : une douzaine de workflows commitent en continu,
et `courbes_alertes` pousse toutes les trois minutes. Trois tentatives
espacées de 5 secondes ne couvrent plus la durée d'un push concurrent.

## Le correctif

**6 tentatives, attente doublée à chaque fois** : 2, 4, 8, 16, 32 secondes,
soit **62 secondes cumulées**. Un run de capture dure environ 25 secondes,
donc on laisse passer deux cycles complets.

Le message indique désormais la tentative en cours, et distingue un push
refusé d'un merge en conflit.

## Les 25 workflows

Trois variantes de boucle coexistaient dans le dépôt. Toutes sont
traitées :

- 21 avec la boucle standard
- `health_check`, `pistes_weekly`, `polymarket_studies` — variante compacte
- `archive_ticks` — variante à `sleep 10` et structure inversée

Vérifié : les 25 ont la boucle à 6 tentatives et l'attente croissante,
et les 25 YAML se chargent sans erreur.

## Si ça se reproduit malgré tout

C'est que la contention est **structurelle**, et il faudra passer les
workflows qui commitent sur un même groupe `concurrency` — ils
s'attendraient au lieu de se marcher dessus. Le message d'échec le
rappelle désormais.

## Note sur l'autre rouge

    🔒 STRICT : 0 livrable(s) en défaut, 1 alerte(s)
    ⚠️ Taille du dépôt : 4,2 Go, seuil franchi (4,0 Go)

**Zéro livrable en défaut** : le pipeline tourne bien, c'est le seuil qui
alerte. Il date d'avant la purge, et la compression des partitions posée
aujourd'hui arrête la croissance.

Vous pouvez le relever à 5 Go dans `pipeline_status.py` pour cesser ces
rouges — la croissance est maîtrisée, le garde-fou a fait son travail.
