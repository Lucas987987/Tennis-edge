# Sentinelle quotidienne + runbook corrigé (29/08/2026)

## Ce que ça change

1. `scripts/repo_sentinel.py` — **branché**, et deux corrections de logique.
2. `.github/workflows/health_check.yml` — appel quotidien de la sentinelle.
3. `RUNBOOK_FILTER_REPO.md` — cibles corrigées sur mesure réelle.

Aucun autre fichier touché. Rien qui tourne en production n'est modifié :
la sentinelle est une surveillance en lecture seule (`gh api`).

---
## 1. La sentinelle était orpheline, et sa docstring l'affirmait active

`repo_sentinel.py` existe depuis le 26/08. Sa docstring déclarait : « la
taille serveur est mesurée chaque semaine via l'API, tracée dans le rapport
de pistes, et le run devient ROUGE au-delà du seuil ». **Rien de tout ça
n'arrivait.** Aucune référence dans `.github/` ; la seule mention dans tout
le dépôt était une case à cocher manuelle dans `RUNBOOK_FILTER_REPO.md:70`.

Hébergée dans `health_check.yml` (quotidien, 7h37 UTC, dispose déjà du
`GH_TOKEN`) plutôt que dans `pistes_weekly.yml` que suggérait la docstring :
avec 0,52 Go de marge mesurés et ~0,1-0,2 Go/jour, un cron dominical
laisserait franchir le seuil un lundi sans le signaler avant six jours.

`|| true` sur l'étape : la sentinelle ne doit jamais faire échouer le health
check lui-même, sinon une panne de `gh` masquerait les vrais résultats de
santé du pipeline. Le franchissement se lit dans le journal du run.

## 2. Deux corrections dans le script

**Indisponibilité ≠ dépassement.** La version précédente sortait `1` sous
`--strict` aussi bien quand `gh api` échouait que quand le seuil était
franchi. C'est le défaut corrigé en v9-v10 sur le `--strict` de
`pipeline_status` (avertissements Polymarket normaux comptés comme échecs) :
une panne passagère de `gh` aurait rendu le run rouge tous les jours, et le
rouge aurait cessé d'être un signal. L'indisponibilité est désormais un
avertissement explicite, avec la consigne de traiter la cause s'il se répète.

**Bande de vigilance** (`SEUIL_VIGILANCE_GO`, défaut 3,0 Go). À 3,48 Go, la
version précédente affichait « ✅ marge restante : 0.52 Go » — vert, donc
rassurant, alors qu'on est à quelques jours du seuil. Un état 🟠 intermédiaire
rend l'approche visible avant le franchissement, sans rendre le run rouge.

## 3. Le runbook visait les mauvaises cibles

Sa v1 (25/08) ciblait `pm_ticks_*`, `kx_ticks_*`, `*.zip` et annonçait
« ~2,6 Go → 400-500 Mo ». **Cette estimation était antérieure à toute mesure
de l'historique.**

Mesure du 29/08, clone `--mirror` complet, 138 059 objets, `size-pack:
3.33 GiB` :

| Catégorie | Poids (top 25) | % pack | Statut |
|---|---|---|---|
| `parts/live_*` | 683 Mo | 20,0 % | purgées à 3 j, blobs éternels |
| **`*_curves_live.jsonl`** | **592 Mo** | **17,4 %** | **MORT** — gitignorés, absents de HEAD |
| ticks pm/kx *(cible v1)* | 393 Mo | 11,5 % | archivés en Releases |
| `closing_lines.json` | 169 Mo | 5,0 % | **ACTIF, à ne jamais purger** |
| `set*_curves.jsonl` | 165 Mo | 4,8 % | absents de HEAD, à qualifier |
| **Total top 25** | **2 002 Mo** | **58,7 %** | |

La cible d'origine ne pèse que 11,5 % du top 25. Le runbook propose désormais
un ordre d'attaque : **A** les `*_curves_live.jsonl` (592 Mo, risque quasi nul
— gitignorés, absents de HEAD, régénérés par `curves_parts.py rebuild`, donc
le filtre ne peut toucher aucun fichier suivi) ; **B** les ticks si A ne
suffit pas ; **C** les `parts/live_*`, signalés comme une décision de fond à
trancher à froid, pas un nettoyage à faire un soir de purge.

## 4. Piège de mesure documenté

Le premier essai a été fait depuis le Codespace, cloné en `filter: blob:none`.
Avec `--missing=allow-any`, `git rev-list` ne classe que les ~12 % de blobs
présents localement et produit un palmarès **faux** : aucun `curves_live` n'y
apparaissait. La procédure de mesure correcte (clone `--mirror`) est
maintenant dans le runbook, avec l'avertissement.

## Bug trouvé dans mon propre harnais de test

Le premier jet faisait `python3 repo_sentinel.py | tr '\n' ' '` puis lisait
`$?` — qui donne le code de `tr`, pas de Python. Les huit cas sortaient `0`,
y compris ceux censés sortir `1`. C'est exactement le défaut reproché au
`verifier.sh` de la livraison précédente. Corrigé (code capturé directement),
retesté.

## Tests effectués

Sens propre → vert (code 0) : 7 contrôles statiques + 10 contrôles d'exécution.

Les 8 branches de décision, via un faux `gh` en tête de `PATH` :

| Taille | `--strict` | `gh` | Code | Sortie |
|---|---|---|---|---|
| 2,10 Go | non / oui | ok | 0 / 0 | ✅ |
| 3,48 Go | non / oui | ok | 0 / 0 | 🟠 vigilance |
| 4,20 Go | non | ok | 0 | 🔴 franchi |
| 4,20 Go | **oui** | ok | **1** | 🔴 franchi |
| — | non / oui | **HS** | 0 / 0 | ⚠️ non vérifiée |

Sens dégradé → sept bugs réintroduits, **chacun doit sortir non nul** :

| # | Bug réintroduit | Code |
|---|---|---|
| 1 | Sentinelle débranchée du workflow | 1 ✅ |
| 2 | Bande de vigilance retirée | 1 ✅ |
| 3 | Seuil franchi ne sort plus 1 sous `--strict` | 1 ✅ |
| 4 | `gh` HS reconfondu avec dépassement (défaut v9-v10) | 1 ✅ |
| 5 | Runbook revenu aux cibles d'origine | 1 ✅ |
| 6 | Étape renommée | 1 ✅ |
| 7 | YAML cassé | 1 ✅ |

## Limite assumée

**Le bac à sable n'a pas de réseau.** L'appel `gh api` réel n'a pas pu être
testé — seule la logique de décision l'est, via un faux `gh`. Ce qui reste
non vérifié : que `gh` soit bien présent et authentifié sur le runner
`ubuntu-latest` avec le `GH_TOKEN` fourni. Il l'est normalement (préinstallé,
et `gh` lit `GH_TOKEN` de l'environnement), et `health_check.yml` passe déjà
ce secret à l'étape précédente — mais **le premier run réel fait foi**.
À vérifier demain matin dans Actions → Health Check → étape « Sentinelle
taille du dépôt » : elle doit afficher une ligne `SENTINELLE DÉPÔT : …`, pas
un `⚠️ gh api indisponible`.

Déclenchement immédiat possible sans attendre 7h37 :
`gh workflow run health_check.yml -R Lucas987987/Tennis-edge`

## Application

```bash
unzip -o sentinelle_quotidienne.zip
cp -r sentinelle_quotidienne/scripts/. scripts/
cp -r sentinelle_quotidienne/.github/. .github/
cp sentinelle_quotidienne/RUNBOOK_FILTER_REPO.md .
bash sentinelle_quotidienne/verifier.sh      # doit sortir vert
python scripts/repo_sentinel.py              # doit afficher 🟠 ~3,48 Go
rm -rf sentinelle_quotidienne sentinelle_quotidienne.zip
git add -A
git commit -m "Sentinelle taille dépôt branchée en quotidien (health_check) + runbook filter-repo corrigé sur mesure réelle (3,33 GiB : curves_live 592 Mo, live_* 683 Mo, ticks 393 Mo)"
git pull --no-rebase --no-edit && git push
```

## Ce que ça ne fait PAS

Ça ne réduit pas la taille du dépôt d'un octet. C'est de la surveillance et
de la préparation. La purge elle-même reste à faire — le runbook dit
« un dimanche matin creux », et un force-push avec gel des écrivains et
réactivation du worker Cloudflare n'est pas une opération à lancer à 23h.
