#!/usr/bin/env bash
# verifier.sh — sentinelle quotidienne + runbook corrigé (29/08/2026).
#
# Le code retour des blocs d'exécution EST capturé (`if ... ; then`) : c'est
# précisément le défaut trouvé sur le verifier.sh de la livraison précédente,
# qui concluait "sûr de committer" malgré un AttributeError.
#
# Usage : bash verifier.sh   (à la racine du dépôt, APRÈS les cp)

set -uo pipefail
ECHECS=0

verif() {
    local fichier="$1" motif="$2" description="$3"
    if [ ! -f "$fichier" ]; then
        echo "❌ $fichier : FICHIER ABSENT"; ECHECS=$((ECHECS+1)); return
    fi
    if grep -q "$motif" "$fichier"; then
        echo "✅ $fichier : $description"
    else
        echo "❌ $fichier : $description -- MOTIF ABSENT ($motif)"; ECHECS=$((ECHECS+1))
    fi
}

echo "=== Vérification -- sentinelle quotidienne (29/08/2026) ==="
echo

verif .github/workflows/health_check.yml "repo_sentinel.py"          "sentinelle branchée dans health_check"
verif .github/workflows/health_check.yml "Sentinelle taille du dépôt" "étape nommée présente"
verif scripts/repo_sentinel.py           "SEUIL_VIGILANCE_GO"        "bande de vigilance ajoutée"
verif scripts/repo_sentinel.py           "ZONE DE VIGILANCE"         "message de vigilance présent"
verif RUNBOOK_FILTER_REPO.md             "RÉVISÉ LE 29/08/2026"      "runbook corrigé sur mesure réelle"
verif RUNBOOK_FILTER_REPO.md             "set1_curves_live.jsonl"    "cible A (592 Mo) documentée"
verif RUNBOOK_FILTER_REPO.md             "Ne jamais purger"          "closing_lines protégé explicitement"

echo
echo "=== Tests d'exécution (code retour CAPTURÉ) ==="

# `gh` n'est pas joignable ici (pas de réseau dans le bac à sable) : la
# mesure RÉELLE ne peut pas être testée, seule la LOGIQUE de décision l'est,
# via un faux `gh` en tête de PATH. Limite explicite, pas contournée.
if python3 - <<'PYEOF'
import ast, os, sys, subprocess, tempfile, stat
src = open('scripts/repo_sentinel.py', encoding='utf-8').read()
ast.parse(src)
print("  ✅ repo_sentinel.py : syntaxe valide")

faux = tempfile.mkdtemp()
chemin = os.path.join(faux, 'gh')
open(chemin, 'w').write(
    '#!/bin/bash\n'
    'if [ "$GH_FAIL" = "1" ]; then echo "gh: panne simulee" >&2; exit 1; fi\n'
    'echo "{\\"size\\": $GH_SIZE_KO}"\n')
os.chmod(chemin, os.stat(chemin).st_mode | stat.S_IEXEC)

def run(ko, strict=False, fail=False):
    env = dict(os.environ, PATH=faux + os.pathsep + os.environ['PATH'],
               GH_SIZE_KO=str(ko), GH_FAIL='1' if fail else '0')
    cmd = [sys.executable, 'scripts/repo_sentinel.py'] + (['--strict'] if strict else [])
    r = subprocess.run(cmd, capture_output=True, text=True, env=env)
    return r.returncode, r.stdout

for ko, strict, fail, code_attendu, motif in [
    (2100000, False, False, 0, '✅'),
    (2100000, True,  False, 0, '✅'),
    (3480000, False, False, 0, 'ZONE DE VIGILANCE'),
    (3480000, True,  False, 0, 'ZONE DE VIGILANCE'),
    (4200000, False, False, 0, 'SEUIL FRANCHI'),
    (4200000, True,  False, 1, 'SEUIL FRANCHI'),
    (0,       False, True,  0, 'NON vérifiée'),
    (0,       True,  True,  0, 'NON vérifiée'),
]:
    code, sortie = run(ko, strict, fail)
    lbl = f"{ko/1e6:.2f} Go{' --strict' if strict else ''}{' [gh HS]' if fail else ''}"
    assert code == code_attendu, f"{lbl}: code {code}, attendu {code_attendu}"
    assert motif in sortie, f"{lbl}: '{motif}' absent de la sortie"
    print(f"  ✅ {lbl:<26} code={code}  ({motif})")

# LE POINT QUI COMPTE : une panne de `gh` ne doit JAMAIS être confondue avec
# un dépassement de seuil (défaut corrigé en v9-v10 sur --strict de
# pipeline_status : avertissements normaux comptés comme échecs).
assert run(0, strict=True, fail=True)[0] == 0, \
    "gh indisponible sort non nul sous --strict : indisponibilité confondue avec dépassement"
print("  ✅ indisponibilité de gh découplée du dépassement de seuil")

import yaml
d = yaml.safe_load(open('.github/workflows/health_check.yml', encoding='utf-8'))
noms = [s.get('name') for s in d['jobs']['health']['steps']]
assert any('Sentinelle' in (n or '') for n in noms), f"étape absente : {noms}"
print(f"  ✅ health_check.yml : YAML valide, {len(noms)} étapes dont la sentinelle")
PYEOF
then
    echo "✅ tests d'exécution : tous passés"
else
    echo "❌ tests d'exécution : ÉCHEC (voir la trace ci-dessus)"
    ECHECS=$((ECHECS+1))
fi

echo
if [ "$ECHECS" -eq 0 ]; then
    echo "✅✅✅ TOUT EST EN PLACE (7 contrôles statiques + tests d'exécution). Sûr de committer."
    exit 0
else
    echo "❌❌❌ $ECHECS CONTRÔLE(S) EN ÉCHEC. NE PAS COMMITTER avant d'avoir compris pourquoi."
    exit 1
fi
