from pathlib import Path
r=Path(__file__).resolve().parent
p=r/'Tennis_Edge_Lab/research_v64.js';s=p.read_text()
if 'prospectiveData = null' not in s:
    s=s.replace('let data = null;', 'let data = null;\n  let prospectiveData = null;')
    s=s.replace('    const rules = (x.criteria || [])', '''    const p = prospectiveData?.selection_id === data?.selection_id ? prospectiveData.hypotheses?.[x.id] : null;
    const future = `<div class="v64-stats"><div><small>Paris depuis le gel</small><b>${p ? fmt(p.n) : 'En attente'}</b></div><div><small>ROI prospectif</small><b>${p ? pct(p.roi_pct) : 'En attente'}</b></div><div><small>CLV prospectif</small><b>${p ? pct(p.clv_mean_pct) : 'En attente'}</b><small>N CLV ${p ? fmt(p.clv_n) : '—'}</small></div></div>`;
    const rules = (x.criteria || [])''')
    s=s.replace('      <small>Découverte ${esc(x.historical_start)}','      ${future}\n      <small>Découverte ${esc(x.historical_start)}')
    s=s.replace('      data = x;', '''      data = x;
      try {
        const resp = await fetch('./live/prospective_v64.json?t=' + Date.now(), {cache:'no-store'});
        if (resp.ok) {
          const p = await resp.json();
          if (p.selection_id === x.selection_id && p.schema_version === 1) prospectiveData = p;
        }
      } catch (_) {}
''')
    p.write_text(s)
p=r/'.github/workflows/pages.yml';s=p.read_text()
if 'prospective_v64.py' not in s:
    s=s.replace('            Tennis_Edge_Lab/research_v64.js','            Tennis_Edge_Lab/research_v64.js\n            Tennis_Edge_Lab/prospective_v64.py\n            Tennis_Edge_Lab/bookmakers_sets_v5.py\n            Tennis_Edge_Lab/source_features.py\n            scripts/oddspapi_v5.py\n            parts')
    step='''      - name: Suivi V6.4 sur la base existante
        run: |
          if [ -s Tennis_Edge_Lab/live/economic_v64.json ] && [ -d parts ]; then
            python3 Tennis_Edge_Lab/prospective_v64.py || rm -f Tennis_Edge_Lab/live/prospective_v64.json
          fi

'''
    s=s.replace('      - name: Construire _site',step+'      - name: Construire _site')
    s=s.replace('          echo "--- contenu publié ---"','''          if [ -s Tennis_Edge_Lab/live/prospective_v64.json ]; then
            cp Tennis_Edge_Lab/live/prospective_v64.json _site/Tennis_Edge_Lab/live/prospective_v64.json
          fi
          echo "--- contenu publié ---"''')
    p.write_text(s)
print('Patch appliqué')
