# Watchdog collecteurs — 26/08/2026

## Diagnostic
capture_closing.yml a DEUX déclencheurs auto : repository_dispatch (Worker
Cloudflare) + cron GitHub natif horaire (filet de secours). kalshi_collector
et polymarket_collector n'ont QUE le repository_dispatch — sans filet.
Confirmé via logs : les deux collecteurs fonctionnent parfaitement en manuel
(push OK, gzip-append intact), donc le code n'est pas en cause — c'est
l'absence de mécanisme automatique de secours qui l'est.

## Décision : pas de cron GitHub supplémentaire
Rejeté explicitement (peu réactif, redondant avec un Worker qui fonctionne).
À la place : un WATCHDOG intégré à capture_closing, qui se déclenche déjà de
façon fiable. Il vérifie le champ last_run_at des deux fichiers d'état ; si
le retard dépasse 20 min (ou si l'état est illisible/absent), il relance le
workflow concerné via `gh workflow run` (API GitHub, permission actions:write
ajoutée à capture_closing.yml). Réaction à un signal réel, pas un calendrier.

## Comportement
- Étape `if: always()`, APRÈS le commit/push principal — ne bloque jamais
  la fonction première de capture_closing.
- `|| true` en sortie de step : un échec de relance ne fait jamais échouer
  le job (mais reste VISIBLE dans les logs, jamais avalé).
- Testé : retard réel (281/296 min sur les vraies données du 26/08) ->
  relance ; état frais -> rien ; état absent/illisible -> relance par
  prudence.

## Application (codespace, racine)
    unzip watchdog_v11.zip
    cp watchdog_v11/scripts/watchdog_collecteurs.py scripts/
    cp watchdog_v11/.github/workflows/capture_closing.yml .github/workflows/
    DRY_RUN=1 python scripts/watchdog_collecteurs.py   # doit lister les 2 collecteurs
    rm -rf watchdog_v11 watchdog_v11.zip
    git add scripts/watchdog_collecteurs.py .github/workflows/capture_closing.yml
    git commit -m "Watchdog : capture_closing relance Kalshi/Polymarket si en retard (pas de cron)"
    git pull --no-rebase --no-edit && git push

Effet dès le prochain run de capture_closing (cron horaire ou dispatch) :
si Kalshi/Polymarket n'ont pas écrit depuis 20 min, ils seront relancés
automatiquement — sans attendre le Worker.
